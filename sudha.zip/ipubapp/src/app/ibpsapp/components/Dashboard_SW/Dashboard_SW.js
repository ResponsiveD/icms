import React from 'react';
import Webix from '../../../../Webix';
import * as data from './Dashboard_SW_Data';
import './Dashboard_SW_style.css';
import { Loader } from '../../../../components/Core/iCore';
import { BookService } from '../../services';

export default class DashboardSW extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedButton: null,
      selectedData: null,
      openEmailPopup: false,
      openInfoPopup: false,
      dataCount: 0
    }

    this.onOpenEmialPopup = this.onOpenEmialPopup.bind(this);
    this.onOpenInfoPopup = this.onOpenInfoPopup.bind(this);
    this.onClosePopup = this.onClosePopup.bind(this);
    this.onSendToSubmit = this.onSendToSubmit.bind(this);
    this.refreshDasboard = this.refreshDasboard.bind(this);
    this.onRefreshDasboard = this.onRefreshDasboard.bind(this);
  }

  onOpenEmialPopup(button, data) {
    let { selectedButton, selectedData, openEmailPopup } = this.state;
    selectedButton = button;
    selectedData = data;
    openEmailPopup = true;
    this.setState({ selectedButton, selectedData, openEmailPopup });
  }

  onOpenInfoPopup(data) {
    let { openInfoPopup, selectedData } = this.state;
    openInfoPopup = true;
    selectedData = data;
    this.setState({ openInfoPopup, selectedData });
    window.$$('info_form').clear();
    window.$$('info_form').parse(selectedData);
  }

  hideForm(_this, formID) {
    // document.getElementById(_this).classList.add('hide');
    let { selectedButton, selectedData, openInfoPopup } = this.state;
    selectedData = null;
    selectedButton = null;
    openInfoPopup = false;
    document.querySelector('[view_id="iALink"] .fa-clone').classList.remove('copytext')
    document.querySelector('[view_id="UserEmailID"] .fa-clone').classList.remove('copytext')
    this.setState({ selectedButton, selectedData, openInfoPopup });
  }

  onSendToSubmit(email = null, selectedDataInt = null) {
    return new Promise((resolve, reject) => {
      try {
        let { selectedButton, selectedData, openEmailPopup, openInfoPopup } = this.state;
        if (selectedDataInt) {
          selectedData = selectedDataInt;
          this.setState({ selectedData: selectedDataInt });
        }

        let SubmitType = selectedData.AtyId == 64 && selectedButton == "Copyeditor" ? 2 : 3;
        let submit_input = {
          aty_id: selectedData.AtyId,
          SubmitType: SubmitType,
          // to_email : email,
          files: JSON.parse(selectedData.file_guids),
        }

        Loader.showLoader();
        if (selectedData.Int_btn && email == "Integra") {
          BookService.sendToSubmit(submit_input).then(result => {
            this.refreshDasboard().then(() => {
              window.webix.message({ text: "Sent successfully", type: "success" });
              Loader.hideLoader();
              resolve(true);
            }).catch(error => {
              this.onClosePopup();
              window.webix.message({ text: error, type: "error" });
              Loader.hideLoader();
            });
          }).catch(error => {
            this.onClosePopup();
            window.webix.message({ text: error.message, type: "error" });
            Loader.hideLoader();
          });
        } else {
          submit_input['to_email'] = email;
          BookService.sendToSubmit(submit_input).then(result => {
            openInfoPopup = true;
            this.refreshDasboard().then(() => {
              openEmailPopup = false;
              openInfoPopup = true;
              Loader.hideLoader();
              this.setState({ openEmailPopup, openInfoPopup });
              let info_data = {};
              info_data.UserEmailID = email;
              info_data.iALink = selectedData.iALink.split('=')[0] + '=' + result.docid;
              window.$$('info_form').clear();
              window.$$('info_form').parse(info_data);
              resolve(true);
            }).catch(error => {
              this.onClosePopup();
              window.webix.message({ text: error, type: "error" });
              Loader.hideLoader();
            });

            // let iAuthor_input = {}
            // iAuthor_input.doc_id = result.docid;
            // iAuthor_input.email = email;
            // iAuthor_input.twfd_id = result.twfd_id;
            // BookService.iAuthorUserUpdate(iAuthor_input).then(result1 => {
            //   this.refreshDasboard().then(() => {
            //     window.webix.message({ text: "Link generated successfully", type: "success" });
            //     Loader.hideLoader();
            //     openEmailPopup = false;
            //     openInfoPopup = true;
            //     this.setState({ openEmailPopup, openInfoPopup });
            //     let info_data = {};
            //     info_data.UserEmailID = email;
            //     info_data.iALink = selectedData.iALink.split('=')[0] + '=' + result.docid;
            //     window.$$('info_form').clear();
            //     window.$$('info_form').parse(info_data);
            //     resolve(true);
            //   }).catch(error => {
            //     this.onClosePopup();
            //     window.webix.message({ text: error, type: "error" });
            //     Loader.hideLoader();
            //   });
            // });
          });
        }
      }
      catch (ex) {
        resolve(false);
      }
    });
  }

  onClosePopup() {
    let { selectedButton, selectedData, openEmailPopup } = this.state;
    selectedData = null;
    selectedButton = null;
    openEmailPopup = false;
    this.setState({ selectedButton, selectedData, openEmailPopup });
  }

  componentDidMount() {
    Loader.showLoader();
    this.refreshDasboard().then(() => {
      Loader.hideLoader();
    }).catch(() => {
      Loader.hideLoader();
    });
  }

  onRefreshDasboard(_this, tag) {
    Loader.showLoader();
    this.refreshDasboard().then(() => {
      Loader.hideLoader();
    }).catch(error => {
      window.webix.message({ text: error, type: "error" });
      Loader.hideLoader();
    });
  }

  refreshDasboard() {
    let { dataCount } = this.state;
    return new Promise((resolve, reject) => {
      BookService.getDashboardBook().then(result => {
        window.$$('dashboard_details_sw').clearAll();
        window.$$('dashboard_details_sw').parse(result);
        dataCount = result.length;
        this.setState({ dataCount });
        resolve(true);
      }).catch(() => {
        resolve(false);
      });
    });
  }

  render() {
    let { selectedData, openEmailPopup, selectedButton, openInfoPopup, dataCount } = this.state;
    return (
      <div className="iopp-dashbord-page">
        <div className="dashboard-chart details-tables">
          <div className="iR-col-12 dashboard-chart-inner chart-height table_shrink">
            <div className="widget-dashboard">
              <div className="widget-dashboard-left">
                Job queue [{dataCount}]
                </div>
              <div className="refresh_btn dashboard_refesh_btn" onClick={this.onRefreshDasboard.bind(this, "refresh")}><i id="refresh" className="fa fa-refresh fa-spin file-process animate-stop" title="Refresh"></i> <span className="refresh_btn_text">Refresh</span></div>
            </div>
            <div className="dashboard_deatils">
              <Webix ui={data.dashboard_details(this.onOpenEmialPopup, this.onOpenInfoPopup, this.onSendToSubmit)}  ></Webix>
            </div>
            {
              openEmailPopup ?
                <div className="overflow-div" id="mail_popup_area">
                  <div className="pop_up_form mail_popup_area">
                    <div className="iR-window-header">
                      <h2>{"Send to " + selectedButton} </h2>
                      <i title="Close" className="material-icons view_cls" onClick={() => this.onClosePopup()} >clear</i>
                    </div>
                    <div className="widget_body">
                      <p>Please enter the email id to which the job has to be sent</p>
                      <Webix ui={data.Mail_input_form()}></Webix>
                    </div>
                    <div className="btn_fun">
                      <div className="common_btn">
                        <Webix ui={data.Mail_send_Button(this.onSendToSubmit)} ></Webix>
                      </div>
                    </div>
                  </div>
                </div> : null
            }
            {/* <div className="overflow-div" id="mail_popup_area_editor">
              <div className="pop_up_form mail_popup_area">
                <div className="iR-window-header">
                  <h2>Send to Copyeditor</h2>
                  <i title="Close" className="material-icons view_cls" onClick={this.hideForm.bind(this, "mail_popup_area_editor")} >clear</i>
                </div>
                <div className="widget_body">
                  <p>Please enter the email id to which the job has to be sent</p>
                  <Webix ui={data.Mail_input_form()}></Webix>
                </div>
                <div className="btn_fun">
                  <div className="common_btn">
                    <Webix ui={data.Mail_send_Button()} ></Webix>
                  </div>
                </div>
              </div>
            </div>
            <div className="overflow-div" id="mail_popup_area_integra">
              <div className="pop_up_form mail_popup_area">
                <div className="iR-window-header">
                  <h2>Send to Integra</h2>
                  <i title="Close" className="material-icons view_cls" onClick={this.hideForm.bind(this, "mail_popup_area_integra")} >clear</i>
                </div>
                <div className="widget_body">
                  <p>Please enter the email id to which the job has to be sent</p>
                  <Webix ui={data.Mail_input_form()}></Webix>
                </div>
                <div className="btn_fun">
                  <div className="common_btn">
                    <Webix ui={data.Mail_send_Button()} ></Webix>
                  </div>
                </div>
              </div>
            </div> */}
            {
              openInfoPopup ?
                <div className="overflow-div" id="info_popup_area">
                  <div className="pop_up_form mail_popup_area">
                    <div className="iR-window-header">
                      <h2>Info</h2>
                      <i title="Close" className="material-icons view_cls" onClick={this.hideForm.bind(this, "info_popup_area")} >clear</i>
                    </div>
                    <div className="widget_body">
                      <Webix ui={data.input_form_copy()}></Webix>
                    </div>
                  </div>
                </div> : null
            }
          </div>
        </div>
      </div>
    )
  }
}
/*1503 */