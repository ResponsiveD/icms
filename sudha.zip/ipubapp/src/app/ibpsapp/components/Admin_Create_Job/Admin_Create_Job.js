import React from 'react';
import Webix from '../../../../Webix';
import * as data from './Admin_Create_Job_Data';
import addmaterila from '../../../../assets/images/icons/add-material.png';
import { Loader } from '../../../../components/Core/iCore';
import { BookService } from '../../services';
import './Admin_Create_Job_style.css';

export default class AdminCreateJob extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      ser_id: 0,
      book_id: 0,
      wfd_id: 0,
      user_aty: [],
      file_GUID: [],
      all_chapter_sub_details: [],
      all_chapter_details: [],
      selected_chapter_file: null
    }

    this.onUploadChapter = this.onUploadChapter.bind(this);
    this.createBook = this.createBook.bind(this);
    this.onChapterFileDelete = this.onChapterFileDelete.bind(this);
    this.Create_job = this.Create_job.bind(this);
    this.onSupplementryFileUpload = this.onSupplementryFileUpload.bind(this);
    this.onSupplementryFileDelete = this.onSupplementryFileDelete.bind(this);
    this.validateMainFile = this.validateMainFile.bind(this);
    this.setBookid = this.setBookid.bind(this);
    this.setWf = this.setWf.bind(this);
    this.clearcontrolls = this.clearcontrolls.bind(this);
    this.onChapterFileSelect = this.onChapterFileSelect.bind(this);
  };

  showForm(_this, formID) {
    if (_this == 'add_book') {
      let { book_id } = this.state;
      document.querySelector('[view_id="add_book_name"]').classList.remove('hide');
      if (book_id != 0) {
        book_id = 0;
        window.$$("book_name").setValue("");
      }
      this.setState({ book_id });
      window.$$("add_book_name").focus();
    }
    else {
      document.getElementById(_this).classList.remove('hide');
    }
  }

  setBookid(id) {
    let { book_id } = this.state;
    book_id = id;
    if (book_id != 0) {
      window.$$("add_book_name").setValue("");
      document.querySelector('[view_id="add_book_name"]').classList.add('hide');
    }
    this.setState({ book_id })
  }

  setWf(wft, sr) {
    let { ser_id, wfd_id } = this.state;
    ser_id = sr;
    wfd_id = wft;
    this.setState({ ser_id, wfd_id });
  }

  onChapterFileSelect(chapter_file) {
    return new Promise((resolve, reject) => {
      if (chapter_file && chapter_file.file_Guid > 0) {
        let { all_chapter_sub_details } = this.state;
        this.setState({ selected_chapter_file: chapter_file });
        let arrayObject = all_chapter_sub_details.filter(item => item.file_id == chapter_file.id && item.is_active)
        window.$$("Upload_suple_form_list").clearAll();
        window.$$('Upload_suple_form_list').parse(arrayObject);
        resolve(true);
      }
      resolve(0);
    });
  }

  onChapterFileDelete(selectedFile) {
    return new Promise(async (resolve, reject) => {
      try {
        let { all_chapter_details, file_GUID } = this.state;
        Loader.showLoader();
        for (let ii = 0; ii < all_chapter_details.length; ii++) {
          if (all_chapter_details[ii].id == selectedFile.id) {
            all_chapter_details[ii].is_active = false;
            await BookService.add_chapter(all_chapter_details[ii]).then(response => {
                file_GUID = file_GUID.filter(ele => {
                  return ele.file_guid != all_chapter_details[ii].file_Guid;
                });
                resolve(true);
              }).catch(error => {
                Loader.hideLoader();
                window.webix.message({ text: error.message, type: "error" });
                resolve(false);
              })
          }
        }
        Loader.hideLoader();
        this.setState({ all_chapter_details, file_GUID });
        resolve(true);
      }
      catch (error) {
        resolve(false);
      }
    });
  };

  onSupplementryFileDelete(selectedFile) {
    return new Promise((resolve, reject) => {
      try {
        let { all_chapter_sub_details } = this.state;
        all_chapter_sub_details.forEach(item => {
          if (item.path == selectedFile.path) {
            item.is_active = false;
          }
        });
        this.setState({ all_chapter_sub_details });
        resolve(true);
      }
      catch (error) {
        resolve(false);
      }
    });
  };

  validateMainFile(chapter_name) {
    let chapter_main_count = 0
    if (chapter_name) {
      let { all_chapter_details } = this.state;
      if (all_chapter_details.length > 0) {
        chapter_main_count = all_chapter_details.filter(item => item.is_active && item.file_name == chapter_name).length;;
      }
    }
    return chapter_main_count;
  }

  createBook() {
    return new Promise((resolve, reject) => {
      let { book_id } = this.state;
      if (book_id == 0 && window.$$('add_book_name').getValue() == '') {
        window.webix.message({ text: 'Please Select Book', type: "error" });
        document.querySelector(".widget_up2").classList.remove('active_up');
      } else if (book_id == 0 && window.$$('add_book_name').getValue() != '') {
        let bookValue = window.$$('add_book_name').getValue();
        let bookObject = {};
        bookObject.book_name = bookValue;
        bookObject.cust_id = window.$$('customerList').getValue();
        bookObject.is_active = 1;
        bookObject.book_code = bookValue;
        bookObject.book_id = 0;
        Loader.showLoader();
        BookService.create_book(bookObject).then(res => {
          Loader.hideLoader();
          book_id = res;
          this.setState({ book_id });
          Loader.hideLoader();
        }).catch(error => {
          document.querySelector(".widget_up2").classList.remove('active_up');
          Loader.hideLoader();
          window.webix.message({ text: error.message, type: "error" });
          reject();
        });
      }
      resolve()
    });
  }

  onUploadChapter(file) {
    try {
      return new Promise((resolve, reject) => {
        let { book_id } = this.state;
        if (book_id == 0 && window.$$('add_book_name').getValue() == '') {
          window.webix.message({ text: 'Please Select Book', type: "error" });
        } else {
          this.uploadmainfile(file);
        }
      });
    } catch (e) {
      Loader.hideLoader();
      window.webix.message({ text: e, type: "error" });
    }
  }

  uploadmainfile(file) {
    return new Promise((resolve, reject) => {
      try {
        let { all_chapter_details, ser_id, wfd_id, book_id, file_GUID, all_chapter_sub_details } = this.state;
        let fileNameWOExt = file.name.slice(0, (file.name.lastIndexOf(".")));
        let fileNameWithExt = file.name;
        let chapter = {};

        chapter.book_id = book_id;
        chapter.file_name = fileNameWOExt;
        chapter.file_order = all_chapter_details.length + 1;
        chapter.ser_id = ser_id;
        chapter.file_type = 1;
        chapter.wfd_id = wfd_id;
        chapter.is_active = 1;
        Loader.showLoader();
        BookService.add_chapter(chapter).then(response => {
          //file_id
          let fileDetails = {};
          fileDetails.wfd_id = wfd_id;
          fileDetails.file = file.file;
          fileDetails.file_guid = response.file_guid;
          fileDetails.filename = fileNameWOExt;
          BookService.chapter_upload(fileDetails).then(FileResponse => {
            let file_Guid = { 'file_guid': response.file_guid }
            file_GUID.push(file_Guid);

            let chapter_main = {};
            chapter_main.file_name = fileNameWithExt;
            chapter_main.file_order = all_chapter_details.length + 1;
            chapter_main.path = FileResponse.path;
            chapter_main.book_id = book_id;
            chapter_main.is_main_file = 1;
            chapter_main.file_size = FileResponse.size;
            chapter_main.is_active = FileResponse.is_active;
            chapter_main.attach_id = response.file_id;
            chapter_main.id = response.file_id;
            chapter_main.file_Guid = response.file_guid;
            chapter_main.title = FileResponse.title;
            chapter_main.size = FileResponse.size;
            chapter_main.ser_id = ser_id;
            chapter_main.file_type = 1;
            chapter_main.wfd_id = wfd_id;
            chapter_main.docdate = FileResponse.doc_added;
            chapter_main.imgsrc = FileResponse.src;

            chapter_main.to_display = 1;
            all_chapter_details.push(chapter_main);

            window.$$("Upload_form_list").clearAll();
            window.$$('Upload_form_list').parse(all_chapter_details.filter(item => item.is_active && item.to_display));

            this.setState({ all_chapter_details });
            // window.webix.message({ text: 'Chapter uploaded successfully', type: "success" });
            Loader.hideLoader();
            resolve(chapter.file_order);
          }).catch(error => {
            window.webix.message({ text: error.message, type: "error" });
            reject(error.message);
            Loader.hideLoader();
          });
        }).catch(error => {
          window.webix.message({ text: error.message, type: "error" });
          reject(error.message);
          Loader.hideLoader();
        });
      } catch (error) {
        window.webix.message({ text: error.message, type: "error" });
        reject(error.message);
      }
    });
  }

  onSupplementryFileUpload(file) {
    return new Promise((resolve, reject) => {
      let { all_chapter_sub_details, selected_chapter_file, wfd_id } = this.state;
      let fileNameWOExt = file.name.slice(0, (file.name.lastIndexOf(".")));

      let fileDetails = {
        file_guid: selected_chapter_file.file_Guid,
        wfd_id: wfd_id,
        filename: fileNameWOExt,
        file: file.file
      };

      Loader.showLoader();
      BookService.supplementary_upload(fileDetails).then(FileResponse => {

        let chapter_sub = {};
        chapter_sub.file_name = fileNameWOExt;
        chapter_sub.file_id = selected_chapter_file.id;
        chapter_sub.is_main_file = 0;
        chapter_sub.file_size = FileResponse.size;
        chapter_sub.path = FileResponse.path;
        chapter_sub.is_active = FileResponse.is_active;
        chapter_sub.title = FileResponse.title;
        chapter_sub.size = FileResponse.size;
        chapter_sub.docdate = FileResponse.doc_added;
        chapter_sub.imgsrc = FileResponse.src;
        chapter_sub.attach_id = 0;
        chapter_sub.file_guid = selected_chapter_file.file_Guid;
        all_chapter_sub_details.push(chapter_sub);

        window.$$("Upload_suple_form_list").clearAll();
        window.$$('Upload_suple_form_list').parse(all_chapter_sub_details.filter(item => item.file_id == selected_chapter_file.id && item.is_active));
        window.webix.message({ text: 'Supplementary uploaded successfully', type: "success" });
        this.setState({ all_chapter_sub_details });
        Loader.hideLoader();
        resolve(true);
      }).catch(error => {
        window.webix.message({ text: error, type: "error" });
        Loader.hideLoader();
        reject(error);
      });
    });
  };

  hideForm(_this, formID) {
    document.getElementById(_this).classList.add('hide')
    this.clearcontrolls();
  }

  componentDidMount() {
    document.getElementById("create_job").classList.add('hide');
    document.querySelector('[view_id="journal_name"]').style.display = "none";
    document.querySelector('[view_id="add_book_name"]').classList.add('hide');

    Loader.showLoader();
    this.loadCustomer().then(() => { Loader.hideLoader(); }).catch(() => { Loader.hideLoader(); });
    this.loadFileType().then(() => { Loader.hideLoader(); }).catch(() => { Loader.hideLoader(); });

    Loader.showLoader();
    BookService.getJobDetails().then(result => {
      window.$$('job_table').clearAll();
      window.$$('job_table').parse(result);
      Loader.hideLoader();
    });

    var acc = document.getElementsByClassName("followup-header");
    var i;

    for (i = 0; i < acc.length; i++) {
      acc[i].addEventListener("click", function () {
        if (document.querySelector(".active_up")) {
          document.querySelector(".active_up").classList.remove('active_up');
        }
        this.parentElement.classList.toggle("active_up");
      });
    }
  }

  toggleWidget(_this, formID) {
    if (_this == 'file_upload_area') {
      document.querySelector(".widget_up").classList.remove('active_up');
      document.querySelector(".widget_up2").classList.remove('active_up');
      document.getElementById(_this).classList.add('active_up');
      this.createBook();
    } else if (_this == 'activity_info') {
      document.querySelector(".widget_up").classList.remove('active_up');
      document.querySelector(".widget_up2").classList.remove('active_up');
      document.getElementById(_this).classList.add('active_up');
    } else {
      document.querySelector(".widget_up").classList.remove('active_up');
      document.querySelector(".widget_up2").classList.remove('active_up');
    }
  }

  loadCustomer() {
    return new Promise((resolve, reject) => {
      BookService.getCustomer().then(res => {

        let OptionList = [];

        res.forEach(element => {
          OptionList.push({
            id: element.cust_id,
            value: element.cust_name
          });
        });
        let customerList = window.$$("customerList").getPopup().getList();
        customerList.parse(OptionList);

        resolve(true);
      }).catch(() => {
        resolve(false);
      });
    });
  }

  loadFileType() {
    return new Promise((resolve, reject) => {
      BookService.getfileType().then(res => {
        let OptionList = [];

        res.forEach(element => {
          OptionList.push({
            id: element.file_type,
            value: element.type_desc
          });
        });

        let customerList = window.$$("file_type").getPopup().getList();
        customerList.parse(OptionList);
        resolve(true);
      }).catch(() => {
        resolve(false);
      });
    });
  }

  clearcontrolls() {
    let { all_chapter_sub_details, all_chapter_details, selected_chapter_file, wfd_id, ser_id, book_id, user_aty, file_GUID } = this.state;
    ser_id = 0;
    book_id = 0;
    wfd_id = 0;
    user_aty = [];
    file_GUID = [];
    all_chapter_sub_details = [];
    all_chapter_details = [];
    selected_chapter_file = null;
    this.setState({ all_chapter_sub_details, all_chapter_details, selected_chapter_file, wfd_id, ser_id, book_id, user_aty, file_GUID });
    window.$$("_CreateJob").clear();
    window.$$("customerList").setValue("");
    window.$$("book_name").setValue("");
    window.$$("file_type").setValue("");
    window.$$("workflow").setValue("");
    document.querySelector('[view_id="add_book_name"]').classList.add('hide');
    window.$$("Upload_suple_form_list") ? window.$$("Upload_suple_form_list").clearAll() : null;
    window.$$("Upload_form_list") ? window.$$("Upload_form_list").clearAll() : null;
    document.querySelector(".widget_up").classList.remove('active_up');
    document.querySelector(".widget_up2").classList.remove('active_up');
    window.$$("activity_list").clearAll();
  }

  Create_job() {

    let { file_GUID, all_chapter_details, all_chapter_sub_details, ser_id, wfd_id } = this.state;
    var mainAttach = [];
    for (let ii = 0; ii < all_chapter_details.length; ii++) {
      let reqobjctAttach = {};
      let files = [];
      reqobjctAttach.file_id = all_chapter_details[ii].id;
      files.push(all_chapter_details[ii]);
      reqobjctAttach.files = files;
      mainAttach.push(BookService.add_file_attachments(reqobjctAttach));
    }

    //var subAttach = [];
    for (let jj = 0; jj < all_chapter_sub_details.length; jj++) {
      let reqobjctAttach = {};
      let files = [];
      reqobjctAttach.file_id = all_chapter_sub_details[jj].file_id;
      files.push(all_chapter_sub_details[jj]);
      reqobjctAttach.files = files;
      mainAttach.push(BookService.add_file_attachments(reqobjctAttach));
    }

    let user_aty = window.$$("activity_list").serialize()
    //let userActivity = [];
    for (let kk = 0; kk < user_aty.length; kk++) {
      if (user_aty[kk].title_two != "") {
        for (let pp = 0; pp < all_chapter_details.length; pp++) {
          let reqObject = {}
          reqObject.is_active = 1;
          reqObject.twfd_id = user_aty[kk].twfd_id;
          reqObject.file_id = all_chapter_details[pp].id;
          reqObject.Email_id = user_aty[kk].title_two;

          mainAttach.push(BookService.post_user_aty(reqObject));
        }
      }
    }

    let reqObjct = {};
    reqObjct.aty_id = 0;
    reqObjct.SubmitType = 3;
    reqObjct.files = file_GUID;
    return new Promise((resolve, reject) => {
      Loader.showLoader();
      Promise.all(mainAttach).then(async (allRes) => {
        BookService.submit_activity(reqObjct).then(res => {
          BookService.getJobDetails().then(result => {
            window.$$('job_table').clearAll();
            window.$$('job_table').parse(result);
            Loader.hideLoader();
          });
          window.webix.message({ text: 'Book submitted successfully', type: "success" });
          resolve(true);
        }).catch((error) => {
          Loader.hideLoader();
          window.webix.message({ text: error, type: "error" });
          reject(error);
        });
      }).catch(function (error) {
        window.webix.message({ text: error, type: "error" });
        Loader.hideLoader();
      });
    });
  }

  render() {
    let { selected_chapter_file } = this.state;
    return (

      <div className="Data-files-page admin_screen admin_create_job">
        <div className="widget">
          <div className="widget_header">Create Job</div>
        </div>

        <div className="admin_create_job_inner">
          <div className="admin_create_job_table"> <Webix ui={data.create_job_table()}></Webix></div>
          <div className="overflow-div" id="create_job">
            <div className="pop_up_form admin_create_job_popup">
              <div className="iR-window-header followup-head">
                <h2>Create Job</h2>
                <i title="Close" className="material-icons view_cls" onClick={this.hideForm.bind(this, "create_job")} >clear</i>
              </div>
              <div className="admin_create_job_popup_scroll">
                <div className="widget_body form_area">
                  <span className='add_book' title='Add Book Name' onClick={this.showForm.bind(this, "add_book")}><i className='material-icons'>add</i>Add</span>
                  <Webix ui={data.create_job_form(this.setBookid, this.setWf)}></Webix>
                </div>
                <div className="widget_up" id="activity_info" >
                  <div className="widget_header followup-header" onClick={this.toggleWidget.bind(this, "activity_info")}> Activity Info
                    <i className="fa fa-expand" title="Expand"></i><i className="fa fa-compress" title="collapse"></i>
                  </div>
                  <div className="widget_body expand-content">
                    <div className="widget activity_area">
                      <div className="activity_area_left">
                        <div className="widget_filter_header">
                          <div className="widget_lt_title"> Activity Name  </div>
                          <div className="widget_rt_title"> Email Id </div>
                        </div>
                        <div className="widget_body">
                          <Webix ui={data.Activity_list()}></Webix>
                        </div>
                      </div>
                      {/* <div className="activity_area_right">
                        <div className="widget_header"> Email Id </div>
                        <div className="widget_body">
                          <Webix ui={data.Email_list()}></Webix>
                        </div>
                      </div> */}
                    </div>
                  </div>
                </div>
                <div className="widget_up2" id="file_upload_area" >
                  <div className="widget_header followup-header" onClick={this.toggleWidget.bind(this, "file_upload_area")}> File Import
                    <i className="fa fa-expand" title="Expand"></i><i className="fa fa-compress" title="collapse"></i>
                  </div>
                  <div className="widget_body expand-content">
                    <div className="admin_create_job_upload">
                      <div className="widget">
                        <div className="widget_header"> MAIN  </div>
                        <div className="widget_body upload_hover" id="mail_upload_list">
                          <Webix ui={data.Upload_form_queue_one(this.onUploadChapter, this.validateMainFile)}></Webix>
                          <Webix ui={data.Upload_form_one_file_list(this.onChapterFileSelect, this.onChapterFileDelete)}></Webix>
                        </div>
                      </div>
                      {
                        selected_chapter_file ?
                          <div className="widget" id="supplement_area">
                            <div className="widget_header"> SUPPLEMENT   </div>
                            <div className="widget_body upload_hover" id="sup_upload_list">
                              <Webix ui={data.Upload_form_queue_two(this.onSupplementryFileUpload)}></Webix>
                              <Webix ui={data.Upload_form_two_file_list(this.onSupplementryFileDelete)}></Webix>
                            </div>
                          </div>
                          : null
                      }
                    </div>
                  </div>
                </div>

                {/* */}
              </div>

              <div className="btn_fun">
                <div className="common_btn">
                  <Webix ui={data.Create_job_Button(this.Create_job, this.clearcontrolls)} ></Webix>
                </div>
              </div>
            </div>
          </div>
          <button type="button" id="add_sel_approv" className="alt-btn app_btn iopp" title="Add Create Job" onClick={this.showForm.bind(this, "create_job")}><img src={addmaterila} alt="add to" /></button>
        </div>
      </div>
    )
  }
}
