import 'webix/webix.js';
import 'webix/webix.css';

import { CommonService, AuthorService } from '../../services';
import { Loader } from '../../../../components/Core/iCore';

var drag = `<i class="material-icons author_icon drag" title="Drag">more_vert</i> <i class="material-icons author_icon drag drag-left">more_vert</i>`;
var edit = `<i class="material-icons author_icon edit-icon" title="Edit">edit</i>`;
var deleter = `<i class="material-icons author_icon delete-icon" title="Delete">delete_outline</i>`;

let isAllowToFetchAuthorDetails = false;

export function CoAuthorCheckBox(onCoAuthorCheckBoxChange) {
	return {
		view: "form",
		elements: [
			{ view: "switch", id:"btn_switch",name:"noCoAuthors", labelRight:"No Co-Authors",click: function () {
				var switch_value=window.$$("btn_switch").getValue();
				if(switch_value =="1"){
					onCoAuthorCheckBoxChange(true);
				}
				else{
					onCoAuthorCheckBoxChange(false);
				}
			}
		},
   		]
	}
};

export function save_button(onAuthorsInstitutionsStepSave) {
	return {
	view: "toolbar", elements: [
		{
			//view:"button", type:"icon", icon:"reply", label:"Resubmit" ,tooltip:"Resubmit" ,click: function () {
		   
		  //}
		},
		{
			view:"button", type:"icon", icon:"floppy-o", label:"Save & Next" ,tooltip:"Save & Next" ,click: function () {
				onAuthorsInstitutionsStepSave();
				}
		}
	]
	}
};

//co-author list
export function Author_Table(onAuthorsInstitutionsDelete) {
	return {
		view: "datatable", id: "authorList",
		rowHeight: 80,
		drag:true,  fixedRowHeight:false, rowLineHeight:20,css:"author-tables2",
		columns: [
			{ id: "order", header: "Order", name: "order", width: 80, template: drag+'#order#' },
			{ id: "name", header: "Name", name: "name", width: 200,css: "auto_table", tooltip: "<div class='tooltip-style'>#name#</div>"},
			{ id: "dept_Inst_name", header: "Institution, Department", name: "dept_Inst_name", width: 300,css: "auto_table", tooltip: "<div class='tooltip-style'>#dept_Inst_name#</div>",  },
			{ id: "email", header: "Email", name: "email", width: 180,css: "auto_table", tooltip: "<div class='tooltip-style'>#email#</div>", },
			{ id: "Icons_Buttons", header: "Option", name: "option", width: 100,template: edit+deleter},

			{ id: "orc_id", header: "orc_id",  hidden: true },
			{ id: "sal_id", header: "sal_id",  hidden: true },
			{ id: "first_name", header: "first_name",  hidden: true },
			{ id: "middle_name", header: "middle_name",  hidden: true },
			{ id: "last_name", header: "last_name",  hidden: true },
			
			{ id: "institution_name", header: "institution_name",  hidden: true },
			{ id: "department", header: "department",  hidden: true },
			{ id: "role", header: "role",  hidden: true },
			{ id: "address_1", header: "Address_1",  hidden: true },
			{ id: "address_2", header: "Address_2",  hidden: true },
			{ id: "author_id", header: "author_id",  hidden: true },
			{ id: "city", header: "city",  hidden: true },
			{ id: "state", header: "state",  hidden: true },
			{ id: "country", header: "country",  hidden: true },
			{ id: "contact_no", header: "contact_no",  hidden: true },

			{ id: "article_author_id", header: "author_id",  hidden: true },

		],
		on:{
			"onresize":window.webix.once(function(){ 
				this.adjustRowHeight("dept_Inst_name", true); 
			}),
			"onAfterLoad": function () {
				this.filter(function(obj){
					return obj.is_active== true;
				});
			}
		},
		onClick: {
			"delete-icon": function (event, id, node) {
				var dtable = this;
				window.webix.confirm("Are you sure, to delete this?", function (action) {
					if (action === true) {
						onAuthorsInstitutionsDelete(window.webix.$$("authorList").getItem(id));
					}
				});
			},
			"edit-icon": function (e, id, node) {
				document.getElementById('iopp_alt_sh').classList.remove('hide');
				var dtable = this;
				var record = dtable.getItem(id.row);
				window.$$("generalInfoFormId").setValues(record);
				window.$$("institutuionInfoFormId").setValues(record);

				var currentElement = document.getElementById('iopp_alt_sh')
				var Point = e.target.getBoundingClientRect();
				var PointY, PointX;
				 if (window.innerHeight > Point.top + 500) {
					PointY = Point.top + 24;
					PointX = Point.left - 505 + 24;
				 } else {
					PointY = Point.top - 500;
					PointX = Point.left + 24 - 505;
				 }

				currentElement.style.left = PointX + 'px';
				currentElement.style.top = PointY + 'px';
				currentElement.style.position = 'fixed';
				//window.$$("genralinfo2").focus('orcidid');
				window.$$("Save").define("label", "Update");
				window.$$("Save").refresh();
			},
		},
		autoheight: true,
		scroll: false,
	}
};

//co-author general information
export function Genral_info(salutations) {
	return {
		view: "form", id: "generalInfoFormId",
		elements: [ 
			{ view: "text", label: "author_id", name: "author_id", id: "author_id", labelWidth: 200, type: "text", hidden: true },
			{ view: "text", label: "article_author_id", name: "article_author_id", id: "article_author_id", labelWidth: 200, type: "text", hidden: true },
			{
				view: "text", label: "ORCID <span class='error_v'>*</span>", name: "orc_id", labelWidth: 200, invalidMessage: "Invalid ORCID", type: "text", validateEvent: "blur",
				validate: function (value) {
					let regexp = /^[A-Za-z0-9-]*$/;
					if (value) {
						if (value.length < 151 && regexp.test(value)) {
							return true;
						}
					}
					else {
						return false;
					}
				},
			},
			{ view: "text", label: "Email <span class='error_v'>*</span>", name: "email", labelWidth: 200, invalidMessage: "Invalid Email", type: "email", validate: window.webix.rules.isEmail, attributes: { maxlength: 200 }, validateEvent: "blur",
				on: {
					onKeyPress: function () {
						window.isAllowToFetchAuthorDetails = true;
					},
					onChange: function () {
						if(window.isAllowToFetchAuthorDetails){
						window.isAllowToFetchAuthorDetails = false;
						let email=this.getValue();
						if (email && this.validate()) {
							let articleCoAuthors=window.$$("authorList").serialize();
							if(articleCoAuthors.find(a=>a.email==email)){
								window.webix.message({ text: "Co-author details already added.", type: "error" })
							}else{
								Loader.showLoader();
								AuthorService.getAuthorDetailByEmail(email).then(res => {
									if (res.length > 0) {
										let authorDetails = res[res.length - 1];
										window.$$("generalInfoFormId").setValues(authorDetails);
										window.$$("institutuionInfoFormId").setValues(authorDetails);
									} else {
										//window.$$("generalInfoFormId").clear();
										//window.$$("institutuionInfoFormId").clear();
									}
									Loader.hideLoader();
								}).catch(error => {
									window.webix.message({ text: error, type: "error" })
									//window.$$("generalInfoFormId").clear();
									//window.$$("institutuionInfoFormId").clear();
									Loader.hideLoader();
								});
							}
						}
					}
					},
				}
			},
			{
				view: "combo", id: "salutationId",
				label: "Sal. <span class='error_v'>*</span>",name: "sal_id", labelWidth: 200,validateEvent: "blur", invalidMessage: "Salutation should not be empty", 
				options:salutations,
				validate: window.webix.rules.isNotEmpty
			}, 
			{ view: "text", label: "First (Given) Name <span class='error_v'>*</span>", name: "first_name", labelWidth: 200, invalidMessage: "First Name should not be empty", type: "text", validate: window.webix.rules.isNotEmpty, attributes: { maxlength: 200 }, validateEvent: "blur" },
			{ view: "text", label: "Middle Name", name: "middle_name", labelWidth: 200, type: "text", attributes: { maxlength: 200 }, validateEvent: "blur" },
			{ view: "text", label: "Last (Family) Name", name: "last_name", labelWidth: 200, type: "text",attributes: { maxlength: 200 }, validateEvent: "blur" },
		]
	}
};

//co-author institutuion information
export function institutuion_info(countries) {
	return {
		view: "form", id: "institutuionInfoFormId",
		elements: [
			{ view: "text", label: "Institution Name <span class='error_v'>*</span>", name: "institution_name", labelWidth: 200, invalidMessage: "Institution Name should not be empty", type: "text", validate: window.webix.rules.isNotEmpty, attributes: { maxlength: 150 }, validateEvent: "blur" },
			{ view: "text", label: "Department <span class='error_v'>*</span>", name: "department", labelWidth: 200, invalidMessage: "Department should not be empty", type: "text", validate: window.webix.rules.isNotEmpty, attributes: { maxlength: 150 }, validateEvent: "blur" },
			{ view: "text", label: "Role <span class='error_v'>*</span>", name: "role", labelWidth: 200, invalidMessage: "Role should not be empty", type: "text", validate: window.webix.rules.isNotEmpty, attributes: { maxlength: 150 }, validateEvent: "blur" },
			{ view: "text", label: "Address 1 <span class='error_v'>*</span>", name: "address_1", labelWidth: 200, invalidMessage: "Address 1 should not be empty", type: "text", validate: window.webix.rules.isNotEmpty, attributes: { maxlength: 150 }, validateEvent: "blur" },
			{ view: "text", label: "Address 2", name: "address_2", labelWidth: 200,type: "text",attributes: { maxlength: 150 } },
			{ 
				view:"combo", id: "countryId",
				label: "Country <span class='error_v'>*</span>",name: "country", labelWidth: 200,validateEvent: "blur", invalidMessage: "Country should not be empty", 
				options:{
					body: {
						data: countries,
						scheme: {
							$init: obj => {
								obj.value = obj.Location,
									obj.id = obj.id
							}
						}
					}
				},
				on: {
					onChange: function (newv, oldv) {
						if (newv) {
							Loader.showLoader();
							CommonService.getStates(newv).then(response => {
								let institutuionInformation = window.$$("institutuionInfoFormId").getValues();
								if(!institutuionInformation.author_id){
									window.$$("stateId").setValue("");
									window.$$("cityId").setValue("");
								}
								let states = window.$$("stateId").getPopup().getList();
								states.clearAll();
								states.parse(response);
								
								let cities = window.$$("cityId").getPopup().getList();
								cities.clearAll();
								Loader.hideLoader();

								// let institutuionInformation = window.$$("institutuionInfoFormId").getValues();
								// if(institutuionInformation.state){
								// 	window.$$("stateId").setValue(institutuionInformation.state);
								// }
							}).catch(error => {
								window.webix.message({ text: error, type: "error" })
								Loader.hideLoader();
							});
						}
					}
				},
				validate: window.webix.rules.isNotEmpty
			},
			{ 
				view:"combo", id: "stateId",
				label: "State / Province <span class='error_v'>*</span>",name: "state", labelWidth: 200,validateEvent: "blur", invalidMessage: "State / Province should not be empty", 
				options:
					{
						body: {
							data: [],
							scheme: {
								$init: obj => {
									obj.value = obj.value,
										obj.id = obj.id
								}
							}
						}
					},
				on: {
					onChange: function (newv, oldv) {
						if (newv) {
							Loader.showLoader();
							CommonService.getCities(newv).then(response => {
								let institutuionInformation = window.$$("institutuionInfoFormId").getValues();
								if(!institutuionInformation.author_id){
									window.$$("cityId").setValue("");
								}
								
								let cities = window.$$("cityId").getPopup().getList();
								cities.clearAll();
								cities.parse(response);
								Loader.hideLoader();

								// let institutuionInformation = window.$$("institutuionInfoFormId").getValues();
								// if(institutuionInformation.city){
								// 	window.$$("cityId").setValue(institutuionInformation.city);
								// }
							}).catch(error => {
								window.webix.message({ text: error, type: "error" })
								Loader.hideLoader();
							});
						}
					}
				},
				validate: window.webix.rules.isNotEmpty
			},
			{ 
				view:"combo", id: "cityId",
				label: "City <span class='error_v'>*</span>",name: "city", labelWidth: 200,validateEvent: "blur", invalidMessage: "City should not be empty", 
				options:
					{
						body: {
							data: [],
							scheme: {
								$init: obj => {
									obj.value = obj.value,
										obj.id = obj.id
								}
							}
						}
					},
				on: {

				},
				validate: window.webix.rules.isNotEmpty
			},
			{
				view: "text", label: "Contact No.", name: "contact_no", labelWidth: 200, validateEvent: "blur", invalidMessage: "Invalid contact no.",
				type: "text", validate: function (val) {
					if (val) {
						return val.length == 12 ? true : false;
					} else {
						return true;
					}
				},
				pattern: { mask: '+############', allow: /[0-9]/g },
			},
		]
	}
};

 
 {/* co-author cancel add button */}
export function cancel_add_button(onAddEditCoAuthor) {
	return {
		view: "toolbar",
		width: 300,
		elements: [
			{
				view: "button", label: "Cancel", id: "Cancel", css: "ser-btn2", autowidth: true, click: function () {
					document.getElementById('iopp_alt_sh').classList.add('hide');
					window.$$("generalInfoFormId").clear();
					window.$$("generalInfoFormId").clearValidation();
					window.$$("institutuionInfoFormId").clear();
					window.$$("institutuionInfoFormId").clearValidation();
				}, tooltip: "Cancel"
			},
			{
				view: "button", label: "Add", id: "Save", type: "form", autowidth: true, tooltip: "Add",click: function() {

					let isGeneralInformationFormValidated = false;
					let isInstitutuionInfoFormationFormValidated = false;
					if (window.$$("generalInfoFormId").validate()) {
						isGeneralInformationFormValidated = true;
					}
					if (window.$$("institutuionInfoFormId").validate()) {
						isInstitutuionInfoFormationFormValidated = true;
					}
					if (isGeneralInformationFormValidated && isInstitutuionInfoFormationFormValidated) {
						let generalInformation = window.$$("generalInfoFormId").getValues();
						let institutuionInformation = window.$$("institutuionInfoFormId").getValues();
						let coAuthorDetails = {
							article_author_id: generalInformation.article_author_id,
							author_id: generalInformation.author_id,
							orc_id: generalInformation.orc_id,
							sal_id: generalInformation.sal_id,
							first_name: generalInformation.first_name,
							middle_name: generalInformation.middle_name,
							last_name: generalInformation.last_name,
							email: generalInformation.email,
							institution_name: institutuionInformation.institution_name,
							department: institutuionInformation.department,
							role:institutuionInformation.role,
							address_1:institutuionInformation.address_1,
							address_2:institutuionInformation.address_2,
							city:institutuionInformation.city,
							state:institutuionInformation.state,
							country:institutuionInformation.country,
							contact_no:institutuionInformation.contact_no,
							is_active: 1
						}
							
						Loader.showLoader();
						onAddEditCoAuthor(coAuthorDetails).then(response => {
							Loader.hideLoader();
							document.getElementById('iopp_alt_sh').classList.add('hide');
							window.$$("generalInfoFormId").clear();
							window.$$("generalInfoFormId").clearValidation();
							window.$$("institutuionInfoFormId").clear();
							window.$$("institutuionInfoFormId").clearValidation();
						}).catch(error => {
							Loader.hideLoader();
							window.webix.message({ text: error, type: "error" });
						});
					}
				}
			},
		]
	}
};
