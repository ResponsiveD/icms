import React from "react";
import Highcharts from "highcharts";
import Webix from "../../../../Webix";
import "./dashboard.css";
import "./Style_IOPP.css";
import * as data from "./Dashboard-data";
import { Loader } from "../../../../components/";
import { PublisherDashboardService, MetadataService } from "../../services";
import { LocalStorage } from "../../../../helpers";
let publisher_dashboard_articles = [],
unfilter_articles = [];

export default class Dashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      journalLists: [],
      selected_status: null,
      dataLength: 0,
    };
    this.getPublisherDashboard = this.getPublisherDashboard.bind(this);
    this.getJournalList = this.getJournalList.bind(this);
  }

  search_box_open() {
    //document.getElementById('search_box').classList.add('search-open');
    document.getElementById('search_box').classList.add('active');
    document.getElementById('search_box_icon').classList.add('hide');
    document.getElementById('clear_filter_button').classList.add('btn_fil');
    window.$$("search_fun").focus('search');
  }

  search_box_close() {
    //document.getElementById('search_box').classList.remove('search-open');
    document.getElementById('search_box').classList.remove('active');
    document.getElementById('search_box_icon').classList.remove('hide');
    document.getElementById('clear_filter_button').classList.remove('btn_fil');
  }

  filter_option() {
    document.getElementById('level0').classList.toggle('hide');
    document.getElementById('level1').classList.add('hide');
    document.getElementById('level2').classList.add('hide');
    document.getElementById('level3').classList.add('hide');
  }

  authorLink(selected_item) {
    let data = {};
    data.JobID = selected_item.ArticleGUID;
    data.ActivityId = selected_item.aty_id;
    let role = LocalStorage.getLocOrSesData('role');
    let roleName = typeof(role) == "object" ? role.join() : role;
    roleName == 'Publisher' ? data.RoleID = 10 : roleName == "Production Editor" ? data.RoleID = 20 : '';    
    data.userDetails = {
      "UserName": LocalStorage.getLocOrSesData('username'),
      "Email": LocalStorage.getLocOrSesData('emailid')
    };
    Loader.showLoader();
    PublisherDashboardService.getAuthorLink(data).then(response => {
      Loader.hideLoader();
      window.open(response);
    }).catch(error => {
      Loader.hideLoader();
      window.webix.message({
        text: error,
        type: "error"
      });
    });
  }

  componentDidMount() {
    this.getPublisherDashboard();
    this.getJournalList();

    document.getElementById('level0').classList.add('hide');
    document.getElementById('level1').classList.add('hide');
    document.getElementById('level2').classList.add('hide');
    document.getElementById('level3').classList.add('hide');

    document.addEventListener("click", function (e) {
      if (e.target.closest('#search_box')) {
      }
      else if (e.target.closest('#search_box_icon')) {

      }
      else {
        if(document.getElementById('search_box')!= null){
          document.getElementById('search_box').classList.remove('active');
          document.getElementById('search_box_icon').classList.remove('hide');
        }
      }
    });
  }

  getJournalList() {
    Loader.showLoader();
    MetadataService.getJournalType()
      .then(result => {
        Loader.hideLoader();
        this.setState({ journalLists: result });
      })
      .catch(error => {
        console.log(error);
      });
  }

  getPublisherDashboard() {
    Loader.showLoader();
    Highcharts.setOptions({
      colors: ["#F36B61", "#8BCB30"]
    });

    PublisherDashboardService.getPublisherDashboard()
      .then(result => {
        Loader.hideLoader();
        let categoriesData = [],
          onTrackCount = [],
          delayCount = [],
          onLoadTrackCount = [];
        result.count.forEach(element => {
          categoriesData.push(element.AtyName);
          onTrackCount.push(element.OnTrack);
          delayCount.push(element.Delay);
        });
        result.values.filter(value => {
          if (value.activity == "Manuscript submitted" && value.track_status == "OnTrack") {
            onLoadTrackCount.push(value);
            this.setState({ selected_status: "Manuscript submitted" });
            this.setState({ dataLength: onLoadTrackCount.length });
            window.publisher_dashboard_articles = onLoadTrackCount;
            window.unfilter_articles = onLoadTrackCount;
            window.$$("dashboard_details").parse(onLoadTrackCount);
            document.getElementById('clear_filter_button').classList.add('hide');
          }
        });
        // Chart Start
        Highcharts.chart("ioppdashboard", {
          chart: {
            type: "bar",
            // height: 500,
            // width: 1400
          },
          title: {
            text: "Queues data & actions",
            align: "left",
            fontSize: "14px",
            fontWeight: "bold",
            fontFamily: "Raleway"
          },
          xAxis: {
            categories: categoriesData,
            crosshair: true
          },
          yAxis: {
            allowDecimals:false,
            gridLineDashStyle: "longdash",
            min: 0,
            title: {
              text: ""
            },
            stackLabels: {
              enabled: true,
              style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
              }
            }
          },
          legend: {
            reversed: true,
            align: "right"
          },
          plotOptions: {
            series: {
              stacking: "normal",
              size: "24",
              cursor: "pointer"
            }
          },
          series: [
            {
              name: "Delay",
              pointWidth: 10,
              showInLegend: false,
              data: delayCount,
              cursor: "pointer",
              point: {
                events: {
                  click: (e) => {
                    let selected_status = e.point.category;
                    this.setState({ selected_status });
                    let showdata = result.values.filter(
                      obj => {
                        if (obj.track_status == "Delay") {
                          if (obj.activity == selected_status)
                            return true;
                        }
                      }
                    );
                    if (showdata.length != 0) {
                      this.setState({ dataLength: showdata.length });
                      window.$$("dashboard_details").clearAll();
                      window.publisher_dashboard_articles = showdata;
                      window.unfilter_articles = showdata;
                      window.$$("dashboard_details").parse(showdata);
                    } else {
                      window.webix.message({
                        text: "No data is available to display.",
                        type: "error"
                      });
                    }
                  }
                }
              }
            },
            {
              name: "On Track",
              pointWidth: 10,
              showInLegend: false,
              data: onTrackCount,
              cursor: "pointer",
              point: {
                events: {
                  click: (e) => {
                    let selected_status = e.point.category;
                    this.setState({ selected_status });
                    let showdata = result.values.filter(
                      obj => {
                        if (obj.track_status == "OnTrack") {
                          if (obj.activity == selected_status)
                            return true;
                        }
                      }
                    );
                    if (showdata.length != 0) {
                      this.setState({ dataLength: showdata.length });
                      window.$$("dashboard_details").clearAll();
                      window.publisher_dashboard_articles = showdata;
                      window.unfilter_articles = showdata;
                      window.$$("dashboard_details").parse(showdata);
                    } else {
                      window.webix.message({
                        text: "No data is available to display.",
                        type: "error"
                      });
                    }
                  }
                }
              }
            }
          ]
        });
        // Chart End
      })
      .catch(err => {
        Loader.hideLoader();
        if (!err.message.includes("Highcharts error")) {
          window.webix.message({
            text: err,
            type: "error"
          });
        }
      });
    document.addEventListener("click", function (event) {
      if (event.target.closest('#clear_filter_button')) {
        if (document.getElementById('clear_filter_button') != null) {
          window.webix.$$("dashboard_details").clearAll();
          window.webix.$$("dashboard_details").parse(window.unfilter_articles);
          document.getElementById('clear_filter_button').classList.add('hide');
        }
      } else if (event.target.closest('#filter_icon')) {
        document.getElementById('filter_overall').classList.remove('hide');
      } else if (!event.target.classList.contains('filter_main_over')) {
        if (document.getElementById('filter_overall') != null) {
          document.getElementById('filter_overall').classList.add('hide');
        }
      }
    });
  }

  render() {
    let { journalLists, selected_status, dataLength } = this.state;
    return (
      <div className="iopp-dashbord-page">
        <div className="dashboard-chart">
          <div className="iR-col-12 dashboard-chart-inner chart-area table_shrink no-padding-top-bottom">
            <div className="iopp chart_select select_right">
              <select>
                {journalLists.map(list => (
                  <option key={list.id} value={list.value}>
                    {list.value}
                  </option>
                ))}
              </select>
            </div>
            <div id="ioppdashboard" />
          </div>
        </div>

        <div className="dashboard-chart details-tables">
          <div className="iR-col-12 dashboard-chart-inner chart-height table_shrink">
            <div className="widget-dashboard">
              <div className="widget-dashboard-left">
               Overall Job Queue - {selected_status} [{dataLength}]
              </div>
              <div className="widget-dashboard-right">
                <div className="filter_search">
                  <div className="search-box2" id="search_box">
                    <Webix ui={data.dashboard_details_search()} />
                    <i
                      title="Close"
                      className="material-icons"
                      onClick={this.search_box_close.bind()}
                    >
                      close
                    </i>
                  </div>
                  <div className="filterallbtn" id="clear_filter_button" title="Clear Filter"> <i className="material-icons">close</i> Clear Filter</div>
                  <i
                    className="material-icons"
                    title="Search"
                    id="search_box_icon"
                    onClick={this.search_box_open.bind()}
                  >
                    search
                  </i>
                  <i className="material-icons" title="filter" id="filter_icon" onClick={this.filter_option.bind()}>filter_list</i>
                </div>
                <div id="filter_overall">
                  <div className="filter_option" id="level0"><Webix ui={data.dashboard_details_main()} ></Webix></div>
                  <div className="filter_option level1" id="level1"><Webix ui={data.dashboard_details_main2()} ></Webix></div>
                  <div className="filter_option level2" id="level2"><Webix ui={data.dashboard_details_main3()} ></Webix></div>
                  <div className="filter_option level3" id="level3"><Webix ui={data.dashboard_details_main4()} ></Webix></div>
                </div>
              </div>
            </div>
            <div className="iopp dashboard_deatils">
              <Webix ui={data.dashboard_details(this.authorLink)} />
            </div>
          </div>
        </div>
      </div>
    );
  }
}
