import React, { Component } from 'react'

export default function Alert(props) {
    
    function Close_Error_Alert() {
      document.getElementById('UploadLoader').classList.add('hide');
    };
    return (

        <div className="overlay_container" id="UploadLoader">
            {props.alertType=="success" ?
                <div className="alert-card sucess">
                    <div className="spinner"></div>
                    <div className="alert-message">
                        {/* <h2>Processing your file</h2> */}
                        <h2>{props.header}</h2>
                        {/* <p><span>3/14</span> Structuring the content...</p> */}
                        <p>{props.content}</p>
                    </div>
                </div>
                :
                <div className="alert-card error">
                    <i className="material-icons error_alert_close" title="Close" onClick={Close_Error_Alert}>clear</i>
                    <i className="material-icons">error_outline</i>
                    <div className="alert-message">
                        <h2>Error occured</h2>
                        <p><span onClick={()=>props.navigateToErrorlog()}>Click here</span> to view log</p>
                    </div>
                </div>
            }
           
        </div>

    )
}

