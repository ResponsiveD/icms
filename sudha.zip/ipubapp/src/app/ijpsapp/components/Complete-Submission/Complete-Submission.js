import React, { Component } from 'react';
import Webix from '../../../../Webix';
import * as Data from './Complete-Submission-Data';

import { ArticleService, MetadataService } from '../../services';

import { Loader } from '../../../../components/Core/iCore';
import Alert from '../Alert/Alert';

export default class CompleteSubmission extends Component {
  constructor(props) {
    super(props);
    this.state = {
      confirmationHtmlContent: [],
      articleConfirmation: [],
      confirmOne: false,
      confirmTwo: false,
      confirmThree: false,
      isAlertShow: false,
      alertType: null,
      alertMessage: {
        header: "",
        content: ""
      },
    };
    this.handleChange = this.handleChange.bind(this);
    this.onCompleteSubmissionStepSave = this.onCompleteSubmissionStepSave.bind(this);
  };

  componentDidMount() {
    let { articleDetails } = this.props;
    //Loader.showLoader();
    this.setState({ isAlertShow: true, alertType: "success", alertMessage: { header: "Loading Complete Submission", content: "Please wait..." } });
    let getConformationHtmlRes = ArticleService.getConformationHtml();
    let getArticleConformationRes = ArticleService.getArticleConformation(articleDetails.article_id);
    let base = this;
    Promise.all([getConformationHtmlRes, getArticleConformationRes]).then(function (allRes) {
      if (allRes[1].length === 3) {
        base.setState({ confirmationHtmlContent: allRes[0], articleConfirmation: allRes[1], confirmOne: true, confirmTwo: true, confirmThree: true });
      } else {
        base.setState({ confirmationHtmlContent: allRes[0] });
      }
      //Loader.hideLoader();
      base.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
    }).catch(function (error) {
      window.webix.message({ text: error, type: "error" });
      //Loader.hideLoader();
      this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
    });
  };

  handleChange(e, maxsize) {
    let { id, checked } = e.target;
    this.setState({ [id]: checked });
  };

  onCompleteSubmissionStepSave() {
    let { articleConfirmation, confirmOne, confirmTwo, confirmThree } = this.state;
    let { articleDetails } = this.props;

    return new Promise((resolve, reject) => {
      if (confirmOne && confirmTwo && confirmThree) {
        let conforms = [];
        if (articleConfirmation.length > 0) {
          for (let conform of articleConfirmation) {
            conforms.push({
              id: conform.id,
              confom_id: conform.conform_id,
              input: "",
              is_active: 1
            });
          }
        } else {
          for (let index = 0; index < 3; index++) {
            conforms.push({
              id: 0,
              confom_id: index + 1,
              input: "",
              is_active: 1
            });
          }
        }

        let confirmDetails = {
          article_id: articleDetails.article_id,
          org_id: 2,
          conforms: conforms
        }

        this.setState({ isAlertShow: true,  alertType: "success", alertMessage: { header: "Saving Complete Submission", content: "Please wait..." } });
        //save confirm details
        ArticleService.addEditArticleConfirmation(confirmDetails).then(addEditArticleConfirmationRes => {
          let finalSubmitData = { article_guid: articleDetails.article_guid, aty_id: 0, wfd_id: articleDetails.wfd_id };

          //Update Metadata in Iauthor
          MetadataService.updateMetadataToIAuthor(articleDetails.article_guid).then(updateMetadataRes => {

           //final Submit
           ArticleService.SubmitArticle(finalSubmitData).then(submitArticleRes => {
          //get job details
          ArticleService.getJobDetails(articleDetails.article_guid).then(getJobDetailsRes => {

            //initialize IAuthor
            ArticleService.initializeIAuthor(getJobDetailsRes).then(response => {

              this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
              resolve(getJobDetailsRes.oData?getJobDetailsRes.oData.jobdetails.JobGUID:'');
              }).catch(error => {
                this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
                reject(error);
              });

            }).catch(error => {
              this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
              reject(error);
            });
          }).catch(error => {
            this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
            reject(error);
          });
        }).catch(error => {
          this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
          reject(error);
        });
        }).catch(error => {
          this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
          reject(error);
        });
      } else {
        reject("Please read and confirm all.");
      }
    });
  };

  render() {
    let { confirmationHtmlContent, confirmOne, confirmTwo, confirmThree, isAlertShow, alertType, alertMessage } = this.state;
    return (

      <div className="Right-Panel Metadata">

        {/* header */}
        <div className="secondary-header">
          <div className="head-left">
            <span className="se-panel-title">Complete Submission</span>
            <div className="btn_fun">
              <div id="service_btn" className="common_btn icon_buttons completed_btns">
                <Webix ui={Data.save_button(this.onCompleteSubmissionStepSave)} ></Webix>
              </div>
            </div>
            {/* <Webix ui={Data.save_button(props.onCompleteSubmissionStepSave)} ></Webix> */}
            <i title="Close" className="material-icons close-btn-top">close</i>
          </div>
        </div>

        <div className="data-scroll file-upload-progress">
        {
          isAlertShow ? <Alert alertType={alertType} header={alertMessage.header} content={alertMessage.content} navigateToSteps={this.props.navigateToSteps} /> : null
        }

        {/* body */}
        <div className="widget">
          <div className="widget_header metadata-tag2">
            Confirm the following <span className='error_v'>*</span>
            </div>
          <div className="widget_body complete_sub_area">
            <label className="iopp-control iopp-control--checkbox">
              <input type="checkbox" id="confirmOne" checked={confirmOne} onChange={this.handleChange} />
              <div className="iopp-control__indicator"></div>
            </label>
            <p>{confirmationHtmlContent.length > 0 && confirmationHtmlContent[0].html_content}</p>
            <label className="iopp-control iopp-control--checkbox checkbox2">
              <input type="checkbox" id="confirmTwo" checked={confirmTwo} onChange={this.handleChange} />
              <div className="iopp-control__indicator"></div>
            </label>
            <p>{confirmationHtmlContent.length > 0 && confirmationHtmlContent[1].html_content}</p>
          </div>
        </div>

        <div className="widget">
          <div className="widget_header metadata-tag2">
            Copyright <span className='error_v'>*</span>
            </div>
          <div className="widget_body complete_sub_area">
            <label className="iopp-control iopp-control--checkbox">
              <input type="checkbox" id="confirmThree" checked={confirmThree} onChange={this.handleChange} />
              <div className="iopp-control__indicator"></div>
            </label>
            <p>{confirmationHtmlContent.length > 0 && (<span dangerouslySetInnerHTML={{ __html: confirmationHtmlContent[2].html_content }} />)}</p>
          </div>

        </div>
        <div className="widget">
          <div className="widget_header metadata-tag2">
            Note
            </div>
          <div className="widget_body">
            {/* <p className="note-cont">When you have clicked on 'Complete upload' you willbe taken to iAuthor to check that your manuscript has been correctly uploaded. Please review the manuscript and complete your submission. Thank You.<br/>
              <span className="complet-note">Please note: the upload of the manuscript can take some time while we process the content.</span> </p>
              */}
            <p className="complete_notes">{confirmationHtmlContent.length > 0 && confirmationHtmlContent[3].html_content} <br/><br/>
            <span className="complet-note">{confirmationHtmlContent.length > 0 && confirmationHtmlContent[4].html_content}</span> 
            </p>
           
          </div>
        </div>
      </div>
      </div>
    )
  }
};

