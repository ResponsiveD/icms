import React from 'react';
import Webix from '../../../../Webix';
import * as data from './Dashboard-author-data';
import addmaterila from '../../../../assets/images/icons/add-material.png';
import { Loader } from '../../../../components/';
import { AuthorDashboardService } from '../../services';
let author_dashboard_articles = [],
unfilter_articles = [];

export default class Dashboard_Author extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataLength: 0,
    };
    this.getAuthorDetails = this.getAuthorDetails.bind(this);
  }
  
  search_box_open() {
    // document.getElementById('search_box').classList.add('search-open');
    document.getElementById('search_box').classList.add('active');
    document.getElementById('search_box_icon').classList.add('hide');
    window.$$("dashboard_details_search").focus();
    document.getElementById('clear_filter_button').classList.add('btn_fil');
  }

  search_box_close() {
    // document.getElementById('search_box').classList.remove('search-open');
    document.getElementById('search_box').classList.remove('active');
    document.getElementById('search_box_icon').classList.remove('hide');
    document.getElementById('clear_filter_button').classList.remove('btn_fil');

  }
  filter_option() {
    document.getElementById('level0').classList.toggle('hide');
    document.getElementById('level1').classList.add('hide');
    document.getElementById('level2').classList.add('hide');
    document.getElementById('level3').classList.add('hide');
  }
  componentDidMount() {
    document.getElementById('level0').classList.add('hide');
    document.getElementById('level1').classList.add('hide');
    document.getElementById('level2').classList.add('hide');
    document.getElementById('level3').classList.add('hide');

    //   function findClosest (element, fn) {
    //     if (!element) return undefined;
    //     return fn(element) ? element : findClosest(element.parentElement, fn);
    //     }
    //       document.addEventListener("click", function(event) {
    //             var target = findClosest(event.target, function(el) {
    //                   return el.id == 'search_box'
    //             });
    //             var target = findClosest(event.target, function(el) {
    //                   return el.id == 'search_box_icon'
    //             });
    //             if (!target) {
    //               document.getElementById('search_box').classList.remove('active');
    //               document.getElementById('search_box_icon').classList.remove('hide');
    //             }
    //       }, false);

    //   document.getElementById('search_box').classList.remove('hide');
    document.addEventListener("click", function (e) {
      if (e.target.closest('#search_box')) {

      }
      else if (e.target.closest('#search_box_icon')) {

      }
      else {
        if(document.getElementById('search_box')!= null){
          document.getElementById('search_box').classList.remove('active');
          document.getElementById('search_box_icon').classList.remove('hide');
        }
      }

    });
    this.getAuthorDetails();

    document.addEventListener("click", function (event) {
      if (event.target.closest('#clear_filter_button')) {
        if (document.getElementById('clear_filter_button') != null) {
          window.webix.$$("dashboard_details").clearAll();
          window.webix.$$("dashboard_details").parse(window.unfilter_articles);
          document.getElementById('clear_filter_button').classList.add('hide');
        }
      } else if (event.target.closest('#filter_icon')) {
        document.getElementById('filter_overall').classList.remove('hide');
      } else if (!event.target.classList.contains('filter_main_over')) {
        if (document.getElementById('filter_overall') != null) {
          document.getElementById('filter_overall').classList.add('hide');
        }
      }
    });
  }

  getAuthorDetails() {
    Loader.showLoader();
    AuthorDashboardService.getAuthorDashboard().then(res => {
        Loader.hideLoader();
        window.author_dashboard_articles = res;
        window.unfilter_articles = res;
        window.webix.$$("dashboard_details").parse(res);
        this.setState({ dataLength: res.length });
        document.getElementById('clear_filter_button').classList.add('hide');
      });
      
  }

  render() {
    let { dataLength } = this.state;
    return (
      <div className="iopp-dashbord-page">
        <div className="dashboard-chart details-tables">
          <div className="iR-col-12 dashboard-chart-inner chart-height table_shrink">
            <div className="widget-dashboard">
              <div className="widget-dashboard-left">
               Overall Job Queue [{dataLength}]
                </div>
              <div className="widget-dashboard-right">
                <div className="filter_search">
                  <div className="search-box2" id="search_box">
                    <Webix ui={data.dashboard_details_search()} ></Webix>
                    <i title="Close" className="material-icons" onClick={this.search_box_close.bind()}>close</i>
                  </div>
                  <div className="filterallbtn" id="clear_filter_button" title="Clear Filter"> <i className="material-icons">close</i> Clear Filter</div>
                  <i className="material-icons" title="Search" id="search_box_icon" onClick={this.search_box_open.bind()}>search</i>
                  <i className="material-icons" title="filter" id="filter_icon" onClick={this.filter_option.bind()}>filter_list</i>
                </div>
                <div id="filter_overall" className="filter_overall">
                    <div className="filter_option" id="level0"><Webix ui={data.dashboard_details_main()} ></Webix></div>
                    <div className="filter_option level1" id="level1"><Webix ui={data.dashboard_details_main2()} ></Webix></div>
                    <div className="filter_option level2" id="level2"><Webix ui={data.dashboard_details_main3()} ></Webix></div>
                    <div className="filter_option level3" id="level3"><Webix ui={data.dashboard_details_main4()} ></Webix></div>
                </div>
              </div>
            </div>
            <div className="dashboard_deatils">
             <Webix ui={data.dashboard_details()}  ></Webix>
            </div>
          </div>
        </div>
        <div className="al-btn iopp-author-btn">
              <a href="#/SubmitManuscript" className="alt-btn app_btn" title="Submit Manuscript"><img src={addmaterila} alt="add to" /></a>
           </div>
      </div>
    )
  }
}
