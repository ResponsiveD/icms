import 'webix/webix.js';
import 'webix/webix.css';
// import { Loader } from '../../../../components/';
// import { AuthorDashboardService } from '../../services';

export function dashboard_details() {
	return {
		responsive: "true",
		view: "datatable",
		id: "dashboard_details",
		rowHeight: 40,
		tooltip: true,
		columns: [
			{
				id: "options",
				name: "options",
				header: "Options",
				css: "icon_styles",
				width: 100,
				tooltip: false
			},
			{
				id: "submissionId",
				name: "submissionId",
				header: "Submission ID",
				width: 125,
				sort: "int",
				css: "auto_table", tooltip: "<div class='tooltip-style'>#submissionId#</div>",
			},
			{
				id: "article_name",
				name: "article_name",
				header: "Article Name",
				// width: 200,
				minWidth: 80,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#article_name#</div>",
				fillspace: true
			},
			{
				id: "journal",
				name: "journal",
				header: "Journal",
				minWidth: 100,
				// width: 200,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#journal#</div>",
				fillspace: true
			},
			{
				id: "stage",
				name: "stage",
				header: "Stage",
				minWidth: 100,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#stage#</div>",
				fillspace: true
			},
			{
				id: "currentlyWith",
				name: "currentlyWith",
				header: "Currently With",
				width: 150,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#currentlyWith#</div>"
			},
			{
				id: "status",
				name: "status",
				header: "Status",
				width: 100,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#status#</div>",
				template: function (obj) {
					if (obj.track_status == "Delay") {
						if (status == true)
							return "<span class='details_check'>" + obj.status + "</span>";
						else return "<span class='details_uncheck'>" + obj.status + "</span>";
					} else return obj.status;
				}
			},
			{
				id: "dueDate",
				name: "dueDate",
				header: "Due Date",
				width: 125,
				sort: "string",
				css: "auto_table",
				css: "auto_table", tooltip: "<div class='tooltip-style'>#dueDate#</div>",
			},
			{
				id: "action",
				name: "action",
				header: "Action",
				minWidth: 180,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#action#</div>",
				fillspace: true
			},
		],

		data: [],
		// ready: function () {
		// 	Loader.showLoader();
		// 	AuthorDashboardService.getAuthorDashboard().then(res => {
		// 		Loader.hideLoader();
		// 		window.$$("dashboard_details").parse(res);
		// 	});
		// },
		scheme: {
			$init: function (obj) {
				obj.index = this.count();
			}
		},
		on: {
			onAfterLoad: function () {
				if (this.count() == 0) {
					this.showOverlay("No Records Found");
				} else {
					this.hideOverlay();
				}
			}
		},
		autoWidth: true,
		scroll: true,
		minHeight: 500,
	}
}

export function dashboard_details_search() {
	return {
		view: "form",
		id: "dashboard_details_search",
		elements: [{
			view: "search",
			align: "center",
			name: "search",
			placeholder: "Search..",
			id: "search",
			width: 300,
			height: 40,
			css: "search-dash-2",
			on: {
				onTimedKeyPress: function () {
					window.webix.$$("dashboard_details").clearAll();
					let searchKeyword = this.getValue().toLowerCase();
					let allArticles = window.author_dashboard_articles;
					let filteredArticles = []
					for (let article of allArticles) {
						let isTextPresent = false;
						for (let key in article) {
							let value = article[key];
							if (value) {
								if (typeof value == "string") {
									if (value.toLowerCase().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								} else {
									if (value.toString().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								}
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("dashboard_details").parse(filteredArticles);


					// var table = window.$$("dashboard_details");
					// var columns = table.config.columns;
					// table.filter(function (obj) {
					// 	for (var i = 0; i < columns.length; i++) {
					// 		// 	console.log(obj, 'OBJ');
					// 		console.log(columns[i].id, 'columns');
					// 		console.log(obj[columns[i].id].toString().toLowerCase().indexOf(text) != -1, 'Get Result');
					// 		if (obj[columns[i].id].toString().toLowerCase().indexOf(text) != -1) {
					// 			return true;
					// 		} else {
					// 			return false;
					// 		}
					// 	}
					// })
				}
			}
		}]
	}
}

export function dashboard_details_main() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main_over' title='#title#'>#title# <span><i class='material-icons filter-arrow'>navigate_next</i></span></div>",
		data: [
			{ id: 1, title: "Currently With" },
			{ id: 2, title: "Status" },
			{ id: 3, title: "Stage" },
		],
		on: {
			onItemClick: function (id, ev) {
				if (id == '1') {
					document.getElementById('level1').classList.remove('hide');
					document.getElementById('level2').classList.add('hide');
					document.getElementById('level3').classList.add('hide');
				}
				else if (id == '2') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.remove('hide');
					document.getElementById('level3').classList.add('hide');
				}
				else if (id == '3') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.add('hide');
					document.getElementById('level3').classList.remove('hide');
				}

			}
		}
	}
}
export function dashboard_details_main2() {
	return {
		view: "list",
		id: "dashboard_details_main2",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "Author" },
			{ id: 2, title: "Publisher" },
			{ id: 3, title: "Reviewer" },
			{ id: 4, title: "Production Editor"},
			{ id: 5, title: "Integra Production"}
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.author_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.currentlyWith.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level1').classList.add('hide');
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}
	}
}
export function dashboard_details_main3() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "In Progress" },
			{ id: 2, title: "Reviewer not assigned" },
			{ id: 3, title: "Awaiting response from reviewers" },
			{ id: 4, title: "No response - Invite more reviewers" },
			{ id: 5, title: "On time" },
			{ id: 6, title: "Overdue reviewer reports" },
			{ id: 7, title: "Overdue decision deadline" },
			{ id: 8, title: "Overdue revision deadline" },
			{ id: 9, title: "Overdue pre-publication checks" },
			{ id: 10, title: "Invitation" },
			{ id: 11, title: "In revision" },
			{ id: 12, title: "Completed" }
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.author_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.status.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level2').classList.add('hide');
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}

	}
}
export function dashboard_details_main4() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id:1, title: "Submission pending"},
			{ id:2, title: "Manuscript submitted"},
			{ id:3, title: "Out to reviewers"},
			{ id:4, title: "Awaiting reviewer report"},
			{ id:5, title: "Awaiting decision"},
			{ id:6, title: "In revision"},
			{ id:7, title: "Revision: manuscript submitted"},
			{ id:8, title: "Revision: Awaiting reviewer report"},
			{ id:9, title: "Revision: Awaiting decision"},
			{ id:10, title: "Revision: Out to reviewers"},
			{ id:11, title: "Send corrections to author"},
			{ id:12, title: "Layout Correction"},
			{ id:13, title: "Author final checks"},
			{ id:14, title: "Send for publication"}
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.author_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.stage.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level3').classList.add('hide');
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}

	}
}

/*25-12-2018*/