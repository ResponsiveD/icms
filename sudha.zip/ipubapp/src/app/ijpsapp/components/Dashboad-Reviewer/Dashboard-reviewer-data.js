import 'webix/webix.js';
import 'webix/webix.css';
import { Loader } from '../../../../components/';
import { ReviewerDashboardService } from '../../services';
import { CONFIG } from '../../../../helpers/config';
import { LocalStorage } from '../../../../helpers';
import moment from 'moment';

export function dashboard_details() {
	return {
		responsive: "true",
		view: "datatable",
		id: "dashboard_details",
		rowHeight: 40,
		tooltip: true,
		columns: [
			{
				id: "options",
				name: "options",
				header: "Options",
				css: "icon_styles",
				width: 125,
				tooltip: false
			},
			{
				id: "submissionId",
				name: "submissionId",
				header: "Submission ID",
				width: 125,
				sort: "int",
				css: "auto_table", tooltip: "<div class='tooltip-style'>#submissionId#</div>", 
			},
			{
				id: "article_name",
				name: "article_name",
				header: "Article Name",
				//width: 220,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#article_name#</div>",
				minWidth: 80,
				fillspace: true
			},
			{
				id: "journal",
				name: "journal",
				header: "Journal",
				//width: 240,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#journal#</div>",
				minWidth: 100,
				fillspace: true
			},
			{
				id: "stage",
				name: "stage",
				header: "Stage",
				//width: 210,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#stage#</div>",
				minWidth: 100,
				fillspace: true
			},
			{
				id: "currentlyWith",
				name: "currentlyWith",
				header: "Currently With",
				width: 150,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#currentlyWith#</div>",
			},
			{
				id: "status",
				name: "status",
				header: "Status",
				//width: 180,
				minWidth: 100,
				fillspace: true,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#status#</div>",
				template: function (obj) {
					if (obj.track_status == "Delay") {
						if (status == true)
							return "<span class='details_check'>" + obj.status + "</span>";
						else return "<span class='details_uncheck'>" + obj.status + "</span>";
					} else return obj.status;
				}
			},
			{
				id: "dueDate",
				name: "dueDate",
				header: "Due Date",
				width: 100,
				sort: "string",
				css: "auto_table", tooltip: "<div class='tooltip-style'>#dueDate#</div>", 
			},
			{
				id: "action",
				name: "action",
				header: "Action",
				minWidth: 180,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#action#</div>",
				fillspace: true
				// template: function (obj) {
				// 	console.log(obj, 'ICON');
				// 	if (obj.id == 1) {
				// 		if (status == true)
				// 			return "<span>" + obj.action + "</span>";
				// 		else return "<span>" + obj.action + " <span title='view abstract' class='bg-color-view'><i class='material-icons'>visibility</i></span></span>";
				// 	} else return "<span>" + obj.action + " <a href='#'title='Open in iAuthor' class='bg-color'>iA</a></span>";
				// }
			}
		],
		data: [],
		// ready: function () {
		// 	Loader.showLoader();
		// 	ReviewerDashboardService.getReviewerDashboard().then(res => {
		// 		Loader.hideLoader();
		// 		window.$$("dashboard_details").parse(res);
		// 	});
		// },
		onClick: {
			"bg-color-view": function (event, id, node) {
				document.getElementById('jobinfo-popup').classList.remove('hide');
			},
			// "pdf-download": function (event, id, node) {
			// 	console.log('AM PDF');
			// }
		},
		scheme:{
			$init:function(obj){ 
				obj.index = this.count(); 
			}
		},
		on: {
			onItemClick: function (id) {
				let item = this.getItem(id);
				window.$$("metadata").parse(item);
			},
			onAfterLoad: function () {
				if (this.count() == 0) {
					this.showOverlay("No Records Found");
				} else {
					this.hideOverlay();
				}
			}
		},
		// autoheight: true,
		// autowidth: true,
		// scroll: false,
		// //   minHeight: 450,
		//autoheight: true,
		autoWidth: true,
		scroll: true,
		minHeight: 500,
	}
};
export function dashboard_details_search() {
	return {
		view: "form",
		id: "search_fun",
		elements: [{
			view: "search",
			align: "center",
			name: "search",
			placeholder: "Search..",
			id: "search",
			width: 300,
			height: 40,
			css: "search-dash-2",
			on: {
				onTimedKeyPress: function () {
					window.webix.$$("dashboard_details").clearAll();
					let searchKeyword = this.getValue().toLowerCase();
					let allArticles = window.reviewer_dashboard_articles;
					let filteredArticles = []
					for (let article of allArticles) {
						let isTextPresent = false;
						for (let key in article) {
							let value = article[key];
							if (value) {
								if (typeof value == "string") {
									if (value.toLowerCase().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								} else {
									if (value.toString().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								}
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("dashboard_details").parse(filteredArticles);
					// var text = this.getValue().toLowerCase();
					// var table = window.$$("dashboard_details");
					// var columns = table.config.columns;
					// table.filter(function (obj) {
					// 	for (var i = 0; i < columns.length; i++) {
					// 		if (obj[columns[i].id].toString().toLowerCase().indexOf(text) !== -1) {
					// 			return true;
					// 		}  else {
					// 			return false;
					// 		}
					// 	}
							
					// })
				}
			}
		}]
	}
}

export function Metadata() {
	return {
		view: "form",
		id: "metadata",
		css:"job_popup",
		elements: [{
				view: "text",
				label: "Journal Name",
				name: "journal",
				labelWidth: 200,
				type: "text"
			},
			{
				view: "richtext",
				label: "Title",
				name: "title",
				labelWidth: 200,
				css:"metatitle",
				type: "text"
			},
			{
				view: "richtext",
				label: "Abstract",
				name: "abstract",
				css: "metatitle2",
				labelWidth: 200,
				type: "text"
			},
		]
	}
};

export function job_info_IOPP() {
	return {
		view: "toolbar",
		width: 600,
		id: 'job_info_IOPP',
		elements: [{
			view: "button",
			label: "Decline to review",
			autowidth: true,
			tooltip: "Decline to review",
			click: function () {
				let declineID = window.$$("metadata").$f;
				if (declineID.reject_id != 0) {
					Loader.showLoader();
					ReviewerDashboardService.reviewerInfo(declineID.reject_id).then(res => {
						Loader.hideLoader();
						document.getElementById('decline-notification-popup').classList.remove('hide');
						//	window.$$("accept_notif_IOPP").parse(res);
						let url = LocalStorage.getLocOrSesData("custid") == 5 ? "mailto:mrx@iop.org" : "mailto:support@integra.co.in";
						let htmlContent = `<p>
							Thank you for your valuable response.
							</p>
							<p class="notification-mail">Please contact our support team in case of any assistance</p>
							<p class="notification-mail">E-Mail to: <a href="${url}" target="_blank">mrx@iop.org</a></p>`;
						window.webix.$$("decline_notifaction").setHTML(htmlContent);
					}).catch(err => {
						window.webix.message({ text: err.message, type: "error" })
						Loader.hideLoader();
					});
					document.getElementById('jobinfo-popup').classList.add('hide');
					// document.getElementById('decline-notification-popup').classList.remove('hide');
				} else {
					window.webix.message({ text: "This link already used or Invalid Id", type: "error" })
					//	document.getElementById('jobinfo-popup').classList.add('hide');
				}
			},
		},
		{
			view: "button",
			label: "Accept to review",
			autowidth: true,
			tooltip: "Accept to review",
			type: "form",
			click: function () {
				let acceptID = window.$$("metadata").$f;
				if (acceptID.accept_id != 0) {
					Loader.showLoader();
					ReviewerDashboardService.reviewerInfo(acceptID.accept_id).then(res => {
						if(res.data.docid != undefined){
						
							let dueDate = moment(res.data.due_date).format("DD/MM/YYYY");
							Loader.hideLoader();
							document.getElementById('accept-notification-popup').classList.remove('hide');
							window.$$("accept_notif_IOPP").parse(res.data);
							let url = LocalStorage.getLocOrSesData("custid") == 5 ? "mailto:mrx@iop.org" : "mailto:support@integra.co.in";
							let htmlContent = `<p>
							Thank you for agreeing to review this article for Materials Research Express.
							Please complete your review by ${dueDate}. You will also receive an email with further details of how to proceed.
							</p>
							<p class="notification-mail">Please contact our support team in case of any assistance</p>
							<p class="notification-mail">E-Mail to: <a href="${url}">mrx@iop.org</a></p>`;
							window.webix.$$("accept_notifaction").setHTML(htmlContent);
						
						}else{
						
							Loader.hideLoader();
							document.getElementById('reviewer-notification-popup').classList.remove('hide');
							window.$$("reveiwer_notif_IOPP").parse(res.data);
							let url = LocalStorage.getLocOrSesData("custid") == 5 ? "mailto:mrx@iop.org" : "mailto:support@integra.co.in";
							let htmlContent = `<p> ${res.message} .</p>
							<p class="notification-mail">Please contact our support team in case of any assistance</p>
							<p class="notification-mail">E-Mail to: <a href="${url}">mrx@iop.org</a></p>`;
							window.webix.$$("reveiwer_notifaction").setHTML(htmlContent);
						
						}
				}).catch(err => {
						window.webix.message({ text: err.message, type: "error" })
						Loader.hideLoader();
					});
					document.getElementById('jobinfo-popup').classList.add('hide');
					// document.getElementById('accept-notification-popup').classList.remove('hide');
				} else {
					window.webix.message({ text: "This link already used or Invalid Id", type: "error" })
					//	document.getElementById('jobinfo-popup').classList.add('hide');
				}
			}
		}]
	}
}

export function accept_notif_IOPP(getReviewerDetails) {
	return {
		view: "toolbar",
		width: 600,
		id: "accept_notif_IOPP",
		elements: [{
				view: "button",
				label: "Start Review",
				autowidth: true,
				tooltip: "Start Review",
				click: function () {
					let docID = window.$$("accept_notif_IOPP").$f.docid;
					let url = CONFIG.iAuthor_Base_URL + docID;
					window.open(url);
					document.getElementById('accept-notification-popup').classList.add('hide');
					window.webix.$$("dashboard_details").clearAll();
					getReviewerDetails();
				}
			},
			{
				view: "button",
				label: "Close",
				autowidth: true,
				tooltip: "Close",
				type: "form",
				css: "close-btn",
				click: function () {
					document.getElementById('accept-notification-popup').classList.add('hide');
					window.webix.$$("dashboard_details").clearAll();
					getReviewerDetails();
				}
			}
		],
	}
}

export function reveiwer_notif_IOPP(getReviewerDetails) {
	return {
		view: "toolbar",
		width: 600,
		id: "reveiwer_notif_IOPP",
		elements: [
			{
				view: "button",
				label: "Close",
				autowidth: true,
				tooltip: "Close",
				type: "form",
				css: "close-btn",
				click: function () {
					document.getElementById('reviewer-notification-popup').classList.add('hide');
					window.webix.$$("dashboard_details").clearAll();
					getReviewerDetails();
				}
			}
		],
	}
}

export function decline_notif_IOPP(getReviewerDetails) {
	return {
		view: "toolbar",
		width: 600,
		id: "decline_notif_IOPP",
		elements: [
			{
				view: "button",
				label: "Close",
				autowidth: true,
				tooltip: "Close",
				type: "form",
				css: "close-btn",
				click: function () {
					document.getElementById('decline-notification-popup').classList.add('hide');
					window.webix.$$("dashboard_details").clearAll();
					getReviewerDetails();
				}
			}
		]
	}
}

export function accept_notifaction(date) {
	return {
		view: "template",
		css: "notification-template",
		id: "accept_notifaction",
	// 	template: `<p>
	// 	Thank you for agreeing to review this article for Materials Research Express.
	// 	Please complete your review by ${date}. You will also receive an email width further details of how to proceed.
	//   </p>
	//   <p class="notification-mail">Please contact our support team in case of any assistance</p>
	//   <p class="notification-mail">Mail to: <a href="#">mrx.iop.org</a></p>`
	}
}

export function reveiwer_notifaction(date) {
	return {
		view: "template",
		css: "notification-template",
		id: "reveiwer_notifaction",
	// 	template: `<p>
	// 	Thank you for agreeing to review this article for Materials Research Express.
	// 	Please complete your review by ${date}. You will also receive an email width further details of how to proceed.
	//   </p>
	//   <p class="notification-mail">Please contact our support team in case of any assistance</p>
	//   <p class="notification-mail">Mail to: <a href="#">mrx.iop.org</a></p>`
	}
}

export function decline_notifaction() {
	return {
		view: "template",
		css: "notification-template",
		id: "decline_notifaction",
	// 	template: `<p>
	// 	Thank you for your valueable response.
	//   </p>
	//   <p class="notification-mail">Please contact our support team in case of any assistance</p>
	//   <p class="notification-mail">Mail to: <a href="http://mrx.iop.org" target="_blank">mrx.iop.org</a></p>`
	}
}

export function dashboard_details_main() {
	return {
		view: "list",
		scroll: false,
		select:  true,
		template: "<div class='filter_main_over' title='#title#'>#title# <span><i class='material-icons filter-arrow'>navigate_next</i></span></div>",
		data: [
			{ id:1, title: "Currently With"},
			{ id:2, title: "Status"},
			{ id:3, title: "Stage"},
		],
		on: {
			onItemClick: function (id, ev) {
				if (id == '1') {
					document.getElementById('level1').classList.remove('hide');
					document.getElementById('level2').classList.add('hide');
					document.getElementById('level3').classList.add('hide');
				}
				else if (id == '2') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.remove('hide');
					document.getElementById('level3').classList.add('hide');
				}
				else if (id == '3') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.add('hide');
					document.getElementById('level3').classList.remove('hide');
				}

			}
		}

	}
}

export function dashboard_details_main1() {
	return {
		view: "list",
		id:"dashboard_details_main2",
		scroll: false,
		select:  true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id:1, title: "Author"},
			{ id:2, title: "Publisher"},
			{ id:3, title: "Reviewer"},
			{ id: 4, title: "Production Editor"},
			{ id: 5, title: "Integra Production"}
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.reviewer_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						let value = article.currentlyWith.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level1').classList.add('hide');	
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}
	}
}

export function dashboard_details_main2() {
	return {
		view: "list",
		scroll: false,
		select:  true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "In Progress" },
			{ id: 2, title: "Reviewer not assigned" },
			{ id: 3, title: "Awaiting response from reviewers" },
			{ id: 4, title: "No response - Invite more reviewers" },
			{ id: 5, title: "On time" },
			{ id: 6, title: "Overdue reviewer reports" },
			{ id: 7, title: "Overdue decision deadline" },
			{ id: 8, title: "Overdue revision deadline" },
			{ id: 9, title: "Overdue pre-publication checks" },
			{ id: 10, title: "Invitation" },
			{ id: 11, title: "In revision" },
			{ id: 12, title: "Completed" }
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.reviewer_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.status.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level2').classList.add('hide');	
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}

	}
}

export function dashboard_details_main3() {
	return {
		view: "list",
		scroll: false,
		select:  true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id:1, title: "Submission pending"},
			{ id:2, title: "Manuscript submitted"},
			{ id:3, title: "Out to reviewers"},
			{ id:4, title: "Awaiting reviewer report"},
			{ id:5, title: "Awaiting decision"},
			{ id:6, title: "In revision"},
			{ id:7, title: "Revision: manuscript submitted"},
			{ id:8, title: "Revision: Awaiting reviewer report"},
			{ id:9, title: "Revision: Awaiting decision"},
			{ id:10, title: "Revision: Out to reviewers"},
			{ id:11, title: "Send corrections to author"},
			{ id:12, title: "Layout Correction"},
			{ id:13, title: "Author final checks"},
			{ id:14, title: "Send for publication"},
			{ id:15, title: "Processing Manuscript file"},
			{ id:16, title: "Update Metadata"},
			{ id:17, title: "Error Reordering references"}
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.reviewer_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.stage.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level3').classList.add('hide');	
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}

	}
}
