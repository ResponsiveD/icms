import { API, CONFIG, LocalStorage } from './helpers/index';
import { authenticationService } from './services/index';
import moment from 'moment';
import { Loader } from './components/Core/iCore';
export function Global_Search() {
	return {
		view: "search", align: "center", placeholder: "Search..", id: "iR_glob_search", width: 250,

		on: {
			onTimedKeyPress: function () {
				document.querySelector('.Search_suggestion').style.display = 'block';
				var value = this.getValue().toLowerCase();
				window.$$("Sugguest_List").filter(function (obj) { //here it filters data!
					window.$$('Sugguest_List').show();
					//	window.$$('iR_glob_search').clearAll();
					return obj.project_title.toLowerCase().indexOf(value) != -1;
				
				})
			},
		},		
	}
}


export function Global_Search_List() {
	return {

		view: "list",
		scroll: true,
		id: "Sugguest_List",
		width: 250,
		height: 300,
		template: "<div class='sug_list_item'>#project_title#</div>",
		// data: [
		// 	{ id: 1, title: "SERVICE FULFILLMENT"},
		// 	{ id: 2, title: "BTech_DIT_Comp 1 AFA"},
		// 	{ id: 3, title: "BE_Comp 1 AHA"},
		// 	{ id: 4, title: "BTech_DIT_Comp 1 AKA"},
		// 	{ id: 5, title: "BE_DIT_Comp 1 ALA"},
		// 	{ id: 6, title: "BTech_DIT_Comp 1 ALA"},
		// 	{ id: 7, title: "BTech_DIT_Comp 1 AMA"},
		// 	{ id: 8, title: "BEech_DIT_Comp 1 AJA"},
		//     { id: 9, title: "Integra Searchable "},
		//     { id: 10, title: "SERVICE FULFILLMENT"},
		//     { id: 11, title: "Video Collection"},
		//     { id: 12, title: "BTech_DIT_Comp 1 AJA"},
		//     { id: 13, title: "BTech_DIT_Comp 1 AJA"},
		//     { id: 14, title: "BTech_DIT_Comp 1 AJA"},
		//     { id: 15, title: "BTech_DIT_Comp 1 AJA"}
		// ]

		data: [],
		autoheight: true,
		ready: function () {
			let user_id = LocalStorage.getLocOrSesData("uid");
			API.getTokenAPI(CONFIG.WIP_List, { user_id: user_id }, "").then(result => {
				if (result) {
					let jsonData = JSON.parse(result);
					window.$$("Sugguest_List").parse(jsonData.data);
				}
				window.$$("Sugguest_List").attachEvent("onItemClick", function (id, e, node) {
					let item = window.$$("Sugguest_List").getItem(id);
					//	var item = this.getItem(id);
					API.getTokenAPI(CONFIG.Get_Project_Details, { project_id: item.project_id }, "").then(result => {
						var current_page = LocalStorage.getLocOrSesData("current_page");
						let jsonData = JSON.parse(result);
						if (current_page == 'PL') {
							window.$$("project_details").clear();
							jsonData.data.receipt_date=new Date(jsonData.data.receipt_date);
							window.$$("project_details").parse(jsonData.data);
							jsonData.data.receipt_date = new Date(jsonData.data.receipt_date);
							jsonData.data.permission_due_date = new Date(jsonData.data.permission_due_date);
							jsonData.data.hires_due_date = new Date(jsonData.data.hires_due_date);
							jsonData.data.file_to_print_date = new Date(jsonData.data.file_to_print_date);
							jsonData.data.closing_date = new Date(jsonData.data.closing_date);
							jsonData.data.publication_date = new Date(jsonData.data.publication_date);
							let services_due_date = jsonData.data.services;
							for (let index = 0; index < services_due_date.length; index++) {
								const element = services_due_date[index];
								services_due_date[index].due_date = new Date(services_due_date[index].due_date);
							}

							window.$$("customer_details").parse(jsonData.data);
							window.$$("duedate").parse(jsonData.data);
							window.$$("services").clearAll();
							let services_details = jsonData.data.services;
							for (let i = 0; i < services_details.length; i++) {
								var final_details = services_details[i];
								services_details[i].attachments = services_details[i].attachments;
								//services_details[i].no_of_attachments = services_details[i].attachments.length + " Attachments";
							}
							window.$$("services").parse(jsonData.data.services);
							window.$$("budget").clear();
							window.$$("budget").parse(jsonData.data);
							window.$$("select_approver").clearAll();
							window.$$("select_approver").parse(jsonData.data.customer_access);
							window.$$("comments").parse(jsonData.data);
							window.$$("downloads").clearAll();
							window.$$("downloads").parse(jsonData.data.project_files);
							//	downloads_details=jsonData.data.project_files;
						}
						// let attachement_details = jsonData.data.project_files;
						// if (attachement_details.length >= 1) {
						// 	var i;
						// 	for (i = 0; i < attachement_details.length; i++) {
						// 		var final_attch_details = attachement_details[i];
						// 		window.$$("_Upload_form").parse(final_attch_details.file_name);
						// 	}
						// }

						else {
							if (jsonData.data.status_id == 4) {
								window.$$('save_button').disable();
							}
							else {
								window.$$('save_button').enable();
							}
							//if (current_page == "CP")
							window.$$("_CreateProject").clear();
							jsonData.data.receipt_date=new Date(jsonData.data.receipt_date);
							window.$$("_CreateProject").parse(jsonData.data);
							window.$$("project_lead_id").hide();
							window.$$("project_lead_name").show();
							window.$$("_customerdetails").parse(jsonData.data);
							jsonData.data.receipt_date = new Date(jsonData.data.receipt_date);
							jsonData.data.permission_due_date = new Date(jsonData.data.permission_due_date);
							jsonData.data.hires_due_date = new Date(jsonData.data.hires_due_date);
							jsonData.data.file_to_print_date = new Date(jsonData.data.file_to_print_date);
							jsonData.data.closing_date = new Date(jsonData.data.closing_date);
							jsonData.data.publication_date = new Date(jsonData.data.publication_date);
							let services_due_date = jsonData.data.services;
							for (let index = 0; index < services_due_date.length; index++) {
								const element = services_due_date[index];
								services_due_date[index].due_date = new Date(services_due_date[index].due_date);
							}
							jsonData.data.due_date = new Date(jsonData.data.due_date);

							window.$$("_DueDate").parse(jsonData.data);
							window.$$("_Create_budget").clear();
							window.$$("_Create_budget").parse(jsonData.data);
							window.$$("_comments").parse(jsonData.data);



							for (let s of jsonData.data.services) {
								s.attachment_names = s.attachments.length + " Attachments";
							}
							window.$$("_Select_Services").clearAll();
							window.$$("_Select_Services").parse(jsonData.data.services);
							window.$$("_Select_Approver").parse(jsonData.data.customer_access);
							window.$$("project_downloads").clearAll();
							window.$$("project_downloads").parse(jsonData.data.project_files);
						}

					});
				});
				window.$$("Sugguest_List").attachEvent("onItemClick", function (id, e, node) {
					var selected_item = node.innerText;
					window.$$('iR_glob_search').setValue(selected_item);
					window.$$('Sugguest_List').hide();

					//window.$$('iR_glob_search').clearAll();
					//window.$$('Sugguest_List').show();
				});
			});

		}
	};
}

export function _change_password() {
    return {
        view: "form",id:"_Login",
        elements: [
            { view: "text", id:"old_pass", type: "password", label: "Old Password",labelWidth: 200, name: "oldpassword", validateEvent:"blur", validate: window.webix.rules.isNotEmpty, invalidMessage: "Old Password should not be empty" },
            { view: "text", id:"new_pass", type: "password", label: "New Password",labelWidth: 200, name: "newpassword", validateEvent:"blur", validate: window.webix.rules.isNotEmpty, invalidMessage: "New Password should not be empty", attributes: { maxlength: 24 }},
            { view: "text", id:"confirm_pass", type: "password", label: "Confirm Password",labelWidth: 200, name: "confirmpassword", validateEvent:"blur", validate: window.webix.rules.isNotEmpty, invalidMessage: "Confirm Password should not be empty"},
        ],       
        elementsConfig: {
            on: {
				onBlur(){ this.validate()}
            }
        }
    };
}

export function _change_btn() {
    return {
    	view: "toolbar",
    	width: 300,
    	id: 'forgot_action',
    	elements: [{
    			view: "button",
    			label: "Close",
    			autowidth: true,
    			tooltip: "Close",
    			click: function () {
    				window.$$('_Login').clear();
    				document.getElementById('change_password').classList.add('hide');
    			}
    		},
    		{
    			view: "button",
    			label: "Submit",
    			autowidth: true,
    			tooltip: "Submit",
    			type: "form",
    			click: function () {
    				let old_pass = window.$$("old_pass").getValue();
    				let new_pass = window.$$("new_pass").getValue();
    				let confirm_pass = window.$$("confirm_pass").getValue();
    				if (window.$$('_Login').validate()) {
    					// if (old_pass.trim() !== '' && new_pass.trim() !== '' && confirm_pass.trim() !== '') {
    						if (old_pass.trim() !== new_pass.trim()) {
    							if (new_pass.trim() === confirm_pass.trim()) {
    								var Check1 = new_pass.match(/^((?=.*?[A-Z])(?=.*?[a-z])(?=.*?\d)|(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[^a-zA-Z0-9])|(?=.*?[A-Z])(?=.*?\d)(?=.*?[^a-zA-Z0-9])|(?=.*?[a-z])(?=.*?\d)(?=.*?[^a-zA-Z0-9])).{8,100}$/g);
    								var Check2 = new_pass.match(/.*[£€¤¥].*/g);
    								if (Check1 != null && Check2 == null) {
    									Loader.showLoader();
    									authenticationService.changePassword(old_pass, new_pass).then(response => {
    										Loader.hideLoader();
    										window.$$('_Login').clear();
    										document.getElementById('change_password').classList.add('hide');
    										window.webix.message({
    											text: response,
    											type: "success"
    										});
    									}).catch(error => {
    										Loader.hideLoader();
    										window.webix.message({
    											text: error,
    											type: "error"
    										});
    									});
    								} else {
										window.$$("new_pass").setValue('');
    									window.$$("confirm_pass").setValue('');
    									window.webix.message({
    										text: "Password must have minimum 8 character with atleast one alphabet, one number and one symbol.",
    										type: "error"
    									});
    								}
    							} else {
    								// window.$$("new_pass").setValue('');
    								window.$$("confirm_pass").setValue('');
    								window.webix.message({
    									text: "New Password and Confirm Password are not matching correctly, Please re-enter the password.",
    									type: "error"
    								});
    							}
    						} else {
								window.$$("new_pass").setValue('');
								window.$$("confirm_pass").setValue('');
    							window.webix.message({
    								text: "System does not allow to enter the existing password as new password.",
    								type: "error"
    							});
    						}
    					// } else {
    					// 	window.webix.message({
    					// 		text: "Password does not match",
    					// 		type: "error"
    					// 	});
    					// }
    				}
    			}
    		}
    	]
    }
}

export function _change_password_IOPP() {
    return {
        view: "form",id:"_Login",
        elements: [
            { view: "text", id:"old_pass", type: "password", label: "Old Password",labelWidth: 200, name: "oldpassword", validateEvent:"blur", validate: window.webix.rules.isNotEmpty, invalidMessage: "Old Password should not be empty" },
            { view: "text", id:"new_pass", type: "password", label: "New Password",labelWidth: 200, name: "newpassword", validateEvent:"blur", validate: window.webix.rules.isNotEmpty, invalidMessage: "New Password should not be empty", attributes: { maxlength: 24 }},
            { view: "text", id:"confirm_pass", type: "password", label: "Confirm Password",labelWidth: 200, name: "confirmpassword", validateEvent:"blur", validate: window.webix.rules.isNotEmpty, invalidMessage: "Confirm Password should not be empty"},
        ],       
        
    };
}


export function _change_btn_IOPP() {
    return {
        view: "toolbar",
        width: 300,
        id:'forgot_action_iopp',
        elements: [
            { view: "button", label: "Close", autowidth: true, tooltip:"Close", click: function(){
				document.getElementById('iopp_change_password').classList.add('hide');
			}},
            { view: "button", label: "Submit", autowidth: true, tooltip:"Submit", type: "form", click: function(){

			}
		}]
    }
}