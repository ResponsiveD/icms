"use strict";
const app = require("./config/lib/app");
const CronJob = require("cron").CronJob;
const getReminderMailController = require("./app/component/ijps/controllers/reminder_mail.controller");
const getReviewerController = require("./app/component/ijps/controllers/reviewer.controller")

// 0 */1 * * * * - runs every min, 0 0 0 * * * (or) 00 00 12 * * 0-6 - runs midnight at 12AM
const job = new CronJob("0 0 0 * * *", () => {
  getReminderMailController.getReminderMailDetails();
  getReviewerController.get_reviewer_incompletedRecord();
  getReviewerController.get_Authorfinalchecks_incompletedRecord();
});
job.start();
app.start();
