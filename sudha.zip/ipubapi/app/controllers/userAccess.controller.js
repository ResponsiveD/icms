const user_access_repo = require("../repository/userAccess.service");
const output = require("../models/Output");
const exception_repo = require("../middleware/exception/exception");
const HttpStatus = require('http-status-codes')

exports.get_user_access = async function (req, res, next) {
  var _output = new output();
  let error = null;
  try {
    let result = await user_access_repo.get_user_access(req);
    _output.data = result;
    _output.is_success = true;
    _output.message = req.query.appname + " log details.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.addedit_user_access_dtl = async function (req, res, next) {
  var _output = new output(); let error = null;
  try {
    let jsondata = [];
    jsondata.UserID = req.User.UserID;
    jsondata.OrgID = req.User.OrgID;
    jsondata.CompID = req.body.CompID;
    jsondata.CustID = req.body.CustID;
    jsondata.AppName = req.body.AppName;
    jsondata.Endpoint = req.body.Endpoint;
    jsondata.Error = req.body.Error;
    jsondata.Method = req.body.Method;
    jsondata.Req = req.body.Req;
    jsondata.Res = req.body.Res;
    jsondata.Status = req.body.Status;
    let result = await user_access_repo.addedit_user_access_dtl(jsondata);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Log Updated.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};