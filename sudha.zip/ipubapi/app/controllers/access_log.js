const access_log = require('../repository/access_log');
const output = require("../component/irights/models/output");
const exception_repo = require("../middleware/exception/exception");
const HttpStatus = require('http-status-codes');


exports.usersystemaccesslog = async function (req, res, next) {
	var _output = new output();
	let error = null;
	try {
		let data = req.body;
		data.Status = data.Status == undefined ? null : data.Status;
		data.Page = data.Page == undefined ? 1 : data.Page;
		data.Limit = data.Limit == undefined ? 50 : data.Limit;
		let result = await access_log.usersystemaccesslog(data);
		_output.data = result;
		_output.is_success = true;
		_output.message = 'User System Access log details get Successfullly';
		req.User.endTime = new Date();
		exception_repo.exception_DB_log(req, _output, error, 1);
	} catch (error) {
		_output.data = '';
		_output.is_success = false;
		_output.message = error.message;
		req.User.endTime = new Date();
		exception_repo.exception_DB_log(req, _output, error, 0);
	}
	res.send(_output);
};
exports.userapiaccesslog = async function (req, res, next) {
	var _output = new output();
	let error = null;
	try {
		let data = req.body;
		data.Status = data.Status == undefined ? null : data.Status;
		data.Page = data.Page == undefined ? 1 : data.Page;
		data.Limit = data.Limit == undefined ? 50 : data.Limit;
		let result = await access_log.userapiaccesslog(data);
		_output.data = result;
		_output.is_success = true;
		_output.message = 'User API Access log details get Successfullly';
		req.User.endTime = new Date();
		exception_repo.exception_DB_log(req, _output, error, 1);
	} catch (error) {
		_output.data = '';
		_output.is_success = false;
		_output.message = error.message;
		req.User.endTime = new Date();
		exception_repo.exception_DB_log(req, _output, error, 0);
	}
	res.send(_output);
};

exports.getcolumns = async function (req, res, next) {
	var _output = new output();
	let error = null;
	try {
		let Tablename = req.body.tablename;
		let result = await access_log.getcolumns(Tablename);
		_output.data = result;
		_output.is_success = true;
		_output.message = 'Successfully get the column names from table ' + Tablename;
		req.User.endTime = new Date();
		exception_repo.exception_DB_log(req, _output, error, 1);
	} catch (error) {
		_output.data = '';
		_output.is_success = false;
		_output.message = error.message;
		req.User.endTime = new Date();
		exception_repo.exception_DB_log(req, _output, error, 0);
	}
	res.send(_output);
};

exports.insertmastertables = async function (req, res, next) {
	var _output = new output();
	let error = null;
	try {
		let req_body = req.body;
		let JsonData = JSON.stringify(req_body);
		let result = await access_log.insertmastertables(JsonData);
		_output.data = result;
		_output.is_success = true;
		_output.message = 'Successfully insert the data in master table ';
		req.User.endTime = new Date();
		exception_repo.exception_DB_log(req, _output, error, 1);
	} catch (error) {
		_output.data = '';
		_output.is_success = false;
		_output.message = error.message;
		req.User.endTime = new Date();
		exception_repo.exception_DB_log(req, _output, error, 0);
	}
	res.send(_output);
};
