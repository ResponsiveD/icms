const automation_repository = require("../repository/automation.service");
const output = require("../models/output");
const common = require("../helpers/common")
const exception_repo = require("../middleware/exception/exception");
const HttpStatus = require('http-status-codes');

exports.get_automation_list = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        let result = await automation_repository.get_automation_list();
        _output.data = result;
        _output.is_success = true;
        _output.message = "Automation Details";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }

}


exports.get_automation_file_path = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        req.User ? null : req.User = {};
        let data = await common.getTokenUserDetail(req, data);
        if (data.Id == undefined || data.Id == '') {
            throw {
                "message": "Id must be provided."
            }
        } else {
            let result = await automation_repository.get_automation_file_path();
            _output.data = result;
            _output.is_success = true;
            _output.message = "Automation Details";
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.ok).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }

}

exports.add_automation_entry = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        let data = await common.getTokenUserDetail(req, data);
        if (data.automation_id == undefined || data.automation_id == 0) {
            throw {
                message: 'automation_id must be provided.'
            }
        }
        if (data.file_name == undefined || data.file_name == '') {
            throw {
                message: 'file_name must be provided.'
            }
        }
        if (data.in_path == undefined || data.in_path == 0) {
            throw {
                message: 'in_path must be provided'
            }
        }
        if (data.out_path == undefined || data.out_path == '') {
            throw {
                message: 'out_path must be provided'
            }
        } else {
            let result = await automation_repository.add_automation_entry(data);
            _output.data = result;
            _output.is_success = true;
            _output.message = "Automation entry updated";
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}



exports.get_automation_list = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        req.User ? null : req.User = {};
        let result = await automation_repository.get_automation_list();
        _output.data = result;
        _output.is_success = true;
        _output.message = "Automation Details";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.get_automation_file = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        req.User ? null : req.User = {};
        let automation_id = req.body.automation_id
        let result = await automation_repository.get_automation_file(automation_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Automation Details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.lock_automation_file = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        req.User ? null : req.User = {};
        let id = req.body.id
        let engine = req.body.engine
        let result = await automation_repository.lock_automation_file(id, engine);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Automation Details";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}



exports.update_automation_status = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        req.User ? null : req.User = {};
        let id = req.body.id
        let engine = req.body.engine
        let remark = req.body.remark
        let status = req.body.status
        let automationId = req.body.automation_id
        let ijps_automation_controller = require("../component/ijps/controllers/automation.controller");
        const article_service = require("../component/ijps/Service/article.service");
        //let result = await automation_repository.update_automation_status(id, engine, remark, status);
        req.body.article_guid = await article_service.get_article_guid_for_automation_id(id)
        var checkSubmitNeed = {};
        var checkSubmitNeed = await article_service.checkToMoveNextActivity(req.body)
        if (status == 4 && automationId == 1) {
            await ijps_automation_controller.get_metadata_from_iAuthor(req, res, next);
            let result = await automation_repository.update_automation_status(id, engine, remark, status);
            if (checkSubmitNeed.need_submit > 0) {
                req.body.SubmitType = 3;
                req.body.user_id = checkSubmitNeed.user_id;
                req.body.org_id = checkSubmitNeed.org_id;
                var article_controller = require("../component/ijps/controllers/article.controller");
                req.body.aty_id = checkSubmitNeed.current_aty;
                await article_controller.submitActivity(req);
            } else {
                _output.data = result;
                _output.is_success = true;
                _output.message = "Automation Details";
                res.send(_output);
            }
        } else {
            let result = await automation_repository.update_automation_status(id, engine, remark, status);
            if (status == 5) {
                try {
                    await automation_repository.alert_automation_failure(id, checkSubmitNeed.user_id, checkSubmitNeed.org_id, remark);
                } catch (error) { }
            }
            _output.data = result;
            _output.is_success = true;
            _output.message = "Automation Details";
            if (checkSubmitNeed.need_submit > 0) {
                req.body.SubmitType = 7;
                req.body.aty_id = checkSubmitNeed.current_aty;
                req.body.user_id = checkSubmitNeed.user_id;
                req.body.org_id = checkSubmitNeed.org_id;
                var article_controller = require("../component/ijps/controllers/article.controller");
                await article_controller.submitActivity(req);
            }
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}