"use strict";
const activity_stream_service = require("../repository/activityStream.service");
const file_upload_config = require("../../config/file_upload_config");
const basepath = file_upload_config.CloudCredentials().cloudBasePath;
const common = require("../helpers/common");
const output = require("../models/output");
const exception_repo = require("../middleware/exception/exception");
const HttpStatus = require('http-status-codes');

exports.download_files_from_blob = async function (req, res, next) {
  var _output = new output();
  let error = null;
  try {
    let data = req.body;
    let FileuploadedPath = '';
    if (data.cust_id == undefined || data.cust_id == "") {
      throw {
        message: "Customer ID must be provided."
      }
    } else if (data.type == undefined || data.type == "") {
      throw {
        message: "Type must be provided."
      }
    } else if (data.article_guid == undefined || data.article_guid == "") {
      throw {
        message: "Article GUID must be provided."
      }
    } else if (data.aty_id == undefined || data.aty_id == "") {
      throw {
        message: "Activity ID must be provided."
      }
    }
    let result = await activity_stream_service.download_files_from_blob(data);
    let pathURL = result.recordsets[0][0].pathURL;
    let jobguid = result.recordsets[1][0].jobguid;
    let filename = result.recordsets[1][0].filename;
    let blobFiles = await common.ListAllFilesPath(pathURL);
    if (blobFiles && blobFiles.length > 0) {
      let uniqueFolder = common.guid();
      let in_path = 'downloadzip/' + jobguid + '/' + uniqueFolder + '/' + data.article_guid + '/' + data.aty_id + '/' + filename + '.zip';
      FileuploadedPath = await activity_stream_service.add_blob_to_zip_with_path(blobFiles, in_path);
      _output.data = basepath + FileuploadedPath;
      _output.is_success = true;
      _output.message = 'File exists in blob.';
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    } else {
      _output.is_success = false;
      _output.message = 'Error in downloading the file, Please contact administrator.';
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 0);
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.upload_files_to_blob = async function (req, res, next) {
  var _output = new output();
  let error = null;
  try {
    let data = {}
    data = req.body;
    let UploadFile = req.files ? req.files.files : null;
    if (data.cust_id == undefined || data.cust_id == "") {
      throw {
        message: "Customer ID must be provided."
      }
    } else if (data.extn_type == undefined || data.extn_type == "") {
      throw {
        message: "ExtnType must be provided."
      }
    } else if (data.article_guid == undefined || data.article_guid == "") {
      throw {
        message: "Article GUID must be provided."
      }
    } else if (data.aty_id == undefined || data.aty_id == "") {
      throw {
        message: "Activity ID must be provided."
      }
    } else if (UploadFile == undefined || UploadFile == null) {
      throw {
        message: "File must be provided."
      }
    }
    data = await common.getTokenUserDetail(req, data);
    let UploadPath = await activity_stream_service.upload_files_to_blob(data);
    if (UploadPath.recordsets[0].length < 1 || UploadPath.recordsets[0][0].isExists === false) {
      throw {
        message: "Path configuration error contact admin."
      }
    }
    await common.blobFileUpload(UploadFile, UploadPath.recordsets[0][0].pathURL).then((result) => {
      _output.data = result;
      _output.is_success = true;
      _output.message = 'File uploaded successfully.';
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    }).catch((error) => {
      _output.data = "";
      _output.is_success = false;
      _output.message = 'Error in Uploading file, contact admin.';
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 0);
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    });
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_all_customer = async function (req, res, next) {
  var _output = new output;
  let error = null;
  try {
    let data = req.query;
    if (data.comp_id == undefined || data.comp_id == "") {
      throw {
        message: "Comp ID must be provided."
      }
    }
    let result = await activity_stream_service.get_all_customer(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Get all customer.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_all_journal = async function (req, res, next) {
  var _output = new output;
  let error = null;
  try {
    let data = req.query;
    if (data.cust_id == undefined || data.cust_id == "") {
      throw {
        message: "Cust ID must be provided."
      }
    }
    let result = await activity_stream_service.get_all_journal(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Get all journal.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_all_book = async function (req, res, next) {
  var _output = new output;
  let error = null;
  try {
    let data = req.query;
    if (data.cust_id == undefined || data.cust_id == "") {
      throw {
        message: "Cust ID must be provided."
      }
    }
    let result = await activity_stream_service.get_all_book(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Get all book.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_all_article = async function (req, res, next) {
  var _output = new output;
  let error = null;
  try {
    let data = req.query;
    if (data.type == "" && data.type == undefined) {
      throw {
        message: "Type must be provided."
      }
    }
    if (data.journal_id == "" && data.book_id == "" || data.journal_id == undefined && data.book_id == undefined) {
      throw {
        message: "Journal ID or Book ID must be provided."
      }
    }
    let result = await activity_stream_service.get_all_article(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Get all article.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_all_activity = async function (req, res, next) {
  var _output = new output;
  let error = null;
  try {
    let data = req.query;
    if (data.cust_id == "" && data.cust_id == undefined) {
      throw {
        message: "Customer ID must be provided."
      }
    }
    let result = await activity_stream_service.get_all_activity(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Get all activity.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_dashboard_data_stream = async function (req, res, next) {
  var _output = new output;
  let error = null;
  try {
    let data = req.body;
    if (data.cust_id == "" && data.cust_id == undefined) {
      throw {
        message: "CustID must be provided."
      }
    } else if (data.comp_id == "" && data.comp_id == undefined) {
      throw {
        message: "CompID must be provided."
      }
    } else if (data.type == "" && data.type == undefined) {
      throw {
        message: "Type must be provided."
      }
    } else if (data.journal_id == "" && data.book_id == "" || data.journal_id == undefined && data.book_id == undefined) {
      throw {
        message: "Journal ID or Book ID must be provided."
      }
    } else if (data.limit == "" && data.limit == undefined) {
      throw {
        message: "Limit must be provided."
      }
    } else if (data.page == "" && data.page == undefined) {
      throw {
        message: "Page must be provided."
      }
    }
    let result = await activity_stream_service.get_dashboard_data_stream(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Get Dashboard data.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}