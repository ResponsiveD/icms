"use strict";
const application_repo = require("../repository/application.service");
const loginService_repo = require("../repository/login.service");
const jwtLib = require('../middleware/auth/lib/jwtlib');
const rsaLib = require('../helpers/rsalib');
const output = require("../models/output");
const exception_repo = require("../middleware/exception/exception");
const HttpStatus = require('http-status-codes');

exports.init = async function (req, res, next) {
  let error = null;
  let result = null;
  req.User = {};
  req.User.startTime = new Date();
  try {
    let result = await application_repo.init(req.body.ClientID, req.body.Secret);
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    if (result.is_success) {
      res.status(result.status != undefined ? result.status : HttpStatus.OK).send(result);
    } else {
      res.status(result.status != undefined ? result.status : HttpStatus.UNPROCESSABLE_ENTITY).send(result);
    }
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};


exports.tokenRenewal = async function (req, res, next) {
  let error = null;
  let result = null;
  try {
    result = await application_repo.tokenRenewal(req.User.UserID, req.User.LoginID, req.body.token);
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    if (result.is_success) {
      res.status(result.status != undefined ? result.status : HttpStatus.OK).send(result);
    } else {
      res.status(result.status != undefined ? result.status : HttpStatus.UNPROCESSABLE_ENTITY).send(result);
    }
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};

exports.externalClientInit = async function (req, res, next) {
  var _output = new output(); let error = null;
  try {
    let result = await application_repo.init(req.headers.clientid, req.headers.apikey);
    req.User ? null : req.User = {};
    if (result.is_success) {
      let docDetails = await loginService_repo.getDocDeailsByDocID(req.body.DocID);
      if (docDetails.recordset.length > 0) {
        _output.data = docDetails.recordset[0];
        if (_output.data.CompID == 3) {
          let userDetails = await loginService_repo.getUserDeailsByUserID(_output.data.UserID, _output.data.isonshore)
          if (userDetails.recordset.length > 0) {
            _output.data["email"] = userDetails.recordset[0].EmailID;
            _output.is_success = true;
            _output.message = "User session is found.";
            _output.token = await jwtLib.generateToken(userDetails.recordset[0], true);
          } else {
            _output.is_success = false;
            _output.message = "User session is not found.";
          }
          req.User.endTime = new Date();
          exception_repo.exception_DB_log(req, _output, error, 1);
          res.status(HttpStatus.OK).send(_output);
        } else {
          if (!_output.data.accessdenied) {
            let userDetails = await loginService_repo.getUserDeailsByUserID(_output.data.UserID, _output.data.isonshore)
            if (userDetails.recordset.length > 0) {
              _output.is_success = true;
              _output.message = "User session is found.";
              _output.token = await jwtLib.generateToken(userDetails.recordset[0], true);
            } else {
              _output.is_success = false;
              _output.message = "User session is not found.";
            }
            req.User.endTime = new Date();
            exception_repo.exception_DB_log(req, _output, error, 1);
            res.status(HttpStatus.OK).send(_output);
          } else {
            _output.is_success = false;
            _output.message = "Thanks for your interest, we have found another reviewer to review this article.";
            req.User.endTime = new Date();
            exception_repo.exception_DB_log(req, _output, error, 1);
            res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
          }
        }

      } else {
        _output.is_success = false;
        _output.message = "Doc ID is not found.";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
      }

    } else {
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, result, error, 1);
      res.status(result.status != undefined ? result.status : HttpStatus.UNPROCESSABLE_ENTITY).send(result);
    }
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};


exports.decrypt = async function (req, res, next) {
  let error = null;
  let result = null;
  try {
    req.User ? null : req.User = {};
    result = await rsaLib.decryptString(req.query.id)
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    if (result) {
      res.status(HttpStatus.OK).send(result);
    } else {
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send();
    }

  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};

exports.encrypt = async function (req, res, next) {
  let error = null;
  let result = null;
  try {
    result = await rsaLib.encryptString(req.body)
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    if (result) {
      res.status(HttpStatus.OK).send(result);
    } else {
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send();
    }

  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};

exports.clientSendMail = async function (req, res, next) {
  var _output = new output();
  try {
    let result = await application_repo.clientSendMail(req.body)
    if (result) {
      _output.is_success = true;
      _output.message = "E-Mail send successfully.";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    } else {
      _output.is_success = false;
      _output.message = "E-Mail not able to send, Please check the input.";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }

  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.INTERNAL_SERVER_ERROR).send(error);
  }
};

exports.getReport = async function (req, res, next) {
  var _output = new output();
  let error = null;
  try {
    let data = req.body;
    let validateRule = ['drop', 'truncate', 'insert', 'update', 'into', 'delete', 'procedure', 'function', 'create', 'alter', 'table', 'values'];
    let validateData = data.query.query.split(' ')
    validateData.map(item => {
      validateRule.map(rule => {
        if (item.trim().toLowerCase() === rule.trim().toLowerCase()) {
          throw { message: `Please use select query and not to use keywords like ${validateRule.join(',').toUpperCase()}` };
        }
      });

    });
    let JsonData = JSON.stringify(data.query);
    let result = await application_repo.getReport(JsonData);
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Report for query';
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};