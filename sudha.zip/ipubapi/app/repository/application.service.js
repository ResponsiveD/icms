"use strict";
const db_library = require('../../config/lib/db_library'),
  param = require('../models/parameter_input'),
  sqlType = require('mssql'),
  jwtLib = require('../middleware/auth/lib/jwtlib'),
  jwt = require("jsonwebtoken"),
  APP_CONFIG = require("../../config/constant/appConfig"),
  mailer = require('../helpers/mailer'),
  output = require("../models/output");
const _mailOptions = require("../helpers/mailOptions");

let options = {
  keyid: 'integra',
  subject: "integra_token",
  issuer: 'integra',
  jwtid: 'integra'
}

exports.init = async (ClientID, Secret) => {
  try {
    let _output = new output();
    let _parameters = [];
    let para = new param('ClientID', sqlType.NVarChar, ClientID);
    _parameters.push(para);
    para = new param('Secret', sqlType.NVarChar, Secret);
    _parameters.push(para);
    let result = await db_library.execute_await('[IPS].[CheckClient]', _parameters, db_library.query_type.SP)
    if (result.recordsets[0].length > 0) {
      let webToken = await jwtLib.generateToken(result.recordsets[0][0], false);
      _output.is_success = true;
      _output.data = {
        token: webToken
      };
      _output.message = "client Hand shake with Server successfully.";
    } else {
      _output.is_success = false;
      _output.message = "client Hand shake with Server unsuccessfully.";
    }
    return _output
  } catch (error) {
    return error;
  }
}

exports.checkAppToken = async (ID, key) => {
  try {
    let _parameters = [];
    let para = new param('ClientID', sqlType.NVarChar, ID);
    _parameters.push(para);
    para = new param('Key', sqlType.NVarChar, key);
    _parameters.push(para);
    return await db_library.execute_await('[IPS].[CheckClientToken]', _parameters, db_library.query_type.SP)
  } catch (error) {
    return error;
  }
}

exports.checkAppKeyExists = async (key, clientid) => {
  try {
    let _parameters = [];
    let para = new param('Key', sqlType.NVarChar, key);
    _parameters.push(para);
    para = new param('ClientId', sqlType.NVarChar, clientid);
    _parameters.push(para);
    return await db_library.execute_await('[IPS].[CheckAPIKeyExists]', _parameters, db_library.query_type.SP)
  } catch (error) {
    return error;
  }
}

exports.checkUserToken = async (UserID, LoginID) => {
  try {
    let _parameters = [];
    let para = new param('UserID', sqlType.Int, UserID);
    _parameters.push(para);
    para = new param('LoginID', sqlType.Int, LoginID);
    _parameters.push(para);
    return await db_library.execute_await('[IPS].[CheckLoginSession]', _parameters, db_library.query_type.SP)
  } catch (error) {
    return error;
  }
}

exports.tokenRenewal = async (UserID, LoginID, Token) => {
  try {
    let _output = new output();
    let data = await jwtLib.decodeToken(Token);
    delete data.exp;
    delete data.iat;
    delete data.iss;
    delete data.jti;
    delete data.sub;
    let webToken = await jwtLib.generateToken(data, true);
    _output.is_success = true;
    _output.data = {
      token: webToken
    };
    _output.message = "Token renewaled successfully.";
    return _output;
  } catch (error) {
    return error;
  }
}

exports.clientSendMail = async (request) => {
  try {
    const config = require('../../config/config');
    var options = new _mailOptions();
    options.bcc = request.bcc;
    options.cc = request.cc;
    options.from = config.mailer.from;
    options.html = request.content;
    options.subject = request.subnect;
    options.to = request.to;
    let result = await mailer.sendMail(options);
    return result;
  } catch (error) {
    return error
  }
};

exports.getReport = async (JsonData) => {
  return await new Promise((resolve, reject) => {
    let parameters = [];
    let para = new param('JsonData', sqlType.NVarChar, JsonData);
    parameters.push(para);
    db_library
      .execute_await('[IPS].[GetReportForQuery]', parameters, db_library.query_type.SP)
      .then((value) => {
        // let report = value.recordsets[0];
        resolve({
          report: value.recordsets[0],
          pagedetails: value.recordsets[1][0]
        });
      })
      .catch((error) => {
        reject(error);
      });
  });
};