"use strict";
const param = require('../models/parameter_input');
var sqlType = require('mssql');
const db_library = require('../../config/lib/db_library')

exports.get_user_access = async function (data) {
    return new Promise((resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('userid', sqlType.Int, data.User.UserID);
            parameters.push(para);
            para = new param('orgid', sqlType.Int, data.User.OrgID);
            parameters.push(para);
            para = new param('AppName', sqlType.NVarChar, data.query.AppName);
            parameters.push(para);
            db_library
                .execute('[IPS].[GetUserAccessDetail]', parameters, db_library.query_type.SP).then((value) => {
                    resolve(value.recordset);
                }).catch(err => {
                    reject(err);
                });
        } catch (err) {
            reject(err);
        }
    });
}

exports.addedit_user_access_dtl = async function (data) {
    return await new Promise((resolve, reject) => {
        try {
            let parameters = [];
            let para_UserID = new param('UserID', sqlType.Int, data.UserID);
            parameters.push(para_UserID);
            let para_OrgID = new param('OrgID', sqlType.Int, data.OrgID);
            parameters.push(para_OrgID);
            let para_CompID = new param('CompID', sqlType.Int, data.CompID);
            parameters.push(para_CompID);
            let para_CustID = new param('CustID', sqlType.Int, data.CustID);
            parameters.push(para_CustID);
            let para_Method = new param('Method', sqlType.NVarChar, data.Method);
            parameters.push(para_Method);
            let para_Endpoint = new param('Endpoint', sqlType.NVarChar, data.Endpoint);
            parameters.push(para_Endpoint);
            let para_req = new param('Req', sqlType.NVarChar, JSON.stringify(data.Req));
            parameters.push(para_req);
            let para_res = new param('Res', sqlType.NVarChar, JSON.stringify(data.Res));
            parameters.push(para_res);
            let para_Error = new param('Error', sqlType.NVarChar, data.Error);
            parameters.push(para_Error);
            let para_AppName = new param('AppName', sqlType.NVarChar, data.AppName);
            parameters.push(para_AppName);
            let para_Status = new param('Status', sqlType.NVarChar, data.Status);
            parameters.push(para_Status);
            db_library.execute('[IPS].[User_API_Access_Log]', parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject(err);
            });
        } catch (error) {
            reject(err);
        }
    });
}