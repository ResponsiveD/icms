const db_library = require('../../config/lib/db_library');
const param = require('../component/irights/models/parameter_input');
const sqlType = require('mssql');

exports.usersystemaccesslog = async (data) => {
	return await new Promise((resolve, reject) => {
		let parameters = [];
		let para = new param('StartDate', sqlType.NVarChar, data.StartDate);
		parameters.push(para);
		para = new param('EndDate', sqlType.NVarChar, data.EndDate);
		parameters.push(para);
		para = new param('Status', sqlType.NVarChar, data.Status);
		parameters.push(para);
		para = new param('Page', sqlType.Int, data.Page);
		parameters.push(para);
		para = new param('Limit', sqlType.Int, data.Limit);
		parameters.push(para);
		db_library
			.execute_await('[IPS].[UsersSystemAccessLogConfig]', parameters, db_library.query_type.SP)
			.then((value) => {
				let results = {
					log_value: value.recordsets[0],
					log_count: value.recordsets[1][0]
				};
				resolve(results);
			})
			.catch((err) => {
				reject({
					message: 'There is an error occured in database.'
				});
			});
	});
};

exports.userapiaccesslog = async (data) => {
	return await new Promise((resolve, reject) => {
		let parameters = [];
		let para = new param('StartDate', sqlType.NVarChar, data.StartDate);
		parameters.push(para);
		para = new param('EndDate', sqlType.NVarChar, data.EndDate);
		parameters.push(para);
		para = new param('Status', sqlType.NVarChar, data.Status);
		parameters.push(para);
		para = new param('Page', sqlType.Int, data.Page);
		parameters.push(para);
		para = new param('Limit', sqlType.Int, data.Limit);
		parameters.push(para);
		db_library
			.execute_await('[IPS].[UsersAPIAccessLogConfig]', parameters, db_library.query_type.SP)
			.then((value) => {
				let results = {
					log_value: value.recordsets[0],
					log_count: value.recordsets[1][0]
				};
				resolve(results);
			})
			.catch((err) => {
				reject({
					message: 'There is an error occurred in database.'
				});
			});
	});
};

exports.getcolumns = async (tablename) => {
	return await new Promise((resolve, reject) => {
		let _parameters = [];
		let para = new param('tablename', sqlType.VarChar, tablename);
		_parameters.push(para);
		db_library
			.execute_await('[IPS].[GetColumnsforMaster]', _parameters, db_library.query_type.SP)
			.then((value) => {
				let results = value.recordsets[0];
				resolve(results);
			})
			.catch((err) => {
				reject({
					message: 'There is an error occured in tablename '
				});
			});
	});
};

exports.insertmastertables = async (JsonData) => {
	return await new Promise((resolve, reject) => {
		let parameters = [];
		let para = new param('JsonData', sqlType.NVarChar, JsonData);
		parameters.push(para);
		db_library
			.execute_await('[IPS].[InsertUpdateMasterTable]', parameters, db_library.query_type.SP)
			.then((value) => {
				let results = value.recordsets[0];
				resolve(results);
			})
			.catch((err) => {
				reject({
					message: 'There is an error occured in database '
				});
			});
	});
};