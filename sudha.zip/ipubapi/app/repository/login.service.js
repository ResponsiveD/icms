"use strict";
const output = require("../models/output");
const jwtLib = require("../middleware/auth/lib/jwtlib");
const Request = require("request");
const db_library = require('../../config/lib/db_library')
const param = require('../models/parameter_input');
var sqlType = require('mssql');

const PACKAGE = require('../../package.json')
const config = require('../../config/env/config.json')

const  baseUrl = config[PACKAGE.environment]["INTERNALBASEPATH"];;
const Ldap = config[PACKAGE.environment]["LDAPCHECK"];

var ipswitch = config[PACKAGE.environment]["IPSWITCH"];
var LDAPURL = config[PACKAGE.environment]["ELDAPURL"];

//const ipswitch = "https://ipswitch.azurewebsites.net/getip?type=host";
//const LDAPURL = "iService/api/LDAP/ValidateUser";

var fs = require('fs');

exports.CredentialChecker = async function (logindetails) {
  var _output = new output();
  return await new Promise(async (resolve, reject) => {
    try {
      if (!Ldap) {
        SkipLDAPLogin(logindetails).then((data) => {
          resolve(data);
        }).catch((err) => {
          reject(err);
        })
      }
      else {
        let ldapBaseURL = baseUrl
        if (config[PACKAGE.environment]["HOSTEDCLOUD"]) {
          ldapBaseURL = await IPSwitchURL();
        }
        ldapBaseURL = ldapBaseURL + LDAPURL;
        //ldapBaseURL = 'http://app.integra.co.in/iService/api/LDAP/ValidateUser';
        var checkCredentialURL = await LDAPLoginCheck(ldapBaseURL, logindetails).catch(err => {
          throw err;
        });
        if (!checkCredentialURL.data) {
          var _CheckCredentialinDB = await CheckCredentialinDB(logindetails);
          resolve(_CheckCredentialinDB);
        }
        else {
          if (checkCredentialURL.data || !Ldap) {
            var out = await GetUserLoginStatus(logindetails);
            resolve(out);
          }
          else {
            _output.is_success = true;
            _output.data = {
              CheckStatus: false,
              UserID: 0
            };
            _output.message = "Invalid UserName or Password.";
            reject(_output);
          }
        }
      }
    } catch (error) {
      _output.is_success = true;
      _output.data = {
        CheckStatus: false,
        UserID: 0
      };
      _output.message = typeof error == "object" ? error.message : error;
      reject(_output);
    }
  });
}

var updateUserDetails = async (logindetails, UserDetails) => {
  return await new Promise((resolve, reject) => {
    let parameters = [];
    let para = new param('UserCode', sqlType.VarChar, logindetails.UserID);
    parameters.push(para);
    para = new param('UserFName', sqlType.NVarChar, UserDetails.data.UserName);
    parameters.push(para);
    para = new param('UserEmailID', sqlType.NVarChar, UserDetails.data.EmailID);
    parameters.push(para);
    para = new param('UpdatedBy', sqlType.Int, 1);
    parameters.push(para);
    para = new param('isInternalUser', sqlType.Bit, true);
    parameters.push(para);
    para = new param('OrgID', sqlType.Int, 1);
    parameters.push(para);
    para = new param('OrgDivID', sqlType.Int, 1);
    parameters.push(para);
    db_library
      .execute('[IPS].[AddEditUser]', parameters, db_library.query_type.SP).then((Result) => {
        resolve({
          CheckStatus: true,
          UserID: Result.recordset[0].userid,
          RoleName: Result.recordset[0].role_name,
          UserName: UserDetails.data.UserName,
          EmailID: UserDetails.data.EmailID,
          UserCode: logindetails.UserID,
          OrgID: 1,
          OrgDivID: 1
        });
      }).catch(err => { reject(err); });
  });
};

var GerUserDetails = async (logindetails) => {
  return await new Promise(async (resolve, reject) => {
    Request.get(baseUrl + 'iService/api/LDAP/GetUserdetails?Empcode=' + logindetails.UserID, (error, response, body) => {
      if (error) {
        reject(error);
      }
      var UserDetails = JSON.parse(JSON.parse(body));
      resolve(UserDetails);
    });
  });
};

var GetUserLoginStatus = async (logindetails) => {
  return await new Promise(async (resolve, reject) => {
    try {
      var _output = new output();
      let parameters = [];
      let para = new param('UserCode', sqlType.VarChar, logindetails.UserID);
      parameters.push(para);
      db_library
        .execute('[IPS].[GetUserid]', parameters, db_library.query_type.SP).then(async (value) => {
          if (value.recordsets[0][0].userid === 0) {
            var _GerUserDetails = await GerUserDetails(logindetails);
            _output.data = await updateUserDetails(logindetails, _GerUserDetails);
            _output.message = "Login success.";
            _output.token = jwtLib.generateToken(logindetails);
            resolve(_output);
          }
          else {
            _output.data = {
              CheckStatus: true,
              UserID: value.recordset[0].userid,
              RoleName: value.recordset[0].RoleName,
              UserName: value.recordset[0].UserFName,
              EmailID: value.recordset[0].UserEmailID,
              UserCode: value.recordset[0].UserCode,
              OrgID: value.recordset[0].OrgID,
              OrgDivID: value.recordset[0].OrgDivID,
              CustName: value.recordset[0].CustName,
              CustID: value.recordset[0].CustID,
              CompID: value.recordset[0].CompID,
              CompName: value.recordset[0].CompName,
              Type: value.recordsets[1]
            };
            _output.message = "Login success.";
            _output.token = jwtLib.generateToken(logindetails);
            resolve(_output);
          }
        }).catch((error) => {
          _output.is_success = false;
          _output.data = {
            CheckStatus: false,
            UserID: 0
          };
          _output.message = "Unable to update details to iPubSuite";
          reject(_output);
        });
    } catch (error) {
      _output.is_success = false;
      _output.data = {
        CheckStatus: false,
        UserID: 0
      };
      _output.message = error;
      reject(_output);
    }
  });
};

var CheckCredentialinDB = async (logindetails) => {
  return new Promise((resolve, reject) => {
    var _output = new output();
    try {
      let parameters = [];
      let para = new param('userid', sqlType.VarChar, logindetails.UserID);
      parameters.push(para);
      para = new param('password', sqlType.VarChar, logindetails.Password);
      parameters.push(para);
      db_library
        .execute('[IPS].[Checklogin]', parameters, db_library.query_type.SP).then(async (value) => {
          if (value.recordset[0].userid == 0) {
            _output.is_success = false;
            _output.data = {
              CheckStatus: true,
              UserID: value.recordset[0].userid
            };
            _output.message = "Username or Password is not Correct.";
            reject(_output);
          }
          else {
            var _out = await SkipLDAPLogin(logindetails)
            resolve(_out);
          }
        }).catch(err => {
          _output.is_success = false;
          _output.data = err;
          _output.message = "Username or Password is not Correct.";
          reject(_output);
        });
    } catch (error) {
      _output.is_success = false;
      _output.data = error;
      _output.message = "Username or Password is not Correct.";
      reject(_output);
    }
  });
};

var log = async (string) => {
  return new Promise(async (resolve, reject) => {
    fs.appendFile(`${__dirname}/switchlog.txt`, string, function (err) {
      if (err) {
        reject(err);
      }
      resolve("The file was saved!");
    });
  });
}

var LDAPLoginCheck = async (url, logindetails) => {
  return await new Promise(async (resolve, reject) => {
    const _common = require('../helpers/common');
    var password = _common.Base64.encode(logindetails.Password);
    var string = `${url}?Empcode=${logindetails.UserID}&&LoginPassword=${password}`;
    //var string = 'http://app.integra.co.in/iService/api/LDAP/ValidateUser?Empcode='+logindetails.UserID+'&&LoginPassword='+logindetails.Password
    Request.get(string, async (error, response, body) => {
      try {
        if (error) {
          //await log(`LDAPLoginCheck ${url + error}`);
          reject(`LDAPLoginCheck ${url + error}`);
        }
        var checkCredentialURL = JSON.parse(JSON.parse(body));
        resolve(checkCredentialURL)
      } catch (error) {
        //log(`LDAPLoginCheck ${url + error}`)
        reject(`LDAPLoginCheck ${url + error}`)
      }
    });
  });
}

var SkipLDAPLogin = async (logindetails) => {
  return await new Promise((resolve, reject) => {
    let parameters = [];
    var _output = new output();

    let para = new param('UserCode', sqlType.VarChar, logindetails.UserID);
    parameters.push(para);
    db_library
      .execute('[IPS].[GetUserid]', parameters, db_library.query_type.SP).then((value) => {
        let role = [];
        if (value.recordsets[0].length > 0) {
          value.recordsets[0].filter(item => {
            if (item.RoleName)
              role.push(item.RoleName);
          });
          role = role.length > 1 ? [...new Set(role)] : role[0];
        }
        if (value.recordsets[0][0].userid === 0) {
          _output.is_success = false;
          _output.data = {
            CheckStatus: true,
            UserID: value.recordset[0].userid
          };
          _output.message = "Username or Password is not Correct.";
          reject(_output);
        }
        else {
          _output.is_success = true;
          _output.data = {
            CheckStatus: true,
            UserID: value.recordset[0].userid,
            // RoleName: value.recordset[0].RoleName,
            RoleName: role,
            UserName: value.recordset[0].UserFName,
            EmailID: value.recordset[0].UserEmailID,
            UserCode: value.recordset[0].UserCode,
            OrgID: value.recordset[0].OrgID,
            OrgDivID: value.recordset[0].OrgDivID,
            CustName: value.recordset[0].CustName,
            CustID: value.recordset[0].CustID,
            CompID: value.recordset[0].CompID,
            CompName: value.recordset[0].CompName,
            IsGDPR: value.recordset[0].isGDPR,
            Type: value.recordsets[1]

          };
          _output.message = "Login success.";
          //_output.token = jwtLib.generateToken(logindetails,true);
          resolve(_output);
        }
      }).catch((err) => {
        _output.is_success = false;
        _output.data = {
          CheckStatus: true,
          UserID: 0
        };
        _output.message = err.message;
        reject(_output);
      });
  });
}

var IPSwitchURL = async function () {
  return await new Promise((resolve, reject) => {
    Request.get(ipswitch, (error, response, body) => {
      if (error) {
        reject('IPSwitchURL' + error);
      }
      resolve('http://' + body + '/');
    });
  });
}

exports.LogInOut = async (user_id, LoginID, End, Start) => {
  return new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('LoginID', sqlType.Int, LoginID);
      parameters.push(para);
      para = new param('End', sqlType.Int, End);
      parameters.push(para);
      para = new param('Start', sqlType.Int, Start);
      parameters.push(para);
      db_library
        .execute('[IPS].[AddEditUserLogin]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value);
        })
        .catch((err) => {
          reject(false);
        }
        );
    } catch (error) {
      reject(false)
    }
  });
}

exports.forget_password = async (mail_id) => {
  var _output = new output();
  return new Promise(async (resolve, reject) => {
    try {
      const activity_actions_repo = require("../component/irights/repository/activity_actions");
      const _mailer = require("../helpers/mailer");
      const _mailOptions = require("../helpers/mailOptions");
      let parameters = [];
      let para = new param('EmailID', sqlType.NVarChar, mail_id);
      parameters.push(para);
      let UserDetails = await db_library
        .execute('[IPS].[PasswordReset]', parameters, db_library.query_type.SP).catch(err => {
          _output.is_success = false;
          _output.data = false;
          _output.message = 'No Such active user available';
          reject(_output);
        });
      if (UserDetails.recordsets.length > 0) {
        let Password = UserDetails.recordsets[0][0];
        UserDetails = UserDetails.recordsets[2][0];
        let options = await activity_actions_repo.get_mail_template(6, UserDetails.UserID);
        options.to = UserDetails.EmailID;
        options.html = options.html.replace('##name##', UserDetails.name).replace('##email##', UserDetails.EmailID.toLowerCase()).replace('##password##', Password[""]);
        _output.is_success = true;
        _output.data = true
        _output.message = "Password has been reset and mail send to your email account.";
        resolve(_output);
        _mailer.sendMail(options);
      } else {
        _output.is_success = false;
        _output.data = false;
        _output.message = 'No Such active user available';
        reject(_output);
      }
    } catch (error) {
      _output.is_success = false;
      _output.data = false;
      _output.message = error.message == undefined ? error : error.message;
      reject(_output);
    }
  });
}

exports.change_password = async (oldpassword, newpassword, user_id) => {
  //exports.change_password = async (oldpassword, newpassword, salt, user_id) => {
  var _output = new output();
  return new Promise(async (resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('OldPassword', sqlType.NVarChar, oldpassword);
      parameters.push(para);
      para = new param('NewPassword', sqlType.NVarChar, newpassword);
      parameters.push(para);
      para = new param('UserID', sqlType.NVarChar, user_id);
      parameters.push(para);
      // para = new param('Salt', sqlType.NVarChar, salt);
      // parameters.push(para);
      db_library
        .execute('[IPS].[Passwordupdate]', parameters, db_library.query_type.SP).then(value => {
          if (value.recordsets[2][0].success == 1) {
            _output.is_success = true;
            _output.data = true
            _output.message = "Password changed successfully.";
          } else if (value.recordsets[2][0].success == 0) {
            _output.is_success = false;
            _output.data = false
            _output.message = "Old password is incorrect.";
          }
          resolve(_output);
        }).catch(err => {
          _output.is_success = false;
          _output.data = false;
          _output.message = err.message == undefined ? err : err.message;
          reject(_output);
        });
    } catch (error) {
      _output.is_success = false;
      _output.data = false;
      _output.message = error.message == undefined ? error : error.message;
      reject(_output);
    }
  });
}

exports.CheckCredentials = async function (logindetails) {
  var _output = new output();
  return await new Promise((resolve, reject) => {
    try {
      if (!config[PACKAGE.environment]["LDAPCHECK"]) {
        let parameters = [];
        let para = new param('UserCode', sqlType.VarChar, logindetails.UserID);
        parameters.push(para);
        db_library
          .execute('[IPS].[GetUserid]', parameters, db_library.query_type.SP).then((value) => {
            if (value.recordset[0].userid === 0) {
              _output.is_success = false;
              _output.data = {
                CheckStatus: true,
                UserID: value.recordset[0].userid
              };
              _output.message = "Username or Password is not Correct.";
              reject(_output);
            }
            else {
              _output.is_success = true;
              _output.data = {
                CheckStatus: true,
                UserID: value.recordset[0].userid,
                UserName: value.recordset[0].UserFName,
                EmailID: value.recordset[0].UserEmailID,
                UserCode: value.recordset[0].UserCode,
                OrgID: value.recordset[0].OrgID,
                Type: value.recordsets[1],
                OrgDivID: value.recordset[0].OrgDivID
              };
              _output.message = "Login success.";
              //_output.token = jwtLib.generateToken(logindetails);
              resolve(_output);
            }
          }).catch((err) => {
            _output.is_success = false;
            _output.data = {
              CheckStatus: true,
              UserID: 0
            };
            _output.message = err.message;
            reject(_output);
          });
      }
      else {
        var baseUrl = config[PACKAGE.environment]["INTERNALBASEPATH"];
        if (config[PACKAGE.environment]["HOSTEDCLOUD"]) {
          Request.get(config[PACKAGE.environment]["IPSWITCH"], (error, response, body) => {
            if (error) {
              throw error
            }
            baseUrl = (body) + '/';
          });
        }
        var checkCredentialURL;
        Request.get(baseUrl + config[PACKAGE.environment]["LDAPURL"] + '?Empcode=' + logindetails.UserID + '&&LoginPassword=' + logindetails.Password, (error, response, body) => {
          if (error) {
            throw error
          }
          checkCredentialURL = JSON.parse(JSON.parse(body));

          if (!checkCredentialURL.isSuccess) {
            let parameters = [];
            let para = new param('userid', sqlType.VarChar, logindetails.UserID);
            parameters.push(para);
            para = new param('password', sqlType.VarChar, logindetails.Password);
            parameters.push(para);
            db_library
              .execute('[IPS].[Checklogin]', parameters, db_library.query_type.SP).then((value) => {
                if (value.recordset[0].userid === 0) {
                  _output.is_success = false;
                  _output.data = {
                    CheckStatus: true,
                    UserID: value.recordset[0].userid
                  };
                  _output.message = "Username or Password is not Correct.";
                  reject(_output);
                }
                else {
                  _output.is_success = true;
                  _output.data = {
                    CheckStatus: true,
                    UserID: value.recordset[0].userid
                  };
                  _output.message = "Login success.";
                  // _output.token = jwtLib.generateToken(logindetails);
                  resolve(_output);
                }
              });
          }
          else {
            _output.is_success = true;
            if (checkCredentialURL.data || !config[PACKAGE.environment]["LDAPCHECK"]) {
              let parameters = [];
              let para = new param('UserCode', sqlType.VarChar, logindetails.UserID);
              parameters.push(para);
              db_library
                .execute('[IPS].[GetUserid]', parameters, db_library.query_type.SP).then((value) => {
                  if (value.recordset[0].userid === 0) {
                    Request.get(baseUrl + 'iService/api/LDAP/GetUserdetails?Empcode=' + logindetails.UserID, (error, response, body) => {
                      if (error) {
                        _output.is_success = false;
                        _output.data = {
                          CheckStatus: false,
                          UserID: 0
                        };
                        _output.message = "Unable to get details from LDAP";
                        reject(_output);
                      }
                      var UserDetails = JSON.parse(JSON.parse(body));
                      if (!UserDetails.data) {
                        _output.is_success = false;
                        _output.data = {
                          CheckStatus: false,
                          UserID: 0
                        };
                        _output.message = "Unable to get details from LDAP";
                        reject(_output);
                      }
                      parameters = [];
                      para = new param('UserCode', sqlType.VarChar, logindetails.UserID);
                      parameters.push(para);
                      para = new param('UserFName', sqlType.NVarChar, UserDetails.data.UserName);
                      parameters.push(para);
                      para = new param('UserEmailID', sqlType.NVarChar, UserDetails.data.EmailID);
                      parameters.push(para);
                      para = new param('UpdatedBy', sqlType.Int, 1);
                      parameters.push(para);
                      para = new param('isInternalUser', sqlType.Bit, true);
                      parameters.push(para);
                      para = new param('OrgID', sqlType.Int, 1);
                      parameters.push(para);
                      para = new param('OrgDivID', sqlType.Int, 1);
                      parameters.push(para);
                      db_library
                        .execute('[IPS].[AddEditUser]', parameters, db_library.query_type.SP).then((Result) => {
                          _output.data = {
                            CheckStatus: true,
                            UserID: Result.recordset[0].userid,
                            UserName: UserDetails.data.UserName,
                            EmailID: UserDetails.data.EmailID,
                            UserCode: logindetails.UserID,
                            Type: value.recordsets[1],
                            OrgID: 1,
                            OrgDivID: 1
                          };
                          _output.message = "Login success.";
                          //_output.token = jwtLib.generateToken(logindetails);
                          resolve(_output);
                        }).catch((error) => {
                          _output.is_success = false;
                          _output.data = {
                            CheckStatus: false,
                            UserID: 0
                          };
                          _output.message = "Unable to update details to iPubSuite";
                          reject(_output);
                        });
                    });
                  }
                  else {
                    _output.data = {
                      CheckStatus: true,
                      UserID: value.recordset[0].userid,
                      UserName: value.recordset[0].UserFName,
                      EmailID: value.recordset[0].UserEmailID,
                      UserCode: value.recordset[0].UserCode,
                      OrgID: value.recordset[0].OrgID,
                      Type: value.recordsets[1],
                      OrgDivID: value.recordset[0].OrgDivID
                    };
                    _output.message = "Login success.";
                    _output.token = jwtLib.generateToken(logindetails);
                    resolve(_output);
                  }
                }).catch((error) => {
                  _output.is_success = false;
                  _output.data = {
                    CheckStatus: false,
                    UserID: 0
                  };
                  _output.message = "Unable to update details to iPubSuite";
                  reject(_output);
                });
            }
            else {
              _output.data = {
                CheckStatus: false,
                UserID: 0
              };
              _output.message = "Invalid UserName or Password.";
              reject(_output);
            }
          }
        });
      }
    } catch (err) {
      _output.is_success = false;
      _output.data = {
        CheckStatus: false,
        UserID: 0
      };
      _output.message = "Username or Password is not Correct.";
      reject(_output);
    }
  });
};

exports.makeTokenData = async function (userdetails, Logindetails) {
  try {
    let tokenData = {
      UserID: Logindetails.UserID,
      LoginID: Logindetails.LoginID,
      UserCode: userdetails.data.UserCode,
      EmailID: userdetails.data.EmailID,
      OrgID: userdetails.data.OrgID,
      OrgDivID: userdetails.data.OrgDivID,
    }
    return tokenData;
  } catch (error) {
    return error;
  }
}

exports.CheckUsersession = async (logindetails) => {
  try {
    let _parameters = [];
    let para = new param('UserCode', sqlType.NVarChar, logindetails.UserID);
    _parameters.push(para);
    return await db_library.execute_await('[IPS].[CheckUserSession]', _parameters, db_library.query_type.SP)
  } catch (error) {
    return error;
  }
}

exports.getUserDeailsByUserID = async (userID, is_onshore) => {
  try {
    let _parameters = [];
    let para = new param('userID', sqlType.Int, userID);
    _parameters.push(para);
    para = new param('isOnShore', sqlType.Bit, is_onshore);
    _parameters.push(para);
    return await db_library.execute_await('[IPS].[GetUserDeailsByUserID]', _parameters, db_library.query_type.SP)
  } catch (error) {
    return error;
  }
}

exports.getDocDeailsByDocID = async (docID) => {
  try {
    let _parameters = [];
    let para = new param('docID', sqlType.Int, docID);
    _parameters.push(para);
    return await db_library.execute_await('[IPS].[GetDocDeailsByDocID]', _parameters, db_library.query_type.SP)
  } catch (error) {
    return error;
  }
}

exports.on_primis_login_check = async (params, system_details) => {
  let _output = new output();

  try {
    let parameters = [];

    let para = new param('UserCode', sqlType.NVarChar(50), params.UserName);
    parameters.push(para);
    para = new param('Name', sqlType.NVarChar(150), params.FirstName);
    parameters.push(para);
    para = new param('RoleId', sqlType.Int, params.RoleId);
    parameters.push(para);
    para = new param('EmailID', sqlType.NVarChar(150), params.EmailId);
    parameters.push(para);
    para = new param('isInternalUser', sqlType.Bit, 1);
    parameters.push(para);
    para = new param('OrgID', sqlType.Int, system_details.org_id);
    parameters.push(para);
    para = new param('OrgDivID', sqlType.Int, system_details.org_div_id);
    parameters.push(para);

    let result = await db_library.execute_await('[IPS].[onPrimisLogin]', parameters, db_library.query_type.SP);
    if (result.recordsets.length > 0) {
      let length = result.recordsets.length;
      _output.is_success = true;
      _output.data = result.recordsets[length - 1][0];
      _output.message = "user login successfully";
    } else {
      _output.is_success = false;
      _output.message = "somthing went worng";
    }

    return _output
  } catch (error) {
    return error
  }

}


exports.get_salt = async (user_id) => {
  try {
    let parameters = [];
    let para = new param('UserID', sqlType.Int, user_id);
    parameters.push(para);
    let result = await db_library.execute_await('[IPS].[Getsalt]', parameters, db_library.query_type.SP);
    if (result.recordsets[0].length > 0) {
      return result.recordsets[0][0].Salt
    } else {
      return false
    }

  } catch (error) {
    return false
  }

}