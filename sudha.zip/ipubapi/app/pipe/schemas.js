// load Joi module
const Joi = require('joi');

//Login API Schema
const loginSchema = Joi.object({
    UserID: Joi.string().lowercase().required(),
    Password: Joi.string().required()
});

//mail API schema
const mailSchema = Joi.object({
    bcc: Joi.string().lowercase().required(),
    cc:Joi.string().lowercase().required(),
    from:Joi.string().lowercase().required(),
    content:Joi.string().lowercase().required(),
    subnect:Joi.string().lowercase().required(),
    to:Joi.string().lowercase().required(),
});


//query Schema
const querySchema = Joi.object({
    id: Joi.required()
});

// export the schemas
module.exports = {
    '/login': loginSchema,
    '/client/mail': mailSchema
};

