'use strict'

function login() {
    this.password = "";
    this.user_id = "";
}

login.prototype.password = function (password) {
    this.password = password;
};
login.prototype.user_id = function (user_id) {
    this.user_id = user_id;
};
module.exports = login;