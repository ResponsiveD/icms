"use strict";

const db_library = require('../../../config/lib/db_library')
const param = require('../../models/parameter_input');
var sqlType = require('mssql');
const exceptionString = require("../exception/exceptionString");

// exports.exception_DB_log = async (OrgID, CompID, UserID, CustID, Method, Endpoint, Req, Error_stack, Status, Res) => {
exports.exception_DB_log = async (req, res, error, status) => {
  try {
    
    req.User == undefined ?  req.User = {} : 0;

    if (typeof (error) == "object" && error != null ) {
      error = JSON.stringify(error);
    }

    if (typeof (res) == "object") {
      res = JSON.stringify(res);
    }

    let parameters = [];
    let para_OrgID = new param('OrgID', sqlType.Int, req.User.OrgID != undefined ? req.User.OrgID : 0);
    parameters.push(para_OrgID);
    let para_CompID = new param('CompID', sqlType.Int, req.User.CompID != undefined ? req.User.CompID : 0);
    parameters.push(para_CompID);
    let para_UserID = new param('UserID', sqlType.Int, req.User.UserID != undefined ? req.User.UserID : 0);
    parameters.push(para_UserID);
    let para_CustID = new param('CustID', sqlType.Int, req.User.CustID != undefined ? req.User.CustID : 0);
    parameters.push(para_CustID);
    let para_Method = new param('Method', sqlType.NVarChar, req.method);
    parameters.push(para_Method);
    let para_Endpoint = new param('Endpoint', sqlType.NVarChar, req.originalUrl);
    parameters.push(para_Endpoint);
    let para_req = new param('Req', sqlType.NVarChar, 'Body = ' + JSON.stringify(req.body) + '; query = ' +  JSON.stringify(req.query));
    parameters.push(para_req);
    let para_Error = new param('Error', sqlType.NVarChar, error != null ? error : 0);
    parameters.push(para_Error);
    let para_Status = new param('Status', sqlType.NVarChar, status);
    parameters.push(para_Status);
    let para_res = new param('Res', sqlType.NVarChar, res);
    parameters.push(para_res);
    let para_appname = new param('AppName', sqlType.NVarChar, req.headers.appname != undefined ? req.headers.appname : 0);
    parameters.push(para_appname);
    let para_clientURL = new param('clientURL', sqlType.NVarChar, req.headers.referer != undefined ? req.headers.referer : 0);
    parameters.push(para_clientURL);
    let para_clientIP = new param('clientIP', sqlType.NVarChar, req.headers.ip ?  req.headers.ip : 0 );
    parameters.push(para_clientIP);
    let para_browser = new param('Browser', sqlType.NVarChar, req.headers['user-agent'] ? req.headers['user-agent'] : 0 );
    parameters.push(para_browser);
    let para_APIURL = new param('APIURL', sqlType.NVarChar, req.protocol + '://' + req.get('host') + req.originalUrl);
    parameters.push(para_APIURL);
    let para_APPversion = new param('APPversion', sqlType.NVarChar, req.headers.appversion != undefined ? req.headers.appversion : 0);
    parameters.push(para_APPversion);
    let para_clientLocation = new param('clientlocation', sqlType.NVarChar, 'india');
    parameters.push(para_clientLocation);
    let para_header = new param('Header', sqlType.NVarChar, JSON.stringify(req.headers));
    parameters.push(para_header);
    let para_APIRequest = new param('APIrequest', sqlType.DateTime, req.User.startTime != undefined ? req.User.startTime : new Date());
    parameters.push(para_APIRequest);
    let para_APIresponce = new param('APIresponse', sqlType.DateTime, req.User.endTime != undefined ? req.User.endTime : new Date());
    parameters.push(para_APIresponce);
    // let para_elapse = new param('Timeelapse', sqlType.DateTime, req.User.startTime - req.User.endTime);
    // parameters.push(para_elapse);

    await db_library.execute_await('[IPS].[User_API_Access_Log]', parameters, db_library.query_type.SP);
    return true
  } catch (error) {
    return error
  }
}


exports.getException = async (param) => {
  try {
    return exceptionString.find(o => o.code === param);
  } catch (error) {
    return { "code": 500, "message": 'get exception object' + error }
  }
}