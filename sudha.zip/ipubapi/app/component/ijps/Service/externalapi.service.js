// var sqlType = require('mssql');
// const db_library = require('../../../../config/lib/db_library');
// const param = require('../../../models/parameter_input');
let common = require('../../../helpers/common')


exports.CastOff = async (input) => {
    return await new Promise(async (resolve, reject) => {
        let externalApis = require("../config/externalApis")
        let url = externalApis.CastOffApi;
        let baseurl  = await common.ActiveIPSwitchURL()
        url  = "https://"+baseurl+ url;
        await common.CallPostAPI(url, input)
            .then((value) => {
                resolve(value)
            })
            .catch((err) => {
                reject({ "message": "There is error on occurred in CastOff Calcluation, Please contact administrator " })
            })
    });
}
