var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');
// const activity_actions_repo = require('../../irights/repository/activity_actions');
const _mailer = require("../../../helpers/mailer");
const output = require("../../../models/Output");
// const rsalib = require("../../../helpers/rsalib")
const PACKAGE = require('../../../../package.json');
const config = require('../../../../config/env/config.json');
const iPubWebsite = config[PACKAGE.environment]["iPubWebsite"];
const iAuthorBaseURL = config[PACKAGE.environment]["iAuthorBaseURL"];
// const path = require("path")
// const article_controller = require("../controllers/article.controller");
// const reviewer_service = require("../Service/reviewer.service");
const getcompid = require('../../../../config/constant/components.json');

exports.reviewerAcceptInvitation = async (Data) => {
    try {

        if ((Data.UserId == 0 || Data.UserId == undefined) && Data.isAccept == 1) {
            let parameters = [];
            let para = new param('UserCode', sqlType.VarChar, Data.email);
            parameters.push(para);
            para = new param('UserFName', sqlType.NVarChar, Data.name);
            parameters.push(para);
            para = new param('UserEmailID', sqlType.NVarChar, Data.email);
            parameters.push(para);
            para = new param('UpdatedBy', sqlType.Int, 1);
            parameters.push(para);
            para = new param('isInternalUser', sqlType.Bit, false);
            parameters.push(para);
            para = new param('Password', sqlType.NVarChar, 'Password@123');
            parameters.push(para);
            para = new param('OrgID', sqlType.Int, 2);
            parameters.push(para);
            para = new param('OrgDivID', sqlType.Int, 2);
            parameters.push(para);
            para = new param('CustID', sqlType.Int, Data.custid);
            parameters.push(para);
            let result = await db_library.execute_await('[IPS].[AddEditUser]', parameters, db_library.query_type.SP);
            if (result.recordsets[0].length > 0) {

                //set user Id after user created
                Data.UserId = result.returnValue;
                let roleParameters = [];
                let rolePara = new param('UpdaterID', sqlType.Int, 1);
                roleParameters.push(rolePara);
                rolePara = new param('UserID', sqlType.Int, result.returnValue);
                roleParameters.push(rolePara);
                rolePara = new param('RoleID', sqlType.Int, 11);
                roleParameters.push(rolePara);
                rolePara = new param('CompID', sqlType.Int, 2);
                roleParameters.push(rolePara);
                await db_library.execute_await('[IRS].[AddeditUserRole]', roleParameters, db_library.query_type.SP);

                //sending mail to new user
                let parametersMail = [];
                let paraMail = new param('ArticleGUID', sqlType.NVarChar, Data.article_guid);
                parametersMail.push(paraMail);
                paraMail = new param('UserId', sqlType.Int, Data.UserId);
                parametersMail.push(paraMail);
                paraMail = new param('NotificationID', sqlType.Int, 17);
                parametersMail.push(paraMail);
                let mailTemplate = await db_library.execute_await("[IJPS].[GetMailTemplate]", parametersMail, db_library.query_type.SP);
                let article_repo = require('../Service/article.service');
                let publishername = await article_repo.get_article_publisher_name_by_articleguid(Data.article_guid)

                if (mailTemplate.recordsets[0].length > 0) {
                    let _mailOptions = require("../../../helpers/mailOptions");
                    let _mailer = require("../../../helpers/mailer");
                    mailTemplate = mailTemplate.recordsets[0][0];

                    let MailContent = mailTemplate.MailContent

                    MailContent = MailContent.replace("##name##", Data.name)
                    MailContent = MailContent.replace("##loginId##", Data.email)
                    MailContent = MailContent.replace("##password##", 'Password@123')
                    MailContent = MailContent.replace("##publishername##", publishername)

                    var options = new _mailOptions();
                    options.bcc = mailTemplate.BCCMailID;
                    options.cc = mailTemplate.CCMailID;
                    options.from = mailTemplate.FromMailID;
                    options.html = MailContent;
                    options.subject = mailTemplate.Subject;
                    options.to = mailTemplate.ToMailID + ';' + Data.email;
                    options.compid = getcompid.ijps.compID;
                    _mailer.sendMail(options);
                }
            }
        } else {
            let parameters = [];
            let para = new param('UserId', sqlType.Int, Data.UserId);
            parameters.push(para);
            await db_library.execute_await("[IJPS].[ChechAuthRev]", parameters, db_library.query_type.SP);
        }
        return await AcceptOrReject(Data);
    } catch (error) {
        return {
            "message": "There is error on occurred in database, Please contact administrator "
        }
    }
}

var AcceptOrReject = async function (Data) {
    try {
        var _output = new output();

        let _parameters = [];

        let para = new param('userEmail', sqlType.NVarChar, Data.email);
        _parameters.push(para);

        para = new param('articleID', sqlType.Int, Data.article_id);
        _parameters.push(para);

        para = new param('AtyID', sqlType.Int, Data.aty_id);
        _parameters.push(para);

        para = new param('userID', sqlType.Int, Data.UserId);
        _parameters.push(para);

        para = new param('AID', sqlType.Int, Data.Aid);
        _parameters.push(para);

        para = new param('Accept', sqlType.Bit, Data.isAccept == true ? 1 : 0);
        _parameters.push(para);

        let result = await db_library.execute_await('[IJPS].[reviewerAcceptOrReject]', _parameters, db_library.query_type.SP)
        if (result.recordsets[0].length > 0) {
            _output.is_success = true;
            _output.data = result.returnValue != undefined ? result.returnValue : '';
            _output.message = result.recordsets[0][0].result;
        } else {
            _output.is_success = false;
            _output.message = "Somthing went worng.";
        }
        return _output
    } catch (error) {
        return {
            "message": "There is error on occurred in database, Please contact administrator "
        }
    }
}

exports.get_reviewer_for_article = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        if (Data.article_guid == undefined || Data.article_guid == '') {
            reject({
                message: "article_guid must be provided."
            })
        }
        if (Data.aty_id == undefined || Data.aty_id == '') {
            reject({
                message: "aty_id must be provided."
            })
        } else {
            let JsonData = JSON.stringify(Data);
            let para = new param('JsonData', sqlType.NVarChar, JsonData);
            parameters.push(para);
            db_library
                .execute("[IJPS].[getUsersForArticleActivity]", parameters, db_library.query_type.SP).then((value) => {
                    resolve(value.recordsets[0]);
                }).catch(err => {
                    reject({
                        "message": "There is error on occurred in database, Please contact administrator "
                    })
                });
        }
    });
}

var MailLinkToReviewer = async (Data, outData) => {
    return await new Promise(async (resolve, reject) => {
        try {
            const _mailOptions = require("../../../helpers/mailOptions");
            const _mailer = require("../../../helpers/mailer");
            let parameters = [];
            let para = new param('ArticleGUID', sqlType.NVarChar, Data.article_guid);
            parameters.push(para);
            para = new param('UserId', sqlType.Int, Data.user_id);
            parameters.push(para);
            para = new param('NotificationID', sqlType.Int, 8);
            parameters.push(para);
            let mailTemplate = await db_library.execute_await("[IJPS].[GetMailTemplate]", parameters, db_library.query_type.SP);
            let article_repo = require('../Service/article.service');
            let publishername = await article_repo.get_article_publisher_name_by_articleguid(Data.article_guid)
            if (mailTemplate.recordsets[0].length > 0) {
                mailTemplate = mailTemplate.recordsets[0][0];

                for (let i = 0; i < outData.length; i++) {
                    let aceptlink = '';
                    let rejectlink = '';

                    let parametersLink = [];
                    let paraLink = new param('email', sqlType.NVarChar, outData[i].email_id);
                    parametersLink.push(paraLink);

                    paraLink = new param('article_guid', sqlType.NVarChar, Data.article_guid);
                    parametersLink.push(paraLink);

                    let link = await db_library.execute_await("[IJPS].[getreviewerlink]", parametersLink, db_library.query_type.SP);
                    let linkData = link.recordsets[0]
                    if (linkData.length > 0) {
                        if (linkData[0].Status == 11) {
                            aceptlink = iPubWebsite + "Review?id=" + linkData[0].Id
                        } else if (linkData[0].Status == 12) {
                            rejectlink = iPubWebsite + "Review?id=" + linkData[0].Id
                        }

                        if (linkData[1].Status == 11) {
                            aceptlink = iPubWebsite + "Review?id=" + linkData[1].Id
                        } else if (linkData[1].Status == 12) {
                            rejectlink = iPubWebsite + "Review?id=" + linkData[1].Id
                        }
                    }

                    let MailContent = mailTemplate.MailContent
                    MailContent = MailContent.replace("##Reviewername##", outData[i].name)
                    MailContent = MailContent.replace("##date##", outData[i].DueDate)

                    MailContent = MailContent.replace("##Agreed##", aceptlink)
                    MailContent = MailContent.replace("##Declined##", rejectlink)
                    MailContent = MailContent.replace("##AgreedLink##", aceptlink)
                    MailContent = MailContent.replace("##DeclinedLink##", rejectlink)
                    MailContent = MailContent.replace("##AcceptLink##", aceptlink)
                    MailContent = MailContent.replace("##RejectLink##", rejectlink)

                    MailContent = MailContent.replace("##articletitle##", outData[i].ArticleTitle)
                    MailContent = MailContent.replace("##author##", outData[i].author)
                    MailContent = MailContent.replace("##abstract##", outData[i].Abstract)
                    MailContent = MailContent.replace("##publishername##", publishername)

                    var options = new _mailOptions();
                    options.bcc = mailTemplate.BCCMailID;
                    options.cc = mailTemplate.CCMailID;
                    options.from = mailTemplate.FromMailID;
                    options.html = MailContent;
                    options.subject = mailTemplate.Subject;
                    options.compid = getcompid.ijps.compID;
                    if (mailTemplate.ToMailID != '') {
                        options.to = mailTemplate.ToMailID + ';' + outData[i].email_id;
                    } else {
                        options.to = outData[i].email_id;
                    }

                    _mailer.sendMail(options);
                }
                resolve(true);
            } else {
                resolve(false);
            }
        } catch (error) {
            reject({
                "message": "There is error on occurred in database, Please contact administrator "
            })
        }
    });
}


exports.mailLinkToReviewerAccept = async (request, data, mailInfo) => {
    try {
        const _mailOptions = require("../../../helpers/mailOptions");
        const _mailer = require("../../../helpers/mailer");
        let parameters = [];
        let para = new param('ArticleGUID', sqlType.NVarChar, data.article_guid);
        parameters.push(para);
        para = new param('UserId', sqlType.Int, request.User.UserID);
        parameters.push(para);
        para = new param('NotificationID', sqlType.Int, 5);
        parameters.push(para);
        let mailTemplate = await db_library.execute_await("[IJPS].[GetMailTemplate]", parameters, db_library.query_type.SP);
        let article_repo = require('../Service/article.service');
        let publishername = await article_repo.get_article_publisher_name_by_articleguid(data.article_guid)
        if (mailTemplate.recordsets[0].length > 0) {
            mailTemplate = mailTemplate.recordsets[0][0];
            let MailContent = mailTemplate.MailContent;
            MailContent = MailContent.replace("##name##", data.name);
            MailContent = MailContent.replace("##duedate##", mailInfo.due_date);
            MailContent = MailContent.replace("##ialink##", iAuthorBaseURL + '?docid=' + mailInfo.docid);
            MailContent = MailContent.replace("##publishername##", publishername)

            var options = new _mailOptions();
            options.bcc = mailTemplate.BCCMailID;
            options.cc = mailTemplate.CCMailID;
            options.from = mailTemplate.FromMailID;
            options.html = MailContent;
            options.subject = mailTemplate.Subject;
            options.compid = getcompid.ijps.compID;
            if (mailTemplate.ToMailID != '') {
                options.to = mailTemplate.ToMailID + ';' + data.email;
            } else {
                options.to = data.email;
            }

            _mailer.sendMail(options);

            return true;
        } else {
            return false;
        }
    } catch (error) {
        return {
            "message": "There is error on occurred in database, Please contact administrator "
        };
    }
}

exports.addEdit_reviewer_for_article = async (Data) => {
    return await new Promise(async (resolve, reject) => {
        let parameters = [];
        if (Data.article_guid == undefined || Data.article_guid == '') {
            reject({
                message: "article_guid must be provided."
            })
        }
        if (Data.aty_id == undefined || Data.aty_id == '') {
            reject({
                message: "aty_id must be provided."
            })
        }
        if (Data.users == undefined || Data.users == '' || Data.users.length < 1) {
            reject({
                message: "users details must be provided."
            })
        } else {
            let JsonData = JSON.stringify(Data);
            let para = new param('JsonData', sqlType.NVarChar, JsonData);
            parameters.push(para);
            db_library
                .execute("[IJPS].[AddEditUsersForArticleActivity]", parameters, db_library.query_type.SP).then(async (value) => {
                    if(value.recordsets[0][0].message == undefined){
                        MailLinkToReviewer(Data, value.recordsets[0]);
                    }
                    resolve(value.recordsets[0]);
                }).catch(err => {
                    reject({
                        "message": "There is error on occurred in database, Please contact administrator "
                    })
                });
        }
    });
}

exports.update_reviewer_action = async (Data) => {
    return await new Promise(async (resolve, reject) => {
        try {
            if (Data.article_guid == undefined || Data.article_guid == '') {
                reject({
                    message: "article_guid must be provided."
                })
            }
            if (Data.aty_id == undefined || Data.aty_id == '') {
                reject({
                    message: "aty_id must be provided."
                })
            }
            if (Data.email_id == undefined || Data.email_id == '') {
                reject({
                    message: "email_id must be provided"
                })
            }
            if (Data.is_rejected == undefined || Data.is_rejected == '') {
                reject({
                    message: "is_rejected must be provided"
                })
            }
            if (Data.is_accepted == undefined || Data.is_accepted == '') {
                reject({
                    message: "is_accepted must be provided"
                })
            } else {
                let parameters = [];
                let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(Data));
                parameters.push(para);
                let result = await db_library("[IJPS].[UpdateReviewerAction]", parameters, db_library.query_type.SP)
                resolve(true);
            }
        } catch (error) {
            reject({
                "message": "There is error on occurred in database, Please contact administrator "
            });
        }
    });
}

exports.add_sugg_comment = async (Data) => {
    return await new Promise((resolve, reject) => {
        try {
            if (Data.ArticleGUID == undefined || Data.ArticleGUID == '') {
                reject({
                    message: "ArticleGUID must be provided."
                })
            } else if (Data.activity_id == undefined || Data.activity_id == '') {
                reject({
                    message: "activity_id must be provided."
                })
            } else {
                let parameters = [];
                let JsonData = JSON.stringify(Data);
                let para = new param('JsonData', sqlType.NVarChar, JsonData);
                parameters.push(para);
                db_library
                    .execute("[IJPS].[AddSuggComment]", parameters, db_library.query_type.SP).then((value) => {
                        resolve(value.recordsets[0]);
                    }).catch(err => {
                        reject(err)
                    });
            }
        } catch (error) {
            reject({
                "message": "There is error on occurred in database, Please contact administrator "
            })
        }
    });
}

exports.get_sugg_comment = async (Data) => {
    return await new Promise((resolve, reject) => {
        if (Data.ArticleGUID == undefined || Data.ArticleGUID <= 0) {
            reject({
                message: 'ArticleGUID must be provided'
            })
        } else {
            let parameters = [];
            let para = new param('UserID', sqlType.Int, Data.user_id);
            parameters.push(para);
            para = new param('OrgID', sqlType.Int, Data.org_id);
            parameters.push(para);
            para = new param('ArticleGUID', sqlType.NVarChar, Data.ArticleGUID);
            parameters.push(para);
            para = new param('activity_id', sqlType.Int, Data.activity_id);
            parameters.push(para);
            db_library
                .execute("[IJPS].[GetSuggComment]", parameters, db_library.query_type.SP).then((value) => {
                    let results = {
                        suggestion: value.recordsets[0],
                        comment: value.recordsets[1]
                    };
                    resolve(results);
                }).catch(err => {
                    reject({
                        "message": "There is error on occurred in database, Please contact administrator "
                    })
                });
        }
    });
}

exports.getInvitationDetails = async (id) => {
    try {
        let parameters = [];
        let para = new param('id', sqlType.Int, id);
        parameters.push(para);
        return db_library.execute_await("[IJPS].[getInvitationDetails]", parameters, db_library.query_type.SP);
    } catch (e) {
        return {
            "message": "There is error on occurred in database, Please contact administrator "
        };
    }
}

exports.get_reviewer_record = async () => {
    return await new Promise((resolve, reject) => {
        db_library
            .execute(`[IJPS].[GetReviewerIncompleterecord]`)
            .then(value => {
                resolve(value.recordsets[0]);
            })
            .catch(err => {
                reject({
                    "message": "There is error on occurred in database, Please contact administrator "
                });
            });
    });
}

exports.Withdraw_Activity = async (article_guid) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_guid', sqlType.NVarChar, article_guid);
        parameters.push(para);
        db_library
            .execute(`[IJPS].[Withdraw_activity]`, parameters, db_library.query_type.SP)
            .then(async (value) => {
                let withdrawdetails = value.recordsets[0][0];
                let parametersMail = [];
                let paraMail = new param('wfid', sqlType.Int, withdrawdetails.wfid);
                parametersMail.push(paraMail);
                paraMail = new param('activityid', sqlType.Int, withdrawdetails.atyid);
                parametersMail.push(paraMail);
                paraMail = new param('mstatus', sqlType.Int, withdrawdetails.statusid);
                parametersMail.push(paraMail);
                paraMail = new param('orgid', sqlType.Int, 2);
                parametersMail.push(paraMail);
                paraMail = new param('userid', sqlType.Int, 1);
                parametersMail.push(paraMail);
                let mailTemplate = await db_library.execute_await("[IJPS].[Sendmailinfo]", parametersMail, db_library.query_type.SP);
                let article_repo = require('../Service/article.service');
                let publishername = await article_repo.get_article_publisher_name_by_articleguid(article_guid);
                if (mailTemplate.recordsets[0].length > 0) {
                    let _mailOptions = require("../../../helpers/mailOptions");
                    let _mailer = require("../../../helpers/mailer");
                    mailTemplate = mailTemplate.recordsets[0][0];

                    let MailContent = mailTemplate.MailContent;

                    MailContent = MailContent.replace("##name##", withdrawdetails.name);
                    MailContent = MailContent.replace("##publishername##", publishername);


                    var options = new _mailOptions();
                    options.bcc = mailTemplate.BCCMailID;
                    options.cc = mailTemplate.CCMailID;
                    options.from = mailTemplate.FromMailID;
                    options.html = MailContent;
                    options.subject = mailTemplate.Subject;
                    options.to = withdrawdetails.email;
                    options.compid = getcompid.ijps.compID;
                    _mailer.sendMail(options);
                }
                resolve(true);
            })
            .catch(err => {
                reject({
                    "message": "There is error on occurred in database, Please contact administrator "
                });
            });

    });
}


exports.Check_Pub_or_Auth = async (articleguid, username, email, user_id, org_id) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('articleguid', sqlType.NVarChar, articleguid);
        parameters.push(para);
        para = new param('username', sqlType.NVarChar, username);
        parameters.push(para);
        para = new param('email', sqlType.NVarChar, email);
        parameters.push(para);
        para = new param('userid', sqlType.NVarChar, user_id);
        parameters.push(para);
        para = new param('orgid', sqlType.NVarChar, org_id);
        parameters.push(para);
        db_library
            .execute(`[IJPS].[CheckPublisher_or_Author]`, parameters, db_library.query_type.SP)
            .then(value => {
                resolve(value.recordsets[0][0]);
            })
            .catch(err => {
                reject({
                    "message": "There is error on occurred in database, Please contact administrator "
                });
            });
    });
}

exports.get_Listof_reviewer = async (role_id, cust_id) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('role_id', sqlType.Int, role_id);
        parameters.push(para);
        para = new param('cust_id', sqlType.Int, cust_id);
        parameters.push(para);
        db_library
            .execute(`[IJPS].[GetListofReviewer]`, parameters, db_library.query_type.SP)
            .then(value => {
                resolve(value.recordsets[0]);
            })
            .catch(err => {
                reject({
                    "message": "There is error on occurred in database, Please contact administrator "
                });
            });
    });
}


exports.get_Authorfinalchecks_Record = async () => {
    return await new Promise((resolve, reject) => {
        db_library
            .execute(`[IJPS].[GetAuthorFinalchecksIncompleterecord]`)
            .then(value => {
                resolve(value.recordsets[0]);
            })
            .catch(err => {
                reject({
                    "message": "There is error on occurred in database, Please contact administrator "
                });
            });
    });
}

exports.Overdue_Activity = async (article_guid) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_guid', sqlType.NVarChar, article_guid);
        parameters.push(para);
        db_library
            .execute(`[IJPS].[Overdue_activity]`, parameters, db_library.query_type.SP)
            .then(async (value) => {
                let withdrawdetails = value.recordsets[0][0];
                let parametersMail = [];
                let paraMail = new param('wfid', sqlType.Int, withdrawdetails.wfid);
                parametersMail.push(paraMail);
                paraMail = new param('activityid', sqlType.Int, withdrawdetails.atyid);
                parametersMail.push(paraMail);
                paraMail = new param('mstatus', sqlType.Int, withdrawdetails.statusid);
                parametersMail.push(paraMail);
                paraMail = new param('orgid', sqlType.Int, 2);
                parametersMail.push(paraMail);
                paraMail = new param('userid', sqlType.Int, 1);
                parametersMail.push(paraMail);
                let mailTemplate = await db_library.execute_await("[IJPS].[Sendmailinfo]", parametersMail, db_library.query_type.SP);
                let article_repo = require('../Service/article.service');
                let publishername = await article_repo.get_article_publisher_name_by_articleguid(article_guid);
                if (mailTemplate.recordsets[0].length > 0) {
                    let _mailOptions = require("../../../helpers/mailOptions");
                    let _mailer = require("../../../helpers/mailer");
                    mailTemplate = mailTemplate.recordsets[0][0];

                    let MailContent = mailTemplate.MailContent;

                    MailContent = MailContent.replace("##name##", withdrawdetails.name);
                    MailContent = MailContent.replace("##articlename##", withdrawdetails.articlename);
                    MailContent = MailContent.replace("##duedate##", withdrawdetails.duedate);
                    MailContent = MailContent.replace("##ialink##", withdrawdetails.ialink);
                    MailContent = MailContent.replace("##publishername##", publishername);


                    var options = new _mailOptions();
                    options.bcc = mailTemplate.BCCMailID;
                    options.cc = mailTemplate.CCMailID;
                    options.from = mailTemplate.FromMailID;
                    options.html = MailContent;
                    options.subject = mailTemplate.Subject;
                    options.to = withdrawdetails.email;
                    options.compid = getcompid.ijps.compID;
                    _mailer.sendMail(options);
                }
                resolve(true);
            })
            .catch(err => {
                reject({
                    "message": "There is error on occurred in database, Please contact administrator "
                });
            });

    });
}