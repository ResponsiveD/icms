const config = require('../../../../config/env/config.json');
const PACKAGE = require('../../../../package.json');
const TOKEN = config[PACKAGE.environment]["DoveGetMetadataDetailsToken"];
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

var PrerequisiteValidation = async function (submissionid) {
    return await new Promise(async (resolve, reject) => {
        try {
            if (!isNaN(submissionid)) {
                let externalApis = require("../config/externalApis");
                var res = await CallGetAPI(externalApis.DoveGetMetadataDetails + submissionid)
                var response = JSON.parse(res);
                if (response.isSuccess) {
                    if (response.data != null && response.data != undefined) {
                        await ValidateProperty(response.data);
                        resolve(true);
                    }
                    else
                        reject({ "type": "validation", "message": "Request data is empty while getting Metadata from dovepress." });
                }
                else
                    reject({ "type": "validation", "message": "Unable to get Metadata from dovepress." });
            }
            else
                reject({ "type": "validation", "message": "Invalid Submission ID." });
        } catch (error) {
            reject({ "type": "error", "message": error.message });
        }
    });
}

var CallGetAPI = async function getAPI(url) {
    return new Promise((resolve, reject) => {
        try {
            let xhttp = new XMLHttpRequest();
            xhttp.timeout = 60000
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    resolve(this.responseText);
                } else if (this.readyState == 4 && (this.status == 400 || this.status == 404)) {
                    reject(this.responseText);
                }
            };
            xhttp.open("GET", url, true);
            xhttp.setRequestHeader('Authorization', 'Bearer ' + TOKEN);
            // xhttp.setRequestHeader('apikey', '7218f19e-72f5-4c9c-85f6-19d5a4d001d7');
            xhttp.send();
        } catch (error) {
            reject(error);
        }
    });
}

var ValidateProperty = async function Validate(inp) {
    return new Promise((resolve, reject) => {
        try {
            var inputjson;
            if (inp.current_status == "5f" || inp.current_status == "5a" || inp.current_status == "5c" || inp.current_status == "5aa") {
                inputjson = _5fjson;
            }
            else if (inp.current_status == "6e" || inp.current_status == "6ex") {
                inputjson = _6ejson;
            }
            else if (inp.current_status == "7e") {
                inputjson = _7ejson;
            }
            else {
                resolve(true);
                return;
            }
            Object.keys(inputjson).forEach((key) => {
                if (inp[key] == null || inp[key] == undefined || (inp[key] && typeof (inp[key]) != 'object' ? inp[key].trim().length : 1) == 0) {
                    reject(emptyMeta(key));
                    return;
                }
                if (typeof (inputjson[key]) == "object") {
                    var obj = inp[key];
                    Object.keys(inputjson[key]).forEach((ikey) => {
                        if (inp[key][ikey] == null || inp[key][ikey] == undefined) {
                            reject(emptyInnerMeta(ikey, key));
                            return;
                        }

                        if (ikey in obj) { }
                        else {
                            reject(missingInnerMeta(ikey, key));
                            return;
                        }
                    })
                }
                if (key in inp) { }
                else { reject(missingMeta(key)); return; }
            });

            resolve(true);

        } catch (error) {
            reject(error);
        }
    });
}

function missingMeta(val) {
    return { message: `${JSON.stringify(val)} is missing in meta data.` };
}

function missingInnerMeta(val, typ) {
    return { message: `${JSON.stringify(val)} is missing for ${JSON.stringify(typ)} in meta data.` };
}

function emptyMeta(val) {
    return { message: `${JSON.stringify(val)} cannot be empty/null/undefined in meta data.` };
}

function emptyInnerMeta(val, typ) {
    return { message: `${JSON.stringify(val)} cannot be empty/null/undefined for ${JSON.stringify(typ)} in meta data.` };
}

const _5fjson = {
    "submission_id": "",
    "article_doi": "",
    "current_status": "",
    "journal": {
        "code": "",
        "code_tf": "",
        "issn": "",
        "name": ""
    },
    "title": "",
    "article_type": "",
    "volume_number": "",
    "volume_year": "",
    "issue_number": "",
    "number_of_authors": "",
    "pdf_name": "",
    "copyright": "",
    "author_name": {
        "salutation": "",
        "firstname": "",
        "surname": "",
        "email": ""
    },
    "pe_name": {
        "firstname": "",
        "surname": "",
        "email": ""
    },
    "ihe_incharge": {
        "realname": "",
        "email": ""
    },
    "is_pre_editing_required": "",
    "is_copy_editing_required": "",
    "copy_editing_due_date": "",
    "pre_editing_due_date": ""
};

const _6ejson = {
    "submission_id": "",
    "article_doi": "",
    "current_status": "",
    "journal": {
        "code": "",
        "code_tf": "",
        "issn": "",
        "name": ""
    },
    "title": "",
    "article_type": "",
    "volume_number": "",
    "volume_year": "",
    "issue_number": "",
    "number_of_authors": "",
    "add_page_numbers": "",
    "add_page_numbers_date_requested": "",
    "page_start": "",
    "page_end": "",
    "remove_watermark": "",
    "remove_watermark_due_date": "",
    "author_correx": "",
    "author_correx_date_requested": "",
    "final_correx_date_requested": "",
    "copyrightyear": ""
};

const _7ejson = {
    "submission_id": "",
    "article_doi": "",
    "current_status": "",
    "journal": {
        "code": "",
        "code_tf": "",
        "issn": "",
        "name": ""
    },
    "title": "",
    "article_type": "",
    "volume_number": "",
    "volume_year": "",
    "issue_number": "",
    "number_of_authors": "",
    "pdf_name": "",
    "copyright": "",
    "author_name": {
        "salutation": "",
        "firstname": "",
        "surname": "",
        "email": ""
    },
    "pe_name": {
        "firstname": "",
        "surname": "",
        "email": ""
    },
    "ihe_incharge": {
        "realname": "",
        "email": ""
    },
    "is_pre_editing_required": "",
    "epub_date": {
        "day": "",
        "month": "",
        "year": ""
    }
};


module.exports = {
    PrerequisiteValidation
}