var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');
let common = require('../../../helpers/common');
const getcompid = require('../../../../config/constant/components.json');
const mailer = require("../../../helpers/mailer");
const exception_repo = require("../../../middleware/exception/exception") 


exports.get_mail_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[submitactivitymail]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.add_automation_sub_status= async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddAutomationSubStatus]", parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_common_mail_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[Comminsubmitactivitymail]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.reset_to_previous_aty = async (article_guid,aty_id,user_id,org_id) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_guid', sqlType.NVarChar, article_guid);
        parameters.push(para);
        para = new param('aty_id', sqlType.Int, aty_id);
        parameters.push(para);
        para = new param('user_id', sqlType.Int, user_id);
        parameters.push(para);
        para = new param('org_id', sqlType.Int, org_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[ResetToPreviousAty]", parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}


exports.get_article_main_file_path = async (ArticleId, OrgId, UserId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('ArticleId', sqlType.Int, ArticleId);
        parameters.push(para);
        para = new param('OrgId', sqlType.Int, OrgId);
        parameters.push(para);
        para = new param('UserId', sqlType.Int, UserId);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticleMainFile]", parameters, db_library.query_type.SP).then((value) => {
                if (value.recordsets[0].length > 0) {
                    let output = {
                        file_path: value.recordsets[0][0].file_path, job_guid: value.recordsets[1][0].job_guid
                        , article_id: value.recordsets[2][0].article_id, base_path: value.recordsets[3][0].base_path
                    }
                    resolve(output);
                }
                else { reject({ "message": "No main file available for this articleId" }) }
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_article_publisher_mailid_by_articleid = async (ArticleId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_id', sqlType.Int, ArticleId);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticlePublisherMailId]", parameters, db_library.query_type.SP).then((value) => {
                if (value.recordsets[0].length > 0) {
                    resolve(value.recordsets[0][0].email_id);
                }
                else { reject({ "message": "Publisher details not found." }) }
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_article_publisher_mailid_by_articleguid = async (Articleguid) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_guid', sqlType.Int, Articleguid);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticlePublisherMailId]", parameters, db_library.query_type.SP).then((value) => {
                if (value.recordsets[0].length > 0) {
                    resolve(value.recordsets[0][0].email_id);
                }
                else { reject({ "message": "Publisher details not found." }) }
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_article_publisher_name_by_articleid = async (ArticleId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_id', sqlType.Int, ArticleId);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticlePublisherName]", parameters, db_library.query_type.SP).then((value) => {
                if (value.recordsets[0].length > 0) {
                    resolve(value.recordsets[0][0].name);
                }
                else { reject({ "message": "Publisher details not found." }) }
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_article_publisher_name_by_articleguid = async (Articleguid) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_guid', sqlType.Int, Articleguid);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticlePublisherName]", parameters, db_library.query_type.SP).then((value) => {
                if (value.recordsets[0].length > 0) {
                    resolve(value.recordsets[0][0].name);
                }
                else { reject({ "message": "Publisher details not found." }) }
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.isAutomationTriggered = async (article_guid) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_guid', sqlType.NVarChar, article_guid);
        parameters.push(para);
        db_library
            .execute("[IJPS].[isAutomationTriggered]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].isAutomationTriggered);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}




exports.get_engine_detail_for_guid = async (ArticleGUID, OrgId, UserId,AutomationId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('ArticleGUID', sqlType.NVarChar, ArticleGUID);
        parameters.push(para);
        para = new param('OrgId', sqlType.Int, OrgId);
        parameters.push(para);
        para = new param('UserId', sqlType.Int, UserId);
        parameters.push(para);
        para = new param('AutomationId', sqlType.Int, AutomationId);
        parameters.push(para);
        db_library
            .execute("[ijps].[getEngineDetailForGuid]", parameters, db_library.query_type.SP).then((value) => {
                    let output = value.recordsets[0]
                    resolve(output);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_article_main_file_path_using_Article_GUID = async (ArticleGUID, OrgId, UserId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('ArticleGUID', sqlType.NVarChar, ArticleGUID);
        parameters.push(para);
        para = new param('OrgId', sqlType.Int, OrgId);
        parameters.push(para);
        para = new param('UserId', sqlType.Int, UserId);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticleMainFileUsingGUID]", parameters, db_library.query_type.SP).then((value) => {
                if (value.recordsets[0].length > 0) {
                    let output = {
                        file_path: value.recordsets[0][0].file_path, job_guid: value.recordsets[1][0].job_guid
                        , article_id: value.recordsets[2][0].article_id, base_path: value.recordsets[3][0].base_path
                    }
                    resolve(output);
                }
                else { reject({ "message": "No main file available for this articleId" }) }
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_article_main_file_path_using_Article_GUIDs = async (JsonData) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(JsonData));
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticleMainFileUsingGUIDList]", parameters, db_library.query_type.SP).then((value) => {
                if (value.recordsets[0].length > 0) {
                    let output = { "data": value.recordsets[0], "journal_name": value.recordsets[1][0].journal_name, "customer_name": value.recordsets[1][0].customer_name };
                    resolve(output);
                }
                else { reject({ "message": "No main file available for this articleIds" }) }
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}
//exports.[IJPS].[GetAutomationFilePaths]

exports.update_castoff_details = async (JsonData) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(JsonData));
        parameters.push(para);
        db_library
            .execute("[IJPS].[UpdateCastoffDetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}


exports.get_journal_type = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getJournalTypedata]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.add_edit_authors = async (Data) => {
    return await new Promise((resolve, reject) => {

        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditAuthor]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });


    });
}

exports.get_batchs = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JournalId', sqlType.Int, Data.journal_id);
        parameters.push(para);
        para = new param('UserId', sqlType.Int, Data.user_id);
        parameters.push(para);
        para = new param('OrgId', sqlType.Int, Data.org_id);
        parameters.push(para);
        para = new param('CustId', sqlType.Int, Data.cust_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetBatchs]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.update_batch = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JournalId', sqlType.Int, Data.journal_id);
        parameters.push(para);
        para = new param('UserId', sqlType.Int, Data.user_id);
        parameters.push(para);
        para = new param('OrgId', sqlType.Int, Data.org_id);
        parameters.push(para);
        para = new param('CustId', sqlType.Int, Data.cust_id);
        parameters.push(para);
        para = new param('IssueId', sqlType.Int, Data.issue_id);
        parameters.push(para);
        para = new param('IssueName', sqlType.NVarChar, Data.issue_name);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditBatchs]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_batch_articles = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('UserId', sqlType.Int, Data.user_id);
        parameters.push(para);
        para = new param('OrgId', sqlType.Int, Data.org_id);
        parameters.push(para);
        para = new param('IssueId', sqlType.Int, Data.issue_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetBatchArticles]", parameters, db_library.query_type.SP).then((value) => {
                resolve({ "article_Details": value.recordsets[0], "article_main": value.recordsets[1], "article_sub": value.recordsets[2] });
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}


exports.add_article_detail = async (Data) => {
    return await new Promise((resolve, reject) => {

        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditArticle]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.add_article_attachment = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditArticleAttch]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}


exports.add_edit_article_coauthor = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditArticleCoAuthor]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.add_edit_article_conform = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditArticleConform]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.add_article_keyword = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        if (Data.user_id == undefined) { Data.user_id = 0; }
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditArticleKeyWords]", parameters, db_library.query_type.SP).then((value) => {
                resolve({ keyword_group: value.recordsets[0], keywords: value.recordsets[1] });
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.main_upload_file = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getMainpath]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].input_path);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.supplementary_upload_file = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getsupplementarypath]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].resource_path);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

//Changes for Article resource path
exports.Article_Resource_upload_file = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getarticleresourcepath]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].resource_path);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_article_attachment = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getarticleattach]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_author_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getauthordetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_author_details_byemail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getauthordetailsbyemail]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_author_email = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getauthoremail]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_conform_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getconformdetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_coauthor_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getcoauthordetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_salutation_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getsalutationdetail]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_service_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getservicedetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_workflow_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getworkflowdetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.Submit_activity = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[Submitactivity]", parameters, db_library.query_type.SP).then((value) => {
                let result = value.recordsets[0];
                if (result === undefined) {
                    resolve(true);
                } else {
                    resolve(value.recordsets[0][0]);
                }
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.Common_Submit_activity = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[CommonSubmitactivity]", parameters, db_library.query_type.SP).then((value) => {
                let out_put = value.recordsets[0][0];
                out_put.cust_id = value.recordsets[1][0].cust_id;
                resolve(out_put);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.remove_article = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('ArticleGUID', sqlType.NVarChar, Data.article_guid);
        parameters.push(para);
        para = new param('OrgID', sqlType.Int, Data.org_id);
        parameters.push(para);
        para = new param('UserID', sqlType.Int, Data.user_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[RemoveArticle]", parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}



exports.get_metadata_details = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('Articleid', sqlType.Int, Data.article_id);
        parameters.push(para);
        para = new param('userid', sqlType.Int, Data.user_id);
        parameters.push(para);
        para = new param('orgid', sqlType.Int, Data.org_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetMetadataDetails]", parameters, db_library.query_type.SP).then((value) => {
                let results = value.recordsets[0];
                resolve(results);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_article_keywords = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('userid', sqlType.Int, Data.user_id);
        parameters.push(para);
        para = new param('orgid', sqlType.Int, Data.org_id);
        parameters.push(para);
        para = new param('Articleid', sqlType.Int, Data.article_id);
        parameters.push(para);
        para = new param('ArticleGUID', sqlType.Int, Data.article_guid);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticleKeywords]", parameters, db_library.query_type.SP).then((value) => {
                resolve({ key_word_groups: value.recordsets[0], key_words: value.recordsets[1], article_details: value.recordsets[2] });
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.getJobDetails = async (docId, atyId, UserID, OrgID) => {
    try {
        let _parameters = [];
        let para = new param('DocID', sqlType.NVarChar, docId);
        _parameters.push(para);
        para = new param('AtyID', sqlType.Int, atyId);
        _parameters.push(para);
        para = new param('userid', sqlType.Int, UserID);
        _parameters.push(para);
        para = new param('orgid', sqlType.Int, OrgID);
        _parameters.push(para);
        return await db_library.execute_await('[IJPS].[GetJobDetails]', _parameters, db_library.query_type.SP)
    } catch (error) {
        return { "message": "There is error on occurred in database, Please contact administrator " };
    }
}
exports.get_article_conform = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getarticleconform]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_nextactivity_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getnextactivity]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_icore_conversion_dtl = async (article_guid,user_id,org_id,aty_id) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_guid', sqlType.NVarChar, article_guid);
        parameters.push(para);
        para = new param('user_id', sqlType.Int, user_id);
        parameters.push(para);
        para = new param('org_id', sqlType.Int, org_id);
        parameters.push(para);
        para = new param('aty_id', sqlType.Int, aty_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetiCoreConversionDtl]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.check_iAuthor_for_activity = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('aty_id', sqlType.NVarChar, Data.nxtaty);
        parameters.push(para);
        para = new param('article_guid', sqlType.NVarChar, Data.article_guid);
        parameters.push(para);
        para = new param('org_id', sqlType.NVarChar, Data.org_id);
        parameters.push(para);
        para = new param('user_id', sqlType.NVarChar, Data.user_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[CheckiAuthorForActivity]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].iAuthorReq);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}


exports.save_article_history = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        //let JsonData = JSON.stringify(Data);
        let JsonData = JSON.stringify({"session":Data.session,"client_ip":Data.client_ip,"browser":Data.browser,
                "platform":Data.platform,"is_autosave":Data.is_autosave,"user_id":Data.user_id,
            "article_guid":Data.article_guid,"aty_id":Data.aty_id,"org_id":Data.org_id});
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[saveArticlehistory]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_suggestionID = async () => {
    return await db_library.execute_await("[IJPS].[GetSuggestionId]", undefined, db_library.query_type.SP);
}

exports.check_automation_status_of_article = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[CheckAutomationStatusOfArticle]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.update_automation_id_to_article = async (Data) => {
    return await new Promise((resolve, reject) => {
        if (Data.id == undefined || Data.id == '') { reject({ "message": "id must be provided." }) }
        else if (Data.article_id == undefined || Data.article_id == '') { reject({ "message": "article_id must be provided." }) }
        else {
            let parameters = [];
            let JsonData = JSON.stringify(Data);
            let para = new param('JsonData', sqlType.NVarChar, JsonData);
            parameters.push(para);
            db_library
                .execute("[IJPS].[UpdateAutomationIdtoArticle]", parameters, db_library.query_type.SP).then((value) => {
                    resolve(true);
                }).catch(err => {
                    reject({ "message": "There is error on occurred in database, Please contact administrator " })
                });
        }
    });
}

exports.update_automation_id_to_article_by_article_guid = async (Data) => {
    return await new Promise((resolve, reject) => {
        if (Data.id == undefined || Data.id == '') { reject({ "message": "id must be provided." }) }
        else if (Data.article_guid == undefined || Data.article_guid == '') { reject({ "message": "article_guid must be provided." }) }
        else {
            let parameters = [];
            let JsonData = JSON.stringify(Data);
            let para = new param('JsonData', sqlType.NVarChar, JsonData);
            parameters.push(para);
            db_library
                .execute("[IJPS].[UpdateAutomationIdtoArticleByGUID]", parameters, db_library.query_type.SP).then((value) => {
                    resolve(true);
                }).catch(err => {
                    reject({ "message": "There is error on occurred in database, Please contact administrator " })
                });
        }
    });
}

exports.update_article_title_and_abstract = async (title, abstract, article_guid) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('title', sqlType.NVarChar, title);
        parameters.push(para);
        para = new param('abstract', sqlType.NVarChar, abstract);
        parameters.push(para);
        para = new param('article_guid', sqlType.NVarChar, article_guid);
        parameters.push(para);
        db_library
            .execute("[IJPS].[UpdateArticleTitleAndAbstract]", parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_metadata_from_iAuthor = async (xmlblobpath) => {
    return await new Promise(async (resolve, reject) => {
        let externalApis = require("../config/externalApis")
        let url = externalApis.GetMetaDataFromiAuthor;
        let params = {};
        params.blobpath = xmlblobpath;
        await common.CallPostAPI(url, params)
            .then((value) => {
                resolve(value)
            })
            .catch((err) => {
                 exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.body), error);
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            })
    });
}


exports.put_metadata_to_iAuthor = async (params) => {
    return await new Promise(async (resolve, reject) => {
        let externalApis = require("../config/externalApis")
        let url = externalApis.PutMetaDataToiAuthor;
        await common.CallPostAPI(url, params)
            .then((value) => resolve(value)).catch((err) => reject({ "message": "There is error on occurred in database, Please contact administrator " }))
    });
}


exports.get_article_by_status = async (params, jid = 0, user_id) => {
    let parameters = [];
    para = new param('status', sqlType.NVarChar, params);
    parameters.push(para);
    para = new param('journalId', sqlType.Int, jid);
    parameters.push(para);
    para = new param('userId', sqlType.Int, user_id);
    parameters.push(para);

    return await db_library.execute_await("[IJPS].[GetArticleByStatus]", parameters, db_library.query_type.SP)
}

exports.get_article_guid_for_automation_id = async (id) => {
    let parameters = [];
    let para = new param('id', sqlType.NVarChar, id);
    parameters.push(para);
    let output = await db_library.execute_await("[IJPS].[ArticleGuidForAutomationId]", parameters, db_library.query_type.SP);
    return output.recordsets[0][0].article_guid;
}

exports.getAllhistoryfileDetail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[Getallhistory]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}
exports.getCurrentActivity = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_guid', sqlType.NVarChar, Data.article_guid);
        parameters.push(para);
        para = new param('org_id', sqlType.NVarChar, Data.org_id);
        parameters.push(para);
        para = new param('user_id', sqlType.NVarChar, Data.user_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetCurrentActivity]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].current_aty);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}



exports.issue_queue = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('issueId', sqlType.NVarChar, Data.issue_id);
        parameters.push(para);
        para = new param('org_id', sqlType.Int, Data.org_id || 1);
        parameters.push(para);
        para = new param('user_id', sqlType.Int, Data.user_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[IssueQueue]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}
exports.paper_queue = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('issueId', sqlType.NVarChar, Data.issue_id);
        parameters.push(para);
        para = new param('org_id', sqlType.Int, Data.org_id || 1);
        parameters.push(para);
        para = new param('user_id', sqlType.Int, Data.user_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[PaperQueue]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.checkToMoveNextActivity = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('article_guid', sqlType.NVarChar, Data.article_guid);
        parameters.push(para);
        // para = new param('org_id', sqlType.NVarChar, Data.org_id);
        // parameters.push(para);
        // para = new param('user_id', sqlType.NVarChar, Data.user_id);
        // parameters.push(para);
        db_library
            .execute("[IJPS].[CheckToMoveNextActivity]", parameters, db_library.query_type.SP).then((value) => {
                resolve(
                    { "current_aty": value.recordsets[0][0].current_aty, 
                      "need_submit": value.recordsets[0][0].need_submit,
                      "user_id": value.recordsets[0][0].user_id, 
                      "org_id":value.recordsets[0][0].org_id
                    }
                    );
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.resetactivityfile = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[Resetatyfile]", parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_article_final_aty_id_using_Article_GUID = async (ArticleGUID) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('ArticleGUID', sqlType.NVarChar, ArticleGUID);
        parameters.push(para);
        db_library
            .execute("[ijps].[GetArticleFinalActivity]", parameters, db_library.query_type.SP).then((value) => {
                if (value.recordsets[0].length > 0) {
                    let output = value.recordsets[0][0].aty_id;
                    resolve(output);
                }
                else { reject({ "message": "Final activity not mapped." }) }
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.wms_createjob_jrnl = async (Data, WFaty) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let clonedata = JSON.parse(JSON.stringify(Data));
        clonedata.JourFileToUpload.some(function (data) {
            data.FileContent = "";
        });
        let JsonData = JSON.stringify(clonedata);
        let AtyJsonData = JSON.stringify(WFaty);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        _parameters.push(para);
        para = new param('AtyJsonData', sqlType.NVarChar, AtyJsonData);
        _parameters.push(para);
        db_library
            .execute("[IJPS].[createjobjrnl]", _parameters, db_library.query_type.SP).then((value) => {
                let length = value.recordsets.length;
                resolve(value.recordsets[length - 1][0]);
            }).catch(err => {
                reject(err)
            });
    });
}


exports.send_aty_ialink = async (JobID, ActivityId, Name, Email, RoleID, user_id, org_id) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let para = new param('articleguid', sqlType.NVarChar, JobID);
        _parameters.push(para);
        para = new param('atyid', sqlType.Int, ActivityId);
        _parameters.push(para);
        para = new param('username', sqlType.NVarChar, Name);
        _parameters.push(para);
        para = new param('email', sqlType.NVarChar, Email);
        _parameters.push(para);
        para = new param('RoleID', sqlType.NVarChar, RoleID);
        _parameters.push(para);
        para = new param('userid', sqlType.NVarChar, user_id);
        _parameters.push(para);
        para = new param('orgid', sqlType.NVarChar, org_id);
        _parameters.push(para);
        //  return await db_library.execute_await('[IJPS].[GetJobDetails]', _parameters, db_library.query_type.SP)
        db_library
            .execute("[IJPS].[sendatyialink]", _parameters, db_library.query_type.SP).then((value) => {
                let length = value.recordsets.length
                resolve(value.recordsets[length - 1][0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_aty_status = async (JobID, ActivityId) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let para = new param('articleguid', sqlType.NVarChar, JobID);
        _parameters.push(para);
        para = new param('atyid', sqlType.Int, ActivityId);
        _parameters.push(para);
        db_library
            .execute("[IJPS].[GetActivityStatus]", _parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_WF_Detail = async (JobID) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let para = new param('articleguid', sqlType.NVarChar, JobID);
        _parameters.push(para);
        db_library
            .execute("[IJPS].[Getwfdetail]", _parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_completedfile_URI = async (JobID, ActivityId) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let para = new param('articleguid', sqlType.NVarChar, JobID);
        _parameters.push(para);
        para = new param('atyid', sqlType.Int, ActivityId);
        _parameters.push(para);
        db_library
            .execute("[IJPS].[getcompletedfile]", _parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.Check_WF_activity = async (Data) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        _parameters.push(para);
        db_library
            .execute("[IJPS].[CheckActivitywithWF]", _parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].status);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.xml_to_html_convertion = async (params) => {
    return await new Promise(async (resolve, reject) => {
        let externalApis = require("../config/externalApis")
        let url = externalApis.XmltoHtmlconvertion;
        await common.CallPostAPI(url, params)
            .then((value) => resolve(value)).catch((err) => reject(err))
    });
}

exports.xml_to_html_convertion_book = async (params) => {
    return await new Promise(async (resolve, reject) => {
        let externalApis = require("../config/externalApis")
        let url = externalApis.XmltoHtmlconvertionBook;
        await common.CallPostAPI(url, params)
            .then((value) => resolve(value)).catch((err) => reject(err))
    });
}

exports.get_meta_data = async (req) => {

    let _parameters = [];
    let para = new param('UserID', sqlType.Int, req.User.UserID);
    _parameters.push(para);
    para = new param('OrgID', sqlType.Int, req.User.OrgID);
    _parameters.push(para);
    para = new param('CompID', sqlType.Int, 1);
    _parameters.push(para);
    para = new param('CustID', sqlType.Int, 1);
    _parameters.push(para);
    para = new param('JournalID', sqlType.Int, req.query.jid);
    _parameters.push(para);

    return db_library.execute_await("[IJPS].[getMedaData]", _parameters, db_library.query_type.SP);
}


exports.get_file_url = async (req) => {

    let _parameters = [];
    let para = new param('UserID', sqlType.Int, req.User.UserID);
    _parameters.push(para);
    para = new param('OrgID', sqlType.Int, req.User.OrgID);
    // _parameters.push(para);
    // para = new param('CompID', sqlType.Int, 1);
    _parameters.push(para);
    para = new param('CustID', sqlType.Int, req.body.cust_id);
    _parameters.push(para);
    para = new param('ArticleGUID', sqlType.NVarChar, req.body.article_guid);
    _parameters.push(para);
    para = new param('DocType', sqlType.NVarChar, req.body.doc_type);
    _parameters.push(para);
    para = new param('AtyId', sqlType.Int, req.body.aty_id);
    _parameters.push(para);

    return db_library.execute_await("[IJPS].[getDocDwonloadPath]", _parameters, db_library.query_type.SP);
}   

exports.send_ialink_publisher = async (JobID, ActivityId, Name, Email, RoleID, user_id, org_id) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let para = new param('articleguid', sqlType.NVarChar, JobID);
        _parameters.push(para);
        para = new param('atyid', sqlType.Int, ActivityId);
        _parameters.push(para);
        para = new param('username', sqlType.NVarChar, Name);
        _parameters.push(para);
        para = new param('email', sqlType.NVarChar, Email);
        _parameters.push(para);
        para = new param('RoleID', sqlType.NVarChar, RoleID);
        _parameters.push(para);
        para = new param('userid', sqlType.NVarChar, user_id);
        _parameters.push(para);
        para = new param('orgid', sqlType.NVarChar, org_id);
        _parameters.push(para);
        //  return await db_library.execute_await('[IJPS].[GetJobDetails]', _parameters, db_library.query_type.SP)
        db_library
            .execute("[IJPS].[SendLinkforpublisher]", _parameters, db_library.query_type.SP).then((value) => {
                let length = value.recordsets.length
                resolve(value.recordsets[length - 1][0]);
            }).catch(err => {
                reject(err)
            });
    });
}
exports.get_pdf_support_upload_paths = async (req) => {

    let _parameters = [];
    let para = new param('UserID', sqlType.Int, req.User.UserID);
    _parameters.push(para);
    para = new param('OrgID', sqlType.Int, req.User.OrgID);
    _parameters.push(para);
    para = new param('CustID', sqlType.Int, req.body.cust_id);
    _parameters.push(para);
    para = new param('ArticleGUID', sqlType.NVarChar, req.body.article_guid);
    _parameters.push(para);
    para = new param('AtyId', sqlType.Int, req.body.aty_id);
    _parameters.push(para);

    return db_library.execute_await("[IJPS].[getPDFSupportUploadPaths]", _parameters, db_library.query_type.SP);
}   

exports.get_dashboard_NL = async (req) => {

    let _parameters = [];
    let para = new param('user_id', sqlType.Int, req.User.UserID);
    _parameters.push(para);
    para = new param('org_id', sqlType.Int, req.User.OrgID);
    _parameters.push(para);

    return db_library.execute_await("[IJPS].[DashboardNL]", _parameters, db_library.query_type.SP);
}

exports.get_dashboard_Integra_Prod = async (req) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let para = new param('UserID', sqlType.Int, req.user_id);
        _parameters.push(para);
        para = new param('OrgID', sqlType.Int, req.org_id);
        _parameters.push(para);

        db_library.execute_await("[IJPS].[GetDashboardIntegraProd]", _parameters, db_library.query_type.SP).then(value => {
            resolve(value.recordsets[0]);
        });
    })
}

exports.config_Author_sendMail = async (UserName,Email,WorkflowID,CustomerID) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let para = new param('userId', sqlType.Int, 1);
        _parameters.push(para);
        para = new param('username', sqlType.NVarChar, UserName);
        _parameters.push(para);
        para = new param('Email', sqlType.NVarChar, Email);
        _parameters.push(para);
        para = new param('RoleID', sqlType.Int, 9);
        _parameters.push(para);
        para = new param('Wfid', sqlType.Int, WorkflowID);
        _parameters.push(para);
        para = new param('CustomerID', sqlType.Int, CustomerID);
        _parameters.push(para);

        db_library.execute_await("[IJPS].[ConfigAuthorDetails]", _parameters, db_library.query_type.SP).then(value => {
            let length = value.recordsets.length;           
            let Maildetails = value.recordsets[length - 1][0];           
        
                let MailContent = Maildetails.MailContent;

                MailContent = MailContent.replace("##name##", Maildetails.name);
                MailContent = MailContent.replace("##loginname##", Maildetails.loginname);
                MailContent = MailContent.replace("##loginpassword##", Maildetails.loginpassword);
                MailContent = MailContent.replace("##iPublogin##", Maildetails.ipublogin);

                const _mailOptions = require("../../../helpers/mailOptions");
                var options = new _mailOptions();
                options.bcc = Maildetails.BCCMailID;
                options.cc = Maildetails.CCMailID;
                options.from = Maildetails.FromMailID;
                options.html = MailContent;
                options.subject = Maildetails.Subject;
                options.to = Maildetails.email;
                options.compid = getcompid.ijps.compID;
                mailer.sendMail(options);
            resolve(true);
        });

    });
}

exports.get_pdf_automation_status = async (Input) => {
    try {
        return await new Promise((resolve, reject) => {
            let _parameters = [];
            let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(Input));
            _parameters.push(para);
            db_library.execute_await("[IJPS].[GetPDFAutomationStatus]", _parameters, db_library.query_type.SP).then(value => {
                resolve(value.recordset[0]);
            });
        })
    } catch (error) {
        reject(error);
    }
}