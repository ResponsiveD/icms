const common = require('../../../helpers/common');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');
var sqlType = require('mssql');

exports.File_VersionCompare = async (article_guid, aty_id,userid,orgid) => {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            parameters.push(new param('article_guid', sqlType.NVarChar, article_guid));
            parameters.push(new param('aty_id', sqlType.Int, aty_id));
            parameters.push(new param('userid', sqlType.Int, userid));
            parameters.push(new param('orgid', sqlType.Int, orgid));
            let output = await db_library.execute_await("[IJPS].[GetCurrentAtyIdForArticleGUID]", parameters, db_library.query_type.SP);
            let iMetaPath = output.recordsets[0][0].iMetaPath;
            let PathExists = await common.doesBlobExist(iMetaPath);
            if (!PathExists) { throw { message: "iMeta file not exists in blob." } }
            iaMetaContent = await common.getBlobToText(iMetaPath);
            var iaMeta = JSON.parse(iaMetaContent);
            if (iaMeta[0].articledetails[0].ia_file_info.ia_save_version != 0 && iaMeta[0].articledetails[0].ia_file_info.ia_current_version != 0) {
                if (iaMeta[0].articledetails[0].ia_file_info.ia_save_version == iaMeta[0].articledetails[0].ia_file_info.ia_current_version) {
                    if (iaMeta[0].articledetails[0].ia_file_info.ia_save_version == iaMeta[0].articledetails[0].ia_file_info.ia_xml_version) {
                        resolve({
                            isFileValid: true,
                            StatusCode: '3',
                            ErrorMessage: 'XML generated.'
                        });
                    } else {
                        resolve({
                            isFileValid: true,
                            StatusCode: '2',
                            ErrorMessage: 'Content is saved properly.'
                        });
                    }
                } else if (iaMeta[0].ia_metainfo.ia_save_version < iaMeta[0].ia_metainfo.ia_current_version) {
                    resolve({
                        isFileValid: true,
                        StatusCode: '1',
                        ErrorMessage: 'Need to save the html.'
                    });
                } else {
                    resolve({
                        isFileValid: true,
                        StatusCode: '1',
                        ErrorMessage: 'Need to save the html.'
                    });
                }
            } else {
                resolve({
                    isFileValid: false,
                    StatusCode: '2',
                    ErrorMessage: 'Content is newly loaded'
                });
            }
        } catch (error) {
            resolve({
                isFileValid: false,
                StatusCode: '5',
                ErrorMessage: error.message
            });
        }
    });
}
