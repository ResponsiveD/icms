const common = require('../../../helpers/common');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');
var sqlType = require('mssql');


exports.add_create_job_log = async (ArticleId, Data) => {
    let parameters = [];
    para = new param('ArticleId', sqlType.Int, ArticleId);
    parameters.push(para);
    para = new param('Data', sqlType.NVarChar, Data);
    parameters.push(para);
    let Id = await db_library.execute_await("[IJPS].[AddCreateJobLog]", parameters, db_library.query_type.SP)
    return Id.recordsets[0][0].Id;
}

exports.get_pending_create_job_log = async () => {
    let parameters = [];
    let output = await db_library.execute_await("[IJPS].[GetPendingCreateJobLog]", parameters, db_library.query_type.SP)
    return output.recordsets[0];
}

exports.update_create_job_log = async (Id, isMovedtoWMS, user_id, Remark) => {
    let parameters = [];
    para = new param('Id', sqlType.Int, Id);
    parameters.push(para);
    para = new param('isMovedtoWMS', sqlType.Bit, isMovedtoWMS);
    parameters.push(para);
    para = new param('Remark', sqlType.NVarChar, Remark);
    parameters.push(para);
    let result = await db_library.execute_await("[IJPS].[UpdateCreateJobLog]", parameters, db_library.query_type.SP)
    return result.recordsets[0][0].Id
}

exports.add_mst_article = async (userId, ArticleName, OrgId, submissionid,isactive) => {
    let parameters = [];
    para = new param('userId', sqlType.Int, userId);
    parameters.push(para);
    para = new param('ArticleName', sqlType.NVarChar, ArticleName);
    parameters.push(para);
    para = new param('OrgId', sqlType.Int, OrgId);
    parameters.push(para);
    para = new param('JobGUID', sqlType.NVarChar, submissionid);
    parameters.push(para);
    para = new param('isactive', sqlType.Bit, isactive);
    parameters.push(para);
    let result = await db_library.execute_await("[IJPS].[AddMstArticle]", parameters, db_library.query_type.SP)
    return {"ArticleId" : result.recordsets[0][0].ArticleId,"IsExists":result.recordsets[0][0].isexists,"Message":result.recordsets[0][0].message}
}

exports.get_submittionid_fileinfo = async (submissionid, atyname) => {
    let parameters = [];
    para = new param('submissionid', sqlType.NVarChar, submissionid);
    parameters.push(para);
    para = new param('atyname', sqlType.NVarChar, atyname);
    parameters.push(para);

    let result = await db_library.execute_await("[IJPS].[getSubmissionIdUploadFileInfo]", parameters, db_library.query_type.SP)
    return result.recordsets[0][0]
}

exports.oct_link_log = async (Data) => {
    let parameters = [];
    let JsonData = JSON.stringify(Data);
    let para = new param('JsonData', sqlType.NVarChar, JsonData);
    parameters.push(para);
    let Id = await db_library.execute_await("[IJPS].[AddOctLog]", parameters, db_library.query_type.SP)
    return Id.recordsets[0][0].Id;
}

exports.is_dove_active_job = async(submissionid)=>{
    let parameters = [];
    let para = new param('submissionid', sqlType.NVarChar, submissionid);
    parameters.push(para);
    let output = await db_library.execute_await("[IJPS].[GetSubmissionIDStatus]", parameters, db_library.query_type.SP)
    return {"is_exists" : output.recordsets[0][0].is_exists,"is_active":output.recordsets[0][0].is_active};
}