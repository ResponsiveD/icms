var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');

exports.get_dashboard_publisher = async (user_id) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('UserID', sqlType.Int, user_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetDashboardPublisher]", parameters, db_library.query_type.SP).then((value) => {
                let results ={"count": value.recordsets[0],"values": value.recordsets[1]};
                resolve(results);
            }).catch(err => {
                reject({"message":"There is error on occurred in database, Please contact administrator "})
            });
    });
}

exports.get_dashboard_auth_rev = async (user_id) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('UserID', sqlType.Int, user_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetDashboardAuthRev]", parameters, db_library.query_type.SP).then((value) => {
                let results = value.recordsets[0];
                resolve(results);
            }).catch(err => {
                reject({"message":"There is error on occurred in database, Please contact administrator "})
            });
    });
}