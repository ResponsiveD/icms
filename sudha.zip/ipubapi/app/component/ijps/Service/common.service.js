var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');


exports.get_country_detail = async function () {
    return await new Promise((resolve, reject) => {
      try {
        var val = [];
        db_library
          .execute('[IPS].[GetCountry]', undefined, db_library.query_type.SP).then((value) => {
            value.recordset.forEach(element => {
              val.push({ "value": element.CountryName, "id": element.CountyID });
            });
            resolve(val);
          }).catch((error) => {
            reject({"message":"There is error on occurred in database, Please contact administrator "});
          });
      } catch (error) {
        reject({"message":"There is error on occurred in database, Please contact administrator "});
      }
    });
  }

  exports.get_state_details = async function (country_id) {
    return await new Promise((resolve, reject) => {
      try {
        var val = [];
        let parameters = [];
        let para = new param('CountryID', sqlType.Int, country_id);
        parameters.push(para);
        db_library
          .execute('[IPS].[GetState]', parameters, db_library.query_type.SP).then((value) => {
            value.recordset.forEach(element => {
              val.push({ "value": element.StateName, "id": element.StateID });
            });
            resolve(val);
          }).catch((error) => {
            reject({"message":"There is error on occurred in database, Please contact administrator "});
          });
      } catch (error) {
        reject({"message":"There is error on occurred in database, Please contact administrator "});
      }
    });
  }

  exports.get_city_details = async function (state_id) {
    return await new Promise((resolve, reject) => {
      try {
        var val = [];
        let parameters = [];
        let para = new param('StateID', sqlType.Int, state_id);
        parameters.push(para);
        db_library
          .execute('[IPS].[GetCities]', parameters, db_library.query_type.SP).then((value) => {
            value.recordset.forEach(element => {
              val.push({ "value": element.CityName, "id": element.CityID });
            });
            resolve(val);
          }).catch((error) => {
            reject({"message":"There is error on occurred in database, Please contact administrator "});
          });
      } catch (error) {
        reject({"message":"There is error on occurred in database, Please contact administrator "});
      }
    });
  }