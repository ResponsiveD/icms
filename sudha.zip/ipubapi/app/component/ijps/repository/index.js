"use strict";
const express = require("express");
const router = express.Router();
const article_controller = require("../controllers/article.controller");
const middelware = require('../../../middleware/auth/auth.middelware');


//article action
router.get("/get-journal-type",middelware.userAuth, article_controller.get_journal_type_value)

module.exports = router;

//sample comments test from prabakar system