'use strict'
const reviewer_service = require("../Service/reviewer.service");
const article_controller = require("../controllers/article.controller");
const output = require("../../../models/Output");
const common = require("../../../helpers/common");
const mailer = require("../../../helpers/mailer");
const article_service = require("../Service/article.service");
const getcompid = require('../../../../config/constant/components.json');
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');

exports.reviewerAcceptOrReject = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    if (req.query.id) {
      let invitataton = await reviewer_service.getInvitationDetails(req.query.id);
      if (invitataton.recordsets[0].length > 0) {
        let data = invitataton.recordsets[0][0];
        if ((data.isActive) || (!data.isActive && !data.isAccept && !data.isRejected && !data.isAccepted)) {
          _output = await reviewer_service.reviewerAcceptInvitation(data);
          if (data.isAccept && (_output.data != undefined && _output.data > 0)) {
            if (_output && data.isAccept == 1) {
              req.User = {};
              req.body.aty_id = data.aty_id;
              req.body.article_guid = data.article_guid;
              req.body.SubmitType = 8;
              req.User.UserID = _output.data;
              req.User.OrgID = 2;
              let nextActivity = await Submit_activitys(req);
              _output.data = nextActivity;
              if (nextActivity && data.isAccept) {
                await reviewer_service.mailLinkToReviewerAccept(req, data, nextActivity);
              }
            }
          }
        } else if (!data.isActive && data.isAccept && !data.isAccepted && !data.isRejected) {
          _output.is_success = true;
          _output.message = "We have enough reviewer to review the article. Thanks for your interest,  you may be contacted again in the future to help us with this manuscript.";
        } else { //if(!data.isActive && data.isAccept && data.action_status) {
          _output.is_success = true; //data.isAccept  == true ?
          _output.message = data.isAccepted == true ? data.isAccept == true ? 'Since you already accepted the manuscript, this article is pending for your review. ' : 'Since you already accepted the manuscript, you can not able to decline this article.' : "You are not authorized to agree/decline the invitation.";
        }
      } else {
        _output.is_success = true;
        _output.message = "You are not authorized to agree/decline the invitation.";
      }
    } else {
      _output.is_success = false;
      _output.message = "Id not found";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_reviewer_for_article = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let result = await reviewer_service.get_reviewer_for_article(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Reviewer details.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}


var Submit_activitys = async function (req) {
  return new Promise(async (resolve, reject) => {
    try {
      let data = {};
      data = req.body;
      data = await common.getTokenUserDetail(req, data);
      let submitstatus = await article_service.Submit_activity(data);
      let getmaildetails = await article_service.get_mail_detail(data);
      if (req.body.aty_id > 0) {
        let getnextactivity = await article_service.get_nextactivity_detail(data);
        if (getnextactivity.nxtaty > 0 && getnextactivity.status == 1) {
          let getfilepath = await common.ListAllFilesPath(getnextactivity.path);
          let moveddata = await common.Listdatamovetodest(getfilepath, getnextactivity.curtaty, getnextactivity.nxtaty);
          let getdata = await common.get_blob_data(getnextactivity.pathhis);
          let final = await common.BlobUpload(getnextactivity.pathatlin, getdata, getdata.length);
        }
        //let getmaildetails = await article_service.get_mail_detail(data);
        if (!(getmaildetails == undefined || getmaildetails.content == undefined || getmaildetails.content == '')) {
          const _mailOptions = require("../../../helpers/mailOptions");
          var options = new _mailOptions();
          options.from = getmaildetails.fromid;
          options.to = getmaildetails.toid;
          options.cc = "";
          options.bcc = getmaildetails.bcc;
          options.html = getmaildetails.content;
          options.subject = getmaildetails.subject;
          options.compid = getcompid.ijps.compID;
          let mail = await mailer.sendMail(options);
          resolve({
            "Notify": getmaildetails.notify,
            "record_id": submitstatus.record_id,
            "docid": submitstatus.docid,
            "due_date": submitstatus.due_date,
            "nxtaty": getnextactivity.nxtaty
          });
        } else {
          resolve({
            "Notify": "success",
            "record_id": submitstatus.record_id,
            "docid": submitstatus.docid,
            "due_date": submitstatus.due_date,
            "nxtaty": getnextactivity.nxtaty
          });
        }
      } else {
        resolve({
          "Notify": getmaildetails.notify
        });
      }
    } catch (error) {
      reject(error)
    }
  });
}


exports.addEdit_reviewer_for_article = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    let JsonData = JSON.stringify(data);
    let reviewerLst = await reviewer_service.get_reviewer_for_article(data)
    if (reviewerLst == undefined || reviewerLst.length == 0) {
      req.body.SubmitType = 4;
      let _out = await Submit_activitys(req);
      data.aty_id = _out.nxtaty;
    }
    data = await common.getTokenUserDetail(req, data);
    let result = await reviewer_service.addEdit_reviewer_for_article(data);
    _output.is_success = true;
    if (result[0].message != undefined) {
      _output.is_reviewer_added = false;
      _output.message = result[0].message;
    } else {
      _output.data = result;
      _output.is_reviewer_added = true;
      _output.message = "Reviewer details updated.";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.update_reviewer_action = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let result = await reviewer_service.update_reviewer_action(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Reviewer action updated.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.add_sugg_comment = async function (req, res, next) {
  var _output = new output();
  let error = null;

  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let result = await reviewer_service.add_sugg_comment(data);
    _output.data = {};
    _output.is_success = true;
    if (result[0].message != undefined) {
      _output.data['ArticleGUID'] = result[0].ArticleGUID;
      _output.isActive = false;
      _output.message = result[0].message;
    } else {
      _output.data['ArticleGUID'] = result[0].ArticleGUID;
      _output.isActive = true;
      _output.message = "Successfully updated Suggestion and Comment";
      let submitData = [];
      submitData.body = data;
      let submitstatus = article_controller.Submit_activitys(submitData);
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_sugg_comment = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.ArticleGUID = req.query.ArticleGUID;
    data.activity_id = req.query.activity_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await reviewer_service.get_sugg_comment(data);
    _output.is_success = true;
    _output.message = "Getting Suggestion and comment";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_reviewer_incompletedRecord = async function (req, res, next) {
  var _output = null;
  let error = null;
  
  try {
    let Reviewerrecords = await reviewer_service.get_reviewer_record();
    if (Reviewerrecords.length != 0) {
      for (let index = 0; index < Reviewerrecords.length; index++) {
        await reviewer_service.Withdraw_Activity(Reviewerrecords[index].ArticleGUID);
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    console.log(error);
  }
}


exports.get_reviewer_List = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.role_id = req.query.role_id;
    data.cust_id = req.query.cust_id;
    let Reviewerrecords = await reviewer_service.get_Listof_reviewer(data.role_id, data.cust_id);
    _output.data = Reviewerrecords;
    _output.is_success = true;
    _output.message = "Getting List of Reviewer successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.Check_Publisher_or_Author = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let Reviewerrecords = await reviewer_service.Check_Pub_or_Auth(data.articleguid, data.username, data.email, data.user_id, data.org_id);
    if (Reviewerrecords.status == 1) {
      _output.data = true;
      _output.is_success = true;
      _output.message = Reviewerrecords.message;
    } else {
      throw {
        "message": Reviewerrecords.message
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_Authorfinalchecks_incompletedRecord = async function (req, res, next) {
  let _output = null;
  let error = null;
  
  try {
    let Finalchecksrecords = await reviewer_service.get_Authorfinalchecks_Record();
    if (Finalchecksrecords.length != 0) {
      for (let index = 0; index < Finalchecksrecords.length; index++) {
        await reviewer_service.Overdue_Activity(Finalchecksrecords[index].ArticleGUID);
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    console.log(error);
  }
}