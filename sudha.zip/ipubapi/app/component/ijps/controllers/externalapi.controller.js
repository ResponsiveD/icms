const output = require("../../../models/Output");
const externalapi_service = require("../Service/externalapi.service");
const article_service = require("../Service/article.service");
let common = require('../../../helpers/common')
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');

exports.cast_off_process = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let data = {};
        data = await common.getTokenUserDetail(req, data);
        //data.org_id=1
        //data.user_id=1
        data.article_guids = req.body.article_guids;
        data.count = req.body.article_guids.length;
        let input = await article_service.get_article_main_file_path_using_Article_GUIDs(data);
        let castoff_input = {}
        castoff_input.Castoff = []
        input.data.forEach(element => {
            castoff_input.Castoff.push({
                "FilePath": element.FilePath,
                "ArticleGUID": element.article_guid,
                "JournalName": input.journal_name,
                "CustomerName": input.customer_name,
                "Column": "single"
            });
        });
        let Castoff_output = await externalapi_service.CastOff(castoff_input);
        Castoff_output = JSON.parse(Castoff_output);
        if (Castoff_output.Status = false) {
            throw {
                "message": Castoff_output.Message
            };
        } else {
            let CastoffDataToUpdate = {};
            CastoffDataToUpdate.user_id = data.user_id;
            CastoffDataToUpdate.org_id = data.org_id;
            CastoffDataToUpdate.castoff = [];
            Castoff_output.Data.forEach(element => {
                CastoffDataToUpdate.castoff.push({
                    "article_guid": element.ArticleGUID,
                    "page_count": element.PageCount
                })
            });
            CastoffDataToUpdate.count = CastoffDataToUpdate.castoff.length
            let ReturnValue = await article_service.update_castoff_details(CastoffDataToUpdate)
            _output.data = ReturnValue;
            _output.is_success = true;
            _output.message = "CastOff updated successfully."
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}