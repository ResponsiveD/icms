'use strict'
const common_service = require("../Service/common.service");
const output = require("../../../models/Output");
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');

exports.get_country_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let result = await common_service.get_country_detail();
    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer Country Details";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_state_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let country_id = req.query.country_id;
    let result = await common_service.get_state_details(country_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer State Details";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_city_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let state_id = req.query.state_id;
    let result = await common_service.get_city_details(state_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer City Details";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}