const { check } = require('express-validator/check');

module.exports.postFeedbackUser = [
    // question is required
    check('question').exists(),
    // articleId is required
    check('articleId').exists(),
    // activityId is required
    check('activityId').exists(),
];

module.exports.getFeedbackUser = [
    // articleId is required
    check('articleId').exists(),
    // activityId is required
    check('activityId').exists()
];