const file_upload = require('../../../helpers/common');
const output = require("../../../models/Output");
const isDocx = require('is-docx');
const docxParser = require('docx-parser');
const isDoc = require('is-doc');
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');

exports.file_byteupload = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let data = {};
        data.byte = req.body.byte
        data.path = req.body.path;
        let result = await file_upload.blobByteUpload(data);
        _output.data = {
            Path: result
        };
        _output.is_success = true;
        _output.message = "File Uploaded in blob";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.file_blob_moves = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let data = {};
        data.start = req.body.start
        data.dest = req.body.dest;
        let result = await file_upload.get_blob_data(data.start);
        let final = await file_upload.BlobUpload(data.dest, result, result.length);
        _output.data = {
            Path: final
        };
        _output.is_success = true;
        _output.message = "File Uploaded in blob";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.file_blob_delete = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        const filePath = req.body.file_path;
        let result = await file_upload.get_blob_data(filePath);
        let final = await file_upload.BlobDelete(filePath, result, result.length);
        _output.data = {
            Path: final
        };
        _output.is_success = true;
        _output.message = "File deleted from blob storage";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.ListAllFilesInPaths = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let data = {};
        data.path = req.body.path
        let final = await file_upload.ListAllFilesPath(data.path);
        _output.data = {
            Path: final
        };
        _output.is_success = true;
        _output.message = "File Uploaded in blob";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.get_blob_datas = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let data = {};
        data.start = req.body.path
        let result = await file_upload.get_blob_data(data.start);
        _output.data = result;
        _output.is_success = true;
        _output.message = "getting file in blob successfully";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}
exports.getListoffileuri = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let path = req.body.path;
        let getfilepath = await file_upload.ListAllblobPathURI(path);
        _output.data = {
            "URI": getfilepath,
            "count": getfilepath.length
        }
        _output.is_success = true;
        _output.message = "Get list of URI";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.Upload_validation = async function (req, res, next) {
    var _output = new output();
    let error = null;
    let result = null;
    
    try {
        const filename = req.files["file"].name;
        const file = req.files["file"].data;
        result = false;
        if (isDocx(file)) {
            let count = 0;
            result = await new Promise(async (resolve, reject) => {
                
                try {
                    docxParser.parseDocx(file, function (data) {
                        count = data.toString().length;
                        resolve((file.length > 0 && count > 3));
                    });
                } catch (error) {
                    resolve(false);
                }
            });
        } else if (isDoc(file)) {
            result = await new Promise(async (resolve, reject) => {
                
                try {
                    resolve((file.length > 0));
                } catch (error) {
                    resolve(false);
                }
            });
        } else {
            result = false;
        }
        _output.data = {
            filename,
            validate: result
        };
        _output.is_success = true;
        _output.message = "upload validation";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);

    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}