const wmaintegration_service = require('../Service/wmsintegration.service');
const dove_prerequisite = require('../Service/dove_prerequisite');
var path = require('path');
const output = require("../../../models/Output");
const file_upload_config = require("../../../../config/file_upload_config");
const article_service = require("../../ijps/Service/article.service");
const common = require("../../../helpers/common");
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');

exports.add_create_job_log = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let data = req.body;
        let OrgId = 1;
        let ArticleName = data.submissionid;
        let userId = 28
        let submissionid = data.submissionid;
        let isactive = data.isactive;
        // await dove_prerequisite.PrerequisiteValidation(submissionid);

        let Result = await wmaintegration_service.add_mst_article(userId, ArticleName, OrgId, submissionid, isactive);
        if (!Result.IsExists) {
            throw ({
                message: Result.Message
            });
        }
        let Id = await wmaintegration_service.add_create_job_log(Result.ArticleId, JSON.stringify(data));
        let wmsinput = {
            "DataReceived": data,
            "Id": Id
        }
        let externalApis = require("../config/externalApis");
        let url = externalApis.DoveAssignJobToWMS;
        let baseurl = await common.ActiveIPSwitchURL()
        url = "https://" + baseurl + url;
        if (isactive == 1) {
            // await dove_prerequisite.PrerequisiteValidation(submissionid);
            let wmsResponse = await common.CallWMSPostAPI(url, wmsinput);
        }
        _output.data = [];
        _output.is_success = true;
        _output.message = "Job Created Successfully for Submission ID: " + ArticleName;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = 0;
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);

        //Custom code error message for client
        _output.message = error.type === 'error' ? "Error occured while processing your request, Please contact support team." : error.message;
        res.status(HttpStatus.OK).send(_output);
    }
}

exports.get_pending_create_job_log = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let result = await wmaintegration_service.get_pending_create_job_log();
        _output.data = result;
        _output.is_success = true;
        _output.message = "Pending details.";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.update_create_job_log = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let Ids = req.body.Ids;
        let Remark = req.body.Comments;
        for (let index = 0; index < Ids.length; index++) {
            const Id = Ids[index].Id;
            await wmaintegration_service.update_create_job_log(Id, 1, 28, Remark);
            if (Ids.length - 1 == index) {
                _output.data = [];
                _output.is_success = true;
                _output.message = "Status updated successfully.";
            }
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.Upload_file = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {

        let data = req.body;
        let filedata = {};
        var paths = "";
        let file = {};

        let filesize;
        let blobupload;

        let attachfiledtl = {};
        let attachdtl = {};
        attachdtl.files = [];
        let isString = false

        var CheckExtension = file_upload_config.DoveAllowedFileExtension.indexOf(path.extname(data.Filename));
        if (data.submissionid == null || data.submissionid == undefined) {
            throw 'Submissionid showld not be empty'
        } else if (data.atyname == null || data.atyname == undefined) {
            throw 'Submissionid showld not be empty'
        } else if (data.Filename == null || data.Filename == undefined) {
            throw 'Submissionid showld not be empty'
        } else if (data.Data == null || data.Data == undefined) {
            throw 'Submissionid showld not be empty'
        } else if (CheckExtension == -1) {
            throw 'Please upload only following file format: .doc,docx,pdf,html,jpeg,jpg,xml,zip,log format\'s';
        } else {
            let detail = await wmaintegration_service.get_submittionid_fileinfo(data.submissionid, data.atyname);
            if (detail.status == 1) {
                attachdtl.article_id = detail.articleid;
                attachdtl.user_id = 1;
                attachdtl.org_id = 2;
                filedata.user_id = 1;
                filedata.org_id = 1;
                filedata.wfd_id = 12;
                filedata.job_GUID = data.submissionid;
                filedata.activity_id = detail.activityid;
                filedata.Article_GUID = detail.articleguid;
                filedata.filename = data.Filename;


                if (data.ismainfile) {
                    paths = await article_service.main_upload_file(filedata);
                    attachfiledtl.is_main_file = 1
                }
                else {
                    paths = await article_service.Article_Resource_upload_file(filedata);//Changes For article resource path
                    attachfiledtl.is_main_file = 0
                }


                file.byte = {};
                file.path = paths;
                //For file upload base 64 changes.
                if (data.Data.data == undefined) {
                    file.byte.data = Buffer.from(data.Data, 'base64');
                } else {
                    file.byte = data.Data;
                }
                filesize = await common.bytesToSize(file.byte.data.length);
                blobupload = await common.blobByteUpload(file);
                //}

                attachfiledtl.id = 0;
                attachfiledtl.file_name = data.Filename;
                attachfiledtl.file_size = filesize
                attachfiledtl.path = blobupload
                attachfiledtl.is_active = 1
                attachdtl.files.push(attachfiledtl);
                await article_service.add_article_attachment(attachdtl);

                _output.data = blobupload;
                _output.is_success = true;
                _output.message = "File uploaded successfully.";
            } else {
                _output.data = "";
                _output.is_success = false;
                _output.message = detail.message;
            }
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
    }
}

exports.get_oct_link = async function (req, res, next) {
    let _output = {};
    _output.data = {};
    let error = null;

    
    try {
        let data = JSON.stringify(req.body);

        let externalApis = require("../config/externalApis")
        let url = externalApis.GetOCTLink;
        let result = await common.CallEncodePostAPI(url, data);

        let oct_link_log = {};
        oct_link_log.api_end_point = url;
        oct_link_log.client_id = "iCorrectProof";
        oct_link_log.in_request = JSON.stringify(data);
        oct_link_log.out_response = JSON.stringify(result);
        oct_link_log.is_move_to_oct = result.is_success;
        oct_link_log.is_success = result.is_success;
        let Id = await wmaintegration_service.oct_link_log(oct_link_log);

        _output = result;

        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);

    } catch (error) {
        get_oct_link_output.data.oct_link = null;
        get_oct_link_output.data.status = false;
        get_oct_link_output.data.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.close_oct_link = async function (req, res, next) {
    let _output = {};
    _output.data = {};
    let error = null;
    
    try {
        let data = JSON.stringify(req.body);
        let externalApis = require("../config/externalApis")
        let url = externalApis.CloseOCTLink;
        let result = await common.CallEncodePostAPI(url, data);

        let oct_link_log = {};
        oct_link_log.api_end_point = url;
        oct_link_log.client_id = "iCorrectProof";
        oct_link_log.in_request = JSON.stringify(data);
        oct_link_log.out_response = JSON.stringify(result);
        oct_link_log.is_move_to_oct = result.data.status;
        oct_link_log.is_success = result.data.status;
        let Id = await wmaintegration_service.oct_link_log(oct_link_log);

        _output = result;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data.status = false;
        _output.data.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.is_dove_active_job = async function (req, res, next) {
    var _output = new output();
    
    try {
        let Submissionid = req.query.submission_id;
        if (Submissionid == undefined || Submissionid == '') {
            throw {
                "message": "submission_id must be provided."
            }
        }
        let Value = await wmaintegration_service.is_dove_active_job(Submissionid);
        if (Value.is_exists == 0) {
            throw {
                "message": "Invalid submission_id"
            }
        } else {
            _output.data = {
                "submission_id": Submissionid,
                "is_active": Value.is_active
            };
            _output.is_success = true;
            _output.message = "Status updated successfully.";
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
    }
    res.send(_output);
}