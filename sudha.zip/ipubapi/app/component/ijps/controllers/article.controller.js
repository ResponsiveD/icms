'use strict'
const article_service = require("../Service/article.service");
const output = require("../../../models/Output");
const common = require("../../../helpers/common");
const mailer = require("../../../helpers/mailer");
const loginService_repo = require('../../../repository/login.service');
const getcompid = require('../../../../config/constant/components.json');
const automation_repository = require("../../../repository/automation.service");
const file_upload_config = require("../../../../config/file_upload_config");
const basepath = file_upload_config.CloudCredentials().cloudBasePath;
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');


exports.get_journal_type_value = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.cust_id = req.query.cust_id;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID     
    _output.data = await article_service.get_journal_type(data);
    _output.is_success = true;
    _output.message = "Getting journal type Successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

var xml_to_html_convertion_book = async function (article_guid, aty_id, user_id, org_id) {
  return await new Promise(async (resolve, reject) => {
    try {
      let dbout = await article_service.get_icore_conversion_dtl(article_guid, user_id, org_id, aty_id).catch(err => {
        throw err
      });
      let xmlContent = await common.getBlobToText(dbout.Path).catch(err => {
        throw err
      });
      let input = {
        "conversion_type": "book",
        "conversion_method": "forward",
        "DOMContent": xmlContent,
        "metaData": "",
        "comment": "",
        "equation": "",
        "configuration": {
          "resourcepath": dbout.ResPath,
          "blobDomain": dbout.BasePath,
          "customer_dtd": dbout.Cust
        }
      }
      let output = await article_service.xml_to_html_convertion_book(input);
      output = JSON.parse(output);
      if (output.is_success == false) {
        reject(output.error_stack);
      } else {
        let apiout = output;
        let DOMContentPath = dbout.htmlPath;
        let MetaDataPath = dbout.MetaPath;
        let CommentsPath = dbout.CommentsPath;
        let KeywordsPath = dbout.KeywordsPath;
        let authorInfoPath = dbout.authorInfoPath;
        let authorInfoMasterAffiliationPath = dbout.authorInfoMasterAffiliationPath;
        let EquationJsonPath = dbout.EquationJsonPath;
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(DOMContentPath, apiout.DOMContent);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(MetaDataPath, apiout.MetaData);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(CommentsPath, apiout.Comments);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(KeywordsPath, apiout.Keywords);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(authorInfoPath, apiout.authorInfo);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(authorInfoMasterAffiliationPath, apiout.authorInfoMasterAffiliation);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(EquationJsonPath, apiout.EquationJson);
        }
        resolve(true);
      }
    } catch (error) {
      reject(error);
    }
  });
}

var xml_to_html_convertions = async function (article_guid, aty_id, user_id, org_id) {
  return await new Promise(async (resolve, reject) => {
    let error = null;
    try {
      let result = await article_service.getJobDetails(article_guid, aty_id, user_id, org_id);
      if (result.recordset.length > 0) {
        let resultObject = {}
        let name = Object.keys(result.recordset[0])[0];
        let JsonData = result.recordset[0][name];
        if (JsonData != '' && JsonData != undefined) {
          resultObject['sMessage'] = "Content Found for GUID";
          resultObject['is_success'] = true;
          let resultarray = JSON.parse(JsonData);
          resultObject['oData'] = resultarray[0];
          let mData = {}
          mData.metaData = resultObject
          let xmltohtml = await article_service.xml_to_html_convertion(mData);
          let xmlstatus = JSON.parse(xmltohtml);
          if (xmlstatus.length > 0) {
            xmlstatus = xmlstatus[0];
          }
          if (xmlstatus.isSuccess) {
            resolve(true)
          } else {
            let error = {
              "message": "Create job failed due to xml to html conversion failed"
            }
            automation_repository.alert_xml_to_html_failure(article_guid, aty_id, user_id, org_id, error)
            reject(error);
          }
        } else {
          let error = {
            "message": "Create job failed due to getjob data empty for xml to html conversion"
          }
          automation_repository.alert_xml_to_html_failure(article_guid, aty_id, user_id, org_id, error)
          reject(error);
        }
      } else {
        let error = {
          "message": "Create job failed due to getjob data empty for xml to html conversion"
        }
        automation_repository.alert_xml_to_html_failure(article_guid, aty_id, user_id, org_id, error)
        reject(error);
      }
    } catch (error) {
      automation_repository.alert_xml_to_html_failure(article_guid, aty_id, user_id, org_id, error)
      reject(error);
    }
  });
}

exports.add_edit_author = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.add_edit_authors(data);
    _output.is_success = true;
    _output.message = "co-author updated Successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_batchs = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    if (data.journal_id == undefined || data.journal_id == '') {
      throw {
        "message": "journal_id must be provided."
      }
    } else if (data.cust_id == undefined || data.cust_id == '') {
      throw {
        "message": "cust_id must be provided."
      }
    } else {
      _output.data = await article_service.get_batchs(data);
      _output.is_success = true;
      _output.message = "Get Batchs";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.update_batch = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    if (data.journal_id == undefined || data.journal_id == '') {
      throw {
        "message": "journal_id must be provided."
      }
    } else if (data.cust_id == undefined || data.cust_id == '') {
      throw {
        "message": "cust_id must be provided."
      }
    } else if (data.issue_name == undefined || data.issue_name == '') {
      throw {
        "message": "issue_name must be provided."
      }
    } else if (data.issue_id == undefined) {
      throw {
        "message": "issue_id must be provided."
      }
    } else {
      _output.data = await article_service.update_batch(data);
      _output.is_success = true;
      _output.message = "Get Batchs";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_batch_articles = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.issue_id = req.query.issue_id;
    data = await common.getTokenUserDetail(req, data);
    if (data.issue_id == undefined || data.issue_id == '') {
      throw {
        "message": "issue_id must be provided."
      }
    } else {
      _output.data = await article_service.get_batch_articles(data);
      _output.is_success = true;
      _output.message = "Get Batch articles";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.add_article_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.add_article_detail(data);
    _output.is_success = true;
    _output.message = "Article updated successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.add_article_attachments = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.add_article_attachment(data);
    if (req.body.files.length > 0) {
      for (let index = 0; index < req.body.files.length; index++) {
        const element = req.body.files[index];
        if (element.is_active != true) {
          let filePath = element.path.split('/').splice(4).join('/');
          let result = await common.get_blob_data(filePath);
          await common.BlobDelete(filePath, result, result.length);
        }
      }
    }
    _output.is_success = true;
    _output.message = "Article attachment updated successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.add_edit_article_coauthors = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.add_edit_article_coauthor(data);
    _output.is_success = true;
    _output.message = "Article co-author updated Successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.add_edit_article_conforms = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.add_edit_article_conform(data);
    _output.is_success = true;
    _output.message = "Article conforms successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.add_article_keywords = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let output = await article_service.add_article_keyword(data);
    let Result = {};
    Result.key_word_groups = [];
    Result.article_id = data.article_id
    if (output.keyword_group == undefined) {
      throw ({
        "message": "check input"
      });
    }
    for (let i = 0; i < output.keyword_group.length; i++) {
      const _ = require("lodash");
      let _out = {};
      _out.key_word_group_id = output.keyword_group[i].key_word_group_id
      _out.key_word_group_name = output.keyword_group[i].key_word_group_name
      _out.is_active = 1
      _out.key_words = _.filter(output.keywords, ['key_word_group_id', _out.key_word_group_id])
      Result.key_word_groups.push(_out);
      if (i == output.keyword_group.length - 1) {
        _output.data = Result;
        _output.is_success = true;
        _output.message = "Article keywords updated successfully";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
      }
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.main_upload_files = async function (req, res, next) {
  var _output = new output();
  let error = null;
  var path = require('path');
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let file = req.files["file"];
    var CheckMimeType = file_upload_config.AllowedFileType.indexOf(req.files.file.mimetype);
    var CheckExtension = file_upload_config.AllowedFileExtension.indexOf(path.extname(req.files.file.name).toLowerCase());
    if (CheckExtension != -1 && CheckMimeType != -1) {
      data.filename = file.name;
      let filepath = await article_service.main_upload_file(data);
      _output.data = {
        "path": await common.blobFileUpload(file, filepath),
        "size": common.bytesToSize(file.data.length),
        "filename": path.basename(filepath)
      }
      _output.is_success = true;
      _output.message = "File uploaded successfully";
    } else {
      _output.data = "";
      _output.is_success = false;
      _output.message = "Please upload only following file format: .jpeg, .jpg, .pdf, .png, .doc, .docx, .xls, .xlsx, .xlsb, .ppt, .pptx, .msg, postscript and ms office file format\'s";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
  res.setTimeout(1000000); // 10 minutes
  res.send(_output);
}

exports.supplementary_upload_files = async function (req, res, next) {
  var _output = new output();
  let error = null;
  var path = require('path')
  
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let file = req.files["file"];
    var CheckMimeType = file_upload_config.AllowedFileType.indexOf(req.files.file.mimetype);
    var CheckExtension = file_upload_config.AllowedFileExtension.indexOf(path.extname(req.files.file.name).toLowerCase());
    if (CheckExtension != -1 && CheckMimeType != -1) {
      data.filename = file.name;
      let filepath = await article_service.supplementary_upload_file(data);
      _output.data = {
        "path": await common.blobFileUpload(file, filepath),
        "size": common.bytesToSize(file.data.length)
      }
      _output.is_success = true;
      _output.message = "File uploaded successfully";
    } else {
      _output.data = "";
      _output.is_success = false;
      _output.message = "Please upload only following file format: .jpeg, .jpg, .pdf, .png, .doc, .docx, .xls, .xlsx, .xlsb, .ppt, .pptx, .msg, postscript and ms office file format\'s";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
  res.setTimeout(1000000); // 10 minutes
  res.send(_output);
}

exports.get_article_attachments = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_article_attachment(data);
    _output.is_success = true;
    _output.message = "Getting article attachments successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_author_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.author_id = req.query.author_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_author_detail(data);
    _output.is_success = true;
    _output.message = "Getting author details successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_author_details_by_email = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.email_id = req.query.email_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_author_details_byemail(data);
    _output.is_success = true;
    _output.message = "Getting author details successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_author_emails = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_author_email(data);
    _output.is_success = true;
    _output.message = "Getting author Emails successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_conform_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.cust_id = req.query.cust_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_conform_detail(data);
    _output.is_success = true;
    _output.message = "Getting Conform Details successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_coauthor_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_coauthor_detail(data);
    _output.is_success = true;
    _output.message = "Getting coauthor Details Successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_salutation_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_salutation_detail(data);
    _output.is_success = true;
    _output.message = "Getting salutation Details Successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_service_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.comp_id = 2;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_service_detail(data);
    _output.is_success = true;
    _output.message = "Getting Service Details Successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_workflow_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.ser_id = req.query.ser_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_workflow_detail(data);
    _output.is_success = true;
    _output.message = "Getting Workflow Details Successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}


exports.Submit_activitys = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let submitstatus = await article_service.Submit_activity(data);
    let getmaildetails = await article_service.get_mail_detail(data);
    if (submitstatus.record_id != null && submitstatus.record_id != undefined && submitstatus.record_id == 'atycompleted') {
      _output.is_success = true;
      _output.data = {
        "articleguid": data.article_guid
      };
      _output.Status_code = submitstatus.Status_code;
      _output.message = submitstatus.message;
    } else {
      if (req.body.aty_id > 0) {
        let getnextactivity = await article_service.get_nextactivity_detail(data);
        if (getnextactivity.nxtaty != null && getnextactivity.status == 1) {
          let getfilepath = await common.ListAllFilesPath(getnextactivity.path);
          let moveddata = await common.Listdatamovetodest(getfilepath, getnextactivity.curtaty, getnextactivity.nxtaty);
          let getdata = await common.get_blob_data(getnextactivity.pathhis);
          let final = await common.BlobUpload(getnextactivity.pathatlin, getdata, getdata.length);
        }
        //let getmaildetails = await article_service.get_mail_detail(data);
        if (!(getmaildetails == undefined || getmaildetails.content == undefined || getmaildetails.content == '')) {
          const _mailOptions = require("../../../helpers/mailOptions");
          var options = new _mailOptions();
          options.from = getmaildetails.fromid;
          options.to = getmaildetails.toid;
          options.cc = "";
          options.bcc = getmaildetails.bcc;
          options.html = getmaildetails.content;
          options.subject = getmaildetails.subject;
          options.compid = getcompid.ijps.compID;
          let mail = await mailer.sendMail(options);
          _output.data = {
            "Notify": getmaildetails.notify,
            "record_id": submitstatus.record_id,
            "docid": submitstatus.docid,
            "due_date": submitstatus.due_date
          }
        } else {
          _output.data = {
            "Notify": "success",
            "record_id": submitstatus.record_id,
            "docid": submitstatus.docid,
            "due_date": submitstatus.due_date
          }
        }
      } else {
        _output.data = {
          "Notify": getmaildetails.notify
        }
      }
      _output.is_success = true;
      _output.message = "Submit activity completed Successfully";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.submitActivity = async function (req) {
  return await new Promise(async (resolve, reject) => {
    var _output = new output();
    
    try {
      let data = {};
      data = req.body;
      if (data.org_id == undefined || data.user_id == undefined) {
        data = await common.getTokenUserDetail(req, data);
      }
      let submitstatus = await article_service.Common_Submit_activity(data);
      let getmaildetails = await article_service.get_common_mail_detail(data);
      if (req.body.aty_id > 0) {
        let getnextactivity = await article_service.get_nextactivity_detail(data);
        if (getnextactivity.nxtaty != null && getnextactivity.status == 1) {
          let getfilepath = await common.ListAllFilesPath(getnextactivity.path);
          let moveddata = await common.Listdatamovetodest(getfilepath, getnextactivity.curtaty, getnextactivity.nxtaty);
          let iAuthorCheck = 0;
          try {
            data.nxtaty = getnextactivity.nxtaty;
            iAuthorCheck = await article_service.check_iAuthor_for_activity(data);
            let getdata = await common.get_blob_data(getnextactivity.pathhis);
            let final = await common.BlobUpload(getnextactivity.pathatlin, getdata, getdata.length);
          } catch (err) {
            if (iAuthorCheck == 1) {
              // let out = await xml_to_html_convertions(data.article_guid, data.nxtaty, data.user_id, data.org_id).catch((err) => {
              //   article_service.reset_to_previous_aty(data.article_guid, data.nxtaty, data.user_id, data.org_id);
              //   throw err;
              // })
              if (submitstatus.cust_id == 6) {
                await xml_to_html_convertion_book(data.article_guid, data.nxtaty, data.user_id, data.org_id).catch((err) => {
                  article_service.reset_to_previous_aty(data.article_guid, data.nxtaty, data.user_id, data.org_id);
                  throw err;
                })
              } else {
                await xml_to_html_convertions(data.article_guid, data.nxtaty, data.user_id, data.org_id).catch((err) => {
                  article_service.reset_to_previous_aty(data.article_guid, data.nxtaty, data.user_id, data.org_id);
                  throw err;
                })
              }
            }
          }
        }
        if (!(getmaildetails == undefined || getmaildetails.content == undefined || getmaildetails.content == '')) {
          const _mailOptions = require("../../../helpers/mailOptions");
          var options = new _mailOptions();
          options.from = getmaildetails.fromid;
          options.to = getmaildetails.toid;
          options.cc = "";
          options.bcc = getmaildetails.bcc;
          options.html = getmaildetails.content;
          options.subject = getmaildetails.subject;
          options.compid = getcompid.ijps.compID;
          let mail = await mailer.sendMail(options);
          _output.data = {
            "Notify": getmaildetails.notify,
            "record_id": submitstatus.record_id,
            "docid": submitstatus.docid,
            "due_date": submitstatus.due_date
          }
        } else {
          _output.data = {
            "Notify": "success",
            "record_id": submitstatus.record_id,
            "docid": submitstatus.docid,
            "due_date": submitstatus.due_date
          }
        }
      } else {
        _output.data = {
          "Notify": getmaildetails.notify
        }
      }
      _output.is_success = true;
      _output.message = "Submit activity completed Successfully";
      resolve(_output);
    } catch (error) {
      _output.data = "";
      _output.is_success = false;
      _output.message = error.message;
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 0);
      reject(_output);
    }
  })
}

exports.manual_word_to_icore_support = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data.SubmitType = 3;
    data = await common.getTokenUserDetail(req, data);
    let file = req.files["file"];
    data.filename = file.name;
    data.activity_id = data.aty_id;
    let iCorePath = await article_service.main_upload_file(data);
    let exisitPathExt = iCorePath.slice((iCorePath.lastIndexOf(".") - 1 >>> 0) + 2);
    iCorePath = iCorePath.replace(exisitPathExt, 'xml')
    let xmlBlobUpload = await common.blobFileUpload(file, iCorePath)
    let submitstatus = await article_service.Common_Submit_activity(data);
    let getmaildetails = await article_service.get_common_mail_detail(data);
    if (req.body.aty_id > 0) {
      let getnextactivity = await article_service.get_nextactivity_detail(data);
      if (getnextactivity.nxtaty != null && getnextactivity.status == 1) {
        let getfilepath = await common.ListAllFilesPath(getnextactivity.path);
        let moveddata = await common.Listdatamovetodest(getfilepath, getnextactivity.curtaty, getnextactivity.nxtaty);
        let iAuthorCheck = 0
        try {
          data.nxtaty = getnextactivity.nxtaty;
          iAuthorCheck = await article_service.check_iAuthor_for_activity(data);
          let getdata = await common.get_blob_data(getnextactivity.pathhis);
          let final = await common.BlobUpload(getnextactivity.pathatlin, getdata, getdata.length);
        } catch (err) {
          if (iAuthorCheck == 1) {
            if (submitstatus.cust_id == 6) {
              await xml_to_html_convertion_book(data.article_guid, data.nxtaty, data.user_id, data.org_id).catch((err) => {
                article_service.reset_to_previous_aty(data.article_guid, data.nxtaty, data.user_id, data.org_id);
                throw err;
              })
            } else {
              await xml_to_html_convertions(data.article_guid, data.nxtaty, data.user_id, data.org_id).catch((err) => {
                article_service.reset_to_previous_aty(data.article_guid, data.nxtaty, data.user_id, data.org_id);
                throw err;
              })
            }
          }
        }
      }
      if (!(getmaildetails == undefined || getmaildetails.content == undefined || getmaildetails.content == '')) {
        const _mailOptions = require("../../../helpers/mailOptions");
        var options = new _mailOptions();
        options.from = getmaildetails.fromid;
        options.to = getmaildetails.toid;
        options.cc = "";
        options.bcc = getmaildetails.bcc;
        options.html = getmaildetails.content;
        options.subject = getmaildetails.subject;
        options.compid = getcompid.ijps.compID;
        let mail = await mailer.sendMail(options);
        _output.data = {
          "Notify": getmaildetails.notify,
          "record_id": submitstatus.record_id,
          "docid": submitstatus.docid,
          "due_date": submitstatus.due_date
        }
      } else {
        _output.data = {
          "Notify": "success",
          "record_id": submitstatus.record_id,
          "docid": submitstatus.docid,
          "due_date": submitstatus.due_date
        }
      }
    } else {
      _output.data = {
        "Notify": getmaildetails.notify
      }
    }
    _output.is_success = true;
    _output.message = "Manual word to icore xml support successfully Completed.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.upload_xml_pdf = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data.SubmitType = 3;
    data = await common.getTokenUserDetail(req, data);
    let PDFfile = req.files["pdf"];
    let XMLfile = req.files["xml"];
    data.activity_id = data.aty_id;
    // if (PDFfile == undefined || PDFfile == "") { throw { "message": "PDFfile must be provided." } };
    // if (XMLfile == undefined || XMLfile == "") { throw { "message": "XMLfile must be provided." } };
    if (req.body.cust_id == undefined || req.body.cust_id == "") {
      throw {
        "message": "cust_id must be provided."
      }
    };
    if (req.body.article_guid == undefined || req.body.article_guid == "") {
      throw {
        "message": "article_guid must be provided."
      }
    };
    if (req.body.aty_id == undefined || req.body.aty_id == "") {
      throw {
        "message": "aty_id must be provided."
      }
    };
    let UploadPath = await article_service.get_pdf_support_upload_paths(req);
    if (UploadPath.recordsets[0].length < 1) {
      throw {
        "message": "Path configeration error contact admin."
      }
    }
    PDFfile ? await common.blobFileUpload(PDFfile, UploadPath.recordsets[0][0].pathPDFURL) : '';
    XMLfile ? await common.blobFileUpload(XMLfile, UploadPath.recordsets[0][0].pathXMLURL) : '';
    let submitstatus = await article_service.Submit_activity(data);
    let getmaildetails = await article_service.get_mail_detail(data);
    if (req.body.aty_id > 0) {
      let getnextactivity = await article_service.get_nextactivity_detail(data);
      if (getnextactivity.nxtaty != null && getnextactivity.status == 1) {
        let getfilepath = await common.ListAllFilesPath(getnextactivity.path);
        let moveddata = await common.Listdatamovetodest(getfilepath, getnextactivity.curtaty, getnextactivity.nxtaty);
        let getdata = await common.get_blob_data(getnextactivity.pathhis);
        let final = await common.BlobUpload(getnextactivity.pathatlin, getdata, getdata.length);
      }
      //let getmaildetails = await article_service.get_mail_detail(data);
      if (!(getmaildetails == undefined || getmaildetails.content == undefined || getmaildetails.content == '')) {
        const _mailOptions = require("../../../helpers/mailOptions");
        var options = new _mailOptions();
        options.from = getmaildetails.fromid;
        options.to = getmaildetails.toid;
        options.cc = "";
        options.bcc = getmaildetails.bcc;
        options.html = getmaildetails.content;
        options.subject = getmaildetails.subject;
        options.compid = getcompid.ijps.compID;
        let mail = await mailer.sendMail(options);
        _output.data = {
          "Notify": getmaildetails.notify,
          "record_id": submitstatus.record_id,
          "docid": submitstatus.docid,
          "due_date": submitstatus.due_date
        }
      } else {
        _output.data = {
          "Notify": "success",
          "record_id": submitstatus.record_id,
          "docid": submitstatus.docid,
          "due_date": submitstatus.due_date
        }
      }
    } else {
      _output.data = {
        "Notify": getmaildetails.notify
      }
    }
    _output.is_success = true;
    _output.message = "Manual PDF support successfully Completed.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.pdf_support_upload = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data.SubmitType = 3;
    data = await common.getTokenUserDetail(req, data);
    let PDFfile = req.files["pdf"];
    let XMLfile = req.files["xml"];
    data.activity_id = data.aty_id;
    if (PDFfile == undefined || PDFfile == "") {
      throw {
        "message": "PDFfile must be provided."
      }
    };
    if (XMLfile == undefined || XMLfile == "") {
      throw {
        "message": "XMLfile must be provided."
      }
    };
    if (req.body.cust_id == undefined || req.body.cust_id == "") {
      throw {
        "message": "cust_id must be provided."
      }
    };
    if (req.body.article_guid == undefined || req.body.article_guid == "") {
      throw {
        "message": "article_guid must be provided."
      }
    };
    if (req.body.aty_id == undefined || req.body.aty_id == "") {
      throw {
        "message": "aty_id must be provided."
      }
    };
    let UploadPath = await article_service.get_pdf_support_upload_paths(req);
    if (UploadPath.recordsets[0].length < 1) {
      throw {
        "message": "Path configeration error contact admin."
      }
    }
    await common.blobFileUpload(PDFfile, UploadPath.recordsets[0][0].pathPDFURL);
    await common.blobFileUpload(XMLfile, UploadPath.recordsets[0][0].pathXMLURL)
    let submitstatus = await article_service.Common_Submit_activity(data);
    let getmaildetails = await article_service.get_common_mail_detail(data);
    if (req.body.aty_id > 0) {
      let getnextactivity = await article_service.get_nextactivity_detail(data);
      if (getnextactivity.nxtaty != null && getnextactivity.status == 1) {
        let getfilepath = await common.ListAllFilesPath(getnextactivity.path);
        let moveddata = await common.Listdatamovetodest(getfilepath, getnextactivity.curtaty, getnextactivity.nxtaty);
        let iAuthorCheck = 0
        try {
          data.nxtaty = getnextactivity.nxtaty;
          iAuthorCheck = await article_service.check_iAuthor_for_activity(data);
          let getdata = await common.get_blob_data(getnextactivity.pathhis);
          let final = await common.BlobUpload(getnextactivity.pathatlin, getdata, getdata.length);
        } catch (err) {
          if (iAuthorCheck == 1) {
            if (submitstatus.cust_id == 6) {
              await xml_to_html_convertion_book(data.article_guid, data.nxtaty, data.user_id, data.org_id).catch((err) => {
                article_service.reset_to_previous_aty(data.article_guid, data.nxtaty, data.user_id, data.org_id);
                throw err;
              })
            } else {
              await xml_to_html_convertions(data.article_guid, data.nxtaty, data.user_id, data.org_id).catch((err) => {
                article_service.reset_to_previous_aty(data.article_guid, data.nxtaty, data.user_id, data.org_id);
                throw err;
              })
            }
          }
        }
      }
      if (!(getmaildetails == undefined || getmaildetails.content == undefined || getmaildetails.content == '')) {
        const _mailOptions = require("../../../helpers/mailOptions");
        var options = new _mailOptions();
        options.from = getmaildetails.fromid;
        options.to = getmaildetails.toid;
        options.cc = "";
        options.bcc = getmaildetails.bcc;
        options.html = getmaildetails.content;
        options.subject = getmaildetails.subject;
        options.compid = getcompid.ijps.compID;
        let mail = await mailer.sendMail(options);
        _output.data = {
          "Notify": getmaildetails.notify,
          "record_id": submitstatus.record_id,
          "docid": submitstatus.docid,
          "due_date": submitstatus.due_date
        }
      } else {
        _output.data = {
          "Notify": "success",
          "record_id": submitstatus.record_id,
          "docid": submitstatus.docid,
          "due_date": submitstatus.due_date
        }
      }
    } else {
      _output.data = {
        "Notify": getmaildetails.notify
      }
    }
    _output.is_success = true;
    _output.message = "Manual PDF support successfully Completed.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.Common_Submit_activitys = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let submitstatus = await article_service.Common_Submit_activity(data);
    let getmaildetails = await article_service.get_common_mail_detail(data);
    if (req.body.aty_id > 0) {
      let getnextactivity = await article_service.get_nextactivity_detail(data);
      if (getnextactivity.nxtaty != null && getnextactivity.status == 1) {
        let getfilepath = await common.ListAllFilesPath(getnextactivity.path);
        let moveddata = await common.Listdatamovetodest(getfilepath, getnextactivity.curtaty, getnextactivity.nxtaty);
        let iAuthorCheck = 0
        try {
          data.nxtaty = getnextactivity.nxtaty;
          iAuthorCheck = await article_service.check_iAuthor_for_activity(data);
          let getdata = await common.get_blob_data(getnextactivity.pathhis);
          let final = await common.BlobUpload(getnextactivity.pathatlin, getdata, getdata.length);
        } catch (err) {
          if (iAuthorCheck == 1) {
            if (submitstatus.cust_id == 6) {
              await xml_to_html_convertion_book(data.article_guid, data.nxtaty, data.user_id, data.org_id).catch((err) => {
                article_service.reset_to_previous_aty(data.article_guid, data.nxtaty, data.user_id, data.org_id);
                throw err;
              })
            } else {
              await xml_to_html_convertions(data.article_guid, data.nxtaty, data.user_id, data.org_id).catch((err) => {
                article_service.reset_to_previous_aty(data.article_guid, data.nxtaty, data.user_id, data.org_id);
                throw err;
              })
            }
          }
        }
      }
      if (!(getmaildetails == undefined || getmaildetails.content == undefined || getmaildetails.content == '')) {
        const _mailOptions = require("../../../helpers/mailOptions");
        var options = new _mailOptions();
        options.from = getmaildetails.fromid;
        options.to = getmaildetails.toid;
        options.cc = "";
        options.bcc = getmaildetails.bcc;
        options.html = getmaildetails.content;
        options.subject = getmaildetails.subject;
        options.compid = getcompid.ijps.compID;
        let mail = await mailer.sendMail(options);
        _output.data = {
          "Notify": getmaildetails.notify,
          "record_id": submitstatus.record_id,
          "docid": submitstatus.docid,
          "due_date": submitstatus.due_date
        }
      } else {
        _output.data = {
          "Notify": "success",
          "record_id": submitstatus.record_id,
          "docid": submitstatus.docid,
          "due_date": submitstatus.due_date
        }
      }
    } else {
      _output.data = {
        "Notify": getmaildetails.notify
      }
    }
    _output.is_success = true;
    _output.message = "Submit activity completed Successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.remove_article = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.article_guid = req.query.article_guid;
    if (data.article_guid == "" || data.article_guid == undefined) {
      throw {
        "message": "article_guid must be provided."
      };
    }
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.remove_article(data);
    _output.is_success = true;
    _output.message = "Article Removed";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.issue_queue = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.issue_id = req.body.issue_id;
    if (data.issue_id == "" || data.issue_id == undefined) {
      throw {
        "message": "issue_id must be provided."
      };
    }
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.issue_queue(data);
    _output.is_success = true;
    _output.message = "Paper Queue.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
exports.paper_queue = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.issue_id = req.body.issue_id;
    if (data.issue_id == "" || data.issue_id == undefined) {
      throw {
        "message": "issue_id must be provided."
      };
    }
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.paper_queue(data);
    _output.is_success = true;
    _output.message = "Paper Queue.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_metadata_details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID     
    _output.data = await article_service.get_metadata_details(data);
    _output.is_success = true;
    _output.message = "Getting Metadata Details";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_article_keywords = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID    
    let Result = {};
    Result.key_word_groups = [];
    Result.article_id = data.article_id
    let output = await article_service.get_article_keywords(data);
    if (output.key_word_groups != undefined && output.key_word_groups.length > 0) {
      for (let i = 0; i < output.key_word_groups.length; i++) {
        const _ = require("lodash");
        let _out = {};
        _out.key_word_group_id = output.key_word_groups[i].key_word_group_id
        _out.key_word_group_name = output.key_word_groups[i].key_word_group_name
        _out.is_active = 1
        _out.key_words = _.filter(output.key_words, ['key_word_group_id', _out.key_word_group_id])
        Result.key_word_groups.push(_out);
        if (i == output.key_word_groups.length - 1) {
          _output.data = Result;
          _output.is_success = true;
          _output.message = "Getting Article Keywords";
          req.User.endTime = new Date();
          exception_repo.exception_DB_log(req, _output, error, 1);
          res.status(HttpStatus.OK).send(_output);
        }
      }
    } else {
      _output.data = [];
      _output.is_success = true;
      _output.message = "Getting Article Keywords";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_article_conforms = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID     
    _output.data = await article_service.get_article_conform(data);
    _output.is_success = true;
    _output.message = "Getting Article conforms";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.getJobDetails = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let result = await article_service.getJobDetails(req.query.docid, req.query.atyid, req.User.UserID, req.User.OrgID);
    if (result.recordset.length > 0) {
      res.status(HttpStatus.OK);

      let resultObject = {}
      let name = Object.keys(result.recordset[0])[0]; // Get the first item of the list;  = key name
      let JsonData = result.recordset[0][name];

      if (JsonData != '' && JsonData != undefined) {
        resultObject['sMessage'] = "Content Found for GUID : " + req.query.docid;
        resultObject['is_success'] = true;
        let resultarray = JSON.parse(JsonData);
        resultObject['oData'] = resultarray[0];
      } else {
        resultObject['sMessage'] = "Content not found for GUID : " + req.query.docid;
        resultObject['oData'] = JsonData;
        resultObject['is_success'] = false;
      }
      exception_repo.exception_DB_log(req.User.OrgID ? req.User.OrgID : 0, 2, req.User.UserID ? req.User.UserID : 0, 0, req.method, req.originalUrl, req.query, error ? error : 0, 1, resultObject ? resultObject : 0);
      res.status(HttpStatus.OK).send(resultObject);
    } else {
      exception_repo.exception_DB_log(req.User.OrgID ? req.User.OrgID : 0, 2, req.User.UserID ? req.User.UserID : 0, 0, req.method, req.originalUrl, req.query, error ? error : 0, 1, 0);
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send();
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    exception_repo.exception_DB_log(req.User.OrgID ? req.User.OrgID : 0, 2, req.User.UserID ? req.User.UserID : 0, 0, req.method, req.originalUrl, req.query, error ? error : 0, 0, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.save_article_historys = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let histguid = await article_service.save_article_history(data);
    if (histguid.status == 'true') {
      let blobdata = {};
      blobdata.byte = req.body.htmlcontent
      blobdata.path = histguid.Path_History;
      histguid.Path_History != '' ? _output.data = await common.blobByteUpload(blobdata) : _output.data = '';
      _output.is_success = true;
      _output.message = histguid.message;

    } else {
      _output.data =
        _output.is_success = false;
      _output.message = "Not saved Successfully";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.getSuggestionId = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let result = await article_service.get_suggestionID();
    if (result.recordset.length > 0) {
      _output.data = result.recordset;
      _output.is_success = true;
      _output.message = "Suggestion List";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    } else {
      _output.is_success = true;
      _output.message = "Result not found";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.check_automation_status_of_article = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID     
    _output.data = await article_service.check_automation_status_of_article(data);
    _output.is_success = true;
    _output.message = "article word to icore xml conversion status.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_article_keywords_for_iAuthor = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data.article_guid = req.query.article_guid;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID    
    let Result = {};
    Result.key_word_groups = [];
    Result.article_guid = data.article_guid
    let output = await article_service.get_article_keywords(data);
    let rst = {};
    rst.objTitle = output.article_details.objTitle
    rst.objAbstract = output.article_details.objAbstract
    rst.objKeyWord = []
    if (output.key_word_groups != undefined && output.key_word_groups.length > 0) {
      for (let i = 0; i < output.key_word_groups.length; i++) {
        const _ = require("lodash");
        let _out = {};
        _out.kwdg_title = output.key_word_groups[i].key_word_group_name
        _out.keys = _.filter(output.key_words, ['key_word_group_id', _out.key_word_group_id]).forEach(ele => {
          ele.kwdtxt = ele.Key_word
          delete ele.Key_word
        })
        rst.objKeyWord.push(_out);
        if (i == output.key_word_groups.length - 1) {
          _output.data = rst;
          _output.is_success = true;
          _output.message = "Getting Article Keywords";
          req.User.endTime = new Date();
          exception_repo.exception_DB_log(req, _output, error, 1);
          res.status(HttpStatus.OK).send(_output);
        }
      }
    } else {
      _output.data = rst;
      _output.is_success = true;
      _output.message = "Getting Article Keywords";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}


exports.get_article_by_status = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let IDs = ''
    if (req.query.id != undefined) {

      if (req.query.id.length > 0) {
        let id_array = req.query.id;
        for (var k in id_array) {
          if (id_array.hasOwnProperty(k)) {
            if (k != 0) {
              IDs = IDs + ',' + id_array[k];
            } else {
              IDs = id_array[k];
            }
          }
        }
      } else {
        IDs = req.query.id
      }
    } else {
      IDs = 0
    }

    let result = await article_service.get_article_by_status(IDs, req.query.jid, req.User.UserID);
    if (result.recordset.length > 0) {
      _output.data = result.recordset;
      _output.is_success = true;
      _output.message = "Article List";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    } else {
      _output.data = [];
      _output.is_success = true;
      _output.message = "Article not fount";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    }

  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.getMetaJobDetails = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let docDetails = await loginService_repo.getDocDeailsByDocID(req.query.docid);
    if (docDetails.recordset.length > 0) {
      _output.data = docDetails.recordset[0];
      _output.is_success = true;
      _output.message = "Doc ID is found.";
      exception_repo.exception_DB_log(0, 0, 2, 0, req.method, req.originalUrl, req.query, error ? error : 0, 1, _output ? _output : 0);
      res.status(HttpStatus.OK).send(_output);
    } else {
      _output.is_success = false;
      _output.message = "Doc ID is not found.";
      exception_repo.exception_DB_log(0, 0, 2, 0, req.method, req.originalUrl, req.query, error ? error : 0, 1, _output ? _output : 0);
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    exception_repo.exception_DB_log(0, 0, 2, 0, req.method, req.originalUrl, req.query, error ? error : 0, 0, _output ? _output : 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.getAllhistoryfileDetails = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let historyDetails = await article_service.getAllhistoryfileDetail(data);
    _output.data = historyDetails;
    _output.is_success = true;
    _output.message = "Rollback done successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.resetactivityfiles = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let resetDetails = await article_service.resetactivityfile(data);
    _output.data = {
      "ArticleGUID": req.body.article_guid
    };
    _output.is_success = true;
    _output.message = "Reset done successfully";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.wms_createjob_jrnls = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    //data = await common.getTokenUserDetail(req, data);
    let validate_JourFileToUpload = req.body.JourFileToUpload.some(function (data) {
      if (data.Filenamewithextension != null && data.Filenamewithextension != undefined && data.FileContent != null && data.FileContent != undefined && data.Code != null && data.Code != undefined) {
        return false;
      } else {
        return true;
      }
    });

    let validate_workflowATY = req.body.workflowDetails.SequenceDetails.some(function (data) {
      if (data.ActivityID != null && data.ActivityID != undefined && data.RoleID != null && data.RoleID != undefined && data.ActivityName != null && data.ActivityName != undefined && data.userDetails[0].UserName != null && data.userDetails[0].UserName != undefined && data.userDetails[0].Email != null && data.userDetails[0].Email != undefined) {
        return false;
      } else {
        return true;
      }
    });

    let validate_cusid = req.body.CustomerID;
    let validate_wfid = req.body.workflowDetails.WorkflowID;
    let validate_journalcode = req.body.JournalDetails.journalcode;
    let validate_journalname = req.body.JournalDetails.journalname;
    let validate_articlename = req.body.JournalDetails.journaltoc[0].FileName;
    let validate_articlecode = req.body.JournalDetails.journaltoc[0].code;
    let validate_articletitle = req.body.JournalDetails.journaltoc[0].title;
    let validate_onshore = req.body.JournalDetails.journaltoc[0].IsOnshore;
    let WFaty = req.body.workflowDetails;
    let validate_pename = req.body.PEUser.UserName;
    let validate_peemail = req.body.PEUser.Email;
    let validate_prooftype = req.body.ProofType;

    if (validate_JourFileToUpload) {
      throw {
        "message": "Check JourFileToUpload Input"
      };
    } else if (validate_pename == null || validate_pename == undefined) {
      throw {
        "message": "Check PE Name Input"
      };
    } else if (validate_peemail == null || validate_peemail == undefined) {
      throw {
        "message": "Check PE Email Input"
      };
    } else if (validate_prooftype == null || validate_prooftype == undefined) {
      throw {
        "message": "Check Proof Type Input"
      };
    } else if (validate_workflowATY) {
      throw {
        "message": "Check WF Activity Input"
      };
    } else if (validate_cusid == null || validate_cusid == undefined) {
      throw {
        "message": "Check CustomerID Input"
      };
    } else if (validate_wfid == null || validate_wfid == undefined) {
      throw {
        "message": "Check WorkflowID Input"
      };
    } else if (validate_journalcode == null || validate_journalcode == undefined) {
      throw {
        "message": "Check journalcode Input"
      };
    } else if (validate_journalname == null || validate_journalname == undefined) {
      throw {
        "message": "Check journalname Input"
      };
    } else if (validate_articlename == null || validate_articlename == undefined) {
      throw {
        "message": "Check ArticleFileName Input"
      };
    } else if (validate_articlecode == null || validate_articlecode == undefined) {
      throw {
        "message": "Check Articlecode Input"
      };
    } else if (validate_articletitle == null || validate_articlecode == undefined) {
      throw {
        "message": "Check Articletitle Input"
      };
    } else if (validate_onshore == null || validate_onshore == undefined) {
      throw {
        "message": "Check Onshore Input"
      };
    } else if (1 != await article_service.Check_WF_activity(WFaty)) {
      throw {
        "message": "Check WF Activity has mismatch Input"
      };
    } else {
      //let checkwfaty =  await article_service.Check_WF_activity(req.body.workflowDetails);
      let createjobDetails = await article_service.wms_createjob_jrnl(data, WFaty);
      if (createjobDetails.status == 1) {
        for (let i = 0; i < req.body.JournalDetails.journaltoc.length; i++) {
          let lstfile = req.body.JourFileToUpload.filter(y => y.Code == req.body.JournalDetails.journaltoc[i].code);
          let filedata = {};
          filedata.user_id = 1;
          filedata.org_id = 2;
          filedata.wfd_id = validate_wfid;
          filedata.job_GUID = createjobDetails.jobguid;
          filedata.activity_id = createjobDetails.atyid;
          filedata.Article_GUID = createjobDetails.articleguid;

          let attachdtl = {};
          attachdtl.article_id = createjobDetails.articleid;
          attachdtl.user_id = 1;
          attachdtl.org_id = 2;

          for (let j = 0; j < lstfile.length; j++) {
            attachdtl.files = [];
            let attachfiledtl = {};
            let check = lstfile[j].FileContent
            filedata.filename = lstfile[j].Filenamewithextension;
            var path = "";
            let isString = false
            if (lstfile[j].isArticle) {
              path = await article_service.main_upload_file(filedata);
              attachfiledtl.is_main_file = 1
            }
            else {
              path = await article_service.Article_Resource_upload_file(filedata);//Changes For article resource path
              attachfiledtl.is_main_file = 0
            }


            let filesize;
            let file = {};
            let blobupload;

            file.path = path;
            file.byte = {};
            //For file upload base 64 changes.
            if (lstfile[j].FileContent.data == undefined) {
              file.byte.data = Buffer.from(lstfile[j].FileContent, 'base64');
            } else {
              file.byte = lstfile[j].FileContent;
            }
            filesize = await common.bytesToSize(file.byte.data.length);
            blobupload = await common.blobByteUpload(file);
            attachfiledtl.id = 0;
            attachfiledtl.file_name = lstfile[j].Filenamewithextension;
            attachfiledtl.file_size = filesize
            attachfiledtl.path = blobupload
            attachfiledtl.is_active = 1
            attachdtl.files.push(attachfiledtl);
            await article_service.add_article_attachment(attachdtl);
          }
        }

        let result = await article_service.getJobDetails(createjobDetails.articleguid, createjobDetails.atyid, 1, 2); //req.User.UserID, req.User.OrgID
        if (result.recordset.length > 0) {
          let resultObject = {}
          let name = Object.keys(result.recordset[0])[0]; // Get the first item of the list;  = key name
          let JsonData = result.recordset[0][name];
          if (JsonData != '' && JsonData != undefined) {
            resultObject['sMessage'] = "Content Found for GUID";
            resultObject['is_success'] = true;
            let resultarray = JSON.parse(JsonData);
            resultObject['oData'] = resultarray[0];
            let mData = {}
            mData.metaData = resultObject
            let xmltohtml = await article_service.xml_to_html_convertion(mData);
            let xmlstatus = JSON.parse(xmltohtml);
            if (xmlstatus.length > 0) {
              xmlstatus = xmlstatus[0];
            }
            if (xmlstatus.isSuccess) {
              _output.data = {
                "jobid": createjobDetails.articleguid,
                "link": createjobDetails.ialink
              };
              _output.is_success = true;
              _output.message = "Link generated Successfully.";
            } else {
              throw {
                "message": "Create job failed due to xml to html conversion failed"
              };
            }
          } else {
            throw {
              "message": "Create job failed due to getjob data empty for xml to html conversion"
            };
          }
        } else {
          throw {
            "message": "Create job failed due to getjob failed for xml to html conversion"
          };
        }
      } else {
        throw {
          "message": createjobDetails.message
        };
      }

    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}



exports.send_aty_ialinks = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    if (req.body.JobID == null || req.body.JobID == undefined) {
      throw {
        "message": "Check jobid Input"
      };
    } else if (req.body.ActivityId == null || req.body.ActivityId == undefined) {
      throw {
        "message": "Check activityid Input"
      };
    } else if (req.body.RoleID == null || req.body.RoleID == undefined) {
      throw {
        "message": "Check RoleID Input"
      };
    } else if (req.body.userDetails.UserName == null || req.body.userDetails.UserName == undefined) {
      throw {
        "message": "Check Name Input"
      };
    } else if (req.body.userDetails.Email == null || req.body.userDetails.Email == undefined) {
      throw {
        "message": "Check Email Input"
      };
    } else {
      let data = {};
      data = req.body;
      data = await common.getTokenUserDetail(req, data);
      let sendlinkDetails = await article_service.send_aty_ialink(data.JobID, data.ActivityId, data.userDetails.UserName, data.userDetails.Email, data.RoleID, data.user_id, data.org_id);
      if (sendlinkDetails.status == 1) {
        _output.data = sendlinkDetails.link;
        _output.is_success = true;
        _output.message = "Link generated Successfully.";
      } else {
        throw {
          "message": sendlinkDetails.message
        }
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_aty_status = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    if (req.query.jobid == null || req.query.jobid == undefined) {
      throw {
        "message": "Check jobid Input"
      };
    } else if (req.query.activityid == null || req.query.activityid == undefined) {
      throw {
        "message": "Check activityid Input"
      };
    } else {
      let data = {};
      data = req.query;
      data = await common.getTokenUserDetail(req, data);
      let getatyDetails = await article_service.get_aty_status(data.jobid, data.activityid);
      if (getatyDetails.message == 'true') {
        _output.data = {
          "status": getatyDetails.status,
          "status_id": getatyDetails.status_id
        };
        _output.is_success = true;
        _output.message = "Getting activity status successfully.";
      } else {
        throw {
          "message": getatyDetails.message
        }
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_WF_Details = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    if (req.query.jobid == null || req.query.jobid == undefined) {
      throw {
        "message": "Check jobid Input"
      };
    } else {
      let data = {};
      data = req.query;
      data = await common.getTokenUserDetail(req, data);
      let getwfDetails = await article_service.get_WF_Detail(data.jobid);
      if (getwfDetails.status == 1) {
        _output.data = getwfDetails.wf_id;
        _output.is_success = true;
        _output.message = "Getting Workflowid successfully.";
      } else {
        throw {
          "message": getwfDetails.message
        }
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_completedfiles_URI = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    if (req.query.jobid == null || req.query.jobid == undefined) {
      throw {
        "message": "Check jobid Input"
      };
    } else if (req.query.activityid == null || req.query.activityid == undefined) {
      throw {
        "message": "Check activityid Input"
      };
    } else {
      let data = {};
      data = req.query;
      data = await common.getTokenUserDetail(req, data);
      let getcompletedDetails = await article_service.get_completedfile_URI(data.jobid, data.activityid);
      if (getcompletedDetails.status == 1) {
        //let path = getcompletedDetails.path;
        let getfilepath = await common.ListAllblobPathURI(getcompletedDetails.path);
        _output.data = {
          "File_name": getcompletedDetails.Filename,
          "URI": getfilepath
        };
        _output.is_success = true;
        _output.message = "Getting completed file successfully.";
      } else {
        throw {
          "message": getcompletedDetails.message
        }
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.download_link = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = await common.getTokenUserDetail(req, data);
    data.article_guid = req.body.article_guid;
    data.ext = req.body.ext;
    if (data.article_guid == undefined || data.article_guid == '') {
      throw {
        "message": "article_guid must be provided."
      }
    } else if (data.ext == undefined || data.ext == '') {
      throw {
        "message": "ext must be provided."
      }
    } else {
      let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id);
      let FinalAtyId = await article_service.get_article_final_aty_id_using_Article_GUID(data.article_guid);
      let currentAty = input.file_path.split('/').slice(4, 5)[0];
      let arry = input.file_path.replace(currentAty, FinalAtyId).replace("Input", "Output").split('/').splice(1);
      arry.pop();
      let pathToCheck = arry.join('/');
      let extensions = [];
      extensions.push(data.ext.toLowerCase());
      let getfilepath = await common.ListAllblobPathURI(pathToCheck);
      let path = require('path');
      let output = getfilepath.filter(x => extensions.includes(path.extname(x).toLowerCase()))
      _output.data = output
      _output.is_success = true;
      _output.message = "Success.";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.HttpStatus(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}


exports.get_meta_data = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let result = await article_service.get_meta_data(req);
    if (result.recordset.length > 0) {
      let result1 = result.recordset[0][Object.keys(result.recordset[0])[0]];
      if (result1 != "") {
        _output.data = JSON.parse(result1)[0];
        _output.is_success = true;
        _output.message = 'Record found';
      } else {
        _output.data = {}
        _output.is_success = true;
        _output.message = 'Record not found';
      }
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    } else {
      _output.is_success = false;
      _output.message = 'something went worng';
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);;
  }
}


exports.get_file_url = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let result = await article_service.get_file_url(req);

    if (result.recordset.length > 0) {
      // if ( typeof path  === 'object') {
      let total_path = [];
      for (let ii = 0; ii < result.recordsets[0].length; ii++) {
        let blobUrl = result.recordsets[0][ii].pathURL.split("/").slice(4).join('/');
        let getfilepath = await common.doesBlobExist(blobUrl);
        if (getfilepath) {
          total_path.push(result.recordsets[0][ii].pathURL)
        }
      }

      if (total_path.length > 0) {
        if (req.body.doc_type == 'zip') {
          let uniqueFolder = common.guid();
          let file_name = total_path[0].substring(total_path[0].lastIndexOf('/') + 1, total_path[0].lastIndexOf("."));
          let in_path = 'ijps/Engine/' + req.body.article_guid + '/In/' + uniqueFolder + '/' + file_name + '.zip';
          let FileuploadedPath = await automation_repository.add_blob_to_zip(total_path, in_path);
          _output.data = basepath + FileuploadedPath;
          _output.is_success = true;
          _output.message = 'file exists in blob.';
        } else {
          _output.data = total_path[0];
          _output.is_success = true;
          _output.message = 'file exists in blob.';
        }
      } else {
        _output.is_success = false;
        _output.message = 'Error in downloading the file, Please contact administrator.';
      }
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    } else {
      _output.is_success = false;
      _output.message = 'something went worng';
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.send_ialink_topublisher = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    if (req.body.JobID == null || req.body.JobID == undefined) {
      throw {
        "message": "Check jobid Input"
      };
    } else if (req.body.ActivityId == null || req.body.ActivityId == undefined) {
      throw {
        "message": "Check activityid Input"
      };
    } else if (req.body.RoleID == null || req.body.RoleID == undefined) {
      throw {
        "message": "Check RoleID Input"
      };
    } else if (req.body.userDetails.UserName == null || req.body.userDetails.UserName == undefined) {
      throw {
        "message": "Check Name Input"
      };
    } else if (req.body.userDetails.Email == null || req.body.userDetails.Email == undefined) {
      throw {
        "message": "Check Email Input"
      };
    } else {
      let data = {};
      data = req.body;
      data = await common.getTokenUserDetail(req, data);
      let sendlinkDetails = await article_service.send_ialink_publisher(data.JobID, data.ActivityId, data.userDetails.UserName, data.userDetails.Email, data.RoleID, data.user_id, data.org_id);
      if (sendlinkDetails.status == 1) {
        _output.data = sendlinkDetails.link;
        _output.is_success = true;
        _output.message = "Link generated Successfully.";
      } else {
        throw {
          "message": sendlinkDetails.message
        }
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_dashboard_NL = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let result = await article_service.get_dashboard_NL(req);
    let results = {
      "count": result.recordsets[0],
      "values": result.recordsets[1]
    };
    _output.data = results;
    _output.is_success = true;
    _output.message = 'Record found';
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_dashboard_Integra_Prod = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let results = await article_service.get_dashboard_Integra_Prod(data);
    _output.data = results;
    _output.is_success = true;
    _output.message = 'Record found';
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.config_Author_sendMail = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    //data = await common.getTokenUserDetail(req, data);
    let results = await article_service.config_Author_sendMail(data.UserName, data.Email, data.WorkflowID, data.CustomerID);
    _output.data = results;
    _output.is_success = true;
    _output.message = 'Author created successfully';
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_pdf_automation_status = async function (req, res, next) {
  var _output = new output();
  let error = null;
  
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    if (data.article_guid == undefined || data.article_guid == "") {
      throw ({
        "message": "article_guid must be provided."
      })
    } else {
      _output.data = await article_service.get_pdf_automation_status(data);
      _output.is_success = true;
      _output.message = "PDF automation status.";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}