const output = require("../../../models/Output");
const common = require("../../../helpers/common")
const iauthor_service = require("../Service/iauthor.service");
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');


exports.File_VersionCompare = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let data = {};
        if (req.body.org_id == undefined && req.body.user_id == undefined) {
            data = await common.getTokenUserDetail(req, data);
        } else {
            data.user_id = req.body.user_id;
            data.org_id = req.body.org_id;
        }
        data.article_guid = req.body.article_guid;
        data.aty_id = req.body.aty_id;
        if (data.article_guid == undefined || data.article_guid == '') {
            throw {
                "message": "article_guid must be provided."
            }
        } else if (data.user_id == undefined || data.user_id == '') {
            throw {
                "message": "user_id must be provided."
            }
        } else if (data.org_id == undefined || data.org_id == '') {
            throw {
                "message": "org_id must be provided."
            }
        } else {
            _output.data = await iauthor_service.File_VersionCompare(data.article_guid, data.aty_id, data.user_id, data.org_id);
            _output.is_success = true;
            _output.message = "Success";
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}