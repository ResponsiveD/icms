const automation_repository = require("../../../repository/automation.service");
const output = require("../../../models/Output");
const common = require("../../../helpers/common")
const article_service = require("../Service/article.service");
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');


exports.word_to_xml_automation_entry = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        let data = req.body;
        data = await common.getTokenUserDetail(req, data);
        data.automation_id = 1
        if (data.article_guid == undefined || data.article_guid == '') {
            throw {
                "message": "article_guid must be provided."
            }
        } else {
            let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
            let engineDetails = await article_service.get_engine_detail_for_guid(data.article_guid, data.org_id, data.user_id, data.automation_id)
            if (engineDetails.length > 0) {
                input.EngineDetails = {}
                input.EngineDetails.EngineName = engineDetails[0].EngineName;
                input.EngineDetails.InPath = engineDetails[0].InPath;
                input.EngineDetails.OutPath = engineDetails[0].OutPath;
                input.EngineDetails.ActivityId = engineDetails[0].ActivityId;
            }
            data.article_id = input.article_id;
            let uniqueFolder = common.guid();
            data.in_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/input.zip';
            data.out_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/output.zip';
            const path = require('path');
            let ext = path.extname(input.file_path);
            input.xmlpath = input.file_path.split('/').slice(1).join('/').replace(ext, '.xml')
            input.resourcePath = path.join(input.file_path.split('/').slice(1, 6).join('/'), 'System', 'Resources')
            let output = automation_repository.createiAMetaForIpubsuite(input)
            let files = [];
            files.push({
                "file_content": output.XMLContent,
                "file_name": "JobInfo.xml"
            })
            input.files = files
            input.file_paths = []
            input.file_paths.push(input.file_path)
            let FileuploadedPath = await automation_repository.add_blob_to_zip_stream(input, data.in_path)
            data.file_name = path.basename(input.file_path)
            let result = await automation_repository.add_automation_entry(data);
            data.id = result.token_id;
            let author_name = result.username;
            await article_service.update_automation_id_to_article(data);
            //sending mail to support team
            if (result) {
                automation_repository.Alert_Manuscript_Upload(data, author_name);
            }
            _output.data = data;
            _output.is_success = true;
            _output.message = "Automation entry updated";
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.bulk_word_to_xml_automation_entry = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        let data = req.body;
        data = await common.getTokenUserDetail(req, data);
        data.automation_id = 1
        if (data.article_guids == undefined || typeof (data.article_guids) != 'object') {
            throw {
                "message": "article_guids must be provided."
            }
        }
        if (data.article_guids.length == undefined || data.article_guids.length < 1) {
            throw {
                "message": "article_guids must be provided."
            }
        } else {

            for (let i = 0; i < data.article_guids.length; i++) {
                let article_guid = data.article_guids[i].article_guid;
                data.article_guid = data.article_guids[i].article_guid;
                let isAutomationTriggered = await article_service.isAutomationTriggered(article_guid);
                if (isAutomationTriggered == 1) {
                    _output.data = data;
                    _output.is_success = true;
                    _output.message = "Automation entry updated";
                    continue;
                }
                let input = await article_service.get_article_main_file_path_using_Article_GUID(article_guid, data.org_id, data.user_id)
                let engineDetails = await article_service.get_engine_detail_for_guid(data.article_guids[i].article_guid, data.org_id, data.user_id, data.automation_id)
                if (engineDetails.length > 0) {
                    input.EngineDetails = {}
                    input.EngineDetails.EngineName = engineDetails[0].EngineName;
                    input.EngineDetails.InPath = engineDetails[0].InPath;
                    input.EngineDetails.ActivityId = engineDetails[0].ActivityId;
                    input.EngineDetails.OutPath = engineDetails[0].OutPath;
                }
                data.article_id = input.article_id;
                let uniqueFolder = common.guid();
                data.in_path = input.file_path.split('/')[1] + '/' +
                    input.job_guid + '/Engine/In/' +
                    uniqueFolder + '/input.zip';
                data.out_path = input.file_path.split('/')[1] + '/' +
                    input.job_guid + '/Engine/In/' +
                    uniqueFolder + '/output.zip';
                const path = require('path');
                let ext = path.extname(input.file_path);
                input.xmlpath = input.file_path.split('/').slice(1).join('/').replace(ext, '.xml')
                input.resourcePath = path.join(input.file_path.split('/').slice(1, 6).join('/'), 'System', 'Resources')
                let output = automation_repository.createiAMetaForIpubsuite(input)
                let files = [];
                files.push({
                    "file_content": output.XMLContent,
                    "file_name": "JobInfo.xml"
                })
                input.files = files
                input.file_paths = []
                input.file_paths.push(input.file_path)
                let FileuploadedPath = await automation_repository.add_blob_to_zip_stream(input, data.in_path)
                data.file_name = path.basename(input.file_path)
                let result = await automation_repository.add_automation_entry(data);
                data.id = result;
                await article_service.update_automation_id_to_article(data);
                if (i == data.article_guids.length - 1) {
                    _output.data = data;
                    _output.is_success = true;
                    _output.message = "Automation entry updated";
                }
            }
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.iCoreToXML = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        let data = req.body;
        data = await common.getTokenUserDetail(req, data);
        //data.user_id=6
        //data.org_id=2
        let aty_id = data.aty_id;
        if (data.aty_id == undefined) {
            aty_id = '31';
        }
        data.automation_id = 2
        if (data.article_guid == undefined || data.article_guid == '') {
            throw {
                "message": "article_guid must be provided."
            }
        } else {
            let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
            let uniqueFolder = common.guid();
            data.in_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/input.zip';
            data.out_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/output.zip';
            const path = require('path');
            let ext = path.extname(input.file_path);
            input.file_path = input.file_path.replace(ext, '.xml')
            //let currentAty = input.file_path.split('/').slice(4, 5)[0]
            //input.xmlpath = input.file_path.replace(currentAty, '31').replace("Input", "Output").replace(ext, '.xml')
            if (input.file_path != undefined) {
                let xmlpathsplit = input.file_path.split('/')
                if (xmlpathsplit.length >= 9) {
                    xmlpathsplit[4] = aty_id;
                    xmlpathsplit[7] = 'Output';
                }
                input.xmlpath = xmlpathsplit.join('/');
                var pos = input.xmlpath.lastIndexOf(".");
                input.xmlpath = input.xmlpath.substr(0, pos < 0 ? input.xmlpath.length : pos) + '.xml';
            }
            input.file_path = input.xmlpath
            input.resourcePath = path.join(input.file_path.split('/').slice(0, 7).join('/'), 'Resources');
            let AutomationDetl = await automation_repository.get_automation_paths(data);
            input.XMLConvertEXE = AutomationDetl.conversion_exe;
            let output = automation_repository.createiAMetaForIpubsuite(input)
            let files = [];
            files.push({
                "file_content": output.XMLContent,
                "file_name": "JobInfo.xml"
            })
            input.files = files
            input.file_paths = []
            input.file_paths.push(input.file_path)
            let FileuploadedPath = await automation_repository.add_blob_to_zip_stream(input, data.in_path)
            data.file_name = path.basename(input.file_path)
            let result = await automation_repository.add_automation_entry(data);
            data.id = result;
            await article_service.update_automation_id_to_article_by_article_guid(data);
            _output.data = data;
            _output.is_success = true;
            _output.message = "Automation entry updated";
            next()
        }
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.iCoreToPDF = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        let data = req.body;
        data = await common.getTokenUserDetail(req, data);
        data.automation_id = 3
        //data.user_id=6
        //data.org_id=2
        let aty_id = data.aty_id;
        if (data.aty_id == undefined) {
            aty_id = '31';
        }
        if (data.article_guid == undefined || data.article_guid == '') {
            throw {
                "message": "article_guid must be provided."
            }
        } else {
            let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
            let uniqueFolder = common.guid();
            data.in_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/input.zip';
            data.out_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/output.zip';
            const path = require('path');
            let ext = path.extname(input.file_path);
            input.file_path = input.file_path.replace(ext, '.xml')
            //let currentAty = input.file_path.split('/').slice(4, 5)[0]
            //input.xmlpath = input.file_path.replace(currentAty, '31').replace("Input", "Output").replace(ext, '.xml')
            if (input.file_path != undefined) {
                let xmlpathsplit = input.file_path.split('/')
                if (xmlpathsplit.length >= 9) {
                    xmlpathsplit[4] = aty_id;
                    xmlpathsplit[7] = 'Output';
                }
                input.xmlpath = xmlpathsplit.join('/');
                var pos = input.xmlpath.lastIndexOf(".");
                input.xmlpath = input.xmlpath.substr(0, pos < 0 ? input.xmlpath.length : pos) + '.xml';
            }
            input.file_path = input.xmlpath
            //input.pdfpath = input.file_path.replace(currentAty, '31').replace("Input", "Output").replace(ext, '.pdf')
            if (input.file_path != undefined) {
                let pdfpathsplit = input.file_path.split('/')
                if (pdfpathsplit.length >= 9) {
                    pdfpathsplit[4] = aty_id;
                    pdfpathsplit[7] = 'Output';
                }
                input.pdfpath = pdfpathsplit.join('/');
                var pos = input.pdfpath.lastIndexOf(".");
                input.pdfpath = input.pdfpath.substr(0, pos < 0 ? input.pdfpath.length : pos) + '.pdf';
            }
            input.resourcePath = path.join(input.file_path.split('/').slice(0, 7).join('/'), 'Resources')
            let pathtolist = path.join(input.file_path.split('/').slice(1, 7).join('/'), 'Resources').split("\\").join("/");
            let getfilepath = await common.ListAllblobPathURI(pathtolist);
            extensions = [".jpg", ".jpeg", ".png", ".bmp"]
            let AutomationDetl = await automation_repository.get_automation_paths(data);
            input.images = getfilepath.filter(x => extensions.includes(path.extname(x)));
            input.XMLConvertEXE = AutomationDetl.conversion_exe;
            let output = automation_repository.createiAMetaForIpubsuite(input)
            let files = [];
            files.push({
                "file_content": output.XMLContent,
                "file_name": "JobInfo.xml"
            })
            input.files = files
            input.file_paths = []
            input.file_paths.push(input.file_path)
            input.file_paths.push(AutomationDetl.automation_path)
            await automation_repository.add_blob_to_zip_stream(input, data.in_path)
            data.file_name = path.basename(input.file_path)
            data.comp_id = 2;
            let result = await automation_repository.add_automation_entry(data);
            data.id = result;
            await article_service.update_automation_id_to_article_by_article_guid(data);
            _output.data = data;
            _output.is_success = true;
            _output.message = "Automation entry updated";
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

// exports.getmetadatafromiAuthor = async function (req) {
//     return await new Promise((resolve, reject) => {
//          try {
//             let data = req.body;
//             data.user_id = 0;
//             data.org_id = 0;
//             if (data.article_guid == undefined || data.article_guid == '') { throw { "message": "article_guid must be provided." } }
//             else {
//                  let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
//                 const path = require('path');
//                 let ext = path.extname(input.file_path);
//                  let file_path = input.file_path.split('/').slice(1).join('/').replace(ext, '.xml')
//                  let output = await article_service.get_metadata_from_iAuthor(file_path);
//                  output = JSON.parse(output);
//                  let Result = [];
//                 if (output.isSuccess == true) {
//                     output = output.result;
//                     let title = '';
//                     let abstract = '';
//                     let key_word_groups = [];
//                     title = await article_title(output);
//                     abstract = await article_abstract(output);
//                     await article_service.update_article_title_and_abstract(title, abstract, data.article_guid)
//                     let Data = {};
//                     Data.key_word_groups = await article_kewwords(output);
//                     Data.user_id = data.user_id;
//                     Data.article_id = data.article_id
//                     Data.org_id = data.org_id
//                     Data.article_guid = data.article_guid
//                     Result = await article_service.add_article_keyword(Data);
//                     resolve(Result);
//                 }
//                 else {
//                     throw { message: 'Received error from iAuthor while requesting metadata.' }
//                 }
//             }
//         }
//         catch (error) {
//             reject(error);
//         }
//     });
// }

exports.get_metadata_from_iAuthor = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        let data = req.body;
        data.user_id = 0;
        data.org_id = 0;
        //data = await common.getTokenUserDetail(req, data);
        if (data.article_guid == undefined || data.article_guid == '') {
            throw {
                "message": "article_guid must be provided."
            }
        } else {
            let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
            const path = require('path');
            let ext = path.extname(input.file_path);
            let file_path = input.file_path.split('/').slice(1).join('/').replace(ext, '.xml')
            let output = await article_service.get_metadata_from_iAuthor(file_path);
            output = JSON.parse(output);
            let Result = [];
            if (output.isSuccess == true) {
                output = output.result;
                let title = '';
                let abstract = '';
                let key_word_groups = [];
                title = await article_title(output);
                abstract = await article_abstract(output);
                await article_service.update_article_title_and_abstract(title, abstract, data.article_guid)
                let Data = {};
                Data.key_word_groups = await article_kewwords(output);
                Data.user_id = data.user_id;
                Data.article_id = data.article_id
                Data.org_id = data.org_id
                Data.article_guid = data.article_guid
                Result = await article_service.add_article_keyword(Data);
                _output.data = Result;
                _output.is_success = true;
                _output.message = "Metadata from iAuthor.";
            } else {
                throw {
                    message: 'Received error from iAuthor while requesting metadata.'
                }
            }
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

var article_abstract = function (output) {
    return new Promise((resolve, reject) => {
        let abstract = ''
        if (output.objAbstract.isAbstractAvailable == true) {
            for (let i = 0; i < output.objAbstract.AbstractInnerHTMLArray.length; i++) {
                abstract = abstract + output.objAbstract.AbstractInnerHTMLArray[i].Content
                if (i == output.objAbstract.AbstractInnerHTMLArray.length - 1) {
                    resolve(abstract)
                }
            }
        } else {
            resolve(abstract)
        }
    });
}


var article_title = function (output) {
    return new Promise((resolve, reject) => {
        let title = ''
        if (output.objTitle.isTitleAvailable == true) {
            title = output.objTitle.TitleInnerHTMLArray[0].Content
            resolve(title);
        } else {
            resolve(title);
        }
    });
}

var article_kewwords = function (output) {
    return new Promise((resolve, reject) => {
        if (output.objKeyWord.isKeywordAvailable == true) {
            let key_word_groups = [];
            if (output.objKeyWord.keyWordInnerHTMLArray.length > 0) {
                for (let i = 0; i < output.objKeyWord.keyWordInnerHTMLArray.length; i++) {
                    let key_word_group = {}
                    key_word_group.key_word_group_id = 0;
                    key_word_group.key_word_group_name = output.objKeyWord.keyWordInnerHTMLArray[i].kwdg_title;
                    key_word_group.is_active = 1;
                    key_word_group.key_words = [];
                    for (let j = 0; j < output.objKeyWord.keyWordInnerHTMLArray[i].keys.length; j++) {
                        let key = {}
                        key.key_word_id = 0;
                        key.key_word = output.objKeyWord.keyWordInnerHTMLArray[i].keys[j].kwd
                        key.is_active = 1
                        key_word_group.key_words.push(key);
                    }
                    key_word_groups.push(key_word_group);
                    if (i == output.objKeyWord.keyWordInnerHTMLArray.length - 1) {
                        resolve(key_word_groups);
                    }
                }
            } else {
                resolve(key_word_groups)
            }
        } else {
            reject({
                message: 'Keyword is not available'
            })
        }
    });
}


exports.put_metadata_to_iAuthor = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        let data = {};
        data = await common.getTokenUserDetail(req, data);
        data.article_guid = req.body.article_guid;
        if (data.article_guid == undefined || data.article_guid == '') {
            throw {
                "message": "article_guid must be provided."
            }
        } else {
            let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
            const path = require('path');
            let ext = path.extname(input.file_path);
            let file_path = input.file_path.split('/').slice(1).join('/').replace(ext, '.xml')
            let Result = {};
            Result.key_word_groups = [];
            Result.article_guid = data.article_guid
            let output = await article_service.get_article_keywords(data);
            let rst = {};
            rst.objTitle = output.article_details[0].title
            rst.objAbstract = output.article_details[0].abstract
            rst.blobpath = file_path;
            rst.objKeyWord = []
            if (output.key_word_groups != undefined && output.key_word_groups.length > 0) {
                for (let i = 0; i < output.key_word_groups.length; i++) {
                    const _ = require("lodash");
                    let _out = {};
                    _out.kwdg_title = output.key_word_groups[i].key_word_group_name
                    _out.keys = _.filter(output.key_words, ['key_word_group_id', output.key_word_groups[i].key_word_group_id])
                    _out.keys.forEach(ele => {
                        ele.kwdtxt = ele.key_word
                        delete ele.key_word
                    })
                    rst.objKeyWord.push(_out);
                    if (i == output.key_word_groups.length - 1) {
                        _output.data = rst;
                        _output.is_success = true;
                        _output.message = "Getting Article Keywords";
                        let output = await article_service.put_metadata_to_iAuthor(rst);
                        req.User.endTime = new Date();
                        exception_repo.exception_DB_log(req, _output, error, 1);
                        res.status(HttpStatus.OK).send(output);
                    }
                }
            } else {
                _output.data = rst;
                _output.is_success = true;
                _output.message = "Getting Article Keywords";
                let output = await article_service.put_metadata_to_iAuthor(rst);
                req.User.endTime = new Date();
                exception_repo.exception_DB_log(req, _output, error, 1);
                res.status(HttpStatus.OK).send(output);
            }
        }

    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.add_automation_sub_status = async function (req, res, next) {
    var _output = new output();
    let error = null;
    try {
        let data = req.body;
        if (data.status == undefined || data.status == 0) {
            throw ({
                "message": "status must be provided."
            });
        } else if (data.automation_id == undefined || data.automation_id == 0) {
            throw ({
                "message": "automation_id must be provided."
            })
        } else if (data.jobid == undefined || data.jobid == 0) {
            throw ({
                "message": "jobid must be provided."
            })
        } else if (data.remarks == undefined) {
            throw ({
                "message": "remarks must be provided."
            })
        } else {
            _output.data = article_service.add_automation_sub_status(data);
            _output.is_success = true;
            _output.message = "Status updated.";
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}