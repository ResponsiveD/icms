const getReminderMailService = require("../Service/reminder_mail.service");
const _mailOptions = require("../../../helpers/mailOptions");
const _mailer = require("../../../helpers/mailer");
const moment = require('moment');
const config = require('../../../../config/env/config.json');
const PACKAGE = require('../../../../package.json');

const iAuthorBaseURL = config[PACKAGE.environment]["iAuthorBaseURL"];
const getcompid = require('../../../../config/constant/components.json');
const exception_repo = require('../../../middleware/exception/exception')

exports.getReminderMailDetails = async (req, res, next) => {
  
  try {
    let finalReminderResult = await getReminderMailService.getReminderMailDetails();
    if (finalReminderResult.recordset != 0) {
      for (let index = 0; index < finalReminderResult.recordset.length; index++) {
        finalReminderResult.recordset[index].DueDate = moment(finalReminderResult.recordset[index].DueDate).format("DD/MM/YYYY");
        finalReminderResult.recordset[index].ArticleTitle = finalReminderResult.recordset[index].ArticleTitle.replace("<article-title>", "");
        finalReminderResult.recordset[index].ArticleTitle = finalReminderResult.recordset[index].ArticleTitle.replace("</article-title>", "");
        finalReminderResult.recordset[index].Abstract = finalReminderResult.recordset[index].Abstract.replace("<para>", "");
        finalReminderResult.recordset[index].Abstract = finalReminderResult.recordset[index].Abstract.replace("</para>", "");
      }
      for (let i = 0; i < finalReminderResult.recordset.length; i++) {
        let value = finalReminderResult.recordset[i];
        await sendmail(value);
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    console.log(error);
  }
};

var sendmail = function (value) {
  return new Promise((resolve, reject) => {
    try {
      let MailContent = value.MailContent
      MailContent = MailContent.replace('##name##', value.UserFName)
      MailContent = MailContent.replace('##ialink##', iAuthorBaseURL + '?docid=' + value.AId)
      MailContent = MailContent.replace('##duedate##', value.DueDate)
      MailContent = MailContent.replace('##abstract##', value.Abstract)
      MailContent = MailContent.replace('##articleauthor##', value.AuthorName)
      MailContent = MailContent.replace('##articletitle##', value.ArticleTitle)
      MailContent = MailContent.replace('##supportemail##', value.SupportEmail)
      MailContent = MailContent.replace('##publishername##', value.PublisherName)
      let options = new _mailOptions();
      options.bcc = value.BCCMailID;
      options.cc = value.CCMailID;
      options.from = value.FromMailID;
      options.html = MailContent;
      options.subject = "Reminder mail for " + value.Subject;
      options.to = value.ToMailID + ';' + value.UserEmailID;
      options.compid = getcompid.ijps.compID;
      _mailer.sendMail(options);
      resolve(true);
    } catch (error) {
      reject(error);
    }
  });
}