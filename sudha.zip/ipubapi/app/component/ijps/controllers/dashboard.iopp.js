const output = require("../../../models/Output");
//Repository
const get_dashboard_iopp_repo = require("../Service/dashboard.iopp");
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');

exports.get_dashboard_publisher = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let user_id = req.User.UserID;
        let result = await get_dashboard_iopp_repo.get_dashboard_publisher(user_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Get Dashboard Publisher";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.get_dashboard_auth_rev = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let user_id = req.User.UserID;
        let result = await get_dashboard_iopp_repo.get_dashboard_auth_rev(user_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Get Dashboard Author Reviewer";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}