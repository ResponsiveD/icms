const {
    check,
    validationResult
} = require('express-validator/check');
const feedbackService = require("../Service/feedback.service");
const output = require("../../../models/Output");
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');

exports.postFeedbackUser = async function (req, res, next) {
    // Finds the validation errors in this request and wraps them in an object with handy functions
    const errors = validationResult(req);
    var _output = new output();
    let error = null;
    if (!errors.isEmpty()) {
        _output.data = "";
        _output.is_success = false;
        _output.message = errors.array();
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    }

    
    try {
        let jsonQuestion = {
            question: []
        };
        // data = await common.getTokenUserDetail(req, data);
        let userId = req.User.UserID;
        let organisationId = req.User.OrgID;
        let {
            articleId,
            activityId,
            question
        } = req.body;
        if (question.length > 0) {
            question.map((a) => {
                jsonQuestion.question.push({
                    "feedbackId": a.feedbackId,
                    "answer": a.answer
                });
            });
        }

        let result = await feedbackService.postFeedbackUser(userId, organisationId, articleId, activityId, jsonQuestion);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Feedback question posted successfully.";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.getFeedbackUser = async function (req, res, next) {
    const errors = validationResult(req);
    var _output = new output();
    let error = null;
    if (!errors.isEmpty()) {
        _output.data = "";
        _output.is_success = false;
        _output.message = errors.array();
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    }

    
    try {
        let data = req.query;
        let userId = req.User.UserID;
        let {
            articleId,
            activityId
        } = req.query;
        let result = await feedbackService.getFeedbackUser(userId, articleId, activityId);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Feedback question retrived successfully.";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.getFeedback = async function (req, res, next) {
    var _output = new output();
    let error = null;
    
    try {
        let organisationId = req.User.OrgID;
        const customerId = req.query.customerId; //5;
        if (customerId == undefined || customerId == '') {
            throw {
                message: "customerId must be provided."
            }
        }
        let result = await feedbackService.getFeedback(organisationId, customerId);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Feedback question retrived successfully.";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}