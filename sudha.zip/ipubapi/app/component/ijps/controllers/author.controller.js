const {
    check,
    validationResult
} = require('express-validator/check');

const authorService = require("../Service/author.service");
const output = require("../../../models/Output");
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');

exports.postPublisherInviteAuthor = async function (req, res, next) {
    // Finds the validation errors in this request and wraps them in an object with handy functions
    const errors = validationResult(req);
    var _output = new output();
    let error = null;
    if (!errors.isEmpty()) {
        _output.data = "";
        _output.is_success = false;
        _output.message = errors.array();
        res.status(HttpStatus.OK).send(_output);
    }

    
    try {
        let authorList = []
        let userId = req.User.UserID;
        let organisationId = req.User.OrgID;
        let {
            author
        } = req.body;
        if (author.length > 0) {
            author.map((a) => {
                authorList.push({
                    "emailId": a.emailId,
                    "name": a.name
                });
            });
        }

        let result = await authorService.postPublisherInviteAuthor(userId, organisationId, authorList);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Authors invited successfully.";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.getAuthorAcceptInvitaion = async function (req, res, next) {
    // Finds the validation errors in this request and wraps them in an object with handy functions
    const errors = validationResult(req);
    var _output = new output();
    let error = null;
    if (!errors.isEmpty()) {
        _output.data = "";
        _output.is_success = false;
        _output.message = errors.array();
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    }

    
    try {
        let result = await authorService.getAuthorAcceptInvitaion(req.query.id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Author invited successfully.";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}