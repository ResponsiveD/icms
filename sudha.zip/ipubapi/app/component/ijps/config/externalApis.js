const config = require('../../../../config/env/config.json');
const PACKAGE = require('../../../../package.json');
const GetMetaDataFromiAuthor = config[PACKAGE.environment]["GetMetaDataFromiAuthor"];
const PutMetaDataToiAuthor = config[PACKAGE.environment]["PutMetaDataToiAuthor"];
const XmltoHtmlconvertion = config[PACKAGE.environment]["XmltoHtmlconvertion"];
const CastOffApi = config[PACKAGE.environment]["CastOffApi"];
const DoveAssignJobToWMS = config[PACKAGE.environment]["DoveAssignJobToWMS"];
const DoveEndPoint = config[PACKAGE.environment]["DoveEndPoint"];
const XmltoHtmlconvertionBook = config[PACKAGE.environment]["XmltoHtmlconvertionBook"];
const GetOCTLink = config[PACKAGE.environment]["GetOCTLink"];
const CloseOCTLink = config[PACKAGE.environment]["CloseOCTLink"];
const DoveGetMetadataDetails = config[PACKAGE.environment]["DoveGetMetadataDetails"];

module.exports = {
    GetMetaDataFromiAuthor,
    PutMetaDataToiAuthor,
    XmltoHtmlconvertion,
    CastOffApi,
    DoveAssignJobToWMS,
    DoveEndPoint,
    XmltoHtmlconvertionBook,
    GetOCTLink,
    CloseOCTLink,
    DoveGetMetadataDetails
};