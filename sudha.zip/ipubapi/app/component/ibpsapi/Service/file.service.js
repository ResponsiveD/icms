var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');
let common = require('../../../helpers/common');


exports.Inactivate_Submit_activity = async(data)=>{
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[LockRecordDetailAndBook]", parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.Submit_activity = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[Submitactivity]", parameters, db_library.query_type.SP).then((value) => {
                let out_put={};
                out_put.submitDtl = value.recordsets[0];
                out_put.soft_dtl = value.recordsets[1];
                resolve(out_put);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.dashboard_book =async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[DashboardBook]", parameters, db_library.query_type.SP).then((value) => {
                let out_put = value.recordsets[0];
                resolve(out_put);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}



exports.get_created_book = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[GetBookCreated]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_icore_conversion_dtl = async (file_guid,user_id,org_id,aty_id) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('file_guid', sqlType.NVarChar, file_guid);
        parameters.push(para);
        para = new param('user_id', sqlType.Int, user_id);
        parameters.push(para);
        para = new param('org_id', sqlType.Int, org_id);
        parameters.push(para);
        para = new param('aty_id', sqlType.Int, aty_id);
        parameters.push(para);
        db_library
            .execute("[IBPS].[GetiCoreConversionDtl]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_mail_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[submitactivitymail]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
  }

exports.xml_to_html_convertion_book = async (params) => {
    return await new Promise(async (resolve, reject) => {
        let externalApis = require("../config/externalApis")
        let url = externalApis.XmltoHtmlconvertionBook;
        await common.CallPostAPI(url, params)
            .then((value) => resolve(value)).catch((err) => reject(err))
    });
}

exports.bits_xml_to_html_convertion_book = async (params) => {
    return await new Promise(async (resolve, reject) => {
        let externalApis = require("../config/externalApis")
        let url = externalApis.BitsXmltoHtmlconvertionBook;
        await common.CallPostAPI(url, params)
            .then((value) => resolve(value)).catch((err) => reject(err))
    });
}

exports.html_to_xml_convertion_book = async (params) => {
    return await new Promise(async (resolve, reject) => {
        let externalApis = require("../config/externalApis")
        let url = externalApis.XmltoHtmlconvertionBook;
        await common.CallPostAPI(url, params)
            .then((value) => resolve(value)).catch((err) => reject(err))
    });
}

exports.iauthor_user_update = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[UserUpdateForiAuthor]", parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.article_history_InActivate =  async (hisID,orgid,userid) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('hisID', sqlType.BigInt, hisID);
        parameters.push(para);
        para = new param('userid', sqlType.Int, userid);
        parameters.push(para);
        para = new param('orgid', sqlType.Int, orgid);
        parameters.push(para);
        db_library
            .execute("[IBPS].[ArticleHistoryIsActivate]", parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.save_article_history = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[saveArticlehistory]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.Check_WF_activity = async (Data) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        _parameters.push(para);
        db_library
            .execute("[IPS].[CheckActivitywithWF]", _parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].status);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_file_attachment = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[AddEditFileAttch]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}


exports.create_book = async (data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
        parameters.push(para);
        db_library
            .execute('[IBPS].[AddEditBook]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0][0].book_id;
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_books = async (data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
        parameters.push(para);
        db_library
            .execute('[IBPS].[GetBooks]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0];
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_customers = async (data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
        parameters.push(para);
        db_library
            .execute('[IBPS].[GetCustomers]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0];
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_file_type = async (data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
        parameters.push(para);
        db_library
            .execute('[IBPS].[GetFileType]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0];
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_workflow = async (data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
        parameters.push(para);
        db_library
            .execute('[IBPS].[GetWorkflow]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0];
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_workflow_atys = async (data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
        parameters.push(para);
        db_library
            .execute('[IBPS].[GetWorkflowAtys]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0];
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_edit_user_for_aty = async (data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
        parameters.push(para);
        db_library
            .execute('[IBPS].[AddEditUserForAty]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0];
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_user_for_aty = async (data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
        parameters.push(para);
        db_library
            .execute('[IBPS].[GetUserForAty]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0];
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_chapter_detail = async (Data) => {
    return await new Promise((resolve, reject) => {

        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[AddEditChapter]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": err.message })
            });
    });
}

exports.add_third_party_log = async (Data) => {
    return await new Promise((resolve, reject) => {

        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IPS].[AddThirdPartyLog]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": err.message })
            });
    });
}



exports.main_upload_file = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[getMainpath]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].input_path);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.supplementary_upload_file = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[getsupplementarypath]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].resource_path);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.get_jobguid = async (req) => {
    try {
        if (!req.body.ChapterGUID) {
            throw {
                "message": "Provide ChapterGUID"
            };
        } else {
            // let aty_id = req.body.aty_id ? req.body.aty_id : 0;
            let _parameters = [];
            let para = new param('UserID', sqlType.Int, req.User.UserID);
            _parameters.push(para);
            para = new param('OrgID', sqlType.Int, req.User.OrgID);
            _parameters.push(para);
            para = new param('ChapterGUID', sqlType.NVarChar, req.body.ChapterGUID);
            _parameters.push(para);
            para = new param('AtyID', sqlType.Int, req.body.aty_id);
            _parameters.push(para);
            return db_library.execute_await("[IBPS].[GetJobGUID]", _parameters, db_library.query_type.SP);
        }
    } catch (error) {
        return {
            "message": "There is error on occurred in database, Please contact administrator "
        };
    }
}

exports.get_file_url = async (req) => {
    try {
        let _parameters = [];
        let para = new param('UserID', sqlType.Int, req.User.UserID);
        _parameters.push(para);
        para = new param('OrgID', sqlType.Int, req.User.OrgID);
        // _parameters.push(para);
        // para = new param('CompID', sqlType.Int, 1);
        _parameters.push(para);
        para = new param('CustID', sqlType.Int, req.body.cust_id);
        _parameters.push(para);
        para = new param('JOBGUID', sqlType.NVarChar, req.body.JOBGUID);
        _parameters.push(para);
        para = new param('ChapterGUID', sqlType.NVarChar, req.body.ChapterGUID);
        _parameters.push(para);
        para = new param('DocType', sqlType.NVarChar, req.body.doc_type);
        _parameters.push(para);
        para = new param('AtyID', sqlType.Int, req.body.aty_id);
        _parameters.push(para);
        return db_library.execute_await("[IBPS].[GetFilesFromBlob]", _parameters, db_library.query_type.SP);
    } catch (error) {
        return {
            "message": "There is error on occurred in database, Please contact administrator "
        };
    }
}

exports.getJobDetails = async (Data) => {
    try {
        let _parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        _parameters.push(para);
        return await db_library.execute_await('[IBPS].[GetJobDetails]', _parameters, db_library.query_type.SP)
    } catch (error) {
        return { "message": "There is error on occurred in database, Please contact administrator " };
    }
}
