"use strict";
const express = require("express");
const router = express.Router();

//Middelware
const middelware = require('../../../middleware/auth/auth.middelware');

//controller
const file_controller = require("../controllers/file.controller");
const fileoperation_controller = require("../controllers/fileoperation.controller");
const attachfile_controller = require("../controllers/attachfile.controller");

//file operation
router.post("/file-byteupload", middelware.userAuthOrSecreat, fileoperation_controller.file_byteupload);
router.post("/get-file-data", middelware.userAuthOrSecreat, fileoperation_controller.get_blob_datas);
router.post("/get-listoffile-uri", middelware.userAuth, fileoperation_controller.getListoffileuri)

//Chapter operation
router.post("/save-file-history", middelware.userAuth, file_controller.save_article_historys)

//i-Author 
router.post("/getjobdetails", middelware.userAuth, file_controller.getJobDetails)
router.get("/get-books",middelware.userAuth,file_controller.get_books)
router.get("/get-customers",middelware.userAuth,file_controller.get_customers)
router.get("/get-file-type",middelware.userAuth,file_controller.get_file_type)
router.get("/get-workflow",middelware.userAuth,file_controller.get_workflow)
router.get("/get-workflow-atys",middelware.userAuth,file_controller.get_workflow_atys)
router.get("/get-user-for-aty",middelware.userAuth,file_controller.get_user_for_aty)
router.post("/addedit-user-for-aty",middelware.userAuth,file_controller.add_edit_user_for_aty)
router.post("/create-book",middelware.userAuth,file_controller.create_book)
router.post("/add-chapter-details",middelware.userAuth,file_controller.add_chapter_details)
router.post("/chapter-upload-files",middelware.userAuth,file_controller.main_upload_files)
router.post("/supplementary-upload-files",middelware.userAuth,file_controller.supplementary_upload_files)
router.post("/add-file-attachments",middelware.userAuth,file_controller.add_file_attachments)
router.post("/submit-activity",middelware.userAuth,file_controller.Submit_activity)
router.post('/add-attach-file', middelware.userAuth, attachfile_controller.add_attachment_files);
router.get('/get-attach-file', middelware.userAuth, attachfile_controller.get_attachment_files);
router.get('/delete-attach-file', middelware.userAuth, attachfile_controller.delete_attachment_files);

//need to explain
router.get('/get-softattch-detail', middelware.userAuth, attachfile_controller.get_soft_attch_detail);
router.post('/add-third-party-log', middelware.userAuth, file_controller.add_third_party_log);
router.post('/iauthor-user-update',middelware.userAuth,file_controller.iauthor_user_update);
router.get('/dashboard-book',middelware.userAuth,file_controller.dashboard_book);
router.get('/get-created-books',middelware.userAuth,file_controller.get_created_book);
router.post('/html-to-xml-conversion-book',middelware.userAuth,file_controller.html_to_xml_conversion_book);
router.post("/get-files-blob", middelware.userAuth, file_controller.get_files_blob)

module.exports = router;