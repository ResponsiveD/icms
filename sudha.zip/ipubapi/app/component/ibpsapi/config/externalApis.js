const config = require('../../../../config/env/config.json');
const PACKAGE = require('../../../../package.json');
const modeconfig = require('../../../../config/env/env_mode.json')
const ENV_MODE = modeconfig.ENVMODE;
const XmltoHtmlconvertionBook = config[ENV_MODE]["XmltoHtmlconvertionBook"];
const BitsXmltoHtmlconvertionBook = config[ENV_MODE]["BitsXmltoHtmlconvertionBook"];

module.exports = {
    XmltoHtmlconvertionBook,
    BitsXmltoHtmlconvertionBook
};