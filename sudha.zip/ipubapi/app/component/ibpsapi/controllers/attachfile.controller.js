'use strict'
const attachfile_service = require("../Service/attachfile.service");
const file_upload = require('../../../helpers/common');
const output = require("../../../models/Output");
const common = require("../../../helpers/common");
const exception_repo = require("../../../middleware/exception/exception");
const HttpStatus = require('http-status-codes');

exports.add_attachment_files = async function (req, res, next) {
    var _output = new output();
    let error = null;
    req.User.CompID = 3;
    try {
        let data = req.body;
        data = await common.getTokenUserDetail(req, data);
        // let file = req.files["file"];
        let file = data.file;
        data.filename = file.name;
        data.file_guid = data.FileGUID;
        if (data.FileGUID == undefined || data.FileGUID == "") { throw { message: "FileGUID must be provided." } }
        else if (data.activity_id == undefined || data.activity_id == "") { throw { message: "activity_id must be provided." } }
        else {
            let blogpath = await attachfile_service.add_attach_filetoBlob(data);
            let result = { "path": await common.blobFileUpload(file.data, blogpath), "size": common.bytesToSize(file.data.data.length) }
            let postdata = {};
            postdata.user_id = data.user_id;
            postdata.org_id = data.org_id;
            postdata.file_guid = data.FileGUID;
            postdata.activity_id = data.activity_id;
            postdata.Filepath = result.path.split('//')[1].split('/').slice(1).join('/');
            postdata.Filename = file.name;
            postdata.Filesize = result.size;
            let path = await attachfile_service.add_attachment_files(postdata);
            _output.data = path;
            _output.is_success = true;
            _output.message = "File uploaded successfully";
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.delete_attachment_files = async function (req, res, next) {
    var _output = new output();
    req.User.CompID = 3;
    let error = null;
    try {
        let data = {};
        data.file_guid = req.query.FileGUID;
        data.AttachID = req.query.AttachID;
        data = await common.getTokenUserDetail(req, data);
        if (data.file_guid == undefined || data.file_guid == "") { throw { "message": "FileGUID Must be provided." } }
        else if (data.AttachID == undefined || data.AttachID == "") { throw { "message": "AttachID Must be provided." } }
        else {
            let path = await attachfile_service.delete_attachment_files(data);
            try {
                let result = await file_upload.get_blob_data(path[0].Filepath);
                let final = await file_upload.BlobDelete(path[0].Filepath, result, result.length);
            } catch (error) { }
            _output.data = path;
            _output.is_success = true;
            _output.message = "File deleted successfully";
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.get_attachment_files = async function (req, res, next) {
    var _output = new output();
    let error = null;
    req.User.CompID = 3;
    try {
        let data = {};
        data.JobGUID = req.query.JobGUID;
        data = await common.getTokenUserDetail(req, data);
        if (data.JobGUID == undefined || data.JobGUID == "") { throw { message: "JobGUID must be provided." } }
        else {
            _output.data = await attachfile_service.get_attachment_files(data);
            _output.is_success = true;
            _output.message = "Getting attached files Successfully";
        }
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.get_soft_attch_detail = async function (req, res, next) {
    var _output = new output();
    let error = null;
    req.User.CompID = 3;
    try {
        let data = {};
        data.soft_name = req.query.soft_name;
        data = await common.getTokenUserDetail(req, data);
        _output.data = await attachfile_service.get_soft_attch_details(data);
        _output.is_success = true;
        _output.message = "Getting software attachment details Successfully";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}