'use strict'

const output = require("../../../models/Output");
const file_service = require("../Service/file.service");
const common = require("../../../helpers/common");
const file_upload_config = require("../../../../config/file_upload_config");
const mailer = require("../../../helpers/mailer");
const getcompid = require('../../../../config/constant/components.json');
const basepath = file_upload_config.CloudCredentials().cloudBasePath;
const automation_repository = require("../../../repository/automation.service");
const exception_repo = require("../../../middleware/exception/exception");
const HttpStatus = require('http-status-codes');

var html_to_xml_convertion_book_call = async function (file_guid, aty_id, user_id, org_id, req) {
  try {
    await html_to_xml_convertion_book(file_guid, aty_id, user_id, org_id);
  } catch (error) {
    exception_repo.exception_DB_log(org_id, 3, user_id, 1, "html_to_xml_convertion_book_call", 'function', 'file_guid = ' + file_guid + ';aty_id = ' + aty_id + ';user_id = ' + user_id, error, 0, 0);
  }
}

var html_to_xml_convertion_book = async function (file_guid, aty_id, user_id, org_id) {
  return await new Promise(async (resolve, reject) => {
    try {
      let dbout = await file_service.get_icore_conversion_dtl(file_guid, user_id, org_id, aty_id).catch(err => {
        throw err;
      });
      let htmlContent = await common.getBlobToText(dbout.htmlPath).catch(err => {
        throw err;
      });
      let MetaPathContent = await common.getBlobToText(dbout.MetaPath).catch(err => {
        throw err;
      });
      let commentContent = await common.getBlobToText(dbout.CommentsPath).catch(err => {
        throw err;
      });
      let KeywordsContent = await common.getBlobToText(dbout.KeywordsPath).catch(err => {
        throw err;
      });
      let input = {
        "conversion_type": "book",
        "conversion_method": "backward",
        "DOMContent": htmlContent,
        "metaData": MetaPathContent,
        "comment": commentContent,
        "equation": KeywordsContent
      }
      let output = await file_service.html_to_xml_convertion_book(input);
      output = JSON.parse(output);
      if (output.is_success == false) {
        reject(output.error_stack);
      } else {
        let outPath = '';
        if (output.DOMContent != undefined && output.DOMContent != "") {
          outPath = await common.BlobTextUpload(dbout.Path.replace('/System/Input/', '/System/Output/'), output.DOMContent);
        }
        resolve(outPath);
      }
    } catch (error) {
      exception_repo.exception_DB_log(org_id, 3, user_id, 1, "html_to_xml_convertion_book", 'function', 'file_guid = ' + file_guid + ';aty_id = ' + aty_id + ';user_id = ' + user_id, error, 0, 0);
      reject(error);
    }
  });
}

var xml_to_html_convertion_book = async function (file_guid, aty_id, user_id, org_id) {
  return await new Promise(async (resolve, reject) => {
    try {
      let dbout = await file_service.get_icore_conversion_dtl(file_guid, user_id, org_id, aty_id).catch(err => {
        exception_repo.exception_DB_log(org_id, 3, user_id, 1, "xml_to_html_convertion_book to get_icore_conversion_dtl", 'function', 'file_guid = ' + file_guid + ';aty_id = ' + aty_id + ';user_id = ' + user_id, error, 0, 0);
        throw err
      });
     
      let xmlContent = await common.getBlobToStream(dbout.Path).catch(err => {
        exception_repo.exception_DB_log(org_id, 3, user_id, 1, "xml_to_html_convertion_book to get_icore_conversion_dtl", 'function', 'file_guid = ' + file_guid + ';aty_id = ' + aty_id + ';user_id = ' + user_id, error, 0, 0);
              throw err
      });

      let input = {
        "conversion_type": "book",
        "conversion_method": "forward",
        "DOMContent": xmlContent,
        "metaData": "",
        "comment": "",
        "equation": "",
        "configuration": {
          "resourcepath": dbout.ResPath,
          "blobDomain": dbout.BasePath,
          "customer_dtd": dbout.Cust
        }
      }
      let output = await file_service.xml_to_html_convertion_book(input);
      output = JSON.parse(output);
      if (output.is_success == false) {
        reject(output.error_stack);
      } else {
        let apiout = output;
        let DOMContentPath = dbout.htmlPath;
        let MetaDataPath = dbout.MetaPath;
        let CommentsPath = dbout.CommentsPath;
        let KeywordsPath = dbout.KeywordsPath;
        let authorInfoPath = dbout.authorInfoPath;
        let authorInfoMasterAffiliationPath = dbout.authorInfoMasterAffiliationPath;
        let EquationJsonPath = dbout.EquationJsonPath;
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(DOMContentPath, apiout.DOMContent);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(MetaDataPath, apiout.MetaData);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(CommentsPath, apiout.Comments);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(KeywordsPath, apiout.Keywords);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(authorInfoPath, apiout.authorInfo);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(authorInfoMasterAffiliationPath, apiout.authorInfoMasterAffiliation);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(EquationJsonPath, apiout.EquationJson);
        }
        resolve(true);
      }
    } catch (error) {
      exception_repo.exception_DB_log(org_id, 3, user_id, 1, "xml_to_html_convertion_book", 'function', 'file_guid = ' + file_guid + ';aty_id = ' + aty_id + ';user_id = ' + user_id, error, 0, 0);
      reject(error);
    }
  });
}

var bits_xml_to_html_convertion_book = async function (file_guid, aty_id, user_id, org_id) {
  return await new Promise(async (resolve, reject) => {
    try {
      let dbout = await file_service.get_icore_conversion_dtl(file_guid, user_id, org_id, aty_id).catch(err => {
        throw err
      });
      let xmlContent = await common.getBlobToText(dbout.Path).catch(err => {
        throw err
      });
      let input = {
        "conversion_type": "book",
        "conversion_method": "bitstoxml",
        "DOMContent": xmlContent,
        "metaData": "",
        "comment": "",
        "equation": "",
        "configuration": {
          "resourcepath": dbout.ResPath,
          "blobDomain": dbout.BasePath,
          "customer_dtd": dbout.Cust
        }
      }
      let output = await file_service.bits_xml_to_html_convertion_book(input);
      output = JSON.parse(output);
      if (output.is_success == false) {
        reject(output.error_stack);
      } else {
        let apiout = output;
        let DOMContentPath = dbout.htmlPath;
        let MetaDataPath = dbout.MetaPath;
        let CommentsPath = dbout.CommentsPath;
        let KeywordsPath = dbout.KeywordsPath;
        let authorInfoPath = dbout.authorInfoPath;
        let authorInfoMasterAffiliationPath = dbout.authorInfoMasterAffiliationPath;
        let EquationJsonPath = dbout.EquationJsonPath;
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(DOMContentPath, apiout.DOMContent);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(MetaDataPath, apiout.MetaData);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(CommentsPath, apiout.Comments);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(KeywordsPath, apiout.Keywords);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(authorInfoPath, apiout.authorInfo);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(authorInfoMasterAffiliationPath, apiout.authorInfoMasterAffiliation);
        }
        if (apiout.DOMContent != undefined && apiout.DOMContent != "") {
          await common.BlobTextUpload(EquationJsonPath, apiout.EquationJson);
        }
        resolve(true);
      }
    } catch (error) {
      exception_repo.exception_DB_log(org_id, 3, user_id, 1, "bits_xml_to_html_convertion_book", 'function', 'file_guid = ' + file_guid + ';aty_id = ' + aty_id + ';user_id = ' + user_id, error, 0, 0);
      reject(error);
    }
  });
}


exports.html_to_xml_conversion_book = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    if (data.file_guid == undefined || data.file_guid == "") {
      throw {
        "message": "file_guid must be Provided."
      };
    } else if (data.aty_id == undefined || data.aty_id == "") {
      throw {
        "message": "aty_id must be Provided."
      };
    }
    _output.data = await html_to_xml_convertion_book(data.file_guid, data.aty_id, data.user_id, data.org_id);
    _output.message = "Html to xml conversion success.";
    _output.is_success = true;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }

}

exports.get_created_book = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);

    _output.data = await file_service.get_created_book(data);
    _output.is_success = true;
    _output.message = "BookDetails.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.iauthor_user_update = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    if (data.doc_id == undefined || data.doc_id == "" || data.doc_id == 0) {
      throw {
        "message": "doc_id must be Provided."
      };
    } else if (data.email == undefined || data.email == "" || data.email == 0) {
      throw {
        "message": "email must be Provided."
      };
    } else if (data.twfd_id == undefined || data.twfd_id == "" || data.twfd_id == 0) {
      throw {
        "message": "twfd_id must be Provided."
      };
    } else {
      _output.data = await file_service.iauthor_user_update(data);
      _output.is_success = true;
      _output.message = "Updated User.";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.add_third_party_log = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = req.query;
    data = await common.getTokenUserDetail(req, data);
    if (data.email == undefined || data.email == "" || data.email == 0) {
      throw {
        "message": "email must be Provided."
      };
    } else if (data.doc_id == undefined || data.doc_id == "" || data.doc_id == 0) {
      throw {
        "message": "doc_id must be Provided."
      };
    } else if (data.party == undefined || data.party == "" || data.party == 0) {
      throw {
        "message": "party must be Provided."
      };
    } else {
      _output.data = await file_service.add_third_party_log(data);
      _output.is_success = true;
      _output.message = "updated log.";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.Submit_activity = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    if (data.aty_id == undefined) {
      throw ({
        message: "aty_id must be provided."
      })
    } else if (data.SubmitType == undefined || data.SubmitType === "") {
      throw ({
        message: "SubmitType must be provided."
      })
    } else if (data.files.length == undefined || data.files.length == 0) {
      throw ({
        message: "files must be provided"
      })
    } else if (data.files.filter((value) => {
      if (value.file_guid == undefined || value.file_guid == "") {
        return false;
      } else {
        return true;
      }
    }).length != data.files.length) {
      throw ({
        message: "files must contain file_guid"
      })
    } else {
      let submitDtl = await file_service.Submit_activity(data);
      let submitstatus = submitDtl.submitDtl;
      let soft_dtl = submitDtl.soft_dtl;
      if (submitstatus.length > 0) {
        if (data.to_email != undefined && data.to_email != '') {
          let userUpdateData = {};
          userUpdateData.user_id = data.user_id;
          userUpdateData.org_id = data.org_id;
          userUpdateData.doc_id = submitstatus[0].docid;
          userUpdateData.email = data.to_email;
          userUpdateData.twfd_id = submitstatus[0].twfd_id;
          await file_service.iauthor_user_update(userUpdateData);
        }
        for (let i = 0; i < submitstatus.length; i++) {
          if (submitstatus[i].iAuthorReq == 1 && data.aty_id == 0) {

            if (submitstatus[i].twfd_id == 83) {
              //bits_xml_to_html_convertion_book
              await bits_xml_to_html_convertion_book(submitstatus[i].FileGUID, submitstatus[i].ToAtyID, data.user_id, data.org_id).catch(async (err) => {
                let InActivateData = {};
                InActivateData.user_id = data.user_id;
                InActivateData.org_id = data.org_id;
                InActivateData.files = [];
                submitstatus.forEach(element => {
                  InActivateData.files.push({ file_guid: element.FileGUID, r_id: element.record_id })
                });
                await file_service.Inactivate_Submit_activity(InActivateData);
                throw err;
              })
            }
            else {
              await xml_to_html_convertion_book(submitstatus[i].FileGUID, submitstatus[i].ToAtyID, data.user_id, data.org_id).catch(async (err) => {
                let InActivateData = {};
                InActivateData.user_id = data.user_id;
                InActivateData.org_id = data.org_id;
                InActivateData.files = [];
                submitstatus.forEach(element => {
                  InActivateData.files.push({ file_guid: element.FileGUID, r_id: element.record_id })
                });
                await file_service.Inactivate_Submit_activity(InActivateData);
                throw err;
              })
            }
          }

          if (submitstatus[i].path != null) {
            let getfilepath = await common.ListAllFilesPath(submitstatus[i].path);
            let moveddata = await common.Listdatamovetodest(getfilepath, submitstatus[i].FromSubpath, submitstatus[i].ToSubpath);
            try {
              let getdata = await common.get_blob_data(submitstatus[i].pathhis);
              let final = await common.BlobUpload(submitstatus[i].pathatlin, getdata, getdata.length);
            } catch (err) {
              if (submitstatus[i].iAuthorReq == 1) {
                await xml_to_html_convertion_book(submitstatus[i].FileGUID, submitstatus[i].ToAtyID, data.user_id, data.org_id).catch((err) => {
                  throw err;
                })
              }
            }
            if (soft_dtl != undefined) {
              if (soft_dtl.filter(e => {
                return e.SoftId == 2
              }).length > 0) {
                html_to_xml_convertion_book_call(submitstatus[i].FileGUID, submitstatus[i].ToAtyID, data.user_id, data.org_id, req);
              }
            }
          }
          if (i == submitstatus.length - 1) {
            let getmaildetails = await file_service.get_mail_detail(data);
            if (getmaildetails != undefined) {
              getmaildetails.forEach(async element => {
                if (element.mailContent != undefined || element.mailContent != '') {
                  const _mailOptions = require("../../../helpers/mailOptions");
                  var options = new _mailOptions();
                  options.from = element.frommailid;
                  options.to = element.tomailid;
                  options.cc = element.ccmailid;
                  options.bcc = element.bccmailid;
                  options.html = element.mailContent;
                  options.subject = element.mailsubject;
                  options.compid = getcompid.ibps.compID;
                  let mail = await mailer.sendMail(options);
                }
              });
            }
            _output.data = _output.data = {
              "Notify": "success",
              "full_data": submitstatus,
              "docid": submitstatus[i].docid,
              "twfd_id": submitstatus[i].twfd_id,
              "due_date": submitstatus[i].due_date
            }
            _output.is_success = true;
            _output.message = "Submit activity completed Successfully";
          }
        }
      } else {
        _output.is_success = true;
        _output.message = "Submit activity completed Successfully";
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.dashboard_book = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await file_service.dashboard_book(data);
    _output.is_success = true;
    _output.message = "Dashboard data.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.getJobDetails = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  //   let mock = '{"is_success":true, "sMessage": "Content Found for GUID : 15987524", "nCode": 1, "sType": "Information", "nType": 2, "oData": {   "jobdetails": {     "JobGUID": "15987524",     "BookName": "CUPSample",     "BookCode": "CUPS",     "OveralJobStatus": "WIP",     "ProofType": "B",     "Customer": "cup",     "ResourcePath": "ibps/15987524/Data/Resources",     "HasTrack": "True",     "HasContentAccess": "True",    "RevisionCount": 0,     "CustomerID": 9,    "CommentEditable": "True",     "isOnshore": false   },   "ActivtyDetails": {     "ActivityID": 55,     "ActivityName": "Author",    "roleID": 12,     "userDetails": {       "roleName": "copy editor",       "Name": "Prabakaran.R",       "Email": "prabakaran.ravy@integra.co.in"     },     "ActivitySequence": 2   },   "chapterdetails": [     {       "ChapterGUID": "11111111",       "ChapterId": 1,       "ChapterName": "Chapter1",                  "ChapterTitle": "Chapter1",       "ChapSeq": 1,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111111/System/Input/Chapter1.html",       "OutputPath": "ibps/15987524/Data/55/11111111/System/OutPut/Chapter1.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111111/System/Resources"     },     {       "ChapterGUID": "22222222",       "ChapterId": 2,       "ChapterName": "Chapter2",                  "ChapterTitle": "Chapter2",       "ChapSeq": 2,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/22222222/System/Input/Chapter2.html",       "OutputPath": "ibps/15987524/Data/55/22222222/System/OutPut/Chapter2.xml",       "ChpResourcePath": "ibps/15987524/Data/55/22222222/System/Resources"     },     {       "ChapterGUID": "33333333",       "ChapterId": 3,       "ChapterName": "Chapter3",                  "ChapterTitle": "Chapter3",       "ChapSeq": 3,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/33333333/System/Input/Chapter3.html",       "OutputPath": "ibps/15987524/Data/55/33333333/System/OutPut/Chapter3.xml",       "ChpResourcePath": "ibps/15987524/Data/55/33333333/System/Resources"     },    {       "ChapterGUID": "44444444",       "ChapterId": 4,       "ChapterName": "Chapter4",                  "ChapterTitle": "Chapter4",       "ChapSeq": 4,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/44444444/System/Input/Chapter4.html",       "OutputPath": "ibps/15987524/Data/55/44444444/System/OutPut/Chapter4.xml",       "ChpResourcePath": "ibps/15987524/Data/55/44444444/System/Resources"     },    {       "ChapterGUID": "55555555",       "ChapterId": 5,       "ChapterName": "Chapter5",                  "ChapterTitle": "Chapter5",       "ChapSeq": 5,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/55555555/System/Input/Chapter5.html",       "OutputPath": "ibps/15987524/Data/55/55555555/System/OutPut/Chapter5.xml",       "ChpResourcePath": "ibps/15987524/Data/55/55555555/System/Resources"     },    {       "ChapterGUID": "66666666",       "ChapterId": 6,       "ChapterName": "Chapter6",                  "ChapterTitle": "Chapter6",       "ChapSeq": 6,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/66666666/System/Input/Chapter6.html",       "OutputPath": "ibps/15987524/Data/55/66666666/System/OutPut/Chapter6.xml",       "ChpResourcePath": "ibps/15987524/Data/55/66666666/System/Resources"     },    {       "ChapterGUID": "77777777",       "ChapterId": 7,       "ChapterName": "Chapter7",                  "ChapterTitle": "Chapter7",       "ChapSeq": 7,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/77777777/System/Input/Chapter7.html",       "OutputPath": "ibps/15987524/Data/55/77777777/System/OutPut/Chapter7.xml",       "ChpResourcePath": "ibps/15987524/Data/55/77777777/System/Resources"     },    {       "ChapterGUID": "88888888",       "ChapterId": 8,       "ChapterName": "Chapter8",                  "ChapterTitle": "Chapter8",       "ChapSeq": 8,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/88888888/System/Input/Chapter8.html",       "OutputPath": "ibps/15987524/Data/55/88888888/System/OutPut/Chapter8.xml",       "ChpResourcePath": "ibps/15987524/Data/55/88888888/System/Resources"     },    {       "ChapterGUID": "99999999",       "ChapterId": 9,       "ChapterName": "Chapter9",                  "ChapterTitle": "Chapter9",       "ChapSeq": 9,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/99999999/System/Input/Chapter9.html",       "OutputPath": "ibps/15987524/Data/55/99999999/System/OutPut/Chapter9.xml",       "ChpResourcePath": "ibps/15987524/Data/55/99999999/System/Resources"     },    {       "ChapterGUID": "11111112",       "ChapterId": 10,       "ChapterName": "Chapter10",                  "ChapterTitle": "Chapter10",       "ChapSeq": 10,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111112/System/Input/Chapter10.html",       "OutputPath": "ibps/15987524/Data/55/11111112/System/OutPut/Chapter10.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111112/System/Resources"     },    {       "ChapterGUID": "11111113",       "ChapterId": 11,       "ChapterName": "Chapter11",                  "ChapterTitle": "Chapter11",       "ChapSeq": 11,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111113/System/Input/Chapter11.html",       "OutputPath": "ibps/15987524/Data/55/11111113/System/OutPut/Chapter11.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111113/System/Resources"     },    {       "ChapterGUID": "11111114",       "ChapterId": 12,       "ChapterName": "Index",                  "ChapterTitle": "Index",       "ChapSeq": 12,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111114/System/Input/Index.html",       "OutputPath": "ibps/15987524/Data/55/11111114/System/OutPut/Index.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111114/System/Resources"     },    {       "ChapterGUID": "11111115",       "ChapterId": 13,       "ChapterName": "Prelims",                  "ChapterTitle": "Prelims",       "ChapSeq": 13,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111115/System/Input/Prelims.html",       "OutputPath": "ibps/15987524/Data/55/11111115/System/OutPut/Prelims.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111115/System/Resources"     },    {       "ChapterGUID": "11111116",       "ChapterId": 14,       "ChapterName": "Chapter12",                  "ChapterTitle": "Chapter12",       "ChapSeq": 14,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111116/System/Input/Chapter12.html",       "OutputPath": "ibps/15987524/Data/55/11111116/System/OutPut/Chapter12.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111116/System/Resources"     },    {       "ChapterGUID": "11111117",       "ChapterId": 15,       "ChapterName": "Chapter13",                  "ChapterTitle": "Chapter13",       "ChapSeq": 15,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111117/System/Input/Chapter13.html",       "OutputPath": "ibps/15987524/Data/55/11111117/System/OutPut/Chapter13.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111117/System/Resources"     }   ] }}';
  // res.send(JSON.parse(mock));
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let result = await file_service.getJobDetails(data);
    if (result.recordset.length > 0) {
      res.status(HttpStatus.OK);

      let resultObject = {}
      let name = Object.keys(result.recordset[0])[0]; // Get the first item of the list;  = key name
      let JsonData = result.recordset[0][name];

      if (JsonData != '' && JsonData != undefined) {
        resultObject['sMessage'] = "Content Found for GUID : " + JSON.stringify(req.body.fileGuids);
        resultObject['is_success'] = true;
        let resultarray = JSON.parse(JsonData);
        resultObject['oData'] = resultarray[0];
      } else {
        resultObject['sMessage'] = "Content not found for GUID : " + JSON.stringify(req.body.fileGuids);
        resultObject['oData'] = JsonData;
        resultObject['is_success'] = false;
      }
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, resultObject, error, 1);
      res.send(resultObject);
    } else {
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send();
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.wms_createjob_book = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = {};
    data = req.body;
    //data = await common.getTokenUserDetail(req, data);
    let validate_lstFileToUpload = req.body.lstFileToUpload.some(function (data) {
      if (data.Filenamewithextension != null && data.Filenamewithextension != undefined && data.FileContent != null && data.FileContent != undefined && data.Code != null && data.Code != undefined) {
        return false;
      } else {
        return true;
      }
    });

    let validate_workflowATY = req.body.workflowDetails.SequenceDetails.some(function (data) {
      if (data.ActivityID != null && data.ActivityID != undefined && data.RoleID != null && data.RoleID != undefined && data.ActivityName != null && data.ActivityName != undefined && data.userDetails[0].UserName != null && data.userDetails[0].UserName != undefined && data.userDetails[0].Email != null && data.userDetails[0].Email != undefined) {
        return false;
      } else {
        return true;
      }
    });

    let validate_booktoc = req.body.BookDetails.booktoc.some(function (data) {
      if (data.FileName != null && data.FileName != undefined && data.Code != null && data.Code != undefined && data.title != null && data.title != undefined && data.IsOnshore != null && data.IsOnshore != undefined) {
        return false;
      } else {
        return true;
      }

    });

    let validate_cusid = req.body.CustomerID;
    let validate_wfid = req.body.workflowDetails.WorkflowID;
    let validate_bookcode = req.body.BookDetails.bookcode;
    let validate_bookname = req.body.BookDetails.bookname;
    let WFaty = req.body.workflowDetails;
    let validate_prooftype = req.body.ProofType;

    if (validate_lstFileToUpload) {
      throw {
        "message": "Check lstFileToUpload Input"
      };
    } else if (validate_prooftype == null || validate_prooftype == undefined) {
      throw {
        "message": "Check Proof Type Input"
      };
    } else if (validate_workflowATY) {
      throw {
        "message": "Check WF Activity Input"
      };
    } else if (validate_cusid == null || validate_cusid == undefined) {
      throw {
        "message": "Check CustomerID Input"
      };
    } else if (validate_wfid == null || validate_wfid == undefined) {
      throw {
        "message": "Check WorkflowID Input"
      };
    } else if (validate_bookcode == null || validate_bookcode == undefined) {
      throw {
        "message": "Check journalcode Input"
      };
    } else if (validate_bookname == null || validate_bookname == undefined) {
      throw {
        "message": "Check journalname Input"
      };
    } else if (validate_booktoc == null || validate_booktoc == undefined) {
      throw {
        "message": "Check booktoc Input"
      };
    } else if (1 != await file_service.Check_WF_activity(WFaty)) {
      throw {
        "message": "Check WF Activity has mismatch Input"
      };
    } else { }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.add_file_attachments = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    if (data.file_id == undefined || data.file_id == "") {
      throw ({
        message: "file_id must be provided"
      });
    } else if (data.files == undefined || data.files == "") {
      throw ({
        message: "files array must be provided"
      });
    } else {
      _output.data = await file_service.add_file_attachment(data);
      if (req.body.files.length > 0) {
        for (let index = 0; index < req.body.files.length; index++) {
          const element = req.body.files[index];
          if (element.is_active != true) {
            let filePath = element.path.split('/').splice(4).join('/');
            let checkisExist = await common.doesBlobExist(filePath);
            if (checkisExist) {
              let result = await common.get_blob_data(filePath);
              await common.BlobDelete(filePath, result, result.length);
            }
          }
        }
      }
      _output.is_success = true;
      _output.message = "File attachment updated successfully";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.create_book = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    if (data.book_name == undefined || data.book_name == "") {
      throw {
        "message": "book_name must be Provided."
      };
    } else if (data.cust_id == undefined || data.cust_id == "" || data.cust_id == 0) {
      throw {
        "message": "cust_id must be Provided."
      };
    } else if (data.is_active == undefined || data.is_active == "") {
      throw {
        "message": "is_active must be Provided."
      };
    } else if (data.book_code == undefined || data.book_code == "") {
      throw {
        "message": "book_code must be Provided."
      };
    } else if (data.book_id == undefined) {
      throw {
        "message": "book_id must be Provided."
      };
    } else {
      _output.data = await file_service.create_book(data);
      _output.is_success = true;
      _output.message = "Book Details.";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_books = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = req.query;
    data = await common.getTokenUserDetail(req, data);
    if (data.cust_id == undefined || data.cust_id == "" || data.cust_id == 0) {
      throw {
        "message": "cust_id must be Provided."
      };
    } else {
      _output.data = await file_service.get_books(data);
      _output.is_success = true;
      _output.message = "Books.";
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_file_type = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = {};
    data = await common.getTokenUserDetail(req, data);
    _output.data = await file_service.get_file_type(data);
    _output.is_success = true;
    _output.message = "Books.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_customers = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = {};
    data = await common.getTokenUserDetail(req, data);
    _output.data = await file_service.get_customers(data);
    _output.is_success = true;
    _output.message = "Books.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.save_article_historys = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    if (req.body.htmlcontent != null && req.body.htmlcontent != null && req.body.htmlcontent != '') {
      let data = {};
      data = req.body;
      data = await common.getTokenUserDetail(req, data);
      let histguid = await file_service.save_article_history(data);
      if (histguid.status == 'true') {
        res.status(HttpStatus.OK);
        let blobdata = {};
        blobdata.byte = req.body.htmlcontent;
        blobdata.path = histguid.Path_History;
        _output.data = await common.blobByteUpload(blobdata);
        if (await common.doesBlobExist(blobdata.path) == false) {
          await file_service.article_history_InActivate(histguid.hisID, data.org_id, data.user_id);
          throw { "message": "Not Saved Successfully" };
        }
        _output.is_success = true;
        _output.message = "Saved Successfully";

      } else {
        _output.data = "";
        _output.is_success = false;
        _output.message = "Not saved Successfully";
      }
    } else {
      throw {
        "message": "Check html content Input"
      };
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.getListoffileuri = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let path = req.body.path;
    let getfilepath = await common.ListAllblobPathURI(path);
    _output.data = {
      "URI": getfilepath,
      "count": getfilepath.length
    }
    _output.is_success = true;
    _output.message = "Get list of URI";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_workflow = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = req.query;
    data = await common.getTokenUserDetail(req, data);
    if (data.cust_id == undefined || data.cust_id == "") {
      throw {
        "message": "cust_id must be Provided."
      };
    }
    _output.data = await file_service.get_workflow(data);
    _output.is_success = true;
    _output.message = "Workflows";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_workflow_atys = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = req.query;
    data = await common.getTokenUserDetail(req, data);
    if (data.wfd_id == undefined || data.wfd_id == "") {
      throw {
        "message": "wfd_id must be Provided."
      };
    }
    _output.data = await file_service.get_workflow_atys(data);
    _output.is_success = true;
    _output.message = "Workflow Activities.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.add_edit_user_for_aty = async function (req, res, next) {
  var _output = new output();
  let error = null;
  req.User.CompID = 3;
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    if (data.is_active == undefined) {
      throw {
        "message": "is_active must be Provided."
      };
    } else if (data.twfd_id == undefined || data.twfd_id == "") {
      throw {
        "message": "twfd_id must be Provided."
      };
    } else if (data.file_id == undefined || data.file_id == "") {
      throw {
        "message": "file_id must be Provided."
      };
    } else if (data.Email_id == undefined || data.Email_id == "") {
      throw {
        "message": "Email_id must be Provided."
      };
    } else {
      _output.data = await file_service.add_edit_user_for_aty(data);
      _output.is_success = true;
      _output.message = "updated the user for Activity";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_user_for_aty = async function (req, res, next) {
  var _output = new output();
  req.User.CompID = 3;
  let error = null;
  try {
    let data = req.query;
    data = await common.getTokenUserDetail(req, data);
    if (data.twfd_id == undefined || data.twfd_id == "") {
      throw {
        "message": "twfd_id must be Provided."
      };
    } else if (data.file_id == undefined || data.file_id == "") {
      throw {
        "message": "file_id must be Provided."
      };
    } else {
      _output.data = await file_service.get_user_for_aty(data);
      _output.is_success = true;
      _output.message = "updated the user for Activity";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.add_chapter_details = async function (req, res, next) {
  var _output = new output();
  req.User.CompID = 3;
  let error = null;
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    if (data.book_id == undefined || data.book_id == "") {
      throw {
        "message": "book_id must be Provided."
      };
    } else if (data.file_name == undefined || data.file_name == "") {
      throw {
        "message": "file_name must be Provided."
      };
    } else if (data.file_order == undefined || data.file_order == "") {
      throw {
        "message": "file_order must be Provided."
      };
    } else if (data.is_active == undefined) {
      throw {
        "message": "is_active must be Provided."
      };
    } else if (data.wfd_id == undefined || data.wfd_id == "") {
      throw {
        "message": "wfd_id must be Provided."
      };
    } else if (data.ser_id == undefined || data.ser_id == "") {
      throw {
        "message": "ser_id must be Provided."
      };
    } else if (data.file_type == undefined || data.file_type == "") {
      throw {
        "message": "file_type must be Provided."
      };
    } else {
      _output.data = await file_service.add_chapter_detail(data);
      _output.is_success = true;
      _output.message = "Chapter updated successfully";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.main_upload_files = async function (req, res, next) {
  var _output = new output();
  req.User.CompID = 3;
  let error = null;
  var path = require('path');
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let file = req.files["file"];
    var CheckMimeType = file_upload_config.AllowedFileType.indexOf(req.files.file.mimetype);
    var CheckExtension = file_upload_config.AllowedFileExtension.indexOf(path.extname(req.files.file.name));
    if (CheckExtension != -1 && CheckMimeType != -1) {
      data.filename = file.name;
      let filepath = await file_service.main_upload_file(data);
      _output.data = {
        "path": await common.blobFileUpload(file, filepath),
        "size": common.bytesToSize(file.data.length)
      }
      _output.is_success = true;
      _output.message = "File uploaded successfully";
    } else {
      _output.data = "";
      _output.is_success = false;
      _output.message = "Please upload only following file format: .jpeg, .jpg, .pdf, .png, .doc, .docx, .xls, .xlsx, .xlsb, .ppt, .pptx, .msg, postscript and ms office file format\'s";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.supplementary_upload_files = async function (req, res, next) {
  var _output = new output();
  req.User.CompID = 3;
  let error = null;
  var path = require('path')
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let file = req.files["file"];
    var CheckMimeType = file_upload_config.AllowedFileType.indexOf(req.files.file.mimetype);
    var CheckExtension = file_upload_config.AllowedFileExtension.indexOf(path.extname(req.files.file.name));
    if (CheckExtension != -1 && CheckMimeType != -1) {
      data.filename = file.name;
      let filepath = await file_service.supplementary_upload_file(data);
      _output.data = {
        "path": await common.blobFileUpload(file, filepath),
        "size": common.bytesToSize(file.data.length)
      }
      _output.is_success = true;
      _output.message = "File uploaded successfully";
    } else {
      _output.data = "";
      _output.is_success = false;
      _output.message = "Please upload only following file format: .jpeg, .jpg, .pdf, .png, .doc, .docx, .xls, .xlsx, .xlsb, .ppt, .pptx, .msg, postscript and ms office file format\'s";
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_files_blob = async function (req, res, next) {
  var _output = new output();
  req.User.CompID = 3;
  let error = null;
  try {
    let data = req.body,
      jobguid = '',
      FileuploadedPath = '';
    // pathvalue = '';
    let path = [],
      file_type = [],
      getfilepath = [];
    // await file_service.get_jobguid(req, req.body.chapter_guid, req.body.aty_id).then((result) => {
    //   pathvalue = result.recordsets[0][0].PathValue;
    // });
    if (data.JOBGUID) {
      path.push('ibps' + '/' + data.JOBGUID + '/')
      jobguid = data.JOBGUID;
    } else if (data.ChapterGUID) {
      let result = await file_service.get_jobguid(req);
      jobguid = result.recordsets[0][0].jobguid;
      for (let i = 0; i < result.recordsets[0].length; i++) {
        path.push('ibps' + '/' + result.recordsets[0][i].jobguid + '/Data/' + result.recordsets[0][i].aty_id + '/' + result.recordsets[0][i].chapter_guid + '/')
      }
    } else {

    }
    for (let i = 0; i < path.length; i++) {
      let value = await common.ListAllFilesPath(path[i]);
      value.length > 0 ? getfilepath.push(value) : '';
    }
    if (getfilepath && getfilepath.length > 0) {
      if (req.body.doc_type == "xml") {
        getfilepath[0].forEach(element => {
          let type = element.split('.')[1];
          if ((type == 'xml') && !(element.toLocaleLowerCase().includes('ICORE_Metadata.xml'.toLocaleLowerCase())) && !(element.toLocaleLowerCase().includes('icore.xml'.toLocaleLowerCase()))) {
            file_type.push(element)
          }
        });
      } else if (req.body.doc_type == "pdf") {
        getfilepath[0].forEach(element => {
          let type = element.split('.')[1];
          if (type == 'pdf')
            file_type.push(element)
        });
      } else if (req.body.doc_type == "doc" || req.body.doc_type == "docx") {
        getfilepath[0].forEach(element => {
          let type = element.split('.')[1];
          if (type == 'doc' || type == 'docx')
            file_type.push(element)
        });
      } else if (req.body.doc_type == "icorexml") {
        getfilepath[0].forEach(element => {
          let type = element.split('.')[1];
          if (type == 'xml' && element.toLocaleLowerCase().includes('icore.xml'.toLocaleLowerCase()) && !(element.toLocaleLowerCase().includes('ICORE_Metadata.xml'.toLocaleLowerCase()))) {
            file_type.push(element)
          }
        });
      } else if (req.body.doc_type == 'zip') {
        let uniqueFolder = common.guid();
        let in_path = 'ibps/' + jobguid + '/downloads/In/' + uniqueFolder + '/' + jobguid + '.zip';
        FileuploadedPath = await automation_repository.add_blob_to_zip_with_path(getfilepath[0], in_path);
      }

      let output = [];
      if (file_type.length > 0) {
        file_type.forEach(element => {
          output.push(basepath + element);
        });
        _output.data = output;
        _output.is_success = true;
        _output.message = 'file exists in blob.';
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
      } else if (FileuploadedPath) {
        _output.data = basepath + FileuploadedPath;
        _output.is_success = true;
        _output.message = 'file exists in blob.';
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
      } else {
        _output.data = '';
        _output.is_success = false;
        _output.message = 'No such files in blob.';
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
      }
    } else {
      _output.data = '';
      _output.is_success = false;
      _output.message = 'No such files in blob.';
      req.User.endTime = new Date();
      exception_repo.exception_DB_log(req, _output, error, 1);
      res.status(HttpStatus.OK).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, _output, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}