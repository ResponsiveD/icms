const file_upload = require('../../../helpers/common');
const output = require("../../../models/Output");
const exception_repo = require('../../../middleware/exception/exception')
const HttpStatus = require('http-status-codes');

exports.file_byteupload = async function (req, res, next) {
    var _output = new output();
    req.User.CompID = 3;
    let error = null;
    try {
        let data = {};
        data.byte = req.body.byte
        data.path = req.body.path;
        let result = await file_upload.blobByteUpload(data);
        _output.data = { Path: result };
        _output.is_success = true;
        _output.message = "File Uploaded in blob";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.get_blob_datas = async function (req, res, next) {
    var _output = new output();
    let error = null;
    req.User.CompID = 3;
    try {
        let data = {};
        data.start = req.body.path
        let result = await file_upload.get_blob_data(data.start);
        _output.data = result;
        _output.is_success = true;
        _output.message = "getting file in blob successfully";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.getListoffileuri = async function (req, res, next) {
    var _output = new output();
    req.User.CompID = 3;
    let error = null;
    try {
        let path = req.body.path;
        if (path == undefined || path == "") { throw { message: "path must be provided." } }
        let getfilepath = await file_upload.ListAllblobPathURI(path);
        _output.data = { "URI": getfilepath, "count": getfilepath.length }
        _output.is_success = true;
        _output.message = "Get list of URI";
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date();
        exception_repo.exception_DB_log(req, _output, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}