"use strict";
const HttpStatus = require('http-status-codes');
// const exception_repo = require("../middleware/exception/exception");


exports.set_meta_data_pipe = async function (req, res, next) {
    try {
      let data = req.query;
      if(data){
            next()
      }else{
        res.state(HttpStatus.UNPROCESSABLE_ENTITY).send("validation error");
      }
    } catch (error) {
   //   exception_repo.exception_DB_log(1,1,1,1,req.method,req.originalUrl,JSON.stringify(req.body),error);
      res.send(error);
    }
  };

  exports.get_file_url = async function (req, res, next) {
    try {
      let data = req.body;
      if(data){
            next()
      }else{
        res.state(HttpStatus.UNPROCESSABLE_ENTITY).send("validation error");
      }
    } catch (error) {
   //   exception_repo.exception_DB_log(1,1,1,1,req.method,req.originalUrl,JSON.stringify(req.body),error);
      res.send(error);
    }
  };