"use strict";
const attachment_type_clearance_repo = require("../repository/attachment_type_clearance");
const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.attachment_type_clearance = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null; 
  req.User.CompID = 1; try {
    result = await attachment_type_clearance_repo.attachment_type_clearance();
    _output.data = result;
    _output.is_success = true;
    _output.message = "Attachment Type list";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}