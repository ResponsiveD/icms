'use strict'
const activity_actions_repo = require("../repository/activity_actions");
const activity_actions = require("../models/activity_actions")
const login_repo = require("../../../repository/login.service");
const output = require("../models/output");
var helper = require("../helpers/json-serialize");
const getcompid = require('../../../../config/constant/components.json');
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.start_activity = async function (req, res, next) {
  var _output = new output();
  let error = null;
  let result = null;
  
  req.User.CompID = 1; try {
    let _activity_actions = await helper.serialize_type(activity_actions, req.body, "")
    _activity_actions.status_id = 2;
    result = await activity_actions_repo.activity_action(_activity_actions);
    _output.data = result;
    _output.is_success = result.result;
    _output.message = result.status_message;

    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.send_mail = async function (object) {
  return new Promise(async (resolve, reject) => {
    let error = null; let result = null;  req.User.CompID = 1; try {
      let id = object.id
      let updater_id = object.user_id
      let name = object.name
      let to = object.to
      let cc = object.cc
      let url = object.url
      let text = object.text
      var options = await activity_actions_repo.get_mail_template(id, updater_id);
      options.to = options.to + ';' + to
      options.cc = options.cc + ';' + cc
      options.compid = getcompid.irights.compID;
      let body = options.html
      body = body.replace('##name##', name)
      body = body.replace('##url##', url)
      body = body.replace('##text##', text);
      _mailer.sendMail(options);
      resolve(true);
    } catch (error) {
      reject(error)
    }
  });
}

exports.put_pending_for_user = async function (req, res, next) {
  let error = null; let result = null;
  var _output = new output();
  
  req.User.CompID = 1; try {
    let user_id = req.query.user_id;
    await activity_actions_repo.put_pending_for_user(user_id);
    // await login_repo.LogInOut(req.User.UserID, req.User.LoginID, 1, 0);
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
exports.pending_activity = async function (req, res, next) {
  var _output = new output();
  let error = null;
  let result = null;
  
  req.User.CompID = 1; try {
    let _activity_actions = await helper.serialize_type(activity_actions, req.body, "")
    _activity_actions.status_id = 3;
    result = await activity_actions_repo.activity_action(_activity_actions);
    _output.data = result;
    _output.is_success = result.result;
    _output.message = result.status_message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
var submit_activity_loop = async function (data) {
  return new Promise(async (resolve, reject) => {
     try {
      let result;
      for (let ii = 0; ii < data.length; ii++) {
        let _activity_actions = await helper.serialize_type(activity_actions, data[ii], "")
        _activity_actions.status_id = 4;
        let cust = _activity_actions.skip_active
        result = await activity_actions_repo.activity_action(_activity_actions, cust);
      }
      resolve(result);
    } catch (err) {
      reject(err.message);
    }
  });
}
exports.submit_activity = async function (req, res, next) {
  var _output = new output();
  let error = null;
  let result = null;
  
  req.User.CompID = 1; try {
    let result;
    if (req.body.length) {
      result = await submit_activity_loop(req.body).catch(err => { throw { message: err }; });
      _output.data = result;
      _output.is_success = result.result;
      _output.message = result.status_message;
    }
    else {
      let _activity_actions = await helper.serialize_type(activity_actions, req.body, "")
      _activity_actions.status_id = 4;
      let cust = _activity_actions.skip_active
      result = await activity_actions_repo.activity_action(_activity_actions, cust);
      _output.data = result;
      _output.is_success = result.result;
      _output.message = result.status_message;
    }

    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

var reject_activity_loop = async function (data) {
  return new Promise((resolve, reject) => {
    try {
      data.forEach(async (element, index, arr) => {
        let _activity_actions = await helper.serialize_type(activity_actions, element, "")
        _activity_actions.status_id = 10;
        let cust = _activity_actions.skip_active
        result = await activity_actions_repo.activity_action(_activity_actions, cust).catch(err => reject(err));
        if (arr.length - 1 == index) {
          resolve(result);
        }
      });
    } catch (err) {
      reject(err.message);
    }
  });
}

exports.reject_activity = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let result;
    if (req.body.length) {
      result = await reject_activity_loop(req.body).catch(err => { throw { message: err }; });
      _output.data = result;
      _output.is_success = result.result;
      _output.message = result.status_message;
    }
    else {
      let _activity_actions = await helper.serialize_type(activity_actions, req.body, "")
      _activity_actions.status_id = 10;
      let cust = _activity_actions.skip_active
      result = await activity_actions_repo.activity_action(_activity_actions, cust);
      _output.data = result;
      _output.is_success = result.result;
      _output.message = result.status_message;
    }

    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
exports.cancel_activity = async function (req, res, next) {
  var _output = new output();
  let error = null;
  let result = null;
  
  req.User.CompID = 1; try {
    let _activity_actions = await helper.serialize_type(activity_actions, req.body, "")
    _activity_actions.status_id = 9;
    result = await activity_actions_repo.activity_action(_activity_actions);
    _output.data = result;
    _output.is_success = result.result;
    _output.message = result.status_message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_process_detail_for_task = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let task_id = req.query.task_id;
    if (task_id == undefined) { throw { message: "must pass task_id" }; }
    result = await activity_actions_repo.get_process_detail_for_task(task_id);
    _output.data = result;
    _output.is_success = result.result;
    _output.message = result.status_message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_update_status_for_clearance = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let project_id = req.query.project_id;
    if (project_id == undefined) { throw { message: "must pass project_id" }; }
    let user_id = req.query.user_id;
    if (user_id == undefined) { throw { message: "must pass user_id" }; }
    result = await activity_actions_repo.get_update_status_for_clearance(project_id, user_id);
    _output.data = result;
    _output.is_success = result.result;
    _output.message = result.status_message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_reject_reason = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let user_id = req.query.user_id;
    if (user_id == undefined) { throw { message: "must pass user_id" }; }
    result = await activity_actions_repo.get_reject_reason(user_id);
    _output.data = result;
    _output.is_success = result.result;
    _output.message = result.status_message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.send_mail = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let object = req.body
    result = await activity_actions_repo.send_mail(id, object);
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance status details.";
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_mail_template = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let template_id = req.query.template_id;
    let user_id = req.query.user_id;
    if (user_id == undefined) { throw { message: "must pass user_id" }; }
    if (template_id == undefined) { throw { message: "must pass template_id" }; }
    result = await activity_actions_repo.get_mail_template(template_id, user_id);
    _output.data = result;
    _output.is_success = result.result;
    _output.message = result.status_message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}