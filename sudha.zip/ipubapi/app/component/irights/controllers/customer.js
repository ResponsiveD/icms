'use strict'

const customer_repository = require("../repository/customer");
const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.customer_selection = function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;
  
  req.User.CompID = 1; try {
    let data = {};
    let result = customer_repository.customer_selection(data);

    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer Selection";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.customer_approval = function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;
  
  req.User.CompID = 1; try {
    let data = {};
    let result = customer_repository.customer_approval(data);

    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer Approval";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.customer_review = function (req, res, next) {
  var _output = new output();
  let error = null;
  let result = null;
  
  req.User.CompID = 1; try {
    let data = {};
    let result = customer_repository.customer_review(data);

    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer Review";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}