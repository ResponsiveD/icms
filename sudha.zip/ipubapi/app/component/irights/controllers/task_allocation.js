'use strict'

const task_allocation_repository = require("../repository/task_allocation");
const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.get_tasks = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let user_id = req.query.user_id;
    let project_id = req.query.project_id;
    result = await task_allocation_repository.get_tasks(user_id, project_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "get task allocation details";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.get_resource_name = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let user_id = req.query.user_id;
    result = await task_allocation_repository.get_resource_name(user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Resource Name";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
exports.get_resource_name_on_activity = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let user_id = req.query.user_id;
    result = await task_allocation_repository.get_resource_name_on_activity(user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Resource Name";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
exports.post_tasks = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let data = (req.body.data);
    let user_id = req.body.user_id;
    //let project_id = req.body.project_id;
    result = await task_allocation_repository.post_tasks(data, user_id);
    // result = await task_allocation_repository.get_tasks(result,project_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Post task allocation";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
