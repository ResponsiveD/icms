const project_wip_list_repo = require("../repository/project_wip_list");
const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.wip_list = async function (req, res, next) {
  let error = null; let result = null;  req.User.CompID = 1; try {
    let data = req.body;
    result = await project_wip_list_repo.wip_list(data.user_id);
    var _output = new output();
    _output.data = result;
    _output.is_success = true;
    _output.message = "Role based wip list";
    req.User.endTime = new Date();     exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();     exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.get_project_details = function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let data = { project_id: "1" };
    let result = project_wip_list_repo.get_project_details(data);

    _output.data = result;
    _output.is_success = true;
    _output.message = "Project Details is listed Successfully";
    req.User.endTime = new Date();     exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();     exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};