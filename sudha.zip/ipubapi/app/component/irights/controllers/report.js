"use strict";

const report_repository = require("../repository/report");
const output = require("../models/output");
const common = require("../../../helpers/common");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.get_project_list_for_page_review = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let user_id = req.query.user_id;
    if (!user_id) { throw 'user_id not provided'; }
    result = await report_repository.get_project_list_for_page_review(user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project List";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_project_page_review = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let project_id = req.query.project_id;
    if (!project_id) { throw 'project_id not provided'; }
    result = await report_repository.get_project_page_review(project_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project List";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.update_page_review = async function (req, res, next) {
  let _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    // if (data.cust_id == undefined || data.cust_id == "" || data.cust_id == 0) {
    //   throw { "message": "cust_id must be Provided." };
    // }
    // else {
    _output.data = await report_repository.update_page_review(data);
    _output.is_success = true;
    _output.message = "Books.";
    // }
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_project_list_for_admin = async function (req, res, next) {
  var _output = new output();
  
  let error = null; let result = null;
  req.User.CompID = 1; try {
    let user_id = req.query.user_id;
    if (!user_id) { throw 'user_id not provided'; }
    result = await report_repository.get_project_list_for_admin(user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project List";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_project_admin = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;
   req.User.CompID = 1; try {
    let project_id = req.query.project_id;
    if (!project_id) { throw 'project_id not provided'; }
    result = await report_repository.get_project_admin(project_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project List";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
