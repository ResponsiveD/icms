'use strict'
const my_task_repository = require("../repository/my_task");
const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.get_selection = function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let data = {
      "ProjectID": "1",
      "ChapterID": "1"
    };
    let result = my_task_repository.get_selection(data);

    _output.data = result;
    _output.is_success = true;
    _output.message = "Get selection";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.get_selection_details = function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let data = {
      "ProjectID": "1",
      "ChapterID": "1"
    };
    let result = my_task_repository.get_selection_details(data);

    _output.data = result;
    _output.is_success = true;
    _output.message = "Get selection details";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};