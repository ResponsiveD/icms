const text_research_repo = require("../repository/text_research");
const output = require("../models/output");
var helper = require("../helpers/json-serialize");
const common = require("../../../helpers/common");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.get_text_list = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let user_id = req.query.user_id;
        let activity_id = req.query.activity_id;
        let chapter_id = req.query.chapter_id;
        let is_spec = 0;
        result = await text_research_repo.get_text_list(user_id, activity_id, chapter_id, is_spec);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text Research task for this user";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.get_selections_list = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let task_id = req.query.task_id;
        if (task_id == undefined || task_id == "" || task_id == "null") {
            throw "task_id must be passed";
        }
        result = await text_research_repo.get_selections(task_id);
        _output.data = {
            "selections_list": result.recordsets[0],
            "chapter_attachments": result.recordsets[1]
        };
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.get_chapter_selections_list = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let chapter_id = req.query.chapter_id;
        if (chapter_id == undefined || chapter_id == "" || chapter_id == "null") {
            throw "task_id must be passed";
        }
        result = await text_research_repo.get_chapter_selections(chapter_id);
        _output.data = {
            "selections_list": result.recordsets[0],
            "chapter_attachments": result.recordsets[1]
        };
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};
exports.get_chapter_taskid = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let chapter_id = req.query.chapter_id;
        if (chapter_id == undefined || chapter_id == "" || chapter_id == "null") {
            throw "task_id must be passed";
        }
        result = await text_research_repo.get_chapter_taskid(chapter_id);
        _output.data = result.recordset[0];
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.get_selections_details = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let selection_id = req.query.selection_id;
        if (selection_id == undefined || selection_id == "" || selection_id == "null") {
            throw "selection_id must be passed";
        }
        result = await text_research_repo.get_selections_details(selection_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.get_selections_details_export = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        //let data = req.body;
        let task_id = req.query.task_id;
        let proj_ser_id = req.query.proj_ser_id;
        let task_record_id = req.query.task_record_id;
        let activity_id = req.query.activity_id;
        if (task_id == undefined || task_id == "" || task_id == "null") {
            throw "task_id must be passed";
        }
        if (proj_ser_id == undefined || proj_ser_id == "" || proj_ser_id == "null") {
            throw "proj_ser_id must be passed";
        }
        if (task_record_id == undefined || task_record_id == "" || task_record_id == "null") {
            throw "task_record_id must be passed";
        }
        if (activity_id == undefined || activity_id == "" || activity_id == "null") {
            throw "activity_id must be passed";
        }

        result = await text_research_repo.get_selections_details_export(task_id, proj_ser_id, task_record_id, activity_id);
        var json2xls = require('json2xls');
        var fs = require('fs');
        var xls = json2xls(result);
        var path = 'app/component/irights/docs/';
        var filename = 'selection_details_' + task_id + '_' + proj_ser_id + '_' + task_record_id + '.xlsx';
        fs.writeFileSync(path + filename, xls, 'binary');

        let filePath = path + filename;

        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);

        var stream = fs.createReadStream(filePath, { encoding: "base64" });
        stream.once("end", function () {
            stream.destroy();
            fs.unlink(filePath, function () { });
        }).pipe(res);


    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.get_selections_clearance_details_export = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        //let data = req.body;
        let task_id = req.query.task_id;
        let proj_ser_id = req.query.proj_ser_id;
        let task_record_id = req.query.task_record_id;
        if (task_id == undefined || task_id == "" || task_id == "null") {
            throw "task_id must be passed";
        }
        if (proj_ser_id == undefined || proj_ser_id == "" || proj_ser_id == "null") {
            throw "proj_ser_id must be passed";
        }
        if (task_record_id == undefined || task_record_id == "" || task_record_id == "null") {
            throw "task_record_id must be passed";
        }

        result = await text_research_repo.get_selections_clearance_details_export(task_id, proj_ser_id, task_record_id);
        var json2xls = require('json2xls');
        var fs = require('fs');
        var xls = json2xls(result);
        var path = 'app/component/irights/docs/';
        var filename = 'selection_clearance_details_' + task_id + '_' + proj_ser_id + '_' + task_record_id + '.xlsx';
        fs.writeFileSync(path + filename, xls, 'binary');

        let filePath = path + filename;

        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);

        var stream = fs.createReadStream(filePath, { encoding: "base64" });
        stream.once("end", function () {
            stream.destroy();
            fs.unlink(filePath, function () { });
        }).pipe(res);

    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};


exports.get_clearance_selections_list = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let task_id = req.query.task_id;
        if (task_id == undefined || task_id == "" || task_id == "null") {
            throw "task_id must be passed";
        }
        result = await text_research_repo.get_clearance_selections(task_id);
        _output.data = {
            "selections_list": result.recordsets[0],
            "chapter_attachments": result.recordsets[1]
        };
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.update_selection = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let data = req.body;
        let user_id = data.user_id;
        if (user_id == undefined || user_id == "" || user_id == "null") {
            throw "user_id must be passed";
        }
        data["attachment_length"] = req.body.selection_attachments.length;
        result = await text_research_repo.update_selection(data);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.get_permission_status = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        result = await text_research_repo.get_permission_status();
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.get_permission_needed = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        result = await text_research_repo.get_permission_needed();
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};
exports.get_project_selections = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        if (req.body.project_id == undefined) { throw { "message": "should pass project_id" } }
        if (req.body.activity_id == undefined) { throw { "message": "should pass activity_id" } }
        result = await text_research_repo.get_project_selections(req.body);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.get_project_selections_full = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        if (req.body.project_id == undefined) { throw { "message": "should pass project_id" } }
        let data = req.body;
        if (data.status_id == undefined) {
            data.status_id = 1;
        }
        result = await text_research_repo.get_project_selections_full(data);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};
exports.get_project_selections_review = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        if (req.body.project_id == undefined) { throw { "message": "should pass project_id" } }
        let data = req.body;
        if (data.status_id == undefined) {
            data.status_id = 4;
        }
        result = await text_research_repo.get_project_selections_full(data);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};
exports.get_selection_rights_holder = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        if (req.body.unique_id == undefined) { throw { "message": "should pass unique_id" } }
        result = await text_research_repo.get_selection_rights_holder(req.body.unique_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.validate_rh_follow_up_for_chapter = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        if (req.body.chapter_id == undefined) { throw { "message": "should pass chapter_id" } }
        result = await text_research_repo.validate_rh_follow_up_for_chapter(req.body.chapter_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "RH validation details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.validate_rh_follow_up_for_spec = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        if (req.body.spec_id == undefined) { throw { "message": "should pass spec_id" } }
        result = await text_research_repo.validate_rh_follow_up_for_spec(req.body.spec_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "RH validation details";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.rights_holder_validation = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let data = req.body;
        data = await common.getTokenUserDetail(req, data);
        let user_id = data.user_id;
        if (user_id == undefined || user_id == "" || user_id == "null") {
            throw "user_id must be passed";
        }
        result = await text_research_repo.rights_holder_validation(data);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Rights Holder Validation Result.";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};