'use strict'

const third_party_approval_repo = require("../repository/third_party_approval");
const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.third_party_approval = function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let data = {};
        let result = third_party_approval_repo.third_party_approval(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Get Third Party PL";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.third_party_approval_details = function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let data = {};
        let result = third_party_approval_repo.third_party_approval_details(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Get Third Party PL";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}