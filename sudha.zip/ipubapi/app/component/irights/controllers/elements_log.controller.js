"use strict";
const element_log_repo = require("../repository/element_log.service");
const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.add_or_edit_elemeent_log = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        if (req.body != '') {
            result = await element_log_repo.add_or_edit_elemeent_log(req.body, req.User);
            if (result) {
                _output.data = result[''];
                _output.is_success = true;
                _output.message = result[''] + " Record got affected";
                req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
                res.status(HttpStatus.OK).send(_output);
            } else {
                _output.is_success = false;
                _output.message = "something went wrong";
                req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
                res.status(HttpStatus.OK).send(_output);
            }
        } else {
            _output.is_success = false;
            _output.message = "Please send valid input";
            req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
            res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
        }
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.elementtype = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        result = await element_log_repo.elementtype(req);
        if (result) {
            _output.data = result;
            _output.is_success = true;
            _output.message = "data found";
            req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
            res.status(HttpStatus.OK).send(_output);
        } else {
            _output.is_success = false;
            _output.message = "something went wrong";
            req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
            res.status(HttpStatus.OK).send(_output);
        }


    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.specifiedas = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        result = await element_log_repo.specifiedas(req);
        if (result) {
            _output.data = result;
            _output.is_success = true;
            _output.message = "data found";
            req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
            res.status(HttpStatus.OK).send(_output);
        } else {
            _output.is_success = false;
            _output.message = "something went wrong";
            req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
            res.status(HttpStatus.OK).send(_output);
        }
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.usage = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        result = await element_log_repo.usage(req);
        if (result) {
            _output.data = result;
            _output.is_success = true;
            _output.message = "data found";
            req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
            res.status(HttpStatus.OK).send(_output);
        } else {
            _output.is_success = false;
            _output.message = "something went wrong";
            req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
            res.status(HttpStatus.OK).send(_output);
        }
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.elemrights = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        result = await element_log_repo.elemrights(req);
        if (result) {
            _output.data = result;
            _output.is_success = true;
            _output.message = "data found";
            req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
            res.status(HttpStatus.OK).send(_output);
        } else {
            _output.is_success = false;
            _output.message = "something went wrong";
            req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
            res.status(HttpStatus.OK).send(_output);
        }

    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};

exports.add_or_edit_task_creation = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        if (req.body != '') {
            result = await element_log_repo.add_or_edit_task_creation(req.body, req.User);
            if (result) {
                _output.data = result[''];
                _output.is_success = true;
                _output.message = result[''] + " Record got affected";
                req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
                res.status(HttpStatus.OK).send(_output);
            } else {
                _output.is_success = false;
                _output.message = "something went wrong";
                req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
                res.status(HttpStatus.OK).send(_output);
            }
        } else {
            _output.is_success = false;
            _output.message = "Please send valid input";
            req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
            res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
        }
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};