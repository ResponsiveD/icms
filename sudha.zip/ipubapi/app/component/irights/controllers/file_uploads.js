'use strict'
const file_upload = require('../repository/file_upload');
const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.Project_File_Upload = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let project_guid = req.body.project_guid;
        if (project_guid == undefined || project_guid == "" || project_guid == "null") {
            project_guid = await file_upload.guid();
        }
        let file = req.files["file"];
        let Path = 'irights/' + project_guid + '/' + file.name
        let allowedType = req.body.allowedType;
        result = await file_upload.UploadFile(req, Path, allowedType);
        _output.data = { Path: result, project_guid: project_guid };
        _output.is_success = true;
        _output.message = "Customer Selection";
        res.setTimeout(1000000); // 10 minutes
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}


exports.Service_File_Upload = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let project_guid = req.body.project_guid;
        let service_guid = req.body.service_guid;
        if (project_guid == undefined || project_guid == "" || project_guid == "null") {
            project_guid = await file_upload.guid();
        }
        if (service_guid == undefined || service_guid == "" || service_guid == "null") {
            service_guid = await file_upload.guid();
        }
        let file = req.files["file"];
        let Path = 'irights/' + project_guid + '/' + service_guid + '/' + file.name
        result = await file_upload.UploadFile(req, Path);
        _output.data = { Path: result, project_guid: project_guid, service_guid: service_guid };
        _output.is_success = true;
        _output.message = "Customer Selection";
        res.setTimeout(1000000); // 10 minutes
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.Task_File_Upload = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let project_guid = req.body.project_guid;
        let service_guid = req.body.service_guid;
        let chapter_guid = req.body.chapter_guid;
        if (project_guid == undefined || project_guid == "" || project_guid == "null") {
            project_guid = await file_upload.guid();
        }
        if (service_guid == undefined || service_guid == "" || service_guid == "null") {
            service_guid = await file_upload.guid();
        }
        if (chapter_guid == undefined || chapter_guid == "" || chapter_guid == "null") {
            chapter_guid = await file_upload.guid();
        }
        let file = req.files["file"];
        let Path = 'irights/' + project_guid + '/' + service_guid + '/' + chapter_guid + '/' + file.name;
        result = await file_upload.UploadFile(req, Path);
        _output.data = { Path: result, project_guid: project_guid, service_guid: service_guid, chapter_guid: chapter_guid };
        _output.is_success = true;
        _output.message = "Customer Selection";
        res.setTimeout(1000000); // 10 minutes
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}

exports.Spec_File_Upload = async function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let project_guid = req.body.project_guid;
        let service_guid = req.body.proj_ser_guid;
        let chapter_guid = req.body.chapter_guid;
        let task_guid = req.body.task_guid;
        if (project_guid == undefined || project_guid == "" || project_guid == "null") {
            project_guid = await file_upload.guid();
        }
        if (service_guid == undefined || service_guid == "" || service_guid == "null") {
            service_guid = await file_upload.guid();
        }
        if (chapter_guid == undefined || chapter_guid == "" || chapter_guid == "null") {
            chapter_guid = await file_upload.guid();
        }
        if (task_guid == undefined || task_guid == "" || task_guid == "null") {
            task_guid = await file_upload.guid();
        }
        let file = req.files["file"];
        let Path = 'irights/' + project_guid + '/' + service_guid + '/' + chapter_guid + '/' + task_guid + '/' + file.name;
        result = await file_upload.imageploadFile(req, Path);
        _output.data = { Path: result, project_guid: project_guid, proj_ser_guid: service_guid, chapter_guid: chapter_guid, task_guid: task_guid };
        _output.is_success = true;
        _output.message = "Customer Selection";
        res.setTimeout(1000000); // 10 minutes
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
}
