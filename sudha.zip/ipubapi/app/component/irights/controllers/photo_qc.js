"use strict";
const photo_qc_repo = require("../repository/photo_qc");
const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.photo_quality_check = function (req, res, next) {
    var _output = new output();
    let error = null; let result = null;  req.User.CompID = 1; try {
        let data = {
            "status_id": 1,
            "status": true,
            "reason": "success",
            "commands": "created"
        };
        let result = photo_qc_repo.photo_quality_check(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Photo Quality Check is Successfully Created";
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
        res.status(HttpStatus.OK).send(_output);
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
};
