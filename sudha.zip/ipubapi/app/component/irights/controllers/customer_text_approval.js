"use strict";
const customer_text_approval_repo = require("../repository/customer_text_approval");
const output = require("../models/output");
var helper = require("../helpers/json-serialize");
var selection_full_details = require("../models/selection_full_details");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.customer_text_approval = function (req, res, next) {
  var _output = new output();
  let error = null;
  let result = null;
  
  req.User.CompID = 1; try {
    let data = { project_id: 1 };
    let result = customer_text_approval_repo.customer_text_approval(data);

    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer Text Approval is listed Successfully";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.customer_text_approval_status = function (req, res, next) {
  var _output = new output();
  let error = null;
  let result = null;
  
  req.User.CompID = 1; try {
    let customer_text_approval_details = helper.serialize(selection_full_details, req.body, "");
    let result = customer_text_approval_repo.customer_text_approval_status(customer_text_approval_details);

    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer Text Approval and Reject Status is updated";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

