"use strict";
// =============================================
// Author:		  Velmurugan P
// Create date: 23/07/2018
// Modified:    Velmurugan P
// Description:	Task creation controller
// =============================================

const task_creation_repo = require("../repository/task_creation");
const output = require("../models/output");
var rights_holder = require("../models/rights_holder");
var helper = require("../helpers/json-serialize");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");
const { service_details, service_docs, chapter_docs, service, chapter_details, task_details, task_spec_details } = require('../models/get_service_details')

exports.get_chapters = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let project_id = req.query.project_id;
    if (!project_id) { throw 'ProjectID not provided'; }
    var _service = {};
    _service.project_id = project_id;
    var _service_details = [];
    var _ = require('lodash');
    result = await task_creation_repo.get_chapters(project_id);
    if (result[0]) {
      result[0].forEach(element => {
        var _service_detail = {};
        _service_detail = element;
        _service_detail.service_docs = _.filter(result[1], ['proj_ser_id', element.proj_ser_id]);
        _service_detail.chapter_details = _.filter(result[2], ['proj_ser_id', element.proj_ser_id]);
        _service_details.push(_service_detail);
      });
    }
    _service.project_guid = result[3][0].ProjectGUID;
    _service.service_details = _service_details;
    _output.data = _service;
    _output.is_success = true;
    _output.message = "Project based chapter list";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
exports.get_chapters_details = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let chapter_id = req.query.chapter_id;
    if (!chapter_id) { throw 'chapter_id not provided'; }
    var _ = require('lodash');
    result = await task_creation_repo.get_chapters(chapter_id);
    _output.data = _service;
    _output.is_success = true;
    _output.message = "Project based chapter list";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
exports.get_all_wip_chapters = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let project_id = req.query.project_id;
    let user_id = req.query.user_id;
    let activity_id = req.query.activity_id;
    result = await task_creation_repo.get_all_wip_chapters(project_id, user_id, activity_id);
    var _service_details = [];
    var _service = new service();
    _service.project_id = project_id;
    _service.project_guid = await task_creation_repo.get_project_guid(project_id);
    if (result[0]) {
      result[0].forEach(element => {
        var _chapter_details = [];
        var _service_detail = new service_details();
        _service_detail.proj_ser_id = element.ProjSerID;
        _service_detail.project_id = element.IRSProjID;
        _service_detail.service_name = element.SerName;
        _service_detail.status_id = element.StatusID;
        _service_detail.status = element.Status;
        _service_detail.Comments = element.Comments;
        _service_detail.is_active = element.isActive;
        _service_detail.ser_id = element.SerID;
        _service_detail.service_guid = element.ProjSerGUID || '';
        if (result[1]) {
          _chapter_details = [];
          result[1].forEach(ele => {
            if (element.ProjSerID === ele.ProjSerID) {
              var _chapter_detail = new chapter_details();
              _chapter_detail.chapter_id = ele.ChapterID;
              _chapter_detail.batch_id = ele.BatchID;
              _chapter_detail.seq_id = ele.SeqID;
              _chapter_detail.total_page = ele.TotalPage;
              _chapter_detail.is_active = ele.isActive;
              _chapter_detail.proj_ser_id = ele.ProjSerID;
              _chapter_detail.status_id = ele.StatusID;
              _chapter_detail.counts = ele.counts;
              _chapter_detail.status_name = ele.Status;
              _chapter_detail.chapter_name = ele.ChapterName;
              _chapter_details.push(_chapter_detail)
            }
          });
          _service_detail.chapter_details = _chapter_details;
        }
        _service_details.push(_service_detail);
      })
    };
    _service.service_details = _service_details;
    _output.data = _service;
    _output.is_success = true;
    _output.message = "Project based wip chapter list";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
exports.get_all_chapters = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let project_id = req.query.project_id;
    if (!project_id) { throw 'ProjectID not provided'; }
    result = await task_creation_repo.get_all_chapters(project_id);
    var _service_details = [];
    var _service = new service();
    _service.project_id = project_id;
    _service.project_guid = await task_creation_repo.get_project_guid(project_id);
    if (result[0]) {
      result[0].forEach(element => {
        var _service_docs = [];
        var _chapter_docs = [];
        var _chapter_details = [];
        var _task_details = [];
        var _task_spec_details = [];
        var _service_detail = new service_details();
        _service_detail.proj_ser_id = element.ProjSerID;
        _service_detail.project_id = element.IRSProjID;
        _service_detail.service_name = element.SerName;
        _service_detail.status_id = element.StatusID;
        _service_detail.status = element.Status;
        _service_detail.Comments = element.Comments;
        _service_detail.is_active = element.isActive;
        _service_detail.ser_id = element.SerID;
        _service_detail.service_guid = element.ProjSerGUID || '';
        if (result[1]) {
          _service_docs = [];
          result[1].forEach(doc => {
            if (doc.ProjSerID === element.ProjSerID) {
              var _service_doc = new service_docs();
              _service_doc.attr_id = doc.AttID
              _service_doc.file_url = doc.FileURL
              _service_doc.proj_ser_id = doc.ProjSerID
              _service_doc.file_name = doc.FileName
              _service_doc.is_active = doc.isActive
              _service_docs.push(_service_doc)
            }
          });
          _service_detail.service_docs = _service_docs;
        }
        if (result[2]) {
          _chapter_details = [];
          result[2].forEach(ele => {
            if (element.ProjSerID === ele.ProjSerID) {
              var _chapter_detail = new chapter_details();
              _chapter_detail.chapter_id = ele.ChapterID;
              _chapter_detail.batch_id = ele.BatchID;
              _chapter_detail.seq_id = ele.SeqID;
              _chapter_detail.total_page = ele.TotalPage;
              _chapter_detail.is_active = ele.isActive;
              _chapter_detail.proj_ser_id = ele.ProjSerID;
              _chapter_detail.status_id = ele.StatusID;
              _chapter_detail.status_name = ele.Status;
              _chapter_detail.chapter_name = ele.ChapterName;
              if (result[3]) {
                _chapter_docs = [];
                result[3].forEach(cdoc => {
                  if (cdoc.ChapterID === ele.ChapterID) {
                    var _chapter_doc = new chapter_docs();
                    _chapter_doc.file_id = cdoc.FileID
                    _chapter_doc.chapter_id = cdoc.ChapterID
                    _chapter_doc.file_name = cdoc.FileName
                    _chapter_doc.file_url = cdoc.FilePath
                    _chapter_doc.is_active = cdoc.isActive
                    _chapter_docs.push(_chapter_doc)
                  }
                });
              }
              _chapter_detail.chapter_docs = _chapter_docs;
              if (result[4]) {
                result[4].forEach(elet => {
                  if (ele.ChapterID === elet.ChapterID) {
                    var _task_detail = new task_details();
                    _task_detail.task_id = elet.TaskID;
                    _task_detail.tl_commands = elet.TLCommands;
                    _task_detail.asign_date = elet.AsignDate;
                    _task_detail.due_Date = elet.DueDate;
                    _task_detail.comp_date = elet.CompDate;
                    _task_detail.status_id = elet.statusID;
                    _task_detail.is_active = elet.isActive;
                    _task_detail.resource_id = elet.ResourceID;
                    _task_detail.assigned_to = elet.AssignedTo;
                    _task_detail.is_allocated = elet.Allocated;
                    if (result[5]) {
                      _task_spec_details = [];
                      result[5].forEach(spec => {
                        if (spec.ProjSerID == elet.ProjSerID && spec.ChapterID == elet.ChapterID && spec.TaskID == elet.TaskID) {
                          var _task_spec_detail = new task_spec_details;
                          _task_spec_detail.s_id = spec.SID;
                          _task_spec_detail.spec_id = spec.SpecID;
                          _task_spec_detail.spec_desc = spec.SpecDesc;
                          _task_spec_detail.page_no = spec.PageNo;
                          _task_spec_detail.status_id = spec.SpecStatusID;
                          _task_spec_detail.no_source = spec.NoSource;
                          _task_spec_detail.no_source_commets = spec.NoSourceComments;
                          _task_spec_detail.hi_res_download = spec.HiResDownloaded;
                          _task_spec_detail.hi_res_url = spec.HiResURL;
                          _task_spec_detail.comments = spec.Comments;
                          _task_spec_detail.photo_id = spec.PhotoID;
                          _task_spec_detail.caption = spec.Caption;
                          _task_spec_detail.is_active = spec.isActive;
                          _task_spec_detail.is_allocated = spec.Allocated;
                          _task_spec_details.push(_task_spec_detail)
                        }
                      });
                      _task_detail.task_spec_details = _task_spec_details;
                    }
                    _chapter_detail.task_details.push(_task_detail);
                  }
                });
              }
              _chapter_details.push(_chapter_detail)
            }
          });
          _service_detail.chapter_details = _chapter_details;
        }
        _service_details.push(_service_detail);
      });
    }
    _service.service_details = _service_details;
    _output.data = _service;
    _output.is_success = true;
    _output.message = "Project based chapter list";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.update_task = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let Service = await helper.serialize_type(service, req.body, "")
    result = await task_creation_repo.update_task(req.body);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Task updated.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.update_task_new = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let Service = await helper.serialize_type(service, req.body, "")
    result = await task_creation_repo.update_task_new(req.body);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Task updated.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.post_chapter_task = function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let data = {};
    let result = task_creation_repo.update_task(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}
exports.AddEdit_rights_holder = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let rights_holder_param = helper.serialize(rights_holder, req.body, "");
    result = await task_creation_repo.AddEdit_rights_holder(JSON.stringify(req.body)).catch((err) => {
      throw err;
    });
    _output.data = result;
    _output.is_success = true;
    _output.message = "Rights holder data created.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.get_rights_holders = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let user_id = req.query.user_id
    result = await task_creation_repo.get_rights_holders(user_id).catch((err) => {
      throw err;
    });
    _output.data = result;
    _output.is_success = true;
    _output.message = "Rights holders data.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.delete_rights_holders = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let rights_holder_id = req.query.rights_holder_id
    result = await task_creation_repo.delete_rights_holders(rights_holder_id).catch((err) => {
      throw err;
    });
    _output.data = result;
    _output.is_success = true;
    _output.message = "Rights holders deleted.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.inactive_rights_holders = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let rights_holder_id = req.body.rights_holder_id
    result = await task_creation_repo.inactive_rights_holders(rights_holder_id).catch((err) => {
      throw err;
    });
    _output.data = result;
    _output.is_success = true;
    _output.message = "Rights holders deleted.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.get_rights_holder_details = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let rights_holder_id = req.query.rights_holder_id
    let user_id = req.query.user_id
    result = await task_creation_repo.get_rights_holder_details(rights_holder_id).catch((err) => {
      throw err;
    });
    _output.data = result;
    _output.is_success = true;
    _output.message = "Rights holders details.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.update_chapter_page = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let chapter_id = req.query.chapter_id
    let user_id = req.query.user_id
    let total_page = req.query.total_page
    let is_save = req.query.is_save
    result = await task_creation_repo.update_chapter_page(chapter_id, total_page, user_id, is_save).catch((err) => {
      throw err;
    });
    _output.data = result;
    _output.is_success = true;
    _output.message = "Rights holders details.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.map_rights_holder_to_task = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let rights_holder_id = req.body.rights_holder_id
    let user_id = req.body.user_id
    let unique_id = req.body.unique_id
    let keywords = req.body.keywords
    result = await task_creation_repo.map_rights_holder_to_task(rights_holder_id, user_id, unique_id, keywords).catch((err) => {
      throw err;
    });
    _output.data = result;
    _output.is_success = true;
    _output.message = "Rights holders details mapped with task.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

// exports.get_chapter = function (req, res, next) {
//   var _output = new output();
//   let error = null;  let result = null;   try{
//     let params = { project_id: 1, chapter_id: 1 };
//     let result = task_creation_repo.get_chapter(params);
//     _output.data = result;
//     _output.is_success = true;
//     _output.message = "Chapter details";
//   } catch (error) {
//     _output.data = "";
//     _output.is_success = false;
//     _output.message = error.message;
//   }

//   res.send(_output);
// };

// exports.get_selection = function (req, res, next) {
//   var _output = new output();
//   let error = null;  let result = null;   try{
//     let params = { project_id: 1, chapter_id: 1, session_id: 1 };
//     let result = task_creation_repo.get_selection(params);
//     _output.data = result;
//     _output.is_success = true;
//     _output.message = "Session details";
//   } catch (error) {
//     _output.data = "";
//     _output.is_success = false;
//     _output.message = error.message;
//   }

//   res.send(_output);
// };