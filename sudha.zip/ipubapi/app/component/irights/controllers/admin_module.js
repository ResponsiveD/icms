const output = require('../models/output');
const usercreation = require('../repository/admin_module');
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.addedituser = async function (req, res, next) {
  var _output = new output();
  let error = null;
  let result = null;
  
  req.User.CompID = 1; try {
    let JsonData = JSON.stringify(req.body);
    result = await usercreation.addedituser(JsonData);
    _output.data = result;
    _output.is_success = true;
    _output.message = 'User detail created Successfullly';
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.addeditcustomer = async function (req, res, next) {
  var _output = new output();
  let error = null;
  let result = null;
  
  req.User.CompID = 1; try {
    let data = req.body;
    //data = await common.getTokenUserDetail(req, data);//data.user_id,data.org_id
    let JsonData = JSON.stringify(data);
    result = await usercreation.addeditcustomer(JsonData);
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Customer detail created Successfullly';
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.addeditservice = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let data = req.body;
    //data = await common.getTokenUserDetail(req, data);//data.user_id,data.org_id
    let JsonData = JSON.stringify(data);
    result = await usercreation.addeditservice(JsonData);
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Service detail created Successfullly';
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.getuserroletype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getuserroletype();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'User Role Type';
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.getusersubroletype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getusersubroletype();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'User Sub Role Type';
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.getuseratytype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getuseratytype();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'User Activity  Type';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.getusercusttype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getusercusttype();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'User Customer  Type';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.getuserreportingtype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let data = req.query.ReportingId;
    result = await usercreation.getuserreportingtype(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = 'User Reporting Type';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.getuserdata = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getuserdata();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'User Role Type';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.getuserorgtype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getuserorgtype();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'User Org  Type';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.getuserorgdivtype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getuserorgdivtype();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Customer Org  Type';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.getcustorgtype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getcustorgtype();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Customer Org  Type';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.getcustcomptype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getcustcomptype();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Customer Comp  Type';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.getcustomerdata = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getcustomerdata();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Customer data';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.getservicedata = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getservicedata();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Service data';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.deleteservicedata = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let sername = req.body.SerName;
    let compname = req.body.CompName;
    let updatedby = req.body.UpdatedBy;
    let isactive = req.body.isActive;
    result = await usercreation.deleteservicedata(sername, compid, updatedby, isactive);
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Delete Service data';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.deleteuserdata = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let usercode = req.body.UserCode;
    let orgname = req.body.Orgname;
    let orgdivname = req.body.Orgdivname;
    let updatedby = req.body.UpdatedBy;
    let isactive = req.body.isActive;
    result = await usercreation.deleteuserdata(usercode, orgid, orgdivid, updatedby, isactive);
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Delete User data';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.deletecustomerdata = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let custname = req.body.CustName;
    let updatedby = req.body.UpdatedBy;
    let isactive = req.body.isActive;
    result = await usercreation.deletecustomerdata(custname, updatedby, isactive);
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Delete Customer data';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.getservicecomptype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getservicecomptype();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Service Comp  Type';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.getserviceorgtype = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    result = await usercreation.getserviceorgtype();
    _output.data = result;
    _output.is_success = true;
    _output.message = 'Service org  Type';
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
