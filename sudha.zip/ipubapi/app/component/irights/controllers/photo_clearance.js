"use strict";
const photo_clearance_repo = require("../repository/photo_clearance");
const output = require("../models/output");
var helper = require("../helpers/json-serialize");
const _mailer = require("../../../helpers/mailer");
const getcompid = require('../../../../config/constant/components.json');
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.get_rights_holder_followup = async function (req, res, next) {
  var _output = new output(); let error = null;
  let result = null;
  req.User.CompID = 1; try {
    let req_body = req.body;
    let data = JSON.stringify(req_body);
    result = await photo_clearance_repo.get_rights_holder_followup(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "rights holder follow up details.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.update_rights_holder_followup = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null; req.User.CompID = 1; try {
    let req_body = req.body;
    req_body["attachment_length"] = req.body.attachment.length;
    let data = JSON.stringify(req_body);
    result = await photo_clearance_repo.update_rights_holder_followup(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "rights holder follow up details.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
exports.get_clearance_status = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null; req.User.CompID = 1; try {
    result = await photo_clearance_repo.get_clearance_status();
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance status details.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

exports.update_highres_status = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null; req.User.CompID = 1; try {
    let hi_res = req.body.hi_res;
    let s_id = req.body.s_id;
    let comments = req.body.comments;
    result = await photo_clearance_repo.update_highres_status(hi_res, s_id, comments);
    _output.data = result;
    _output.is_success = true;
    _output.message = "high res status details.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

//get mail
exports.get_followup_mail_template = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null; req.User.CompID = 1; try {
    const activity_actions_repo = require("../repository/activity_actions");
    let cust_id = req.query.cust_id;
    let followup_id = req.query.followup_id;
    if (!cust_id) { throw 'cust_id not provided'; }
    let mailID = 0;
    switch (cust_id) {
      case "1":
        mailID = 47;
        break;
      case "2":
        mailID = 48;
        break;
      case "3":
        mailID = 49;
        break;
      case "8":
        mailID = 66;
        break;
      case "14":
        mailID = 70;
        break;
    }

    result = await activity_actions_repo.get_mail_template(mailID, req.User.UserID, cust_id, followup_id);
    //result = await photo_clearance_repo.get_followup_mail_template();
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance mail template";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

//send mail
exports.send_mail_follow_up = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null; req.User.CompID = 1; try {
    let results = req.body;
    const _mailOptions = require("../../../helpers/mailOptions");
    var options = new _mailOptions();
    options.bcc = results.bcc;
    options.cc = results.cc;
    options.from = results.from;
    options.html = results.html;
    options.subject = results.subject;
    options.to = results.to;
    options.compid = getcompid.irights.compID;
    options.attachments = results.followup_attachments;
    options.followup_id = results.followup_id;
    result = await _mailer.sendMail(options);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Mail sent successfully.";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};

