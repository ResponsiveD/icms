"use strict";
const load_indicator_repo = require("../repository/load_indicator");
const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");

exports.load_indicator = async function (req, res, next) {
  var _output = new output();
  let error = null; let result = null;  req.User.CompID = 1; try {
    let data = req.query;
    result = await load_indicator_repo.load_indicator(data.start_date, data.end_date, data.user_id);

    _output.data = result;
    _output.is_success = true;
    _output.message = "Photo Quality Check is Successfully Created";
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
};
