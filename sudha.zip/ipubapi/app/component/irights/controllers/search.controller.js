'use strict'


const output = require("../models/output");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");
const serachservice = require("../repository/search.service");
const common = require("../../../helpers/common");

exports.textSearch = async function (req, res, next) {
  let _output = new output(), error = null, result = null;
   req.User.CompID = 1; try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    result = await serachservice.textSearch(data);

    let name = Object.keys(result.recordset[0])[0];
    let JsonData = JSON.parse(result.recordset[0][name]);

    if (JsonData != '' && JsonData != undefined) {
      _output.is_success = true;
      _output.message = "text  List";
      _output.data = JsonData[0];
    } else {
      _output.message = "text not found List";
      _output.data = [];
      _output.is_success = false;
    }

    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.photSearch = async function (req, res, next) {
  let _output = new output(), error = null, result = null;
   req.User.CompID = 1; try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    result = await serachservice.photoSearch(data);
    // _output.data = result;

    let name = Object.keys(result.recordset[0])[0];
    let JsonData = JSON.parse(result.recordset[0][name]);

    if (JsonData != '' && JsonData != undefined) {
      _output.is_success = true;
      _output.message = "image List";
      _output.data = JsonData[0];
    } else {
      _output.message = "image not found List";
      _output.data = [];
      _output.is_success = false;
    }


    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.getSourceName = async function (req, res, next) {
  let _output = new output(), error = null, result = null;
   req.User.CompID = 1; try {
    result = await serachservice.getSourceName(req);

    let name = Object.keys(result.recordset[0])[0];
    let JsonData = result.recordset[0][name];

    if (JsonData != '' && JsonData != undefined) {
      _output.message = "Source name list";
      _output.is_success = true;
      _output.data = JSON.parse(JsonData);
    } else {
      _output.message = "Source name not found";
      _output.data = [];
      _output.is_success = false;
    }

    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}

exports.getPhotographerName = async function (req, res, next) {
  let _output = new output(), error = null, result = null;
   req.User.CompID = 1; try {
    result = await serachservice.getPhotographerName(req);
    let name = Object.keys(result.recordset[0])[0];
    let JsonData = result.recordset[0][name];

    if (JsonData != '' && JsonData != undefined) {
      _output.message = "Photographer name list";
      _output.is_success = true;
      _output.data = JSON.parse(JsonData);
    } else {
      _output.message = "Photographer name not found";
      _output.data = [];
      _output.is_success = false;
    }

    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(_output);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    req.User.endTime = new Date(); exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
  }
}