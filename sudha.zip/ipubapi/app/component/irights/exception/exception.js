"use strict";

const exceptionString = require("../exception/exceptionString");

exports.getException = async (param) => {
  try {
    return exceptionString.find(o => o.code === param);
  } catch (error) {
    return { "code": 500, "message": 'get exception object' + error   }
  }
}