"use strict";

module.exports = [
 {
    "code": 2000 ,
    "message": "body not found"
 },
 {
    "code": 2001 ,
    "message": ""
 },
 {
    "code": 2002 ,
    "message": ""
 },
 {
    "code": 2003 ,
    "message": "project Ser Id should not be empty"
 },
 {
    "code": 2004 ,
    "message": "project Ser Id should not be number"
 },
 {
    "code": 2005 ,
    "message": "Chapter Id should not be empty"
 },
 {
    "code": 2006 ,
    "message": "Chapter Id should not be number"
 },
 {
    "code": 2007 ,
    "message": "Task Id should not be empty"
 },
 {
    "code": 2008 ,
    "message": "Task Id should not be number"
 },
 {
    "code": 2009 ,
    "message": "Id should not be empty"
 },
 {
    "code": 2010 ,
    "message": "Selection Name should not be empty"
 },
 {
    "code": 2011 ,
    "message": "Is_Active should not be empty"
 },
 {
    "code": 2012 ,
    "message": "Selection ID  should not be empty"
 },
 {
    "code": 2013 ,
    "message": "Element should be string"
 },
 {
    "code": 2014 ,
    "message": "Element length should be 150"
 },
 {
    "code": 2015 ,
    "message": "Element should not be empty"
 },
 {
    "code": 2016 ,
    "message": "Image NameCalc should be string"
 },
 {
    "code": 2017 ,
    "message": "Image NameCalc length should be 150"
 },
 {
    "code": 2018 ,
    "message": "Ms Page should be string"
 },
 {
    "code": 2019 ,
    "message": "Ms Page length should be 150"
 },
 {
    "code": 2020 ,
    "message": "Specfd_as should not be empty"
 },
 {
    "code": 2021 ,
    "message": "Specfd_as not found"
 },
 {
    "code": 2022 ,
    "message": "Pickup Source length should be 150"
 },
 {
    "code": 2023 ,
    "message": "OldElementNum length should be 150"
 },
 {
    "code": 2024 ,
    "message": "Element Type not found"
 },
 {
    "code": 2025 ,
    "message": "Usage should not be empty"
 },
 {
    "code": 2026 ,
    "message": "Usage not found"
 },
 {
    "code": 2027 ,
    "message": "Description should be string"
 },
 {
    "code": 2028 ,
    "message": "Description length should be 500"
 },
 {
    "code": 2029 ,
    "message": "Caption should be string"
 },
 {
    "code": 2030 ,
    "message": "Caption length should be 500"
 },
 {
    "code": 2031 ,
    "message": "Source should be string"
 },
 {
    "code": 2032 ,
    "message": "Source length should be 500"
 },
 {
    "code": 2033,
    "message": "SrcTrackNum should be string"
 },
 {
    "code": 2034 ,
    "message": "SrcTrackNum length should be 500"
 },
 {
    "code": 2035 ,
    "message": "Credit Line should be string"
 },
 {
    "code": 2036,
    "message": "Credit Line length should be 500"
 },
 {
    "code": 2037 ,
    "message": "Rights not found"
 },
 {
    "code": 2038 ,
    "message": "PermsOnFile not found"
 },
 {
    "code": 2039, 
    "message": "PermStatus not found"
 },
 {
    "code": 2040 ,
    "message": "ProdStatus should be string"
 },
 {
    "code": 2041 ,
    "message": "ProdStatus length should be 500"
 },
 {
    "code": 2042 ,
    "message": "Final Page should be string"
 },
 {
    "code": 2043 ,
    "message": "Final Page length should be 500"
 },
 {
    "code": 2044,
    "message": "Invoice Num should be string"
 },
 {
    "code": 2045 ,
    "message": "Invoice Num length should be 500"
 },
 {
    "code": 2046 ,
    "message": "Invoice Date should be string"
 },
 {
    "code": 2047 ,
    "message": "Invoice Date length should be 500"
 },
 {
    "code": 2048 ,
    "message": "Plate should be string"
 },
 {
    "code": 2049 ,
    "message": "Plate length should be 500"
 },
 {
    "code": 2050 , 
    "message": "Author should be string"
 },
 {
    "code": 2051 ,
    "message": "Author length should be 500"
 },
 {
    "code": 2052 ,
    "message": "Rf Sub should be string"
 },
 {
    "code": 2053 ,
    "message": "Rf Sub length should be 500"
 },
 {
    "code": 2054 ,
    "message": "TotalProjFees should be string"
 },
 {
    "code": 2055 ,
    "message": "TotalProjFees length should be 500"
 },
 {
    "code": 2056 ,
    "message": "Ebook should be string"
 },
 {
    "code": 2057 ,
    "message": "Ebook length should be 500"
 },
 {
    "code": 2058 ,
    "message": "Printed Textbook should be string"
 },
 {
    "code": 2059 ,
    "message": "Printed Textbook length should be 500"
 },
 {
    "code": 2060 ,
    "message": "Digital Lms should be string"
 },
 {
    "code": 2061 ,
    "message": "Digital Lms length should be 500"
 },
 {
    "code": 2062 ,
    "message": "Printed Ancillary should be string"
 },
 {
    "code": 2063 ,
    "message": "Printed Ancillary length should be 500"
 },
 {
    "code": 2064 ,
    "message": "Elect Ancillary should be string"
 },
 {
    "code": 2065 ,
    "message": "Elect Ancillary length should be 500"
 },
 {
    "code": 2066 ,
    "message": "Derivative Prod should be string"
 },
 {
    "code": 2067 ,
    "message": "Derivative Prod length should be 500"
 },
 {
    "code": 2068 ,
    "message": "Future Edition should be string"
 },
 {
    "code": 2069 ,
    "message": "Future Edition length should be 500"
 },
 {
    "code": 2070 ,
    "message": "Future Revisions should be string"
 },
 {
    "code": 2071 ,
    "message": "Future Revisions length should be 500"
 },
 {
    "code": 2072 ,
    "message": "Hires should be string"
 },
 {
    "code": 2073 ,
    "message": "Hires length should be 500"
 },
 {
    "code": 2074 ,
    "message": "Model Releases should be string"
 },
 {
    "code": 2075 ,
    "message": "Model Releases length should be 500"
 },
 {
    "code": 2076 ,
    "message": "Sizeon Page should be string"
 },
 {
    "code": 2077 ,
    "message": "Sizeon Page length should be 500"
 },
 {
    "code": 2078 ,
    "message": "Note should be string"
 },
 {
    "code": 2079 ,
    "message": "Note length should be 500"
 },
 {
    "code": 2080 ,
    "message": "Note Createdby should be string"
 },
 {
    "code": 2081 ,
    "message": "Note Createdby length should be 500"
 },
 {
    "code": 2082 ,
    "message": "Researcher should be string"
 },
 {
    "code": 2083 ,
    "message": "Researcher length should be 500"
 },
 {
    "code": 2084 ,
    "message": ""
 },
 {
    "code": 2085 ,
    "message": ""
 },
 {
    "code": 2086 ,
    "message": ""
 },
 {
    "code": 2087 ,
    "message": ""
 },
 {
    "code": 2088 ,
    "message": ""
 },
 {
    "code": 2089 ,
    "message": ""
 },
 {
    "code": 2090 ,
    "message": ""
 },
 {
    "code": 2091 ,
    "message": ""
 },
 {
    "code": 2092,
    "message": ""
 },
 {
    "code": 2093 ,
    "message": ""
 },
 {
    "code": 2094 ,
    "message": ""
 },
 {
    "code": 2095 ,
    "message": ""
 },
 {
    "code": 2096 ,
    "message": ""
 },
 {
    "code": 2097 ,
    "message": ""
 },
 {
    "code": 2098 ,
    "message": ""
 },
 {
    "code": 2090 ,
    "message": ""
 },
 {
    "code": 2091 ,
    "message": ""
 },
 {
    "code": 2092 ,
    "message": ""
 },
 {
    "code": 2093 ,
    "message": ""
 },
 {
    "code": 2094 ,
    "message": ""
 },
 {
    "code": 2095 ,
    "message": ""
 },
 {
    "code": 2096 ,
    "message": ""
 },
 {
    "code": 2097 ,
    "message": ""
 },
 {
    "code": 2098 ,
    "message": ""
 },
 {
    "code": 2099,
    "message": ""
 },
 {
    "code": 2100,
    "message": ""
 },
 {
    "code": 2101,
    "message": ""
 },
 {
    "code": 2102,
    "message": ""
 },
 {
    "code": 2103,
    "message": ""
 },
 {
    "code": 2104,
    "message": ""
 },
 {
    "code": 2105,
    "message": ""
 },
 {
    "code": 2106,
    "message": ""
 },
 {
    "code": 2107,
    "message": ""
 },
 {
    "code": 2108,
    "message": ""
 },
 {
    "code": 2109,
    "message": ""
 },
 {
    "code": 2110,
    "message": ""
 },
 {
    "code": 2111,
    "message": ""
 },
 {
    "code": 2112,
    "message": ""
 },
 {
    "code": 2113,
    "message": ""
 },
 {
    "code": 2114,
    "message": ""
 },
 {
    "code": 2115,
    "message": ""
 },
 {
    "code": 2116,
    "message": ""
 },
 {
    "code": 2117,
    "message": ""
 },
 {
    "code": 2118,
    "message": ""
 },
 {
    "code": 2119,
    "message": ""
 },
 {
    "code": 2120,
    "message": ""
 },
 {
    "code": 2121,
    "message": ""
 },
 {
    "code": 2122,
    "message": ""
 },
 {
    "code": 2150,
    "message": "Enter valid source name"
 },
 {
    "code": 2151,
    "message": "Enter valid photo grapher name"
 },
 {
    "code": 2152,
    "message": "Enter the search ext"
 },
 {
    "code": 2153,
    "message": "Enter valid API limit"
 },
 {
    "code": 2154,
    "message": "Enter valid Page"
 },
 {
    "code": 2155,
    "message": "Body not found"
 },
 {
   "code": 2156,
   "message": "Enter the valid years"
},
{
   "code": 2157,
   "message": "Enter the valid rightsholders"
},
{
   "code": 2158,
   "message": "Enter the valid elementtype"
}
]