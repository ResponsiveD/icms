"use strict";
const express = require("express");
const router = express.Router();

const project_creation_controller = require("../controllers/project_creation");
const wip_list_controller = require("../controllers/project_wip_list");
const task_creation_controller = require("../controllers/task_creation");
const photo_research_controller = require("../controllers/photo_research");
const text_qc_controller = require("../controllers/text_qc");
const text_pl_review_controller = require("../controllers/text_pl_review");
const photo_clearance_controller = require("../controllers/photo_clearance");
const user_access_controller = require("../controllers/user_access");
const activity_actions_controller = require("../controllers/activity_actions")
const dashboard_controller = require("../controllers/dashboard")
const get_text_clearance_controller = require("../controllers/text_clearance");
const get_text_research_controller = require("../controllers/text_research");
const customer_controller = require("../controllers/customer");
const task_allocation_controller = require("../controllers/task_allocation");
const customer_text_approval_controller = require("../controllers/customer_text_approval");
const file_upload = require('../controllers/file_uploads');
const Attachment_type = require('../controllers/attachment_type_clearance');
const text_pending_task_ctrl = require('../controllers/text_pending_task');
const third_party_approval_ctrl = require('../controllers/third_party_approval');
const load_indicator_ctrl = require('../controllers/load_indicator');
const element_log_ctrl = require('../controllers/elements_log.controller');
const middelware = require('../../../middleware/auth/auth.middelware');
const elements_log_pipe = require('../pipe/element_log.pipe');
const report_controller = require("../controllers/report");
const create_user_controller = require('../controllers/admin_module');

//Global Search Pipe
const globalSearchPipe = require('../pipe/global_search.pipe');

//Global Search Controller
const searchController = require('../controllers/search.controller');


//User Access module
router.get("/get-users", middelware.userAuth, user_access_controller.user_list)
router.get("/get-roles", middelware.userAuth, user_access_controller.get_roles);
router.get("/get-research-type", middelware.userAuth, user_access_controller.get_research_type);
router.get("/get-activities", middelware.userAuth, user_access_controller.get_activities_based_on_role);
router.get("/get-allactivities", middelware.userAuth, user_access_controller.get_allactivities);
router.get("/get-user-access", middelware.userAuth, user_access_controller.get_activity_rights_on_user);
router.post("/update-user-access", middelware.userAuth, user_access_controller.update_user_access);
router.get("/get-sub-roles-type", middelware.userAuth, user_access_controller.get_sub_roles);
router.post("/create-user", middelware.userAuth, user_access_controller.create_external_user);
router.get("/user-menu", middelware.userAuth, user_access_controller.user_menu);
router.get("/deactivate-user", middelware.userAuth, user_access_controller.deactivate_user);
router.get("/activate-user", middelware.userAuth, user_access_controller.activate_user);

//Project Creation module
router.post("/create-project", middelware.userAuth, project_creation_controller.create_project);
router.get("/get-project", middelware.userAuth, project_creation_controller.get_project_full_details);
router.get("/get-project-services", middelware.userAuth, project_creation_controller.get_project_services);
router.get("/get-project-modeofreceipts", middelware.userAuth, project_creation_controller.get_project_modeofreceipts);
router.get("/get-project-roletypes", middelware.userAuth, project_creation_controller.get_project_roletypes);
router.get("/get-customer-location", middelware.userAuth, project_creation_controller.get_customer_location);
router.get("/get-customer-category", middelware.userAuth, project_creation_controller.get_customer_category);
router.get("/get-customer-subcategory", middelware.userAuth, project_creation_controller.get_customer_subcategory);
router.get("/get-customer-currency", middelware.userAuth, project_creation_controller.get_customer_currency);
router.get("/get-project-pl-list", middelware.userAuth, project_creation_controller.Get_ProjectPLList);
router.get("/get-project-list", middelware.userAuth, project_creation_controller.Get_projectList);
router.get("/Get-project-List-For-Reviewer", middelware.userAuth, project_creation_controller.Get_projectListForReviewer);
router.get("/get-projectlead", middelware.userAuth, project_creation_controller.Get_ProjectLead);
router.get("/get-customer", middelware.userAuth, project_creation_controller.Get_Customer);
router.post("/customer-email-check", middelware.userAuth, project_creation_controller.customer_email_check);

//task creation module
router.get("/get-all-chapters", middelware.userAuth, task_creation_controller.get_all_chapters);
router.get("/get-all-wip-chapters", middelware.userAuth, task_creation_controller.get_all_wip_chapters);
router.post("/update-task", middelware.userAuth, task_creation_controller.update_task_new);
router.post("/create-rights-holder", middelware.userAuth, task_creation_controller.AddEdit_rights_holder);
router.get("/get-rights-holders", middelware.userAuth, task_creation_controller.get_rights_holders);
router.post("/map-rights-holder", middelware.userAuth, task_creation_controller.map_rights_holder_to_task);
router.get("/delete-rights-holders", middelware.userAuth, task_creation_controller.delete_rights_holders);
router.post('/task/right-holder/inactive', middelware.userAuth, task_creation_controller.inactive_rights_holders);
router.get("/get-rights-holder-details", middelware.userAuth, task_creation_controller.get_rights_holder_details);
router.get("/update-chapter-page", middelware.userAuth, task_creation_controller.update_chapter_page);
router.get("/get-chapter-selection-list", middelware.userAuth, get_text_research_controller.get_chapter_selections_list);
router.get("/get-chapter-taskid", middelware.userAuth, get_text_research_controller.get_chapter_taskid);

// router.get("/get-chapters",task_creation_controller.get_chapters);
// router.get("/get-chapters-details",task_creation_controller.get_chapters_details);

//activity actions
router.post("/start-activity", middelware.userAuth, activity_actions_controller.start_activity)
router.post("/cancel-activity", middelware.userAuth, activity_actions_controller.cancel_activity)
router.post("/pending-activity", middelware.userAuth, activity_actions_controller.pending_activity)
router.post("/send-mail", middelware.userAuth, activity_actions_controller.send_mail)
router.post("/reject-activity", middelware.userAuth, activity_actions_controller.reject_activity)
router.post("/submit-activity", middelware.userAuth, activity_actions_controller.submit_activity)
router.get("/get-process-detail", middelware.userAuth, activity_actions_controller.get_process_detail_for_task)
router.get("/create-clearance", middelware.userAuth, activity_actions_controller.get_update_status_for_clearance)
router.get("/get-reject-reason", middelware.userAuth, activity_actions_controller.get_reject_reason)
router.get("/put-pending-for-user", middelware.userAuth, activity_actions_controller.put_pending_for_user)

//dashboard 
router.post("/get-activity-status", middelware.userAuth, dashboard_controller.get_task_status_for_user);
router.post("/get-activity-status-delay", middelware.userAuth, dashboard_controller.get_task_status_for_user_delay);
router.post("/get-activity-status-ontrack", middelware.userAuth, dashboard_controller.get_task_status_for_user_ontrack);
router.post("/get-activity-status-r", middelware.userAuth, dashboard_controller.get_task_status_for_user_r);
router.post("/get-activity-status-delay-r", middelware.userAuth, dashboard_controller.get_task_status_for_user_delay_r);
router.post("/get-activity-status-ontrack-r", middelware.userAuth, dashboard_controller.get_task_status_for_user_ontrack_r);
router.post("/get-activity-status-report-r", middelware.userAuth, dashboard_controller.get_task_status_report_for_user_r);
router.post("/get-activity-status-report-delay-r", middelware.userAuth, dashboard_controller.get_task_status_report_for_user_delay_r);
router.post("/get-activity-status-report-ontrack-r", middelware.userAuth, dashboard_controller.get_task_status_report_for_user_ontrack_r);
router.post("/get-activity-status-clearance-pl", middelware.userAuth, dashboard_controller.get_task_status_for_user_clearance_PL);
router.post("/get-activity-status-clearance-pl-delay", middelware.userAuth, dashboard_controller.get_task_status_for_user_clearance_PL_delay);
router.post("/get-activity-status-clearance-pl-ontrack", middelware.userAuth, dashboard_controller.get_task_status_for_user_clearance_PL_ontrack);
router.post("/get-activity-status-clearance-r", middelware.userAuth, dashboard_controller.get_task_status_for_user_clearance_r);
router.post("/get-activity-status-clearance-r-delay", middelware.userAuth, dashboard_controller.get_task_status_for_user_clearance_r_delay);
router.post("/get-activity-status-clearance-r-ontrack", middelware.userAuth, dashboard_controller.get_task_status_for_user_clearance_r_ontrack);
router.post("/get-activity-status-pl", middelware.userAuth, dashboard_controller.get_task_status_for_user_pl);
router.post("/get-activity-status-report-pl", middelware.userAuth, dashboard_controller.get_task_status_for_user_report_pl);
router.post("/get-activity-status-delay-pl", middelware.userAuth, dashboard_controller.get_task_status_for_user_delay_pl);
router.post("/get-activity-status-delay-report-pl", middelware.userAuth, dashboard_controller.get_task_status_for_user_delay_report_pl);
router.post("/get-activity-status-ontrack-pl", middelware.userAuth, dashboard_controller.get_task_status_for_user_ontrack_pl);
router.post("/get-activity-status-ontrack-report-pl", middelware.userAuth, dashboard_controller.get_task_status_for_user_ontrack_report_pl);
router.post("/get-activity-status-report-c", middelware.userAuth, dashboard_controller.get_task_status_for_user_report_c);
router.post("/get-activity-status-c", middelware.userAuth, dashboard_controller.get_task_status_for_user_c);
router.post("/get-activity-status-delay-c", middelware.userAuth, dashboard_controller.get_task_status_for_user_delay_c);
router.post("/get-activity-status-delay-report-c", middelware.userAuth, dashboard_controller.get_task_status_for_user_delay_report_c);
router.post("/get-activity-status-ontrack-c", middelware.userAuth, dashboard_controller.get_task_status_for_user_ontrack_c);
router.post("/get-activity-status-ontrack-report-c", middelware.userAuth, dashboard_controller.get_task_status_for_user_ontrack_report_c);
router.post("/get-primary-status", middelware.userAuth, dashboard_controller.get_primary_task_status);
router.post("/get-primary-status-pl", middelware.userAuth, dashboard_controller.get_primary_task_status_pl);
router.post("/get-primary-status-c", middelware.userAuth, dashboard_controller.get_primary_task_status_c);
router.post("/get-primary-status-pl-ontrack", middelware.userAuth, dashboard_controller.get_primary_task_status_pl_ontrack);
router.post("/get-primary-status-pl-delay", middelware.userAuth, dashboard_controller.get_primary_task_status_pl_delay);
router.post("/get-primary-status-pr", middelware.userAuth, dashboard_controller.get_primary_task_status_pr);
router.post("/get-primary-status-tr", middelware.userAuth, dashboard_controller.get_primary_task_status_tr);
router.post("/get-task-clearance", middelware.userAuth, dashboard_controller.get_task_clearance_status);
router.post("/get-task-clearance-delay-tr", middelware.userAuth, dashboard_controller.get_task_clearance_status_delay_tr);
router.post("/get-task-clearance-ontrack-tr", middelware.userAuth, dashboard_controller.get_task_clearance_status_ontrack_tr);
router.post("/get-task-clearance-delay-pr", middelware.userAuth, dashboard_controller.get_task_clearance_status_delay_pr);
router.post("/get-task-clearance-ontrack-pr", middelware.userAuth, dashboard_controller.get_task_clearance_status_ontrack_pr);
router.post("/get-task-clearance-c-pr", middelware.userAuth, dashboard_controller.get_task_clearance_status_c_pr);
router.post("/get-task-clearance-delay-c-pr", middelware.userAuth, dashboard_controller.get_task_clearance_status_delay_c_pr);
router.post("/get-task-clearance-ontrack-c-pr", middelware.userAuth, dashboard_controller.get_task_clearance_status_ontrack_c_pr);
router.post("/get-task-clearance-c-tr", middelware.userAuth, dashboard_controller.get_task_clearance_status_c_tr);
router.post("/get-task-clearance-delay-c-tr", middelware.userAuth, dashboard_controller.get_task_clearance_status_delay_c_tr);
router.post("/get-task-clearance-ontrack-c-tr", middelware.userAuth, dashboard_controller.get_task_clearance_status_ontrack_c_tr);
router.post("/get-activity-status-customer-photo", middelware.userAuth, dashboard_controller.get_task_status_for_user_customer_photo);
router.post("/get-activity-status-customer-photo-ontrack", middelware.userAuth, dashboard_controller.get_task_status_for_user_customer_photo_ontrack);
router.post("/get-activity-status-customer-photo-delay", middelware.userAuth, dashboard_controller.get_task_status_for_user_customer_photo_delay);
router.post("/get-activity-status-customer-text", middelware.userAuth, dashboard_controller.get_task_status_for_user_customer_text);
router.post("/get-activity-status-customer-text-delay", middelware.userAuth, dashboard_controller.get_task_status_for_user_customer_text_delay);
router.post("/get-activity-status-customer-text-ontrack", middelware.userAuth, dashboard_controller.get_task_status_for_user_customer_text_ontrack);
router.post("/get-task-clearance-tr", middelware.userAuth, dashboard_controller.get_task_clearance_status_tr);
router.post("/get-task-clearance-pr", middelware.userAuth, dashboard_controller.get_task_clearance_status_pr);

//Photo Research, QC and PL Review
router.get("/get-spec-list", middelware.userAuth, photo_research_controller.get_spec_list);
router.get("/get-spec-list-reviewer", middelware.userAuth, photo_research_controller.get_spec_list_reviewer);
router.get("/get-spec-list-clearance-reviewer", middelware.userAuth, photo_research_controller.get_spec_list_clearance_reviewer);
router.post("/get-spec-details", middelware.userAuth, photo_research_controller.get_spec_details);
router.get("/get-spec-details-export", middelware.userAuth, photo_research_controller.get_spec_details_export);
router.get("/get-clearance-spec-export", middelware.userAuth, photo_research_controller.get_clearance_spec_export);
router.post("/update-spec-details", middelware.userAuth, photo_research_controller.update_spec_details);
router.get("/get-rights-type", middelware.userAuth, photo_research_controller.get_rights_type);
router.get("/get-image-src", middelware.userAuth, photo_research_controller.get_image_src);
router.get("/get-image-type", middelware.userAuth, photo_research_controller.get_image_type);
router.post("/spec-status-update", middelware.userAuth, photo_research_controller.put_select_approve_reject);
/* */
router.get("/get-model-release", middelware.userAuth, photo_research_controller.model_release);
router.get("/get-property-release", middelware.userAuth, photo_research_controller.property_release);
router.get("/get-add-rights-req", middelware.userAuth, photo_research_controller.add_rights_req);
// router.post("/update-asset-details", photo_research_controller.update_asset_details);
// router.post("/photo-quality-check", photo_qc_controller.photo_quality_check);
// router.post("/photo-pl-review", photo_pl_review_controller.photo_pl_review);

//photo clearance 
router.post("/get-rights-holder-followup", middelware.userAuth, photo_clearance_controller.get_rights_holder_followup);
router.post("/update-rights-holder-followup", middelware.userAuth, photo_clearance_controller.update_rights_holder_followup);
router.get("/get-clearance-status", middelware.userAuth, photo_clearance_controller.get_clearance_status)
router.post("/update-highres-status", middelware.userAuth, photo_clearance_controller.update_highres_status)
router.get("/get-follow-up-mail-template", middelware.userAuth, photo_clearance_controller.get_followup_mail_template)

//send mail clearance follow-up
router.post('/send-mail-follow-up', middelware.userAuth, photo_clearance_controller.send_mail_follow_up);

//Text research, QC and PL Review
router.get("/get-text-list", middelware.userAuth, get_text_research_controller.get_text_list);
router.get("/get-selection-list", middelware.userAuth, get_text_research_controller.get_selections_list);
router.get("/get-selection-details", middelware.userAuth, get_text_research_controller.get_selections_details);
router.get("/get-clearance-selection-list", middelware.userAuth, get_text_research_controller.get_clearance_selections_list);
router.get("/get-selection-details-export", middelware.userAuth, get_text_research_controller.get_selections_details_export);
router.get("/get-clearance-selection-details-export", middelware.userAuth, get_text_research_controller.get_selections_clearance_details_export);
router.post("/update-selection", middelware.userAuth, get_text_research_controller.update_selection);
router.get("/get-permission-status", middelware.userAuth, get_text_research_controller.get_permission_status);
router.get("/get-permission-needed", middelware.userAuth, get_text_research_controller.get_permission_needed);
router.post("/get-project-selections", middelware.userAuth, get_text_research_controller.get_project_selections)
router.post("/get-project-selections-full", middelware.userAuth, get_text_research_controller.get_project_selections_full)
router.post("/get-project-selections-review", middelware.userAuth, get_text_research_controller.get_project_selections_review)
router.post("/get-selection-rights-holder", middelware.userAuth, get_text_research_controller.get_selection_rights_holder)
router.post("/get-rh-followup-validation", middelware.userAuth, get_text_research_controller.validate_rh_follow_up_for_chapter)
router.post("/get-rh-followup-validation-photo", middelware.userAuth, get_text_research_controller.validate_rh_follow_up_for_spec)
router.post("/rights_holder_validation", middelware.userAuth, get_text_research_controller.rights_holder_validation)

//text clearance
router.post("/get-text-clearance", middelware.userAuth, get_text_clearance_controller.get_text_clearance);
//Update text clearance
router.post("/update-text-clearance", middelware.userAuth, get_text_clearance_controller.update_text_clearance);
router.post("/wip-list", middelware.userAuth, wip_list_controller.wip_list);
router.post("/get-project-details", middelware.userAuth, wip_list_controller.get_project_details);



//Photo Research Clearance
router.get("/get-spec-clearance-details", middelware.userAuth, photo_research_controller.get_spec_clearance_details);


//text QC
router.post("/text-quality-check", middelware.userAuth, text_qc_controller.text_quality_check);
//text PL review
router.post("/text-pl-review", middelware.userAuth, text_pl_review_controller.text_pl_review);

//customer selection
router.post("/customer-selection", middelware.userAuth, customer_controller.customer_selection);
//customer approval
router.post("/customer-approval", middelware.userAuth, customer_controller.customer_approval);
//customer reviewer
router.post("/customer-review", middelware.userAuth, customer_controller.customer_review);

//task allocation
router.get("/get-tasks", middelware.userAuth, task_allocation_controller.get_tasks);
router.post("/post-tasks", middelware.userAuth, task_allocation_controller.post_tasks);
router.get("/get-resource-name", middelware.userAuth, task_allocation_controller.get_resource_name);
router.get("/get-resource-name-on-activity", middelware.userAuth, task_allocation_controller.get_resource_name_on_activity);

//Customer Text Approval
router.get("/customer-text-approval", middelware.userAuth, customer_text_approval_controller.customer_text_approval);
router.post("/customer-text-approval", middelware.userAuth, customer_text_approval_controller.customer_text_approval_status);

//fileupload apis
router.post('/project-uploads', middelware.userAuth, file_upload.Project_File_Upload)
router.post('/service-uploads', middelware.userAuth, file_upload.Service_File_Upload)
router.post('/task-uploads', middelware.userAuth, file_upload.Task_File_Upload)
router.post('/spec-uploads', middelware.userAuth, file_upload.Spec_File_Upload)
router.get("/get-attachment-type", middelware.userAuth, Attachment_type.attachment_type_clearance);

//text_pending_task
router.get('/text-pending-task', middelware.userAuth, text_pending_task_ctrl.text_pending_task);
router.get('/text-pending-task-details', middelware.userAuth, text_pending_task_ctrl.text_pending_task_details);
router.get('/third-party-approval', middelware.userAuth, third_party_approval_ctrl.third_party_approval);
router.get('/third-party-approval-details', middelware.userAuth, third_party_approval_ctrl.third_party_approval_details);

//load Indicator
router.get('/get-load-indicator', middelware.userAuth, load_indicator_ctrl.load_indicator);

//excel upload 
//Element Log
router.post('/element-log/addedit', middelware.userAuth, elements_log_pipe.element_log, element_log_ctrl.add_or_edit_elemeent_log);

//task creation
router.post('/task-creation/addedit', middelware.userAuth, elements_log_pipe.task_creation, element_log_ctrl.add_or_edit_task_creation);

//selection list master Data
router.get('/elementtype', middelware.userAuth, element_log_ctrl.elementtype);
router.get('/specifiedas', middelware.userAuth, element_log_ctrl.specifiedas);
router.get('/usage', middelware.userAuth, element_log_ctrl.usage);
router.get('/elemrights', middelware.userAuth, element_log_ctrl.elemrights);

//Reports
router.get("/get-project-list-page-review", middelware.userAuth, report_controller.get_project_list_for_page_review);
router.get("/get-project-page-review", middelware.userAuth, report_controller.get_project_page_review);
router.post("/update-page-review", middelware.userAuth, report_controller.update_page_review);
router.get("/get-project-list-admin", middelware.userAuth, report_controller.get_project_list_for_admin);
router.get("/get-project-admin", middelware.userAuth, report_controller.get_project_admin); 

//Admin Module
router.post('/create-user-details', middelware.userAuth, create_user_controller.addedituser);
router.post('/create-customer-details', middelware.userAuth, create_user_controller.addeditcustomer);
router.post('/create-service-details', middelware.userAuth, create_user_controller.addeditservice);
router.get('/get-user-role-type', middelware.userAuth, create_user_controller.getuserroletype);
router.get('/get-user-sub-role-type', middelware.userAuth, create_user_controller.getusersubroletype);
router.get('/get-user-aty-type', middelware.userAuth, create_user_controller.getuseratytype);
router.get('/get-user-cust-type', create_user_controller.getusercusttype);
router.get('/get-user-reporting-type', middelware.userAuth, create_user_controller.getuserreportingtype);
router.get('/get-user-data', middelware.userAuth, create_user_controller.getuserdata);
router.get('/get-cust-org-type', middelware.userAuth, create_user_controller.getcustorgtype);
router.get('/get-user-org-type', middelware.userAuth, create_user_controller.getuserorgtype);
router.get('/get-user-org-div-type', middelware.userAuth, create_user_controller.getuserorgdivtype);
router.get('/get-cust-comp-type', middelware.userAuth, create_user_controller.getcustcomptype);
router.get('/get-service-comp-type', middelware.userAuth, create_user_controller.getservicecomptype);
router.get('/get-service-org-type', middelware.userAuth, create_user_controller.getserviceorgtype);
router.get('/get-customer-data', middelware.userAuth, create_user_controller.getcustomerdata);
router.get('/get-service-data', middelware.userAuth, create_user_controller.getservicedata);
router.post('/delete-service-data', middelware.userAuth, create_user_controller.deleteservicedata);
router.post('/delete-user-data', middelware.userAuth, create_user_controller.deleteuserdata);
router.post('/delete-customer-data', middelware.userAuth, create_user_controller.deletecustomerdata);

//Global Search API
router.post('/search/get-text', middelware.userAuth, globalSearchPipe.textSearch, searchController.textSearch);
router.post('/search/get-photo', middelware.userAuth, globalSearchPipe.photoSearch, searchController.photSearch);

router.get('/sourcename', middelware.userAuth, globalSearchPipe.sourcename, searchController.getSourceName);
router.get('/photographername', middelware.userAuth, globalSearchPipe.photographername, searchController.getPhotographerName);


module.exports = router;