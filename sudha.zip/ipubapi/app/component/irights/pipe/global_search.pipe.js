"use strict";

const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");
const exception = require("../exception/exception");


exports.textSearch = async function (req, res, next) {
  try {
    let data = req.body;
    let error = [];
    let isnumber = /^[0-9]{1,10}$/;

    if (data) {

      if (data.searchtexts == undefined) {
        error.push(await exception.getException(2152));
      }

      if (data.limit == undefined || !isnumber.test(data.limit)) {
        error.push(await exception.getException(2153));
      }

      if (data.page == undefined || !isnumber.test(data.page)) {
        error.push(await exception.getException(2154));
      }

      // if (data.years != undefined && !(data.years.length > 0)) {
      //   error.push(await exception.getException(2156));
      // }

      // if (data.rightsholders != undefined && !(data.rightsholders.length > 0)) {
      //   error.push(await exception.getException(2157));
      // }

      // if (data.elementtype != undefined && !(data.elementtype.length > 0)) {
      //   error.push(await exception.getException(2158));
      // }


    } else {
      error.push(await exception.getException(2155));
    }

    if (error.length === 0) {
      next()
    } else {
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
    }

  } catch (error) {
    exception_repo.exception_DB_log(req.User.OrgID ? req.User.OrgID : 0, 1, req.User.UserID ? req.User.UserID : 0, 0, req.method, req.originalUrl, req.body, error ? error : 0, 0, 'pipe');
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};


exports.photoSearch = async function (req, res, next) {
  try {

    let data = req.body;
    let error = [];
    let isnumber = /^[0-9]{1,10}$/;

    if (data) {

      if (data.searchtexts == undefined) {
        error.push(await exception.getException(2152));
      }

      if (data.limit == undefined || !isnumber.test(data.limit)) {
        error.push(await exception.getException(2153));
      }

      if (data.page == undefined || !isnumber.test(data.page)) {
        error.push(await exception.getException(2154));
      }

      // if (data.years != undefined && !(data.years.length > 0)) {
      //   error.push(await exception.getException(2156));
      // }

      // if (data.rightsholders != undefined && !(data.rightsholders.length > 0)) {
      //   error.push(await exception.getException(2157));
      // }

      // if (data.sourcename != undefined && !(data.elementtype.length > 0)) {
      //   error.push(await exception.getException(2158));
      // }

    } else {
      error.push(await exception.getException(2155));
    }

    if (error.length === 0) {
      next()
    } else {
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
    }

  } catch (error) {
    exception_repo.exception_DB_log(req.User.OrgID ? req.User.OrgID : 0, 1, req.User.UserID ? req.User.UserID : 0, 0, req.method, req.originalUrl, req.body, error ? error : 0, 0, 'pipe');
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};

exports.sourcename = async function (req, res, next) {
  try {

    let data = req.query;
    let error = [];
    let rex = /^[a-z0-9]+$/i;

    if (data.name != undefined && !rex.test(data.name)) {
      error.push(await exception.getException(2150));
    }

    if (error.length === 0) {
      next()
    } else {
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
    }

  } catch (error) {
    exception_repo.exception_DB_log(req.User.OrgID ? req.User.OrgID : 0, 1, req.User.UserID ? req.User.UserID : 0, 0, req.method, req.originalUrl, req.query, error ? error : 0, 0, 'pipe');
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};

exports.photographername = async function (req, res, next) {
  try {

    let data = req.query;
    let error = [];
    let rex = /^[a-z0-9]+$/i;

    if (data.name != undefined && !rex.test(data.name)) {
      error.push(await exception.getException(2151));
    }

    if (error.length === 0) {
      next()
    } else {
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
    }

  } catch (error) {
    exception_repo.exception_DB_log(req.User.OrgID ? req.User.OrgID : 0, 1, req.User.UserID ? req.User.UserID : 0, 0, req.method, req.originalUrl, req.query, error ? error : 0, 0, 'pipe');
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};