"use strict";

const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");
const exception = require("../exception/exception");
const validationCheck = require("../../irights/repository/pipe.service");

exports.element_log = async function (req, res, next) {
  try {
    let data = req.body;
    let error = [];
    if (data) {

      if (data.proj_ser_id != undefined) {
        if (typeof (data.proj_ser_id) != "number") {
          error.push(await exception.getException(2004));
        }
      } else {
        error.push(await exception.getException(2003));
      }

      if (data.chapter_id != undefined) {
        if (typeof (data.chapter_id) != "number") {
          error.push(await exception.getException(2006));
        }
      } else {
        error.push(await exception.getException(2005));
      }

      if (data.task_id != undefined) {
        if (typeof (data.task_id) != "number") {
          error.push(await exception.getException(2008));
        }
      } else {
        error.push(await exception.getException(2007));
      }

      if (data.selections_details.length > 0) {

        for (let ii = 0; ii < data.selections_details.length; ii++) {
          let row = ii + 1;
          let int_error = {
            "row": row,
            "error": []
          }

          if (data.selections_details[ii].id == undefined) {
            int_error.error.push({ "column": "id", "error": await exception.getException(2009) });
          }

          if (data.selections_details[ii].selection_name == undefined) {
            int_error.error.push({ "column": "selection_name", "error": await exception.getException(2010) });
          }

          if (data.selections_details[ii].is_active == undefined) {
            int_error.error.push({ "column": "is_active", "error": await exception.getException(2011) });
          }

          if (data.selections_details[ii].selection_id == undefined) {
            int_error.error.push({ "column": "selection_id", "error": await exception.getException(2012) });
          }


          if (data.selections_details[ii].element != undefined) {
            if (data.selections_details[ii].element != null) {
              if (typeof (data.selections_details[ii].element) != "string") {
                int_error.error.push({ "column": "element", "error": await exception.getException(2013) });
              } else {
                let str = data.selections_details[ii].element;
                if (str.length > 150) {
                  int_error.error.push({ "column": "element", "error": await exception.getException(2014) });
                }
              }
            }
          } else {
            int_error.error.push({ "column": "element", "error": await exception.getException(2015) });
          }

          if (data.selections_details[ii].image_namecalc != null) {
            if (typeof (data.selections_details[ii].image_namecalc) != "string") {
              int_error.error.push({ "column": "image_namecalc", "error": await exception.getException(2016) });
            } else {
              let str = data.selections_details[ii].image_namecalc;
              if (str.length > 150) {
                int_error.error.push({ "column": "image_namecalc", "error": await exception.getException(2017) });
              }
            }

          }

          if (data.selections_details[ii].ms_page != null) {
            if (typeof (data.selections_details[ii].ms_page) != "string") {
              int_error.error.push({ "column": "ms_page", "error": await exception.getException(2018) });
            } else {
              let str = data.selections_details[ii].ms_page;
              if (str.length > 150) {
                int_error.error.push({ "column": "ms_page", "error": await exception.getException(2019) });
              }
            }
          }

          if (data.selections_details[ii].specfd_as === undefined && data.selections_details[ii].specfd_as == null) {
            int_error.error.push({ "column": "specfd_as", "error": await exception.getException(2020) });
          } else {
            // let result = await validationCheck.get_spec_details_export('[IRS].[Mst_Specified_dtl]', 'SpecifiedAs', data.selections_details[ii].specfd_as);
            // if (result.recordsets[0].length > 0) {
            let info = [
              { "name": "New", "value": 1 },
              { "name": "Pickup", "value": 2 },
              { "name": "Revised", "value": 3 },
              { "name": "Re-use", "value": 4 },
              { "name": "Killed", "value": 5 }
            ]
            let result = info.find(el => el.name == data.selections_details[ii].specfd_as);
            if (result) {
              data.selections_details[ii].specfd_as = result.value;
            } else {
              int_error.error.push({ "column": "specfd_as", "error": await exception.getException(2021) });
            }
          }

          if (data.selections_details[ii].pickup_source != null) {
            let str = data.selections_details[ii].pickup_source;
            if (str.length > 150) {
              int_error.error.push({ "column": "pickup_source", "error": await exception.getException(2022) });
            }
          }

          if (data.selections_details[ii].oldelem_num != null) {
            let str = data.selections_details[ii].oldelem_num;
            if (str.length > 150) {
              int_error.error.push({ "column": "ioldelem_numd", "error": await exception.getException(2023) });
            }
          }

          if (data.selections_details[ii].elem_type != null) {
            // let result = await validationCheck.get_spec_details_export('[IRS].[Mst_ElementType_dtl]', 'Element', data.selections_details[ii].elem_type);
            let info = [
              { "name": "Text", "value": 1 },
              { "name": "Image", "value": 2 },
              { "name": "Video", "value": 3 },
              { "name": "Audio", "value": 4 }
            ]
            let result = info.find(el => el.name == data.selections_details[ii].elem_type);
            if (result) {
              data.selections_details[ii].elem_type = result.value;
            } else {
              int_error.error.push({ "column": "elem_type", "error": await exception.getException(2024) });
            }
          }

          if (data.selections_details[ii].usage === undefined) {
            int_error.error.push({ "column": "usage", "error": await exception.getException(2025) });
          } else if (data.selections_details[ii].usage != null) {
            // let result = await validationCheck.get_spec_details_export('[IRS].[Mst_Usage_dtl]', 'Usage', data.selections_details[ii].usage);
            // if (result.recordsets[0].length > 0) {
            //   data.selections_details[ii].usage = result.recordsets[0][0].ID;
            let info = [
              { "name": "APP", "value": 2 },
              { "name": "BOX", "value": 3 },
              { "name": "BMA", "value": 4 },
              { "name": "COP", "value": 5 },
              { "name": "CVR", "value": 7 },
              { "name": "DSG", "value": 8 },
              { "name": "EXH", "value": 9 },
              { "name": "FIG", "value": 10 },
              { "name": "FMA", "value": 11 },
              { "name": "FTR", "value": 12 },
              { "name": "TAB", "value": 13 },
              { "name": "TXT", "value": 14 },
              { "name": "UNN", "value": 15 },
              { "name": "SKD", "value": 16 },
              { "name": "SOP", "value": 17 }
            ]
            let result = info.find(el => el.name == data.selections_details[ii].usage);
            if (result) {
              data.selections_details[ii].usage = result.value;
            } else {
              int_error.error.push({ "column": "usage", "error": await exception.getException(2026) });
            }
          }

          if (data.selections_details[ii].description != null) {
            if (typeof (data.selections_details[ii].description) != "string") {
              int_error.error.push({ "column": "description", "error": await exception.getException(2027) });
            } else {
              let str = data.selections_details[ii].description;
              if (str.length > 500) {
                int_error.error.push({ "column": "description", "error": await exception.getException(2028) });
              }
            }
          }

          if (data.selections_details[ii].caption != null) {
            if (typeof (data.selections_details[ii].caption) != "string") {
              int_error.error.push({ "column": "caption", "error": await exception.getException(2029) });
            } else {
              let str = data.selections_details[ii].caption;
              if (str.length > 500) {
                int_error.error.push({ "column": "caption", "error": await exception.getException(2030) });
              }
            }
          }

          if (data.selections_details[ii].source != null) {
            if (typeof (data.selections_details[ii].source) != "string") {
              int_error.error.push({ "column": "source", "error": await exception.getException(2031) });
            } else {
              let str = data.selections_details[ii].source;
              if (str.length > 500) {
                int_error.error.push({ "column": "source", "error": await exception.getException(2032) });
              }
            }
          }

          if (data.selections_details[ii].srctrack_num != null) {
            if (typeof (data.selections_details[ii].srctrack_num) != "string") {
              int_error.error.push({ "column": "srctrack_num", "error": await exception.getException(2033) });
            } else {
              let str = data.selections_details[ii].srctrack_num;
              if (str.length > 500) {
                int_error.error.push({ "column": "srctrack_num", "error": await exception.getException(2034) });
              }
            }
          }

          if (data.selections_details[ii].credit_line != null) {
            if (typeof (data.selections_details[ii].credit_line) != "string") {
              int_error.error.push({ "column": "credit_line", "error": await exception.getException(2035) });
            } else {
              let str = data.selections_details[ii].credit_line;
              if (str.length > 500) {
                int_error.error.push({ "column": "credit_line", "error": await exception.getException(2036) });
              }
            }
          }

          if (data.selections_details[ii].rights != undefined && data.selections_details[ii].rights != null) {
            // let result = await validationCheck.get_spec_details_export('[IRS].[Mst_ElemRights_dtl]', 'Rights', data.selections_details[ii].rights);
            // if (result.recordsets[0].length > 0) {
            //   data.selections_details[ii].rights = result.recordsets[0][0].ID;
            let info = [
              { "name": "AU Owns", "value": 1 },
              { "name": "AU Supplied", "value": 2 },
              { "name": "Fair Use Confirmed", "value": 3 },
              { "name": "Free Use", "value": 4 },
              { "name": "JB Owns", "value": 5 },
              { "name": "JB Owns w/Restrictions", "value": 6 },
              { "name": "Multi-Perm,North America", "value": 7 },
              { "name": "Public Domain", "value": 8 },
              { "name": "Royalty Free", "value": 9 },
              { "name": "Royalty Free w/Restrictions", "value": 10 },
              { "name": "Unlimited Use", "value": 11 },
              { "name": "Unlimited Use w/Restrictions", "value": 12 },
              { "name": "World in All", "value": 13 },
              { "name": "World in English", "value": 14 },
              { "name": "World in English +1", "value": 15 }
            ]
            let result = info.find(el => el.name == data.selections_details[ii].rights);
            if (result) {
              data.selections_details[ii].rights = result.value;
            } else {
              int_error.error.push({ "column": "rights", "error": await exception.getException(2037) });
            }
          }

          if (data.selections_details[ii].perms_onfile != undefined && data.selections_details[ii].perms_onfile != null) {
            // let result = await validationCheck.get_spec_details_export('[IRS].[mst_permission_needed]', 'Name', data.selections_details[ii].perms_onfile);
            // if (result.recordsets[0].length > 0) {
            //   data.selections_details[ii].perms_onfile = result.recordsets[0][0].ID;

            let info = [
              { "name": "Interview Release Form", "value": 1 },
              { "name": "Invoice", "value": 3 },
              { "name": "JBL North America Letter", "value": 4 },
              { "name": "JBL Stock Perm Letter", "value": 5 },
              { "name": "JBL World All letter", "value": 6 },
              { "name": "JBL World English Letter", "value": 7 },
              { "name": "JBL UU Letter", "value": 8 },
              { "name": "Letter from other source", "value": 9 },
              { "name": "Modified JBL perm letter", "value": 10 },
              { "name": "PD statement", "value": 11 },
              { "name": "WFH", "value": 12 }
            ]

            let result = info.find(el => el.name == data.selections_details[ii].perms_onfile);
            if (result) {
              data.selections_details[ii].perms_onfile = result.value;
            } else {
              int_error.error.push({ "column": "perms_onfile", "error": await exception.getException(2038) });
            }
          }

          if (data.selections_details[ii].perm_status != undefined && data.selections_details[ii].perm_status != null) {
            // let result = await validationCheck.get_spec_details_export('[IRS].[mst_permission_status]', 'Name', data.selections_details[ii].perm_status);
            // if (result.recordsets[0].length > 0) {
            //   data.selections_details[ii].perm_status = result.recordsets[0][0].ID;

            let info = [
              { "name": "Filled", "value": 1 },
              { "name": "In Review", "value": 2 },
              { "name": "Invoice Requested", "value": 3 },
              { "name": "Killed", "value": 4 },
              { "name": "Need AU Confirmation", "value": 5 },
              { "name": "Need Comp Copy", "value": 7 },
              { "name": "Need Final Review", "value": 8 },
              { "name": "Need Invoice", "value": 9 },
              { "name": "Need PD Confirmation", "value": 10 },
              { "name": "Need Permission", "value": 11 },
              { "name": "Need Perm Review", "value": 12 },
              { "name": "Perm Requested", "value": 13 },
              { "name": "Photo Shoot", "value": 14 },
              { "name": "Processing Image", "value": 15 },
              { "name": "Ready for Review", "value": 16 },
              { "name": "Research", "value": 17 },
              { "name": "TK from Author", "value": 18 },
            ]

            let result = info.find(el => el.name == data.selections_details[ii].perm_status);
            if (result) {
              data.selections_details[ii].perm_status = result.value;
            } else {
              int_error.error.push({ "column": "perm_status", "error": await exception.getException(2039) });
            }
          }

          if (data.selections_details[ii].prod_status != null) {
            if (typeof (data.selections_details[ii].prod_status) != "string") {
              int_error.error.push({ "column": "prod_status", "error": await exception.getException(2040) });
            } else {
              let str = data.selections_details[ii].prod_status;
              if (str.length > 500) {
                int_error.error.push({ "column": "prod_status", "error": await exception.getException(2041) });
              }
            }
          }

          if (data.selections_details[ii].final_page != null) {
            if (typeof (data.selections_details[ii].final_page) != "string") {
              int_error.error.push({ "column": "final_page", "error": await exception.getException(2042) });
            } else {
              let str = data.selections_details[ii].final_page;
              if (str.length > 500) {
                int_error.error.push({ "column": "final_page", "error": await exception.getException(2043) });
              }
            }
          }

          if (data.selections_details[ii].invoice_num != null) {
            if (typeof (data.selections_details[ii].invoice_num) != "string") {
              int_error.error.push({ "column": "invoice_num", "error": await exception.getException(2044) });
            } else {
              let str = data.selections_details[ii].invoice_num;
              if (str.length > 500) {
                int_error.error.push({ "column": "invoice_num", "error": await exception.getException(2045) });
              }
            }
          }

          if (data.selections_details[ii].invoice_date != null) {
            if (typeof (data.selections_details[ii].invoice_date) != "string") {
              int_error.error.push({ "column": "invoice_date", "error": await exception.getException(2046) });
            } else {
              let str = data.selections_details[ii].invoice_date;
              if (str.length > 500) {
                int_error.error.push({ "column": "invoice_date", "error": await exception.getException(2047) });
              }
            }
          }


          if (data.selections_details[ii].plate != null) {
            if (typeof (data.selections_details[ii].plate) != "string") {
              int_error.error.push({ "column": "plate", "error": await exception.getException(2048) });
            } else {
              let str = data.selections_details[ii].plate;
              if (str.length > 500) {
                int_error.error.push({ "column": "plate", "error": await exception.getException(2049) });
              }
            }
          }

          if (data.selections_details[ii].author != null) {
            if (typeof (data.selections_details[ii].author) != "string") {
              int_error.error.push({ "column": "author", "error": await exception.getException(2050) });
            } else {
              let str = data.selections_details[ii].author;
              if (str.length > 500) {
                int_error.error.push({ "column": "author", "error": await exception.getException(2051) });
              }
            }
          }

          if (data.selections_details[ii].rf_sub != null) {
            if (typeof (data.selections_details[ii].rf_sub) != "string") {
              int_error.error.push({ "column": "rf_sub", "error": await exception.getException(2052) });
            } else {
              let str = data.selections_details[ii].rf_sub;
              if (str.length > 500) {
                int_error.error.push({ "column": "rf_sub", "error": await exception.getException(2053) });
              }
            }
          }

          if (data.selections_details[ii].total_projfees != null) {
            if (typeof (data.selections_details[ii].total_projfees) != "string") {
              int_error.error.push({ "column": "total_projfees", "error": await exception.getException(2054) });
            } else {
              let str = data.selections_details[ii].total_projfees;
              if (str.length > 500) {
                int_error.error.push({ "column": "total_projfees", "error": await exception.getException(2055) });
              }
            }
          }

          if (data.selections_details[ii].ebook != null) {
            if (typeof (data.selections_details[ii].ebook) != "string") {
              int_error.error.push({ "column": "ebook", "error": await exception.getException(2056) });
            } else {
              let str = data.selections_details[ii].ebook;
              if (str.length > 500) {
                int_error.error.push({ "column": "ebook", "error": await exception.getException(2057) });
              }
            }
          }

          if (data.selections_details[ii].printed_textbook != null) {
            if (typeof (data.selections_details[ii].printed_textbook) != "string") {
              int_error.error.push({ "column": "printed_textbook", "error": await exception.getException(2058) });
            } else {
              let str = data.selections_details[ii].printed_textbook;
              if (str.length > 500) {
                int_error.error.push({ "column": "printed_textbook", "error": await exception.getException(2059) });
              }
            }
          }

          if (data.selections_details[ii].digital_lms != null) {
            if (typeof (data.selections_details[ii].digital_lms) != "string") {
              int_error.error.push({ "column": "digital_lms", "error": await exception.getException(2060) });
            } else {
              let str = data.selections_details[ii].digital_lms;
              if (str.length > 500) {
                int_error.error.push({ "column": "digital_lms", "error": await exception.getException(2061) });
              }
            }
          }

          if (data.selections_details[ii].printed_ancillary != null) {
            if (typeof (data.selections_details[ii].printed_ancillary) != "string") {
              int_error.error.push({ "column": "printed_ancillary", "error": await exception.getException(2062) });
            } else {
              let str = data.selections_details[ii].printed_ancillary;
              if (str.length > 500) {
                int_error.error.push({ "column": "id", "error": await exception.getException(2063) });
                int_error.error.push(await exception.getException(2068));
              }
            }
          }

          if (data.selections_details[ii].elect_ancillary != null) {
            if (typeof (data.selections_details[ii].elect_ancillary) != "string") {
              int_error.error.push({ "column": "elect_ancillary", "error": await exception.getException(2064) });
            } else {
              let str = data.selections_details[ii].elect_ancillary;
              if (str.length > 500) {
                int_error.error.push({ "column": "elect_ancillary", "error": await exception.getException(2065) });
              }
            }
          }

          if (data.selections_details[ii].derivative_prod != null) {
            if (typeof (data.selections_details[ii].derivative_prod) != "string") {
              int_error.error.push({ "column": "derivative_prod", "error": await exception.getException(2066) });
            } else {
              let str = data.selections_details[ii].derivative_prod;
              if (str.length > 500) {
                int_error.error.push({ "column": "derivative_prod", "error": await exception.getException(2067) });
              }
            }
          }

          if (data.selections_details[ii].future_edition != null) {
            if (typeof (data.selections_details[ii].future_edition) != "string") {
              int_error.error.push({ "column": "future_edition", "error": await exception.getException(2068) });
            } else {
              let str = data.selections_details[ii].future_edition;
              if (str.length > 500) {
                int_error.error.push({ "column": "future_edition", "error": await exception.getException(2069) });
              }
            }
          }

          if (data.selections_details[ii].future_revisions != null) {
            if (typeof (data.selections_details[ii].future_revisions) != "string") {
              int_error.error.push({ "column": "future_revisions", "error": await exception.getException(2070) });
            } else {
              let str = data.selections_details[ii].future_revisions;
              if (str.length > 500) {
                int_error.error.push({ "column": "future_revisions", "error": await exception.getException(2071) });
              }
            }
          }

          if (data.selections_details[ii].hires != null) {
            if (typeof (data.selections_details[ii].hires) != "string") {
              int_error.error.push({ "column": "hires", "error": await exception.getException(2072) });
            } else {
              let str = data.selections_details[ii].hires;
              if (str.length > 500) {
                int_error.error.push({ "column": "hires", "error": await exception.getException(2073) });
              }
            }
          }

          if (data.selections_details[ii].model_releases != null) {
            if (typeof (data.selections_details[ii].model_releases) != "string") {
              int_error.error.push({ "column": "model_releases", "error": await exception.getException(2074) });
            } else {
              let str = data.selections_details[ii].model_releases;
              if (str.length > 500) {
                int_error.error.push({ "column": "imodel_releasesd", "error": await exception.getException(2075) });
              }
            }
          }

          if (data.selections_details[ii].sizeon_page != null) {
            if (typeof (data.selections_details[ii].sizeon_page) != "string") {
              int_error.error.push({ "column": "sizeon_page", "error": await exception.getException(2076) });
            } else {
              let str = data.selections_details[ii].sizeon_page;
              if (str.length > 500) {
                int_error.error.push({ "column": "sizeon_page", "error": await exception.getException(2077) });
              }
            }
          }

          if (data.selections_details[ii].note != null) {
            if (typeof (data.selections_details[ii].note) != "string") {
              int_error.error.push({ "column": "note", "error": await exception.getException(2078) });
            } else {
              let str = data.selections_details[ii].note;
              if (str.length > 500) {
                int_error.error.push({ "column": "note", "error": await exception.getException(2079) });
              }
            }
          }

          if (data.selections_details[ii].note_createdby != null) {
            if (typeof (data.selections_details[ii].note_createdby) != "string") {
              int_error.error.push({ "column": "note_createdby", "error": await exception.getException(2080) });
            } else {
              let str = data.selections_details[ii].note_createdby;
              if (str.length > 500) {
                int_error.error.push({ "column": "note_createdby", "error": await exception.getException(2081) });
              }
            }
          }

          if (data.selections_details[ii].researcher != null) {
            if (typeof (data.selections_details[ii].researcher) != "string") {
              int_error.error.push({ "column": "researcher", "error": await exception.getException(2082) });
            } else {
              let str = data.selections_details[ii].researcher;
              if (str.length > 500) {
                int_error.error.push({ "column": "researcher", "error": await exception.getException(2083) });
              }
            }
          }

          if (int_error.error.length > 0) {
            error.push(int_error);
          }

        }
      } else {
        error.push(await exception.getException(2089));
      }

    } else {
      error.push(await exception.getException(2090));
    }

    if (error.length === 0) {
      next()
    } else {
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
    }

  } catch (error) {
    await exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.body), error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};


exports.task_creation = async function (req, res, next) {
  try {

    let data = req.body;
    let error = [];

    if (data === undefined) {
      error.push(await exception.getException(2089));
    } else {

      if (data.proj_ser_id == undefined) {
        error.push(await exception.getException(2003));
      }

      if (typeof (data.proj_ser_id) != "number") {
        error.push(await exception.getException(2004));
      }

      if (data.irsproj_id == undefined) {
        error.push(await exception.getException(2003));
      }

      if (typeof (data.irsproj_id) != "number") {
        error.push(await exception.getException(2004));
      }

      if (data.chapter_id == undefined) {
        error.push(await exception.getException(2005));
      }

      if (typeof (data.chapter_id) != "number") {
        error.push(await exception.getException(2006));
      }

      // if (data.task_id == undefined) {
      //   error.push(await exception.getException(2007));
      // }

      // if (typeof (data.task_id) != "number") {
      //   error.push(await exception.getException(2008));
      // }

      if (data.task_details.length > 0) {
        for (let ii = 0; ii < data.task_details.length; ii++) {

          let int_error = {
            "row": ii,
            "error": []
          }

          if (data.task_details[ii].sid == undefined) {
            int_error.error.push({ "column": "sid", "error": await exception.getException(2009) });
          }

          if (typeof (data.task_details[ii].sid) != "number") {
            int_error.error.push({ "column": "sid", "error": await exception.getException(2023) });
          }

          //spec
          if (data.task_details[ii].spec_desc == undefined) {
            int_error.error.push({ "column": "spec_desc", "error": await exception.getException(2010) });
          }

          if (typeof (data.task_details[ii].spec_desc) != "string") {
            int_error.error.push({ "column": "spec_desc", "error": await exception.getException(2026) });
          } else {
            let str = data.task_details[ii].spec_desc;
            if (str.length > 2000) {
              int_error.error.push({ "column": "spec_desc", "error": await exception.getException(2027) });
            }
          }

          //photo no
          if (data.task_details[ii].photo_no == undefined) {
            int_error.error.push({ "column": "photo_no", "error": await exception.getException(2012) });
          }

          if (typeof (data.task_details[ii].photo_no) != "string") {
            int_error.error.push({ "column": "photo_no", "error": await exception.getException(2026) });
          } else {
            let str = data.task_details[ii].photo_no;
            if (str.length > 50) {
              int_error.error.push({ "column": "photo_no", "error": await exception.getException(2027) });
            }
          }

          //page no
          if (data.task_details[ii].page_no == undefined) {
            int_error.error.push({ "column": "page_no", "error": await exception.getException(2011) });
          }

          if (typeof (data.task_details[ii].page_no) != "number") {
            int_error.error.push({ "column": "page_no", "error": await exception.getException(2023) });
          }

          // Caption
          if (data.task_details[ii].caption == undefined) {
            int_error.error.push({ "column": "caption", "error": await exception.getException(2011) });
          }

          if (typeof (data.task_details[ii].caption) != "string") {
            int_error.error.push({ "column": "caption", "error": await exception.getException(2026) });
          } else {
            let str = data.task_details[ii].caption;
            if (str.length > 501) {
              int_error.error.push({ "column": "caption", "error": await exception.getException(2027) });
            }
          }

          //active
          if (data.task_details[ii].is_active == undefined) {
            int_error.error.push({ "column": "is_active", "error": await exception.getException(2011) });
          }

          if (int_error.length > 0) {
            error.push(int_error);
          }
        }
      } else {
        error.push(await exception.getException(2089));
      }
    }

    if (error.length === 0) {
      next()
    } else {
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
    }

  } catch (error) {
    await exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.body), error, 0);
    res.send(error);
  }
};