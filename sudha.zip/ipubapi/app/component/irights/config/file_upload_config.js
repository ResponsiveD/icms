
exports.AllowedFileExtension = [
    '.jpeg',
    '.jpg',
    '.pdf',
    '.png',
    '.doc',
    '.docx',
    '.xls',
    '.xlsx',
    '.xlsb',
    '.ppt',
    '.pptx',
    '.msg'
];

exports.AllowedImageFileType = [
    'image/jpeg',
    'image/png'
];

exports.AllowedImageFileExtension = [
    '.jpeg',
    '.jpg',
    '.png'
];
exports.AllowedMailType =[
    'application/vnd.ms-outlook',
    'message/rfc822'
];

exports.AllowedMailExtension =[
    '.msg',
    '.eml'
];

const ALLOWEDTYPE = { ALL: 1, EMAIL: 2 };

// export {ALLOWEDTYPE};

module.exports.ALLOWEDTYPE=ALLOWEDTYPE;