module.exports = {
  PL: "PL",
  Admin: "Admin",
  Customer: "Customer",
  Task_Creator: "Task_Creator",
  TL: "TL",
  Photo_Researcher: "Photo_Researcher",
  Text_Researcher: "Text_Researcher"
};