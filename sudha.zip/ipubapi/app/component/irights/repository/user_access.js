"use strict";
const param = require('../models/parameter_input');
var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')

exports.get_roles = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IPS].[GetAllRoles]', parameters, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "role_name": element.name, "role_id": element.id });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

exports.get_research_type = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      para = new param('RoleID', sqlType.Int, 7);
      parameters.push(para);
      db_library
        .execute('[IPS].[GetAllSubRoles]', parameters, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "sub_role_name": element.name, "sub_role_id": element.id });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

exports.get_sub_roles = async function (UserID, RoleID) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, UserID);
      parameters.push(para);
      para = new param('RoleID', sqlType.Int, RoleID);
      parameters.push(para);
      db_library
        .execute('[IPS].[GetAllSubRoles]', parameters, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "sub_role_name": element.name, "sub_role_id": element.id });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.user_menu =  async function (UserID) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, UserID);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetMenuForUser]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordset);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.UpdateUserStatus=async function (UserID,isActive) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, UserID);
      parameters.push(para);
      para = new param('isActive', sqlType.Bit, isActive);
      parameters.push(para);
      db_library
        .execute('[IRS].[UpdateUserStatus]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordset);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.get_allactivities = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetActivities]', parameters, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "activity_name": element.name, "activity_id": element.id, "isHavingRights": 0 });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

exports.get_activity_rights_on_user = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let val1 = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetUserCurrentRights]', parameters, db_library.query_type.SP).then((value) => {

          value.recordsets[1].forEach(element => {
            if (element.SubRoleID)
              val1.push({ "sub_role_id": element.SubRoleID, "sub_role_name": element.SubRole });
          });
          value.recordsets[2].forEach(element => {
            if (element.atyname)
              val.push({ "activity_name": element.atyname, "activity_id": element.atyid, "isHavingRights": element.HaveRights });
          });
          var result = {
            user_code: value.recordsets[0][0].usercode,
            user_id: value.recordsets[0][0].userid,
            user_email: value.recordsets[0][0].useremailid,
            role_name: value.recordsets[0][0].rolename,
            role_id: value.recordsets[0][0].uroleid,
            sub_role: val1,
            activity: val
          }
          resolve(result);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.get_rights_details_for_user = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let val1 = [];
      let val2 = [];
      let result = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IRS].[Getactivitiesbasedonuser]', parameters, db_library.query_type.SP).then((value) => {
          value.recordsets[0].forEach(element => {
            val.push({ "role_name": element.rolename, "role_id": element.uroleid });
          });
          value.recordsets[1].forEach(element => {
            val1.push({ "sub_role_name": element.subrole, "sub_role_id": element.subroleid, "role_id": element.RoleID });
          });
          value.recordsets[2].forEach(element => {
            val2.push({ "activity_id": element.activityid, "activity_name": element.atyname });
          });
          result = {
            "role": val,
            "subrole": val1,
            "activities": val2
          }
          resolve(result);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.get_activities_based_on_role = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let val1 = [];
      let result = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IRS].[Getactivitiesbasedonrole]', parameters, db_library.query_type.SP).then((value) => {
          value.recordsets[0].forEach(element => {
            val.push({ "role_name": element.rolename, "role_id": element.uroleid, "activity_id": element.activityid, "activity_name": element.atyname });
          });
          value.recordsets[1].forEach(element => {
            val1.push({ "sub_role_name": element.subrole, "sub_role_id": element.subroleid, "activity_id": element.activityid, "activity_name": element.atyname, "role_id": element.RoleID });
          });
          result = {
            "activity_on_role": val,
            "activity_on_Subrole": val1
          }
          resolve(result);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.user_list = async function (data) {
  return await new Promise(async (resolve, reject) => {
    try {
      let user_id = data;
      let parameters = [];
      let para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      await db_library
        .execute('[IPS].[GetUserList]', parameters, db_library.query_type.SP).then((value) => {
          var UserList = [];
          if (value.recordsets[0].length == 0) { reject('User details not received from db') }
          value.recordsets[0].forEach((element, index, arr) => {
            UserList.push({ "user_name": element.UserName, "user_id": element.UserID, "is_internal": element.isInternalUser });

            if (arr.length - 1 == index) {
              resolve(UserList);
            }
          });
        });
    }
    catch (err) {
      reject(err);
    }
  });
}

exports.update_user_rights = async function (data) {
  //
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val="";
      if (data.activity) {
        data.activity_count = data.activity.length;
      }
      if (data.sub_role) {
        data.sub_role_count = data.sub_role.length;
      }
      let para = new param('JsonValue', sqlType.NVarChar, JSON.stringify(data));
      parameters.push(para);
      db_library
        .execute('[IRS].[AddEditUserRights]', parameters, db_library.query_type.SP).then((value) => {
          val = value.recordset[0].UserID;
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.update_user_access = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let updater_id = data.updater_id;
      let user_id = data.user_id;
      let role_id = data.role_id;
      let sub_role = data.sub_role;
      let activity = data.activity;

      let para = new param('UpdaterID', sqlType.Int, updater_id);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('RoleID', sqlType.Int, role_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[AddeditUserRole]', parameters, db_library.query_type.SP).then((value) => {
          val = value.recordset[0].UserID;
          if (sub_role) {
            var subroles = "";
            sub_role.forEach(element => {
              parameters = [];
              para = new param('UpdaterID', sqlType.Int, updater_id);
              parameters.push(para);
              para = new param('UserID', sqlType.Int, user_id);
              parameters.push(para);
              para = new param('SubRoleID', sqlType.Int, element.sub_role_id);
              parameters.push(para);
              subroles += (element.sub_role_id + ",")
              db_library
                .execute('[IRS].[AddEditSubRole]', parameters, db_library.query_type.SP).then((value) => {
                  val = value.recordset[0].UserID;
                }).catch((error) => {
                  reject(error);
                });
            });
            let paras = [];
            para = new param('SubRoleIDS', sqlType.VarChar, subroles + "0");
            paras.push(para);
            para = new param('UpdaterID', sqlType.Int, updater_id);
            paras.push(para);
            para = new param('UserID', sqlType.Int, user_id);
            paras.push(para);
            db_library
              .execute('[IRS].[DisableOtherSubRole]', paras, db_library.query_type.SP).then((value) => {
                val = value.recordset[0].UserID;
                resolve({ "user_id": val });
              }).catch((error) => {
                reject(error);
              });
          }
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

exports.create_external_user = async function (updater_id, user_email, user_name) {
  return await new Promise(async (resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('UserCode', sqlType.VarChar, user_email);
      parameters.push(para);
      para = new param('UserFName', sqlType.NVarChar, user_name);
      parameters.push(para);
      para = new param('UserEmailID', sqlType.NVarChar, user_email);
      parameters.push(para);
      para = new param('UpdatedBy', sqlType.Int, updater_id);
      parameters.push(para);
      para = new param('isInternalUser', sqlType.Bit, false);
      parameters.push(para);
      para = new param('OrgID', sqlType.Int, 0);
      parameters.push(para);
      para = new param('OrgDivID', sqlType.Int, 0);
      parameters.push(para);
      await db_library
        .execute('[IPS].[AddEditUser]', parameters, db_library.query_type.SP).then((value) => {
          resolve("Inserted Successfully");
        }).catch(
          err => {
            throw err;
          });
    }
    catch (err) {
      reject(err);
    }
  });
}
