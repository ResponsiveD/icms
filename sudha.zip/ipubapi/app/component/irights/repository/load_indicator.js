"use strict";
var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');

exports.load_indicator = async function (start, end, user_id) {
  return new Promise(async (resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime, new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetLoadIndicator]', parameters, db_library.query_type.SP).then((value) => {
          let result = {
            "count": value.recordsets[0],
            "value": value.recordsets[1]
          }
          resolve(result);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error)
    }
  });
}

// exports.load_indicator1 = (start, end, user_id) => {
//   let data = {
//     sections: [{
//         key: 1,
//         label: "James Smith"
//       },
//       {
//         label: "David",
//         key: 2
//       },
//       {
//         key: 3,
//         label: "David Miller"
//       },
//       {
//         key: 4,
//         label: "Linda Brown"
//       }
//     ],

//     schedulerData: [
//       // {
//       //   end_date: "2018-11-09T05:30:00.000Z",
//       //   resource_id: 2,
//       //   start_date: "2018-11-08T05:30:00.000Z",
//       //   total_task: 10
//       // },
//       {
//         start_date: "2018-05-28 00:00",
//         end_date: "2018-05-28 24:00",
//         text: "8 Spec",
//         resource_id: 1,
//         // subject: 'normal'
//       },
//       {
//         start_date: "2018-05-28 00:00",
//         end_date: "2018-05-28 24:00",
//         text: "8 Spec",
//         resource_id: 2,
//         // subject: 'normal'
//       },
//       {
//         start_date: "2018-05-28 00:00",
//         end_date: "2018-05-28 24:00",
//         text: "8 Spec",
//         resource_id: 3,
//         // subject: 'normal'
//       },
//       {
//         start_date: "2018-05-28 00:00",
//         end_date: "2018-05-28 24:00",
//         text: "8 Spec",
//         resource_id: 4,
//         // subject: 'normal'
//       },
//       {
//         start_date: "2018-05-29 00:00",
//         end_date: "2018-05-29 24:00",
//         text: "8 Spec",
//         resource_id: 4,
//         // subject: 'normal'
//       },
//       // {
//       //   start_date: "2018-05-28 00:00",
//       //   end_date: "2018-05-28 24:00",
//       //   text: "8 Spec",
//       //   user_id: 5,
//       //   subject: 'normal'
//       // },
//       // // {
//       // //   start_date: "2018-05-28 00:00",
//       // //   end_date: "2018-05-28 24:00",
//       // //   text: "15 Spec",
//       // //   user_id: 6,
//       // //   subject: 'load'
//       // // },
//       // // {
//       // //   start_date: "2018-05-29 00:00",
//       // //   end_date: "2018-05-29 24:00",
//       // //   text: "15 Spec",
//       // //   user_id: 6,
//       // //   subject: 'load'
//       // // },
//       // // {
//       // //   start_date: "2018-05-28 00:00",
//       // //   end_date: "2018-05-28 24:00",
//       // //   text: "8 Spec",
//       // //   user_id: 7,
//       // //   subject: 'normal'
//       // // },
//       // // {
//       // //   start_date: "2018-05-28 00:00",
//       // //   end_date: "2018-05-28 24:00",
//       // //   text: "8 Spec",
//       // //   user_id: 8,
//       // //   subject: 'normal'
//       // // },
//       // // {
//       // //   start_date: "2018-05-28 00:00",
//       // //   end_date: "2018-05-28 24:00",
//       // //   text: "8 Spec",
//       // //   user_id: 9,
//       // //   subject: 'normal'
//       // // },
//       // // {
//       // //   start_date: "2018-05-28 00:00",
//       // //   end_date: "2018-05-28 24:00",
//       // //   text: "20 Spec",
//       // //   user_id: 10,
//       // //   subject: 'delay'
//       // // },
//       // // {
//       // //   start_date: "2018-05-28 00:00",
//       // //   end_date: "2018-05-28 24:00",
//       // //   text: "8 Spec",
//       // //   user_id: 11,
//       // //   subject: 'adjustment'
//       // // },
//       // // {
//       // //   start_date: "2018-05-28 00:00",
//       // //   end_date: "2018-05-28 24:00",
//       // //   text: "8 Spec",
//       // //   user_id: 12,
//       // //   subject: 'adjustment'
//       // // }
//     ]
//   };
//   return data;
// }