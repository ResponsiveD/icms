"use strict";

const db_library = require('../../../../config/lib/db_library')

exports.attachment_type_clearance = async function () {
    return await new Promise(async (resolve, reject) => {
      try {
        db_library
          .execute('[IRS].[AttachmentType]',undefined,  db_library.query_type.SP).then((value) => {
            resolve(value.recordsets[0]);
          }).catch(err => reject(err));
      } catch (error) {
        reject(error);
  
      }
    });
  }