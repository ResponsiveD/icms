const output = require("../models/output");
const db_library = require('../../../../config/lib/db_library');
const param = require('../models/parameter_input');
const sqlType = require('mssql');

exports.add_or_edit_elemeent_log = async function (data, user) {
  try {
    data["selection_count"] = data.selections_details.length;
    data["user_id"] = user.UserID;

    let parameters = [];
    let json_value = JSON.stringify(data);
    parameters.push(new param('JsonValue', sqlType.NVarChar, json_value));

    let result = await db_library.execute_await("[IRS].[AddEditeElementLog]", parameters, db_library.query_type.SP);

    if (result.recordsets.length > 0) {
      return result.recordsets[0][0]
    } else {
      return false
    }
  } catch (error) {
    throw error
  }
}

exports.elementtype = async function (data, user) {
  try {

    let result = await db_library.execute_await("[IRS].[getElementType]", undefined, db_library.query_type.SP);
    if (result.recordsets.length > 0) {
      return result.recordsets[0]
    } else {
      return false
    }
  } catch (error) {
    throw error
  }
}


exports.specifiedas = async function (data, user) {
  try {
    let result = await db_library.execute_await("[IRS].[getSpecifiedAS]", undefined, db_library.query_type.SP);
    if (result.recordsets.length > 0) {
      return result.recordsets[0]
    } else {
      return false
    }
  } catch (error) {
    throw error
  }
}


exports.usage = async function (data, user) {
  try {
    let result = await db_library.execute_await("[IRS].[getUsage]", undefined, db_library.query_type.SP);
    if (result.recordsets.length > 0) {
      return result.recordsets[0]
    } else {
      return false
    }
  } catch (error) {
    throw error
  }
}


exports.elemrights = async function (data, user) {
  try {
    let result = await db_library.execute_await("[IRS].[getElemRights]", undefined, db_library.query_type.SP);
    if (result.recordsets.length > 0) {
      return result.recordsets[0]
    } else {
      return false
    }
  } catch (error) {
    throw error
  }
}

exports.add_or_edit_task_creation = async function (data, user) {
  try {

    data["task_count"] = data.task_details.length;
    data["user_id"] = user.UserID;

    let parameters = [];
    let json_value = JSON.stringify(data);
    parameters.push(new param('JsonValue', sqlType.NVarChar, json_value));

    let result = await db_library.execute_await("[IRS].[AddEditeTask]", parameters, db_library.query_type.SP);

    if (result.recordsets.length > 0) {
      return result.recordsets[0][0]
    } else {
      return false
    }
  } catch (error) {
    throw error
  }
}