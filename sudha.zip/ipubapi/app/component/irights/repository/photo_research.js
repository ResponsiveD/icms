"use strict";

const get_spec_list = require("../../irights/data/get_specfor_chapter.json");
const spec_details = require("../../irights/data/get_spec_details.json");
const get_spec_clearance_details = require("../../irights/data/get_spec_clearance_details.json");

const update_spec_dtls = require("../../irights/data/update_spec_details.json");
const update_details = require("../../irights/data/update_asset_details.json");

const task_list_for_activity_repo = require("./task_list_for_activity");
const activity_ids = require("../helpers/activity_ids");
var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');

exports.get_spec_list = async (user_id, activity_id, chapter_id, customer_reviewer = 0, is_clearance = 0) => {
  return await new Promise(async (resolve, reject) => {
    try {
      await task_list_for_activity_repo.activity_task_list(user_id, activity_id, chapter_id, customer_reviewer, undefined, is_clearance).then((value) => {
        resolve(value);
      }).catch(err => reject(err));
    } catch (error) {
      reject(error);
    }
  });
}

exports.put_select_approve_reject = async function (data) {
  //
  return await new Promise(async (resolve, reject) => {
    try {
      data.total_records = data.selected_image_ids.length;
      let parameters = [];
      let para = new param('JsonValue', sqlType.NVarChar, JSON.stringify(data));
      parameters.push(para);
      db_library
        .execute('[IRS].[SpecAproveORReject]', parameters, db_library.query_type.SP).then((value) => {
          resolve(true);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error)
    }
  });
}

exports.get_spec_details_export = async function (task_id, proj_ser_id, task_record_id, activity_id) {
  return await new Promise(async (resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('TaskID', sqlType.Int, task_id);
      parameters.push(para);
      para = new param('ProjSerID', sqlType.Int, proj_ser_id);
      parameters.push(para);
      para = new param('TaksRdID', sqlType.Int, task_record_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, activity_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetSpecFullDetailsExport]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0]);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error)
    }
  });
};

exports.get_clearance_spec_export = async function (task_id, proj_ser_id, task_record_id) {
  return await new Promise(async (resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('TaskID', sqlType.Int, task_id);
      parameters.push(para);
      para = new param('ProjSerID', sqlType.Int, proj_ser_id);
      parameters.push(para);
      para = new param('TaksRdID', sqlType.Int, task_record_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetClearanceSpecDetailsExport]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0]);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error)
    }
  });
};

exports.get_spec_details = async function (task_id, proj_ser_id, task_record_id) {
  return await new Promise(async (resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('TaskID', sqlType.Int, task_id);
      parameters.push(para);
      para = new param('ProjSerID', sqlType.Int, proj_ser_id);
      parameters.push(para);
      para = new param('TaksRdID', sqlType.Int, task_record_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetSpecFullDetails]', parameters, db_library.query_type.SP).then((value) => {
          var _ = require('lodash');
          var results = value.recordsets[0][0];
          if (results) {
            results.chapter_file = value.recordsets[1];
            results.activity_id = activity_ids.PhotoResearch;
            if (value.recordsets[2].length > 0) {
              results.uploaded_asset = value.recordsets[2];
              results.uploaded_asset.forEach(c => {
                let rhs = _.filter(value.recordsets[3], ['unique_id', c.unique_id]);
                if (rhs.length > 0) {
                  //c.keywords = rhs[0].keywords
                  c.rights_holder_details = rhs;
                }
                else {
                  c.rights_holder_details = [];
                  // c.keywords ="";
                }
              });
            }
            else {
              results.uploaded_asset = [];
            }
          }
          resolve(results);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error)
    }
  });
};


exports.get_spec_clearance_details = function (project_id) {
  try {
    return get_spec_clearance_details;
  } catch (error) {
    throw error;
  }
};


exports.update_spec_details = async function (data) {
  return await new Promise(async (resolve, reject) => {
    try {
      let parameters = [];
      data.spec.task_id = data.task_id;
      data.spec.chapter_id = data.chapter_id;
      data.spec.proj_ser_id = data.proj_ser_id;
      data.spec.user_id = data.user_id;
      let para = new param('JsonValue', sqlType.NVarChar, JSON.stringify(data.spec));
      parameters.push(para);
      db_library
        .execute('[IRS].[AddEditSpecDetails]', parameters, db_library.query_type.SP).then((value) => {
          var result = value.recordsets[0];
          result.forEach(element => {
            var _ = require("lodash");
            element.rights_holder_details = _.filter(value.recordsets[1], ['image_id', element.image_id])
            // if (element.rights_holder_details.length > 0) {
            //   element.keywords = element.rights_holder_details[0].keywords
            // }
          })
          resolve(result[0]);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error);

    }
  });
};

exports.get_image_type = async function (data) {
  return await new Promise(async (resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetImageType]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0]);
        }).catch(err => {
          reject(err);
        });
    } catch (error) {
      reject(error);

    }
  });
}


exports.get_image_src = async function (data) {
  return await new Promise(async (resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetImgSrcID]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0]);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error);

    }
  });
}


exports.get_rights_type = async function (data) {
  return await new Promise(async (resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetRightsType]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0]);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error);

    }
  });
}

exports.get_model_release = async function () {
  return await new Promise(async (resolve, reject) => {
    try {
      db_library
        .execute('[IRS].[GetModelRelease]', undefined, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0]);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error);

    }
  });
}

exports.get_property_release = async function () {
  return await new Promise(async (resolve, reject) => {
    try {
      db_library
        .execute('[IRS].[GetPropertyRelease]', undefined, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0]);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error);

    }
  });
}

exports.add_rights_req = async function () {
  return await new Promise(async (resolve, reject) => {
    try {
      db_library
        .execute('[IRS].[GetAddRightsReq]', undefined, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0]);
        }).catch(err => reject(err));
    } catch (error) {
      reject(error);
    }
  });
}
