'use strict'
//added by Nisar
const get_text_pending_task_data = require("../data/get_text_for_task.json");
const get_text_pending_task_details_data = require("../data/get_text_for_task_details.json");
const task_list_for_activity_repo = require("./task_list_for_activity");

exports.text_pending_task =async function (user_id, activity_id, chapter_id) {
    return await new Promise(async (resolve, reject) => {
        try {
          await task_list_for_activity_repo.activity_task_list(user_id, activity_id, chapter_id,undefined,is_spec).then((value) => {
            resolve(value);
          }).catch(err => reject(err));
        } catch (error) {
          reject(error);
        }
      });
}

exports.text_pending_task_details = function (data) {
    try {
        return get_text_pending_task_details_data;
    } catch (error) {
        throw data;
    }
}