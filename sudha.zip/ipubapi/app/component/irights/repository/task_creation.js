"use strict";
// =============================================
// Author:		  Velmurugan P
// Create date: 23/07/2018
// Modified:    Saktivel P
// Description:	Task creation repository
// =============================================
const chapter_details = require("../../irights/data/get_chapter.json");
const selection_details = require("../../irights/data/get_selection_details.json");
var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');
//get_chapters
exports.get_project_guid = async (project_id) => {
  return await new Promise((resolve, reject) => {
    let parameters = [];
    let para = new param('ProjectID', sqlType.Int, project_id);
    parameters.push(para);
    db_library
      .execute('[IRS].[GetProjectGUID]', parameters, db_library.query_type.SP).then((value) => {
        resolve(value.recordsets[0][0].ProjectGUID);
      }).catch(err => reject(err));
  });
}
exports.get_all_chapters = async function (project_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('IRSProjID', sqlType.Int, project_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetProjectTaskDetails]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.get_all_wip_chapters = async function (project_id,user_id,activity_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('IRSProjID', sqlType.Int, project_id);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, activity_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetProjectWIPChapters]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

exports.get_chapters = async function (project_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('IRSProjID', sqlType.Int, project_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetProjectTasks]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.get_task_chapters = async function (chapter_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('ChapterID', sqlType.Int, chapter_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetProjectTaskChapterDetail]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.get_chapter = function (params) {
  try {
    //let chapter_details = all_chapters.find(chapter_id == param_chapter_id);
    return chapter_details;
  } catch (error) {
    throw error;
  }
};

exports.get_selection = function (params) {
  try {
    return selection_details;
  } catch (error) {
    throw error;
  }
};
async function chapdocupdate(element, chapter_id, user_id) {
  return await new Promise((resolve, reject) => {
    let parameters = [];
    let para = new param('FileID', sqlType.Int, element.file_id);
    parameters.push(para);
    para = new param('ChapterID', sqlType.Int, chapter_id);
    parameters.push(para);
    para = new param('FileName', sqlType.NVarChar, element.file_name);
    parameters.push(para);
    para = new param('FilePath', sqlType.NVarChar, element.file_url);
    parameters.push(para);
    para = new param('isActive', sqlType.Bit, element.is_active);
    parameters.push(para);
    para = new param('UpdatedBy', sqlType.Int, user_id);
    parameters.push(para);
    db_library.execute('[IRS].[AddEditChapterAttach]', parameters, db_library.query_type.SP).then((value) => {
      element.file_id = value.recordsets[0][0].FileID;
      resolve(element);
    }).catch((err) => {
      reject(err);
    });
  });
}
// async function TaskRecordDetail(TaskID, ProjSerID,UserID) {
//   return await new Promise((resolve, reject) => {
//     let parameters = [];
//     let para = new param('TaskID', sqlType.Int, TaskID);
//     parameters.push(para);
//     para = new param('ProjSerID', sqlType.Int, ProjSerID);
//     parameters.push(para);
//     para = new param('UserID', sqlType.NVarChar, UserID);
//     parameters.push(para);
//     db_library.execute('[IRS].[AddTaskRecordDetails]', parameters, db_library.query_type.SP).then((value) => {
//       resolve(true);
//     }).catch((err) => {
//       reject(err);
//     });
//   });
// }
//
async function chapdocloop(arr, chapter_id, user_id) {
  return await new Promise(async (resolve, reject) => {
    try {
      if (arr.length == 0) { resolve(arr); }
      else {
        arr.forEach(async (element, index, arrray) => {
          element = await chapdocupdate(element, chapter_id, user_id);
          if (arr.length - 1 == index) {
            resolve(arr)
          }
        });
      }
    }
    catch (err) {
      reject(err);
    }
  });
}
function taskupdate(element, chapter_id, user_id, project_id, proj_ser_id, total_page) {
  return new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('IRSProjID', sqlType.Int, project_id);
      parameters.push(para);
      para = new param('ProjSerID', sqlType.Int, proj_ser_id);
      parameters.push(para);
      para = new param('TLCommands', sqlType.NVarChar, element.tl_commands);
      parameters.push(para);
      para = new param('ChapterID', sqlType.Int, chapter_id);
      parameters.push(para);
      para = new param('statusID', sqlType.Int, 6);//element.status_id);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('isActive', sqlType.Bit, element.is_active);
      parameters.push(para);
      para = new param('SID', sqlType.Int, element.s_id || 0);
      parameters.push(para);
      para = new param('SpecID', sqlType.Int, element.spec_id || 0);
      parameters.push(para);
      para = new param('SpecDesc', sqlType.NVarChar, element.spec_desc || '');
      parameters.push(para);
      para = new param('PageNo', sqlType.Int, element.page_no || 0);
      parameters.push(para);
      para = new param('SpecStatusID', sqlType.Int, element.status_id || 1);
      parameters.push(para);
      para = new param('PhotoID', sqlType.NVarChar, element.photo_id);
      parameters.push(para);
      para = new param('TaskID', sqlType.Int, element.task_id || 0);
      parameters.push(para);
      para = new param('TaskGUID', sqlType.NVarChar, element.task_guid || '');
      parameters.push(para);
      para = new param('TotalPage', sqlType.Int, total_page || 0);
      parameters.push(para);
      para = new param('NoSource', sqlType.Int, element.no_source || 0);
      parameters.push(para);
      para = new param('NoSourceComments', sqlType.NVarChar, element.no_source_commets || 0);
      parameters.push(para);
      db_library
        .execute('[IRS].[AddEditSpecTask]', parameters, db_library.query_type.SP).then(async (value) => {
          // if(element.task_id !=0){
          //   var rslt = await TaskRecordDetail( element.task_id,proj_ser_id,user_id).catch(err=>{});
          // }
          element.task_id = value.recordsets[0][0].TaskID;
          element.s_id = value.recordsets[0][0].SID;
          resolve(element);
        }).catch((error) => {
          reject(error);
        });
    }
    catch (err) {
      reject(err);
    }
  });
}
async function chapTaskloop(arr, chapter_id, user_id, project_id, proj_ser_id, total_page) {
  return await new Promise(async (resolve, reject) => {
    try {
      if (arr.length == 0) { resolve(arr); }
      else {
        arr.forEach(async (element, index, arrray) => {
          await taskupdate(element, chapter_id, user_id, project_id, proj_ser_id, total_page).then(value => {
            element = value;
            if (arr.length - 1 == index) {
              resolve(arr);
            }
          }).catch(error => {
            reject(error.message)
          });
        });
      }
    }
    catch (err) {
      reject(err);
    }
  });
}
async function chaploop(arr, proj_ser_id, project_id, user_id) {
  return await new Promise(async (resolve, reject) => {
    try {
      let a =0;
      if (arr.length == 0) { resolve(arr); }
      else {
        arr.forEach(async (element, index, arrray) => {
          var total_page = element.total_page;
          await chapdocloop(element.chapter_docs, element.chapter_id, user_id).then(value=>{
            element.chapter_docs = value;
          })
          await chapTaskloop(element.task_details, element.chapter_id, user_id, project_id, proj_ser_id, total_page).then(value => {
            element.task_details = value;
            a=a+1;
            if (arr.length - 1 == a) {
              resolve(arrray);
            }
          }).catch(error => {
            reject(error)
          })
        })
      }
    } catch (error) {
      reject(error);
    }
  });
}
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
exports.update_task = async function (service) {
  return new Promise(async (resolve, reject) => {
    try {
      if (service.service_details.length == 0) { resolve(service); }
      else {
        let a =0
        service.service_details.forEach(async (element, ind, arr) => {
          if (element.chapter_details) {
            await chaploop(element.chapter_details, element.proj_ser_id, service.project_id, service.user_id).then(async value => {
              element.chapter_details = value;
              a=a+1;
              if (a == service.service_details.length-1){
                resolve(service);
              }
            }).catch(error=>{
              reject(error);
            })
          }
        });
      }
    } catch (error) {
      reject(error);
    }
  });
};
exports.update_task_new = async function (input) {
  return new Promise(async (resolve, reject) => {
    try {
      input.service_details_count = input.service_details.length;
      input.service_details.forEach(elemnet=>{
        elemnet.chapter_details_count = elemnet.chapter_details.length
        elemnet.chapter_details.forEach(ele=>{
          ele.chapter_docs_count = ele.chapter_docs.length;
          ele.task_details_count =ele.task_details.length
        })
      });
      let parameters = [];
      let para = new param('JsonValue', sqlType.NVarChar, JSON.stringify(input));
      parameters.push(para);
      db_library
        .execute('[IRS].[AddEditTaskCreation]', parameters, db_library.query_type.SP).then((value) => {
          resolve(true);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.AddEdit_rights_holder = async function (right_holder) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('JsonData', sqlType.NVarChar, right_holder);
      parameters.push(para);
      db_library
        .execute('[IRS].[AddEditRightsHolder]', parameters, db_library.query_type.SP).then((value) => {
          var RtsID = value.recordset[0].RtsID;
          resolve(RtsID);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.get_rights_holder_details = async function (rights_holder_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('RtsID', sqlType.Int, rights_holder_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[getRightsHolderDetails]', parameters, db_library.query_type.SP).then((value) => {
          var result = value.recordsets[0][0];
          resolve(result);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};
exports.update_chapter_page = async function (chapter_id, total_page, user_id,Flag) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('ChapterID', sqlType.Int, chapter_id);
      parameters.push(para);
      para = new param('TotalPage', sqlType.Int, total_page);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, Flag);
      parameters.push(para);
      db_library
        .execute('[IRS].[UpdateChapterPageNo]', parameters, db_library.query_type.SP).then((value) => {
          var result = true;
          resolve(result);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

exports.map_rights_holder_to_task = async function (rights_holder_id, user_id, unique_id, keywords) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('RstID', sqlType.Int, rights_holder_id);
      parameters.push(para);
      para = new param('UniqueID', sqlType.NVarChar, unique_id);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Keywords', sqlType.NVarChar, keywords);
      parameters.push(para);
      db_library
        .execute('[IRS].[MapRightsHolderToTask]', parameters, db_library.query_type.SP).then((value) => {
          var result = value.recordsets[0][0];
          resolve(result);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

exports.get_rights_holders = async function (user_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[getRightsHolder]', parameters, db_library.query_type.SP).then((value) => {
          var result = value.recordsets[0];
          resolve(result);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

exports.delete_rights_holders = async function (rights_holder_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('rights_holder_id', sqlType.Int, rights_holder_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[DeleteRightsHolder]', parameters, db_library.query_type.SP).then((value) => {
          var result = true;
          resolve(result);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

exports.inactive_rights_holders = async function (rights_holder_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('rights_holder_id', sqlType.Int, rights_holder_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[inActiveRightsHolder]', parameters, db_library.query_type.SP).then((value) => {
          var result = true;
          resolve(result);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
};

