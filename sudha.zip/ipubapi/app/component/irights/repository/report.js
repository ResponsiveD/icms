"use strict";
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input'); 
const project_basic_details = require('../models/project_basic_details'); 

var sqlType = require('mssql');

 
exports.get_project_list_for_page_review = async function (user_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para); 
     
      db_library
        .execute("[IRS].[GetPageReviewProjectList]", parameters, db_library.query_type.SP).then((value) => {
          value.recordsets[0].forEach(element => {
            var _project_basic_details = new project_basic_details();
            _project_basic_details.created_on = element.CreatedDate;
            _project_basic_details.customer = element.CustomerName;
            _project_basic_details.project_id = element.ProjectID;
            _project_basic_details.closing_date = element.ProjectClosingDate;
            _project_basic_details.project_title = element.ProjectTitle;
            _project_basic_details.project_code = element.ProjectCode;
            _project_basic_details.Status = element.Status;
            _project_basic_details.StatusID = element.StatusID;
            _project_basic_details.is_ext_approve = element.IsExtApprove;
            val.push(_project_basic_details);
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.get_project_page_review = async function (project_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('IRSProjID', sqlType.Int, project_id);
      parameters.push(para); 
     
      db_library
        .execute("[IRS].[GetProjectPageReview]", parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0]);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.update_page_review = async (data) => {
  return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
      parameters.push(para);
      db_library
          .execute('[IRS].[AddEditPageReview]', parameters, db_library.query_type.SP).then((value) => {
              var results = value.recordsets[0];
              resolve(results);
          }).catch(err => {
              reject(err)
          });
  });
}

exports.get_project_list_for_admin = async function (user_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para); 
     
      db_library
        .execute("[IRS].[GetAdminProjectList]", parameters, db_library.query_type.SP).then((value) => {
          value.recordsets[0].forEach(element => {
            var _project_basic_details = new project_basic_details();
            _project_basic_details.created_on = element.CreatedDate;
            _project_basic_details.customer = element.CustomerName;
            _project_basic_details.project_id = element.ProjectID;
            _project_basic_details.closing_date = element.ProjectClosingDate;
            _project_basic_details.project_title = element.ProjectTitle;
            _project_basic_details.project_code = element.ProjectCode;
            _project_basic_details.Status = element.Status;
            _project_basic_details.StatusID = element.StatusID;
            _project_basic_details.is_ext_approve = element.IsExtApprove;
            val.push(_project_basic_details);
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.get_project_admin = async function (project_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('IRSProjID', sqlType.Int, project_id);
      parameters.push(para); 
     
      db_library
        .execute("[IRS].[GetProjectAdmin]", parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0]);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}
