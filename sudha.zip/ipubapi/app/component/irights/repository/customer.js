'use strict'

const customer_review_data = require("../data/get_spec_details.json");
exports.customer_selection = function (data) {
    try {
        return [{
            "project_id": "1",
            "chapter_id": "1",
            "spec_id": "1"
        }];
    } catch (error) {
        throw error;
    }
}

exports.customer_approval = function (data) {
    try {
        return [{
            "project_id": "1",
            "chapter_id": "1",
            "spec_id": "1"
        }];
    } catch (error) {
        throw error;
    }
}

exports.customer_review = function (data) {
    try {
        return customer_review_data;
    } catch (error) {
        throw error;
    }
}