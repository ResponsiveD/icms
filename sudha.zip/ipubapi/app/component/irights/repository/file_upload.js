'user strict'

const azure = require('azure');
let Duplex = require('stream').Duplex;
var path = require('path')
const file_upload_config = require('../../../../config/file_upload_config');
const _mailer = require("../../../helpers/mailer");
const accessKey = file_upload_config.CloudCredentials().accessKey;
const storageAccount = file_upload_config.CloudCredentials().storageAccount;
const containerName = file_upload_config.CloudCredentials().containerName;
const basepath = file_upload_config.CloudCredentials().cloudBasePath;
const getcompid = require('../../../../config/constant/components.json');

var blobService = azure.createBlobService(storageAccount, accessKey);

exports.guid = function () {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return (s4() + s4());
}
async function bufferToStream(buffer) {
    return await new Promise((resolve, reject) => {
        try {
            let stream = new Duplex();
            stream.push(buffer);
            stream.push(null);
            resolve(stream);
        } catch (err) { reject(err); }
    });
}
BlobUpload = async (Path, data, length) => {
    return await new Promise(async(resolve, reject) => {
        var datas = await bufferToStream(data);
        blobService.createBlockBlobFromStream(
            containerName,
            Path,
            datas,
            length,
            function (error) {
                if (error) {
                    reject(error);
                } else {
                    resolve(Path);
                }
            }
        )
    });
};
exports.UploadFile = async function (req, Path,allowedType = file_upload_config.ALLOWEDTYPE.ALL) {
    return new Promise(async (resolve, reject) => {
        try {
            let file = req.files["file"];
            // var CheckMimeType = file_upload_config.AllowedFileType.indexOf(req.files.file.mimetype);
            // var CheckExtension = file_upload_config.AllowedFileExtension.indexOf(path.extname(req.files.file.name));
            var CheckMimeType = null;
            var CheckExtension = null;
            switch (allowedType) {
                case file_upload_config.ALLOWEDTYPE.ALL:
                    CheckMimeType = file_upload_config.AllowedFileType.indexOf(req.files.file.mimetype);
                    CheckExtension = file_upload_config.AllowedFileExtension.indexOf(path.extname(req.files.file.name));
                    break;
                case file_upload_config.ALLOWEDTYPE.EMAIL:
                    CheckMimeType = file_upload_config.AllowedMailType.indexOf(req.files.file.mimetype);
                    CheckExtension = file_upload_config.AllowedMailExtension.indexOf(path.extname(req.files.file.name));
                    break;
            }
            if (CheckMimeType == -1 || CheckExtension == -1) {
                let activity_actions_repo = require("../repository/activity_actions");
                let extn = req.files.file.name.slice(req.files.file.name.lastIndexOf(".") + 1, req.files.file.name.lastIndexOf(".").length)
                var options = await activity_actions_repo.get_mail_template(7,1);
                options.html = options.html.replace('##fileName##', req.files.file.name);
                options.html = options.html.replace('##fileExtension##', extn);
                options.html = options.html.replace('##fileformate##',req.files.file.mimetype);
                options.html = options.html.replace('##endpoint##', req.path);
                options.compid = getcompid.irights.compID;
                setTimeout(function(){ 
                    _mailer.sendMail(options); 
                }, 3000);
                switch (allowedType) {
                    case file_upload_config.ALLOWEDTYPE.ALL:
                        throw "Please upload only following file format: .jpeg,.jpg,.pdf,.png,.doc,.docx,.xls,.xlsx,.xlsb,.ppt,.pptx,.msg,postscript and ms office file format\'s";
                        break;
                    case file_upload_config.ALLOWEDTYPE.EMAIL:
                        throw "Please upload only following file format: .msg and .eml file format\'s";
                        break;
                }
            }
            await BlobUpload(Path, file.data, file.data.length).then(
                (Path) => {
                    resolve(basepath + Path);
                }).catch(
                    (err) => {
                        throw err;
                    });
        } catch (error) {
            reject(error);
        }
    });
}

exports.imageploadFile = async function (req, Path) {
    return new Promise(async (resolve, reject) => {
        try {
            let file = req.files["file"];
            var CheckMimeType = file_upload_config.AllowedImageFileType.indexOf(req.files.file.mimetype);
            var CheckExtension = file_upload_config.AllowedImageFileExtension.indexOf(path.extname(req.files.file.name));
            if (CheckMimeType == -1 || CheckExtension == -1) {
                let activity_actions_repo = require("../repository/activity_actions");
                let extn = req.files.file.name.slice(req.files.file.name.lastIndexOf(".") + 1, req.files.file.name.lastIndexOf(".").length)
                var options = await activity_actions_repo.get_mail_template(7,1);
                options.html = options.html.replace('##fileName##', req.files.file.name);
                options.html = options.html.replace('##fileExtension##', extn);
                options.html = options.html.replace('##fileformate##',req.files.file.mimetype);
                options.html = options.html.replace('##endpoint##', req.path);
                options.compid = getcompid.irights.compID;
                setTimeout(function(){ 
                    _mailer.sendMail(options); 
                }, 3000);
                throw "Please upload only following file format: .jpeg,.jpg, .png file format\'s";
            }
            await BlobUpload(Path, file.data, file.data.length).then(
                (Path) => {
                    resolve(basepath + Path);
                }).catch(
                    (err) => {
                        throw err;
                    });
        } catch (error) {
            reject(error);
        }
    });
}