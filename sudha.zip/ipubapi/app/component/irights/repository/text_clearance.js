'use strict'

const get_text_clearance_data = require("../data/get_text_clearance.json");
const update_text_clearance_data = require("../data/input_rights_holders_details.json");
exports.get_text_clearance = function (data) {
  try {
    return get_text_clearance_data;
  } catch (error) {
    throw error;
  }
};

exports.update_text_clearance = function (selection_details) {
  try {
    return update_text_clearance_data;
  } catch (error) {
    throw error;
  }
};