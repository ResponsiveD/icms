"use strict";

const sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');


exports.get_spec_details_export = async function (table_name, column_name, column_value) {
  try {
    let parameters = [];
    let para = new param('TableName', sqlType.NVarChar(500), table_name);
    parameters.push(para);
    para = new param('ColumnName', sqlType.NVarChar(500), column_name);
    parameters.push(para);
    para = new param('ColumnValue', sqlType.NVarChar(500), column_value);
    parameters.push(para);
    let result = await db_library.execute_await('[IRS].[getInputDetails]', parameters, db_library.query_type.SP);
    return result;
  } catch (error) {
    return { "code": 9999, "message": "There is error on occurred in database, Please contact administrator " }
  }
};