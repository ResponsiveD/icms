"use strict";
//const photo_qc = require("../../irights/data/photo_quality_check.json");

exports.photo_quality_check = function (project_id) {
    try {
        return {};
    } catch (error) {
        throw error;
    }
};