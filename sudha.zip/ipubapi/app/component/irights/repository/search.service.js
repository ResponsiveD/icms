var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');

exports.textSearch = async function (request) {
    try {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(request));
        parameters.push(para);
        return db_library.execute_await('[IRS].[searchtext]', parameters, db_library.query_type.SP);
    } catch (error) {
        return error
    }
}

exports.photoSearch = async function (request) {
    try {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar,JSON.stringify(request));
        parameters.push(para);
        return db_library.execute_await('[IRS].[searchimage]', parameters, db_library.query_type.SP);
    } catch (error) {
        return error
    }
}

exports.getSourceName = async function (req) {
    try {
        let parameters = [];
        let para = new param('sourceName', sqlType.NVarChar, req.query.name != undefined ? req.query.name : null);
        parameters.push(para);
        para = new param('UserID', sqlType.Int, req.User.UserID);
        parameters.push(para);
        para = new param('OrgID', sqlType.Int, req.User.OrgID);
        parameters.push(para);
        return db_library.execute_await('[IRS].[GetSourceName]', parameters, db_library.query_type.SP);
    } catch (error) {
        return error
    }
}

exports.getPhotographerName = async function (req) {
    try {
        let parameters = [];
        let para = new param('photographerName', sqlType.NVarChar, req.query.name != undefined ? req.query.name : null);
        parameters.push(para);
        para = new param('UserID', sqlType.Int, req.User.UserID);
        parameters.push(para);
        para = new param('OrgID', sqlType.Int, req.User.OrgID);
        parameters.push(para);
        return db_library.execute_await('[IRS].[GetPhotographerName]', parameters, db_library.query_type.SP);
    } catch (error) {
        return error
    }
}

