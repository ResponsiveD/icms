var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');

exports.get_task_status_for_user = async (atyid,start,end,user_id,flag) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('AtyID', sqlType.Int, atyid);
      parameters.push(para);
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, flag);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForUser]", parameters, db_library.query_type.SP).then((value) => {
          let results = value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_r = async (atyid,start,end,user_id,flag) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('AtyID', sqlType.Int, atyid);
      parameters.push(para);
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, flag);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForUserR]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status": value.recordsets[0],"values": value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_report_for_user_r = async (atyid,start,end,user_id,flag) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('AtyID', sqlType.Int, atyid);
      parameters.push(para);
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, flag);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusReportForUserR]", parameters, db_library.query_type.SP).then((value) => {
          let results  = value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_c = async (AtyID,start,end,user_id,flag,ServiceID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, flag);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForC]", parameters, db_library.query_type.SP).then((value) => {
          let results  = value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_report_c = async (AtyID,start,end,user_id,flag,ServiceID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, flag);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForC]", parameters, db_library.query_type.SP).then((value) => {
          let results  = value.recordsets[1];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_report_pl= async (AtyID,CustomerID,start,end,user_id,flag) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('CustomerID', sqlType.Int, CustomerID);
      parameters.push(para);
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, flag);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusReportForPL]", parameters, db_library.query_type.SP).then((value) => {
          let results  = value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_clearance_r = async (user_id,ServiceID,AtyID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForClearanceR]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status": value.recordsets[0],"values": value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_clearance_r_delay = async (user_id,ServiceID,AtyID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, 2);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForClearanceR]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status": value.recordsets[0],"values": value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_clearance_r_ontrack = async (user_id,ServiceID,AtyID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, 1);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForClearanceR]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status": value.recordsets[0],"values": value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_clearance_PL = async (CustomerID,user_id,ServiceID,AtyID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('CustomerID', sqlType.Int, CustomerID);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForClearancePL]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status": value.recordsets[0],"values": value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_clearance_PL_delay = async (CustomerID,user_id,ServiceID,AtyID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('CustomerID', sqlType.Int, CustomerID);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, 2);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForClearancePL]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status": value.recordsets[0],"values": value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_clearance_PL_ontrack = async (CustomerID,user_id,ServiceID,AtyID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('CustomerID', sqlType.Int, CustomerID);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, 1);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForClearancePL]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status": value.recordsets[0],"values": value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_pl = async (AtyID,CustomerID,start,end,user_id,ServiceID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('CustomerID', sqlType.Int, CustomerID);
      parameters.push(para);
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForPL]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status": value.recordsets[0],"values": value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_delay_pl = async (AtyID,CustomerID,start,end,user_id,ServiceID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('CustomerID', sqlType.Int, CustomerID);
      parameters.push(para);
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, 2);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForPL]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status": value.recordsets[0],"values": value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_status_for_user_ontrack_pl = async (AtyID,CustomerID,start,end,user_id,ServiceID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('CustomerID', sqlType.Int, CustomerID);
      parameters.push(para);
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, 1);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForPL]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status": value.recordsets[0],"values": value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_primary_task_status = async (start,end,user_id) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetPrimaryTaskStatusForUser]", parameters, db_library.query_type.SP).then((value) => {
          var results =value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_primary_task_status_pl = async (start,end,user_id) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetPrimaryTaskStatusForPL]", parameters, db_library.query_type.SP).then((value) => {
          var results =value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  
  exports.get_primary_task_status_c = async (start,end,user_id) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetPrimaryTaskStatusForC]", parameters, db_library.query_type.SP).then((value) => {
          var results =value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_primary_task_status_pl_delay = async (start,end,user_id) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetPrimaryTaskStatusForPLDelay]", parameters, db_library.query_type.SP).then((value) => {
          var results =value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_primary_task_status_pl_ontrack = async (start,end,user_id) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetPrimaryTaskStatusForPLOnTrack]", parameters, db_library.query_type.SP).then((value) => {
          var results =value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_primary_task_status_pr = async (start,end,user_id) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetPrimaryTaskStatusForUserPR]", parameters, db_library.query_type.SP).then((value) => {
          var results =value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }

  exports.get_primary_task_status_tr = async (start,end,user_id) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetPrimaryTaskStatusForUserTR]", parameters, db_library.query_type.SP).then((value) => {
          var results =value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }

  exports.get_task_clearance_status = async (start,end,user_id) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetClearanceDashboardData]", parameters, db_library.query_type.SP).then((value) => {
          var results =value.recordsets[0];
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }

  exports.get_task_clearance_status_tr = async (AtyID,start,end,user_id,CustomerID,Flag) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, Flag);
      parameters.push(para);
      para = new param('CustomerID', sqlType.Int, CustomerID);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetClearanceReportText]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status":value.recordsets[0],"values":value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
  exports.get_task_clearance_status_c_tr = async (user_id,Flag,ServiceID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, Flag);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetClearanceReportCustomerText]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status":value.recordsets[0],"values":value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }
exports.get_task_clearance_status_c_pr = async (user_id,Flag,ServiceID) => {
  return await new Promise((resolve, reject) => {
    let parameters = [];
   let para = new param('UserID', sqlType.Int, user_id);
    parameters.push(para);
    para = new param('Flag', sqlType.Int, Flag);
    parameters.push(para);
    para = new param('ServiceID', sqlType.Int, ServiceID);
    parameters.push(para);
    db_library
      .execute("[IRS].[GetClearanceReportCustomerPhoto]", parameters, db_library.query_type.SP).then((value) => {
        var results ={"status":value.recordsets[0],"values":value.recordsets[1]};
        resolve(results);
      }).catch(err => {
        reject(err)
      });
  });
}
  exports.get_task_clearance_status_pr = async (atyid,start,end,user_id,CustomerID,Flag) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      let para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, Flag);
      parameters.push(para);
      para = new param('CustomerID', sqlType.Int, CustomerID);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, atyid);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetClearanceReportPhoto]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status":value.recordsets[0],"values":value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }

  exports.get_task_status_for_user_customer_photo = async (AtyID,start,end,user_id,flag,ServiceID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, flag);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForCustomerPhoto]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status":value.recordsets[0],"values":value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }

  exports.get_task_status_for_user_customer_text = async (AtyID,start,end,user_id,flag,ServiceID) => {
    return await new Promise((resolve, reject) => {
      let parameters = [];
      para = new param('StartDate', sqlType.DateTime,new Date(start));
      parameters.push(para);
      para = new param('EndDate', sqlType.DateTime, new Date(end));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, AtyID);
      parameters.push(para);
      para = new param('Flag', sqlType.Int, flag);
      parameters.push(para);
      para = new param('ServiceID', sqlType.Int, ServiceID);
      parameters.push(para);
      db_library
        .execute("[IRS].[GetTaskStatusForCustomerText]", parameters, db_library.query_type.SP).then((value) => {
          var results ={"status":value.recordsets[0],"values":value.recordsets[1]};
          resolve(results);
        }).catch(err => {
          reject(err)
        });
    });
  }