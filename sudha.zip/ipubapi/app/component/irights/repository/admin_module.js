'use strict';
const param = require('../models/parameter_input');
var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');

exports.addedituser = async (JsonData) => {
	return await new Promise((resolve, reject) => {
		let parameters = [];
		let para = new param('JsonData', sqlType.NVarChar, JsonData);
		parameters.push(para);
		db_library
			.execute_await('[IPS].[AddEditUserConfig]', parameters, db_library.query_type.SP)
			.then((value) => {
				var UserCode = value.recordset[0];
				resolve(UserCode);
			})
			.catch((err) => {
				reject({ message: 'There is an error occured in database ' });
			});
	});
};

exports.addeditcustomer = async (JsonData) => {
	return await new Promise((resolve, reject) => {
		let parameters = [];
		let para = new param('JsonData', sqlType.NVarChar, JsonData);
		parameters.push(para);
		db_library
			.execute_await('[IPS].[AddEditCustomerConfig]', parameters, db_library.query_type.SP)
			.then((value) => {
				var UserCode = value.recordset[0];
				resolve(UserCode);
			})
			.catch((err) => {
				reject({ message: 'There is an error occured in database' });
			});
	});
};
exports.addeditservice = async (JsonData) => {
	return await new Promise((resolve, reject) => {
		let parameters = [];
		let para = new param('JsonData', sqlType.NVarChar, JsonData);
		parameters.push(para);
		db_library
			.execute_await('[IPS].[AddEditServiceWorkflowConfig]', parameters, db_library.query_type.SP)
			.then((value) => {
				var UserCode = value.recordset[0];
				resolve(UserCode);
			})
			.catch((err) => {
				reject({ message: 'There is an error occured in database ' });
			});
	});
};
exports.deleteservicedata = async (sername, compname, updatedby, isactive) => {
	return await new Promise((resolve, reject) => {
		let parameters = [];
		let para = new param('SerName', sqlType.NVarChar, sername);
		parameters.push(para);
		para = new param('CompName', sqlType.NVarChar, compname);
		parameters.push(para);
		para = new param('UpdatedBy', sqlType.NVarChar, updatedby);
		parameters.push(para);
		para = new param('isActive', sqlType.NVarChar, isactive);
		parameters.push(para);
		db_library
			.execute_await('[IPS].[DeleteServiceWorkflowConfig]', parameters, db_library.query_type.SP)
			.then((value) => {
				var UserCode = value.recordset[0];
				resolve(UserCode);
			})
			.catch((err) => {
				reject({ message: 'There is an error occured in database ' });
			});
	});
};
exports.deleteuserdata = async (usercode, orgname, orgdivname, updatedby, isactive) => {
	return await new Promise((resolve, reject) => {
		let parameters = [];
		let para = new param('UserCode', sqlType.NVarChar, usercode);
		parameters.push(para);
		para = new param('Orgname', sqlType.NVarChar, orgname);
		parameters.push(para);
		para = new param('OrgDivname', sqlType.NVarChar, orgdivname);
		parameters.push(para);
		para = new param('UpdatedBy', sqlType.NVarChar, updatedby);
		parameters.push(para);
		para = new param('isActive', sqlType.NVarChar, isactive);
		parameters.push(para);
		db_library
			.execute_await('[IPS].[DeleteUserDataConfig]', parameters, db_library.query_type.SP)
			.then((value) => {
				var UserCode = value.recordset[0];
				resolve(UserCode);
			})
			.catch((err) => {
				reject({ message: 'There is an error occured in database ' });
			});
	});
};
exports.deletecustomerdata = async (custname, updatedby, isactive) => {
	return await new Promise((resolve, reject) => {
		let parameters = [];
		let para = new param('CustName', sqlType.NVarChar, custname);
		parameters.push(para);
		para = new param('UpdatedBy', sqlType.NVarChar, updatedby);
		parameters.push(para);
		para = new param('isActive', sqlType.NVarChar, isactive);
		parameters.push(para);
		db_library
			.execute_await('[IPS].[DeleteCustomerDataConfig]', parameters, db_library.query_type.SP)
			.then((value) => {
				var UserCode = value.recordset[0];
				resolve(UserCode);
			})
			.catch((err) => {
				reject({ message: 'There is an error occured in database ' });
			});
	});
};
exports.getuserroletype = async function () {
	return await new Promise((resolve, reject) => {
		try {
			var val = [];
			db_library
				.execute_await('[IPS].[GetUserRoleIdTypeConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ RoleType: element.RoleName, id: element.URoleID });
					});
					resolve(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};

exports.getusersubroletype = async function () {
	return await new Promise((resolve, reject) => {
		try {
			var val = [];
			db_library
				.execute_await('[IPS].[GetUserSubRoleIdTypeConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ RoleType: element.SubRole, id: element.SubRoleID });
					});
					resolve(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};

exports.getuseratytype = async function () {
	return await new Promise((resolve, reject) => {
		try {
			var val = [];
			db_library
				.execute_await('[IPS].[GetUserAtyIdTypeConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ RoleType: element.AtyName, id: element.AtyID });
					});
					resolve(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};

exports.getusercusttype = async function () {
	return await new Promise((resolve, reject) => {
		try {
			var val = [];
			db_library
				.execute_await('[IPS].[GetUserCustIdTypeConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ CustType: element.CustName, id: element.CustID });
					});
					resolve(val);
					//console.log(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};
exports.getuserreportingtype = async function (data) {
	return await new Promise((resolve, reject) => {
		try {
			let parameters = [];
			let val = [];
			let para = new param('ReportingId', sqlType.Int, data);
			parameters.push(para);
			db_library
				.execute_await('[IPS].[GetUserReportingIdTypeConfig]', parameters, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ ReportingType: element.ReportingName, id: element.UserId });
					});
					resolve(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};
exports.getuserorgtype = async function () {
	return await new Promise((resolve, reject) => {
		try {
			var val = [];
			db_library
				.execute_await('[IPS].[GetUserOrgIdTypeConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ OrgType: element.OrgName, id: element.OrgID });
					});
					resolve(val);
					//console.log(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};
exports.getuserorgdivtype = async function () {
	return await new Promise((resolve, reject) => {
		try {
			var val = [];
			db_library
				.execute_await('[IPS].[GetUserOrgDivIdTypeConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ OrgDivType: element.OrgDivName, id: element.OrgDivID });
					});
					resolve(val);
					//console.log(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};
exports.getuserdata = async function () {
	return await new Promise((resolve, reject) => {
		try {
			let parameters = [];
			let val = [];
			db_library
				.execute_await('[IPS].[GetMstUserDataConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({
							UserCode: element.UserCode,
							UserFName: element.UserFName,
							UserLName: element.UserLName,
							UserDesignation: element.UserDesignation,
							UserEmailID: element.UserEmailID,
							PhoneNo: element.PhoneNo,
							PersonalEmailID: element.PersonalEmailID,
							isInternalUser: element.isInternalUser,
							OrgName: element.OrgName,
							OrgDivName: element.OrgDivName,
							RoleName: element.RoleName,
							SubRoleName: element.SubRoleName,
							ActivityName: element.ActivityName,
							CustomerName: element.CustomerName,
							ReportingName: element.ReportingName
						});
					});
					resolve(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};

exports.getcustorgtype = async function () {
	return await new Promise((resolve, reject) => {
		try {
			var val = [];
			db_library
				.execute_await('[IPS].[GetCustOrgIdTypeConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ OrgType: element.OrgName, id: element.OrgID });
					});
					resolve(val);
					//console.log(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};
exports.getcustcomptype = async function () {
	return await new Promise((resolve, reject) => {
		try {
			var val = [];
			db_library
				.execute_await('[IPS].[GetCustCompIdTypeConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ CompType: element.CompName, id: element.CompID });
					});
					resolve(val);
					//console.log(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};
exports.getservicecomptype = async function () {
	return await new Promise((resolve, reject) => {
		try {
			var val = [];
			db_library
				.execute_await('[IPS].[GetServiceCompIdTypeConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ CompType: element.CompName, id: element.CompID });
					});
					resolve(val);
					//console.log(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};
exports.getserviceorgtype = async function () {
	return await new Promise((resolve, reject) => {
		try {
			var val = [];
			db_library
				.execute_await('[IPS].[GetServiceOrgIdTypeConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({ OrgType: element.OrgName, id: element.OrgID });
					});
					resolve(val);
					//console.log(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};
exports.getcustomerdata = async function () {
	return await new Promise((resolve, reject) => {
		try {
			let parameters = [];
			let val = [];
			db_library
				.execute_await('[IPS].[GetMstCustomerDataConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({
							CustName: element.CustName,
							CustomerCode: element.CustomerCode,
							ShortName: element.ShortName,
							OrgName: element.OrgName,
							CompName: element.CompName
						});
					});
					//console.log(val);
					resolve(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};
exports.getservicedata = async function () {
	return await new Promise((resolve, reject) => {
		try {
			let parameters = [];
			let val = [];
			db_library
				.execute_await('[IPS].[GetMstServiceWorkflowDataConfig]', undefined, db_library.query_type.SP)
				.then((value) => {
					value.recordset.forEach((element) => {
						val.push({
							ServiceName: element.SerName,
							ServiceDesc: element.SerDesc,
							ComponentName: element.CompName,
							WorkflowName: element.WfdName,
							WorkflowDescription: element.WfdDesc,
							isGlobal: element.isGlobal,
							Organization: element.OrgName,
							ActivityName: element.AtyName,
							ActivityOrder: element.ActivityOrder
						});
					});
					//console.log(val);
					resolve(val);
				})
				.catch((error) => {
					reject(error);
				});
		} catch (error) {
			reject(error);
		}
	});
};
