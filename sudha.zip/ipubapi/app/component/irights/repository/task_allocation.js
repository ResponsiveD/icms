'use strict'

const get_project_data = require("../data/get_project.json");
const get_service_data = require("../data/get_service.json");
const get_activity_data = require("../data/get_activity.json");
var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');

exports.get_resource_name_on_activity = async function (user_id) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let result=[];
            let para = new param('UserID', sqlType.Int, user_id);
            parameters.push(para);
            db_library
                .execute('[IPS].[GetUsersUnderUserID]', parameters, db_library.query_type.SP).then(async (value) => {
                    var _ = require('lodash');
                    var UserList = value.recordsets[0];
                    var actyList = value.recordsets[1];
                    // actyList.forEach(element=>{
                    //     element.resource= _.filter(UserList, ['activity_id', element.activity_id]);
                    // });

                    actyList.forEach(element => {
                        var key = element.activity_id
                        var ele = {
                            activity_name: element.activity_name,
                            user_list: _.filter(UserList, ['activity_id', key])
                        }
                        result.push(ele);
                    });
                    resolve(result);
                }).catch(err => {
                    reject(err);
                })
        } catch (error) {
            reject(error);
        }
    });
}
exports.get_resource_name = async function (user_id) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('UserID', sqlType.Int, user_id);
            parameters.push(para);
            db_library
                .execute('[IPS].[GetUsersUnderUserID]', parameters, db_library.query_type.SP).then(async (value) => {
                    var _ = require('lodash');
                    var UserList = value.recordsets[0];
                    var actyList = value.recordsets[1];
                    var result = [];
                    // actyList.forEach(element=>{
                    //     var val = element.activity_name
                    //     var key = element.activity_id
                    //     var ele = {};
                    //     ele[val]= _.filter(UserList, ['activity_id', key]);
                    //     result.push(ele);
                    // });

                    UserList.forEach(element => {
                        if (_.filter(result, ['user_name', element.user_name]).length == 0)
                            result.push({ "user_name": element.user_name, "id": element.user_id, "user_id": element.user_id })
                    });
                    resolve(result);
                }).catch(err => {
                    reject(err);
                })
        } catch (error) {
            reject(error);
        }
    });
}

exports.get_tasks = async function (user_id, project_id) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('UserID', sqlType.Int, user_id);
            parameters.push(para);
            para = new param('Project_ID', sqlType.Int, project_id);
            parameters.push(para);
            let Output = [];
            db_library
                .execute('[IRS].[GetTaskAllocation]', parameters, db_library.query_type.SP).then(async (value) => {
                    var Project = value.recordsets[0];
                    var Service = value.recordsets[1];
                    var task = value.recordsets[2];
                    var spec = value.recordsets[3];
                    //var asigned_task = value.recordsets[4];
                    var activity = [];
                    var servc = [];
                    var proj = [];
                    var _ = require('lodash');
                    _.forEach(Project, (element) => {
                        Output.push(element);
                        var count = _.filter(activity, ['project_id', element.activity_id]).length;
                        if (count <= 0) {
                            proj.push({ 'project_id': element.project_id, 'project_name': element.text })
                        }
                    });
                    _.forEach(Service, (element) => {
                        Output.push(element);
                        var count = _.filter(activity, ['service_id', element.activity_id]).length;
                        if (count <= 0) {
                            servc.push({ 'service_id': element.service_id, 'service_name': element.text });
                        }
                    });
                    _.forEach(task, (element) => {
                        Output.push(element);
                        var count = _.filter(activity, ['activity_id', element.activity_id]).length;
                        element.total_page='';
                        if (count <= 0) {
                            activity.push({ 'activity_id': element.activity_id, 'activity': element.text })
                        }
                    });
                    _.forEach(spec, (element) => {
                        var asigned_task = _.filter(spec, ['resource', element.resource]).length
                        if (element.resource != "<i class='fa fa-plus'></i>") {
                            element.asigned_task = asigned_task;
                        }
                        else {
                            element.asigned_task = 0;
                        }
                        Output.push(element);
                    });
                    resolve({
                        'get_tasks': Output,
                        'get_service': servc,
                        'get_activity': activity,
                        'get_project': proj,
                    });
                }).catch((error) => {
                    reject(error);
                });
        }
        catch (err) {
            reject(err);
        }
    });
}
exports.post_tasks = async function (data, user_id) {
    return await new Promise(async (resolve, reject) => {
        try {
            var _ = require('lodash');
            var ToUpdate = _.filter(data, ['to_update', 1])
            var input = {
                "count": ToUpdate.length,
                "data": ToUpdate,
                "UserID": user_id
            }

            let parameters = [];
            let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(input));
            parameters.push(para);
            db_library
                .execute('[IRS].[AddEditTaskAllocation]', parameters, db_library.query_type.SP).then(async (value) => {
                    var user_id = value.recordset[0].UserID;
                    resolve(user_id);
                }).catch(err => reject(err))
        } catch (error) {
            reject(error);
        }
    });
}