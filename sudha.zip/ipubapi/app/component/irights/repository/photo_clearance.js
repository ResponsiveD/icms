"use strict";
var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');


  exports.get_rights_holder_followup = async function(data){
    return new Promise(async (resolve, reject)=>{
      try {
        let parameters = [];
        let para = new param('JsonValue', sqlType.NVarChar, data);
        parameters.push(para);
        db_library
          .execute('[IRS].[GetRightsHolderFollowups]', parameters, db_library.query_type.SP).then((value) => {
            let result = {"followUps":value.recordsets[0],"attachment":value.recordsets[1]}
            resolve(result);
          }).catch(err => reject(err));
      } catch (error) {
        reject(error)
      }
    });
  }

  exports.update_rights_holder_followup = async function(data){
    return new Promise(async (resolve, reject)=>{
      try {
        let parameters = [];
        let para = new param('JsonValue', sqlType.NVarChar, data);
        parameters.push(para);
        db_library
          .execute('[IRS].[AddEditRightsHolderFollowups]', parameters, db_library.query_type.SP).then((value) => {
            let result = value.recordsets[0][0]
            resolve(result);
          }).catch(err => reject(err));
      } catch (error) {
        reject(error)
      }
    });
  }
  
  exports.get_clearance_status = async function(){
    return new Promise(async (resolve, reject)=>{
      try {
        let parameters = [];
        db_library
          .execute('[IRS].[GetClearanceStatus]', parameters, db_library.query_type.SP).then((value) => {
            let result = value.recordset
            resolve(result);
          }).catch(err => reject(err));
      } catch (error) {
        reject(error)
      }
    });
  }

  exports.update_highres_status = async function(hi_res,s_id,comments){
    return new Promise(async (resolve, reject)=>{
      try {
        let parameters = [];
        let para = new param('HiResDownloaded', sqlType.Bit, hi_res);
        parameters.push(para);
        para = new param('SID', sqlType.Int, s_id);
        parameters.push(para);
        para = new param('comments', sqlType.NVarChar, comments);
        parameters.push(para);
        db_library
          .execute('[IRS].[UpdateHighResStatus]', parameters, db_library.query_type.SP).then((value) => {
            let result = true
            resolve(result);
          }).catch(err => reject(err));
      } catch (error) {
        reject(error)
      }
    });
  }
 