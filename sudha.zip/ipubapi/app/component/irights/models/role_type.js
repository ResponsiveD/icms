"use strict";
function role_type() {
  this.role_type_name = "";
  this.role_type_id = "";
}

role_type.prototype.role_type_name = function(role_type_name) {
  this.role_type_name = role_type_name;
};
role_type.prototype.role_type_id = function(role_type_id) {
  this.role_type_id = role_type_id;
};
module.exports = role_type;
