"use strict";
function spec_for_chapter() {
  this.project_id = "";
  this.chapter_id = "";
  this.specs = "";
  this.chapter_attachments = "";
}

spec_for_chapter.prototype.project_id = function(project_id) {
  this.project_id = project_id;
};
spec_for_chapter.prototype.chapter_id = function(chapter_id) {
  this.chapter_id = chapter_id;
};
spec_for_chapter.prototype.specs = function(specs) {
  this.specs = specs;
};
spec_for_chapter.prototype.chapter_attachments = function(chapter_attachments) {
  this.chapter_attachments = chapter_attachments;
};
module.exports = spec_for_chapter;
