"use strict";
function activity() {
  this.activity_name = "";
  this.activity_id = "";
}

activity.prototype.activity_name = function(activity_name) {
  this.activity_name = activity_name;
};

activity.prototype.activity_id = function(activity_id) {
  this.activity_id = activity_id;
};

module.exports = activity;
