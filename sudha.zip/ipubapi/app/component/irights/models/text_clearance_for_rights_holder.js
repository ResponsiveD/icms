"use strict";
function text_clearance_for_rights_holder() {
  this.project_id = "";
  this.chapter_id = "";
  this.selection_id = "";
  this.rights_holder_id = "";
  this.text_clearances = [];
}

text_clearance_for_rights_holder.prototype.project_id = function(project_id) {
  this.project_id = project_id;
};
text_clearance_for_rights_holder.prototype.chapter_id = function(chapter_id) {
  this.chapter_id = chapter_id;
};
text_clearance_for_rights_holder.prototype.selection_id = function(
  selection_id
) {
  this.selection_id = selection_id;
};
text_clearance_for_rights_holder.prototype.rights_holder_id = function(
  rights_holder_id
) {
  this.rights_holder_id = rights_holder_id;
};
text_clearance_for_rights_holder.prototype.text_clearances = function(
  text_clearances
) {
  this.text_clearances = text_clearances;
};
module.exports = text_clearance_for_rights_holder;
