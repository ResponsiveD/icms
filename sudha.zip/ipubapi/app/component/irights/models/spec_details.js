"use strict";
function spec_Details() {
  this.proj_ser_id = "";
  this.chapter_id = "";
  this.chapter_name="";
  this.spec_id = "";
  this.spec_desc = "";
  this.page_no = "";
  this.photo_no = "";
  this.due_date = "";
  this.tl_comments = "";
  this.chapter_file = [];
  // this.uploaded_asset = [];
  // this.metadata = [];
  this.rights_holder_details = [];
  this.task_id="";
  this.task_record_id="";
  this.user_id="";
  this.sid=""
}
spec_Details.prototype.user_id = function(user_id) {
  this.user_id = user_id;
};
spec_Details.prototype.chapter_name = function(chapter_name) {
  this.chapter_name = chapter_name;
};
spec_Details.prototype.sid = function(sid) {
  this.sid = sid;
};
spec_Details.prototype.project_id = function(proj_ser_id) {
  this.proj_ser_id = proj_ser_id;
};
spec_Details.prototype.task_id = function(task_id) {
  this.task_id = task_id;
};
spec_Details.prototype.task_record_id = function(task_record_id) {
  this.task_record_id = task_record_id;
};
spec_Details.prototype.chapter_id = function(chapter_id) {
  this.chapter_id = chapter_id;
};
spec_Details.prototype.spec_id = function(spec_id) {
  this.spec_id = spec_id;
};
spec_Details.prototype.spec_desc = function(spec_desc) {
  this.spec_desc = spec_desc;
};
spec_Details.prototype.chapter_file = function(chapter_file) {
  this.chapter_file = chapter_file;
};
spec_Details.prototype.uploaded_asset = function(uploaded_asset) {
  this.uploaded_asset = uploaded_asset;
};
spec_Details.prototype.page_no = function(page_no) {
  this.page_no = page_no;
};
spec_Details.prototype.photo_no = function(photo_no) {
  this.photo_no = photo_no;
};
spec_Details.prototype.due_date = function(due_date) {
  this.due_date = due_date;
};
spec_Details.prototype.tl_comments = function(tl_comments) {
  this.tl_comments = tl_comments;
};
// spec_Details.prototype.metadata = function(metadata) {
//   this.metadata = metadata;
// };
spec_Details.prototype.rights_holder_details = function(rights_holder_details) {
  this.rights_holder_details = rights_holder_details;
};
module.exports = spec_Details;
