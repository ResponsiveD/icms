"use strict";
function activity_actions() {
    this.user_id = "";
    this.activity_id = "";
    this.task_id = "";
    this.proj_ser_id = "";
    this.comment = "";
    this.status_id = "";
}

activity_actions.prototype.user_id = function (user_id) {
    this.user_id = user_id;
};

activity_actions.prototype.activity_id = function (activity_id) {
    this.activity_id = activity_id;
};
activity_actions.prototype.task_id = function (task_id) {
    this.task_id = task_id;
};

activity_actions.prototype.project_ser_id = function (project_ser_id) {
    this.project_ser_id = project_ser_id;
};
activity_actions.prototype.comment = function (comment) {
    this.comment = comment;
};

activity_actions.prototype.status_id = function (status_id) {
    this.status_id = status_id;
};
module.exports = activity_actions;
