"use strict";
function research() {
  this.research_name = "";
  this.research_id = "";
}

research.prototype.research_name = function(research_name) {
  this.research_name = research_name;
};
research.prototype.research_id = function(research_id) {
  this.research_id = research_id;
};
module.exports = research;
