"use strict";

function project_basic_details() {
  this.project_title = "";
  this.project_code = "";
  this.project_id = "";
  this.customer = "";
  this.created_on = "";
  this.Status = "";
  this.StatusID = "";
  this.closing_date = "";
  this.is_ext_approve = ""
}

project_basic_details.prototype.closing_date = function (closing_date) {
  this.closing_date = closing_date;
};
project_basic_details.prototype.project_code = function (project_code) {
  this.project_code = project_code;
};
project_basic_details.prototype.project_title = function (project_title) {
  this.project_title = project_title;
};
project_basic_details.prototype.project_id = function (project_id) {
  this.project_id = project_id;
};
project_basic_details.prototype.customer = function (customer) {
  this.customer = customer;
};
project_basic_details.prototype.created_on = function (created_on) {
  this.created_on = created_on;
};
project_basic_details.prototype.Status = function (Status) {
  this.Status = Status;
};
project_basic_details.prototype.StatusID = function (StatusID) {
  this.StatusID = StatusID;
};
project_basic_details.prototype.is_ext_approve = function (is_ext_approve) {
  this.is_ext_approve = is_ext_approve;
};
module.exports = project_basic_details;
