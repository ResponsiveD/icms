"use strict";
function text_clearance_for_session() {
  this.project_id = "";
  this.chapter_id = "";
  this.selection_id = "";
  this.text_clearance_for_rightsholders = [];
}

text_clearance_for_session.prototype.project_id = function(project_id) {
  this.project_id = project_id;
};
text_clearance_for_session.prototype.chapter_id = function(chapter_id) {
  this.chapter_id = chapter_id;
};
text_clearance_for_session.prototype.selection_id = function(selection_id) {
  this.selection_id = selection_id;
};
text_clearance_for_session.prototype.text_clearance_for_rightsholders = function(
  text_clearance_for_rightsholders
) {
  this.text_clearance_for_rightsholders = text_clearance_for_rightsholders;
};
module.exports = text_clearance_for_session;
