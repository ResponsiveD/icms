"use strict";
function sub_category() {
  this.sub_category_name = "";
  this.sub_category_id = "";
}

sub_category.prototype.sub_category_name = function(sub_category_name) {
  this.sub_category_name = sub_category_name;
};
sub_category.prototype.sub_category_id = function(sub_category_id) {
  this.sub_category_id = sub_category_id;
};
module.exports = sub_category;
