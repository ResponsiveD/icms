"use strict";
function project_chapter_full_details() {
  this.chapter_name = "";
  this.chapter_id = "";
  this.project_id = "";
  this.chapter_files = "";
  this.photos = "";
  this.text = "";
}

project_chapter_full_details.prototype.chapter_name = function(chapter_name) {
  this.chapter_name = chapter_name;
};
project_chapter_full_details.prototype.chapter_id = function(chapter_id) {
  this.chapter_id = chapter_id;
};
project_chapter_full_details.prototype.project_id = function(project_id) {
  this.project_id = project_id;
};
project_chapter_full_details.prototype.chapter_files = function(chapter_files) {
  this.chapter_files = chapter_files;
};
project_chapter_full_details.prototype.photos = function(photos) {
  this.photos = photos;
};
project_chapter_full_details.prototype.text = function(text) {
  this.text = text;
};
module.exports = project_chapter_full_details;
