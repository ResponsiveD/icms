"use strict";

function location() {
  this.location_name = "";
  this.location_id = "";
}

location.prototype.location_name = function(location_name) {
  this.location_name = location_name;
};

location.prototype.location_id = function(location_id) {
  this.location_id = location_id;
};
module.exports = location;
