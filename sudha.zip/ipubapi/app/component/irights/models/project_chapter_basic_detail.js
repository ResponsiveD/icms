"use strict";

function project_chapter_basic_detail() {
  this.chapter_name = "";
  this.chapter_id = "";
  this.project_id = "";
}

project_chapter_basic_detail.prototype.chapter_name = function(chapter_name) {
  this.chapter_name = chapter_name;
};
project_chapter_basic_detail.prototype.chapter_id = function(chapter_id) {
  this.chapter_id = chapter_id;
};
project_chapter_basic_detail.prototype.project_id = function(project_id) {
  this.project_id = project_id;
};
module.exports = project_chapter_basic_detail;
