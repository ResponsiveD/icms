"use strict";
function asset() {
  this.image_id = "";
  this.asset_id = "";
  this.is_customer_selected = "";
  this.is_aproved = "";
  this.source = "";
  this.image_cost = "";
  this.source_url = "";
  this.photographer_name = "";
  this.keywords = "";
  this.clearance_required = "";
  this.rights_type = "";
  this.image_type = "";
  this.source_type = "";
  this.usage_restriction = "";
  this.currency = "";
  this.model_release = "";
  this.property_release = "";
  this.comments = "";
  this.rights_holder_details = "";
}

asset.prototype.image_id = function(image_id) {
  this.image_id = image_id;
};
asset.prototype.asset_id = function(asset_id) {
  this.asset_id = asset_id;
};
asset.prototype.is_customer_selected = function(is_customer_selected) {
  this.is_customer_selected = is_customer_selected;
};
asset.prototype.is_aproved = function(is_aproved) {
  this.is_aproved = is_aproved;
};
asset.prototype.source = function(source) {
  this.source = source;
};
asset.prototype.image_cost = function(image_cost) {
  this.image_cost = image_cost;
};
asset.prototype.source_url = function(source_url) {
  this.source_url = source_url;
};
asset.prototype.photographer_name = function(photographer_name) {
  this.photographer_name = photographer_name;
};
asset.prototype.keywords = function(keywords) {
  this.keywords = keywords;
};
asset.prototype.clearance_required = function(clearance_required) {
  this.clearance_required = clearance_required;
};
asset.prototype.rights_type = function(rights_type) {
  this.rights_type = rights_type;
};
asset.prototype.image_type = function(image_type) {
  this.image_type = image_type;
};
asset.prototype.source_type = function(source_type) {
  this.source_type = source_type;
};
asset.prototype.usage_restriction = function(usage_restriction) {
  this.usage_restriction = usage_restriction;
};
asset.prototype.currency = function(currency) {
  this.currency = currency;
};
asset.prototype.model_release = function(model_release) {
  this.model_release = model_release;
};
asset.prototype.property_release = function(property_release) {
  this.property_release = property_release;
};
asset.prototype.comments = function(comments) {
  this.comments = comments;
};
asset.prototype.rights_holder_details = function(rights_holder_details) {
  this.rights_holder_details = rights_holder_details;
};
module.exports = asset;
