function mailOptions() {
    this.from = '',
        this.to = '',
        this.cc = '',
        this.bcc = '',
        this.subject = '',
        //this.text = '',
        this.html = '',
        this.compid = null,
        this.followup_id = null,
        this.attachments = []
};
mailOptions.prototype.from = function (from) {
    this.from = from;
};
mailOptions.prototype.to = function (to) {
    this.to = to;
};
mailOptions.prototype.subject = function (subject) {
    this.subject = subject;
};
mailOptions.prototype.cc = function (cc) {
    this.cc = cc;
};
mailOptions.prototype.bcc = function (bcc) {
    this.bcc = bcc;
};
mailOptions.prototype.html = function (html) {
    this.html = html;
};
mailOptions.prototype.compid = function (compid) {
    this.compid = compid;
};
mailOptions.prototype.followup_id = function (followup_id) {
    this.followup_id = followup_id;
};
mailOptions.prototype.attachments = function (attachments) {
    this.attachments = attachments;
};
module.exports = mailOptions;