const Cryptr = require('cryptr');
const config = require('../../config/config');
const cryptr = new Cryptr(config.crypto_key);

exports.encryptString = async function (data) {
    try {
        if (typeof data === 'object') {
            return cryptr.encrypt(JSON.stringify(data));
        } else {
            return cryptr.encrypt(data);
        }
    } catch (e) {
        return e
    }
}

exports.decryptString = async function (data) {
    try {
        let result = cryptr.decrypt(data);
        return result
    } catch (e) {
        return e
    }
}