'use strict'
const PACKAGE = require('../../package.json')
const config = require('../../config/config')
const configjson = require('../../config/env/config.json')
const param = require('../models/parameter_input');
const db_library = require('../../config/lib/db_library');
var sqlType = require('mssql');

const _nodemailer = (account, mailOptions) => {
    return new Promise((resolve, reject) => {
        const nodemailer = require('nodemailer');

        nodemailer.createTestAccount(() => {
            // create reusable transporter object using the default SMTP transport
            let transporter = nodemailer.createTransport({
                host: "smtp.office365.com",
                port: 587,
                secure: false, // true for 465, false for other ports
                auth: {
                    user: account.user,//
                    pass: account.password// 
                },
                tls: {
                    ciphers: 'SSLv3'
                }
            });
            // send mail with defined transport object
            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    reject(error);
                }
                else {
                    resolve(info);
                }
            });
        })
    })
}

exports.sendMail = async (_mailOptions) => {
    if (configjson[PACKAGE.environment]["Tomail"] == "N") {
        _mailOptions.to = "";
    }
    if (configjson[PACKAGE.environment]["ccmail"] == "N") {
        _mailOptions.cc = "";
    }
    if (PACKAGE.environment == "dev" || PACKAGE.environment == "test") {
        _mailOptions.subject = PACKAGE.environment + ' - ' + _mailOptions.subject;
    }

    let result = await _nodemailer(config.mailer.options.auth, _mailOptions).then(async (info) => {
        let data1 = await logSendMai(_mailOptions, 1, 'success');
        return 1;
    }).catch(async (err) => {
        let data = await logSendMai(_mailOptions, 0, err.message);
        return 0;
    });
    return result;
}

const logSendMai = async (data, status, statusmessage) => {
    return await new Promise((resolve, reject) => {

        let _parameters = [];
        let para = new param('FromMailID', sqlType.NVarChar, data.from);
        _parameters.push(para);
        para = new param('ToMailID', sqlType.NVarChar, data.to);
        _parameters.push(para);
        para = new param('CCMailID', sqlType.NVarChar, data.cc);
        _parameters.push(para);
        para = new param('BCCMailID', sqlType.NVarChar, data.bcc);
        _parameters.push(para);
        para = new param('Subject', sqlType.NVarChar, data.subject);
        _parameters.push(para);
        para = new param('MailContent', sqlType.NVarChar, data.html);
        _parameters.push(para);
        para = new param('status', sqlType.Bit, status);
        _parameters.push(para);
        para = new param('StatusMessage', sqlType.NVarChar, statusmessage);
        _parameters.push(para);
        para = new param('CompID', sqlType.Int, data.compid);
        _parameters.push(para);
        para = new param('FollowUpID', sqlType.Int, data.followup_id);
        _parameters.push(para);

        let attachments = ""
        if (data.attachments) {
            data.attachments.map(item => {
                if (item.is_active == true){
                    attachments += attachments == "" ? item.href : "," + item.href;
                }
            });
        }
        
        para = new param('Attachments', sqlType.NVarChar, attachments);
        _parameters.push(para);
        db_library
            .execute("[IPS].[Mail_track_dtl_logs]", _parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject(err)
            });
    });
}