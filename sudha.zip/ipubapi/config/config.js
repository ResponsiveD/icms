'use strict';

/**
 * Module dependencies.
 */
var _ = require('lodash'),
  chalk = require('chalk'),
  glob = require('glob'),
  fs = require('fs'),
  path = require('path');



/**
 * Initialize global configuration
 */
var initGlobalConfig = function () {


  // Get the default config
  var defaultConfig = require(path.join(process.cwd(), 'config/env/default'));

  // Get the current config
  var environmentConfig = require(path.join(process.cwd(), 'config/env/environment')) || {};

  // Merge config files
  var config = _.merge(defaultConfig, environmentConfig);

  // read package.json for PEAN.JS project information
  var pkg = require(path.resolve('./package.json'));
  config.iPubSuite = pkg;

  return config;
};

/**
 * Set configuration object
 */
module.exports = initGlobalConfig();
