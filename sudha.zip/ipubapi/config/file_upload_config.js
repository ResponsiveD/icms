const PACKAGE = require('../package.json');


exports.CloudCredentials = () => {
    if (PACKAGE.environment == "dev") {
        return {
            accessKey: '86NuRWfrPuRPi/QM7RYWy3x3g9tQdL6F7aecafPv6T3D9TjibM8RSCD1RTjpMspg/M/jXf8hChA5scKCd3penA==',
            storageAccount: 'ipubsuitedev',
            containerName: 'ipubsuite',
            cloudBasePath: 'https://ipubsuitedev.blob.core.windows.net/ipubsuite/'
        }
    }
    else if (PACKAGE.environment == "test") {
        return {
            accessKey: 'u/Enms2E+ffFdWNynpELYZZARsLgx6e5uAXRI3AT0rzeA3zThUSx5mn4mKh8adw7JpHfeEvgdJpIVaJZdenQoA==',
            storageAccount: 'ipubsuitetest',
            containerName: 'ipubsuite',
            cloudBasePath: 'https://ipubsuitetest.blob.core.windows.net/ipubsuite/'
        }
    }
    else if (PACKAGE.environment == "testreg") {
        return {
            accessKey: 'PgaBEfTkeY0ooDX8SStnFQTN9Jx8kh2qIjB9y5QAw7A/dLzZaLik5BwBavPhwqCkBeoEQwe8dWZT3wlTw30wZw==',
            storageAccount: 'ipubsuitetestreg',
            containerName: 'ipubsuite',
            cloudBasePath: 'https://ipubsuitetestreg.blob.core.windows.net/ipubsuite/'
        }
    }
    else if (PACKAGE.environment == "demo") {
        return {
            accessKey: 'UJuCnIJJcYrEF8Vz3rdvDsy4ctkDh/3qN75CwLZzt9TIna03Of16Y0UUGqeTqmOokjlYs5OCZUydTH6hZTLTng==',
            storageAccount: 'ipubsuitedemo',
            containerName: 'ipubsuite',
            cloudBasePath: 'https://ipubsuitedemo.blob.core.windows.net/ipubsuite/'
        }
    }
    else if (PACKAGE.environment == "prod") {
        return {
            accessKey: 'sc48hOPgC0ODQ2t/4DpwMViyTJqCRQ3kywo1hE370jqqsZb3g1JaXDmy92hZtWZErqVTa9pr8h1Sr1gPPxc3TA==',
            storageAccount: 'ipubsuite',
            containerName: 'ipubsuite',
            cloudBasePath: 'https://ipubsuite.blob.core.windows.net/ipubsuite/'
        }
    }
}

exports.AllowedFileType = ['application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel.sheet.binary.macroenabled.12',
    'image/jpeg',
    'application/pdf',
    'application/msword',
    'image/png',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/postscript',
    'application/vnd.ms-powerpoint',
    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    'application/octet-stream',
    'text/xml'
];

exports.AllowedFileExtension = [
    '.jpeg',
    '.jpg',
    '.pdf',
    '.png',
    '.doc',
    '.docx',
    '.xls',
    '.xlsx',
    '.xlsb',
    '.ppt',
    '.pptx',
    '.msg',
    '.xml'
];

exports.DoveAllowedFileExtension = [
    '.doc',
    '.docx',
    '.pdf',
    '.html',
    '.jpeg',
    '.jpg',
    '.bmp',
    '.tiff',
    '.png',
    '.gif',
    '.xml',
    '.zip',
    '.log'   
];

exports.AllowedImageFileType = [
    'image/jpeg',
    'image/png'
];

exports.AllowedImageFileExtension = [
    '.jpeg',
    '.jpg',
    '.png',

];

exports.AllowedMailType =[
    'application/vnd.ms-outlook',
    'message/rfc822'
];

exports.AllowedMailExtension =[
    '.msg',
    '.eml'
];

const ALLOWEDTYPE = { ALL: 1, EMAIL: 2 };

// export {ALLOWEDTYPE};

module.exports.ALLOWEDTYPE = ALLOWEDTYPE;