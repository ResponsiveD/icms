'use strict';

const fs = require('fs');
const path = require("path");
const PACKAGE = require('../../package.json')
const configjson = require('../env/config.json')

module.exports = {
  log: {
    // logging with Morgan - https://github.com/expressjs/morgan
    // Can specify one of 'combined', 'common', 'dev', 'short', 'tiny'
    format: 'combined',
    options: {
      // Stream defaults to process.stdout
      // Uncomment/comment to toggle the logging to a log on the file system
      stream: {
        directoryPath: process.cwd() + '/log/',
        rotatingLogs: { // for more info on rotating logs - https://github.com/holidayextras/file-stream-rotator#usage
          active: true, // activate to use rotating logs 
          date_format: 'YYYYMMDD',
          fileName: path.join('access-%DATE%.log'),
          frequency: 'daily',
          verbose: 'false',
          audit_file:  path.join('log-audit.json') 
        }
      }
    }
  },
  port: process.env.port != undefined ? process.env.port : configjson[PACKAGE.environment]["ENVPORT"],
  env_mode: configjson[PACKAGE.environment]["ENVPORT"],
  env_node: 'non-secure',
  crypto_key: 'iPubsuite',
  secure: {
    ssl: true,
    privateKey: './config/sslcerts/key.pem',
    certificate: './config/sslcerts/cert.pem'
  },
  mailer: {
    from: 'support@integra.co.in',//process.env.MAILER_FROM || 'MAILER_FROM',
    options: {
      service: process.env.MAILER_SERVICE_PROVIDER || 'MAILER_SERVICE_PROVIDER',
      auth: {
        user: process.env.MAILER_EMAIL_ID || 'iengine.cloudtest@integra.co.in',
        password: process.env.MAILER_PASSWORD || 'Fu!&LS#t0u!0ry'
      }
    }
  },
  roles: ['admin', 'guest', 'user'],
  db: {
    options: {
      logging: process.env.DB_LOGGING === 'true' ? console.log : false,
      host: process.env.DB_HOST || 'localhost',
      port: process.env.DB_PORT || '5432'
    },
    sync: {
      force: process.env.DB_FORCE === 'true' ? true : false
    }
  },
  seed: {
    data: {
      user: {
        username: process.env.DB_SEED_USER_USERNAME || 'user',
        provider: 'local',
        email: process.env.DB_SEED_USER_EMAIL || 'user@localhost.com',
        firstName: 'User',
        lastName: 'Local',
        displayName: 'User Local',
        roles: ['user']
      },
      admin: {
        username: process.env.DB_SEED_ADMIN_USERNAME || 'admin',
        provider: 'local',
        email: process.env.DB_SEED_ADMIN_EMAIL || 'admin@localhost.com',
        firstName: 'Admin',
        lastName: 'Local',
        displayName: 'Admin Local',
        roles: ['user', 'admin']
      }
    },
    init: process.env.DB_SEED === 'true' ? true : false,
    logging: process.env.DB_SEED_LOGGING === 'false' ? false : true
  }
};