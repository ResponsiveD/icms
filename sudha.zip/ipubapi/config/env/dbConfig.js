const config = require('./config.json');
const PACKAGE = require('../../package.json');
const host = config[PACKAGE.environment]["server"];
const user = config[PACKAGE.environment]["user"];
const password = config[PACKAGE.environment]["password"];
const database = config[PACKAGE.environment]["database"];
const connectionTimeout = config[PACKAGE.environment]["connectionTimeout"];
const requestTimeout = config[PACKAGE.environment]["requestTimeout"];
const encrypt = config[PACKAGE.environment]["encrypt"];

module.exports = {
  server: host,
  user: user,
  password: password,
  database: database,
  connectionTimeout: connectionTimeout,
  requestTimeout: requestTimeout,
  options: {
    encrypt: encrypt
  }
};