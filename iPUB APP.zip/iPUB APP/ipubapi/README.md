# iPUBAPI
API project created for iPubsuite


## Before You Begin


## Prerequisites
Make sure you have installed all of the following prerequisites on your development machine:
* Node.js - [Download & Install Node.js](https://nodejs.org/en/download/) and the npm package manager. If you encounter any problems, you can also use this [GitHub Gist](https://gist.github.com/isaacs/579814) to install Node.js.
  * Node v5 IS NOT SUPPORTED AT THIS TIME! 


## Quick Install
To install Node.js dependencies you're going to use npm again. In the application folder, run this from the command-line:

```bash
$ npm install
```

This command does a few things:
* First it will install the dependencies needed for the application to run.
* If you're running in a development environment, it will then also install development dependencies needed for testing and running your application.
* Finally, when the install process is over, npm will initiate a bower install command to install all the front-end modules needed for the application.

## Running Your Application
The first thing you will need to do is supply your MS SQL credentials.


Now just run your application using Grunt. 

In the application folder, run this from the command-line:

```
$ grunt
```

or in 'debugging' mode:

```
$ grunt debug
```

### Running in Production mode
To run your application with *production* environment configuration, execute gulp as follows:

```bash
$ npm run prod
```



## Community


## Contributing


## Credits


## License
(The MIT License)
