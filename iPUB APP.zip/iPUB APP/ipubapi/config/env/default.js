'use strict';

module.exports = {
  app: {
    title: 'iPubSuite',
    description: 'iPubSuite description',
  },
  port: 7070,
  host: '0.0.0.0',
  uploads: {
    profileUpload: {
      dest: './modules/users/client/img/profile/uploads/', // Profile upload destination path
      limits: {
        fileSize: 1*1024*1024 // Max file size in bytes (1 MB)
      }
    }
  }
};
