"use strict";
const prefix = '/integra/ips';//"/api/v1";
const PACKAGE = require('../../package.json');
const configjson = require('../env/config.json')

module.exports = {
  JWT_SECRET_KEY: "!Pub$u!t9@p!V1",
  EXPIRES: 86400,
  FilePath:{
    ProjectAttach : '#projectid#/Attachment/',
    ServiceAttach : '#projectid#/#serviceid#/Attachment/',
    ChapterAttach : '#projectid#/#serviceid#/#chapterID#/Attachment/',
    SpecAttach : '#projectid#/#serviceid#/#chapterid#/#id#/Attachment/',
    TextAttach : '#projectid#/#serviceid#/#chapterid#/#id#/Attachment/'
  },
  ROUTE: {
    PREFIX: prefix,
    IRIGHTS_PREFIX: '/integra/ips/irs',//"/api/v1/irights",
    IJPS_PREFIX: '/integra/ips/ijps',
    IBPS_PREFIX: '/integra/ips/ibps',
    AUTH_URL: {
      LOGIN: prefix + "/login",
      WELCOME: prefix+"/",
      FORGETPASSWORD: prefix+"/forgot-password" 
    }
  },
  CROS_OPTIONS: {
    ORIGIN: configjson[PACKAGE.environment]["iPubWebsite"],
    ALLOWEDHEADERS: [
      "Content-Type",
      "Access-Control-Allow-Headers",
      "Access-Control-Allow-Origin",
      "Authorization",
      "X-Requested-With"
    ],
    EXPOSEDHEADERS: ["Authorization"],
    ALLOWEDMETHODS: ["GET,POST"]
  }
};
