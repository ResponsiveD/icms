var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');

exports.postFeedbackUser = async (userId, organisationId, articleId, activityId, data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let jsonData = JSON.stringify(data);
        parameters.push(new param('JsonData', sqlType.NVarChar, jsonData));
        parameters.push(new param('userId', sqlType.Int, userId));
        parameters.push(new param('organisationId', sqlType.Int, organisationId));
        parameters.push(new param('articleId', sqlType.Int, articleId));
        parameters.push(new param('activityId', sqlType.Int, activityId));

        db_library
            .execute("[IJPS].[AddUserFeedbackQuestion]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.getFeedbackUser = async (userId, articleId, activityId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        parameters.push(new param('userId', sqlType.Int, userId));
        parameters.push(new param('articleId', sqlType.Int, articleId));
        parameters.push(new param('activityId', sqlType.Int, activityId));

        db_library
            .execute("[IJPS].[GetUserFeedbackQuestion]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.getFeedback = async (organisationId, customerId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        parameters.push(new param('organisationId', sqlType.Int, organisationId));
        parameters.push(new param('customerId', sqlType.Int, customerId));

        db_library
            .execute("[IJPS].[GetFeedbackQuestion]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets);
            }).catch(err => {
                reject(err)
            });
    });
}