var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');
let common = require('../../../helpers/common')


exports.get_mail_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[submitactivitymail]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_article_main_file_path = async (ArticleId, OrgId, UserId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('ArticleId', sqlType.Int, ArticleId);
        parameters.push(para);
        para = new param('OrgId', sqlType.Int, OrgId);
        parameters.push(para);
        para = new param('UserId', sqlType.Int, UserId);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticleMainFile]", parameters, db_library.query_type.SP).then((value) => {
                if (value.recordsets[0].length > 0) {
                    let output = {
                        file_path: value.recordsets[0][0].file_path, job_guid: value.recordsets[1][0].job_guid
                        , article_id: value.recordsets[2][0].article_id, base_path: value.recordsets[3][0].base_path
                    }
                    resolve(output);
                }
                else { reject({ "message": "No main file available for this articleId" }) }
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_article_main_file_path_using_Article_GUID = async (ArticleGUID, OrgId, UserId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('ArticleGUID', sqlType.NVarChar, ArticleGUID);
        parameters.push(para);
        para = new param('OrgId', sqlType.Int, OrgId);
        parameters.push(para);
        para = new param('UserId', sqlType.Int, UserId);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticleMainFileUsingGUID]", parameters, db_library.query_type.SP).then((value) => {
                if (value.recordsets[0].length > 0) {
                    let output = {
                        file_path: value.recordsets[0][0].file_path, job_guid: value.recordsets[1][0].job_guid
                        , article_id: value.recordsets[2][0].article_id, base_path: value.recordsets[3][0].base_path
                    }
                    resolve(output);
                }
                else { reject({ "message": "No main file available for this articleId" }) }
            }).catch(err => {
                reject(err)
            });
    });
}

//exports.[IJPS].[GetAutomationFilePaths]




exports.get_journal_type = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getJournalTypedata]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_edit_authors = async (Data) => {
    return await new Promise((resolve, reject) => {

        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditAuthor]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });


    });
}

exports.add_article_detail = async (Data) => {
    return await new Promise((resolve, reject) => {

        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditArticle]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_article_attachment = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditArticleAttch]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}


exports.add_edit_article_coauthor = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditArticleCoAuthor]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_edit_article_conform = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditArticleConform]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_article_keyword = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddEditArticleKeyWords]", parameters, db_library.query_type.SP).then((value) => {
                resolve({ keyword_group: value.recordsets[0], keywords: value.recordsets[1] });
            }).catch(err => {
                reject(err)
            });
    });
}

exports.main_upload_file = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getMainpath]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].input_path);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.supplementary_upload_file = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getsupplementarypath]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].resource_path);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_article_attachment = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getarticleattach]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_author_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getauthordetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_author_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getauthordetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_author_email = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getauthoremail]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_conform_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getconformdetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_coauthor_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getcoauthordetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_salutation_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getsalutationdetail]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_service_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getservicedetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_workflow_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getworkflowdetails]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.Submit_activity = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[Submitactivity]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].record_id);
            }).catch(err => {
                reject(err)
            });
    });
}


exports.get_metadata_details = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('Articleid', sqlType.Int, Data.article_id);
        parameters.push(para);
        para = new param('userid', sqlType.Int, Data.user_id);
        parameters.push(para);
        para = new param('orgid', sqlType.Int, Data.org_id);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetMetadataDetails]", parameters, db_library.query_type.SP).then((value) => {
                let results = value.recordsets[0];
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_article_keywords = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('userid', sqlType.Int, Data.user_id);
        parameters.push(para);
        para = new param('orgid', sqlType.Int, Data.org_id);
        parameters.push(para);
        para = new param('Articleid', sqlType.Int, Data.article_id);
        parameters.push(para);
        para = new param('ArticleGUID', sqlType.Int, Data.article_guid);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetArticleKeywords]", parameters, db_library.query_type.SP).then((value) => {
                resolve({ key_word_groups: value.recordsets[0], key_wordss: value.recordsets[1], article_details: value.recordsets[2] });
            }).catch(err => {
                reject(err)
            });
    });
}

exports.getJobDetails = async (docId, atyId, UserID, OrgID) => {
    try {
        let _parameters = [];
        let para = new param('DocID', sqlType.NVarChar, docId);
        _parameters.push(para);
        para = new param('AtyID', sqlType.Int, atyId);
        _parameters.push(para);
        para = new param('userid', sqlType.Int, UserID);
        _parameters.push(para);
        para = new param('orgid', sqlType.Int, OrgID);
        _parameters.push(para);
        return await db_library.execute_await('[IJPS].[GetJobDetails]', _parameters, db_library.query_type.SP)
    } catch (error) {
        return error;
    }
}
exports.get_article_conform = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getarticleconform]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_nextactivity_detail = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[getnextactivity]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.save_article_history = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[saveArticlehistory]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_suggestionID = async () => {
    return await db_library.execute_await("[IJPS].[GetSuggestionId]", undefined, db_library.query_type.SP);
}

exports.check_automation_status_of_article = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[CheckAutomationStatusOfArticle]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.update_automation_id_to_article = async (Data) => {
    return await new Promise((resolve, reject) => {
        if (Data.id == undefined || Data.id == '') { reject({ "message": "id must be provided." }) }
        else if (Data.article_id == undefined || Data.article_id == '') { reject({ "message": "article_id must be provided." }) }
        else {
            let parameters = [];
            let JsonData = JSON.stringify(Data);
            let para = new param('JsonData', sqlType.NVarChar, JsonData);
            parameters.push(para);
            db_library
                .execute("[IJPS].[UpdateAutomationIdtoArticle]", parameters, db_library.query_type.SP).then((value) => {
                    resolve(true);
                }).catch(err => {
                    reject(err)
                });
        }
    });
}

exports.update_automation_id_to_article_by_article_guid = async (Data) => {
    return await new Promise((resolve, reject) => {
        if (Data.id == undefined || Data.id == '') { reject({ "message": "id must be provided." }) }
        else if (Data.article_guid == undefined || Data.article_guid == '') { reject({ "message": "article_guid must be provided." }) }
        else {
            let parameters = [];
            let JsonData = JSON.stringify(Data);
            let para = new param('JsonData', sqlType.NVarChar, JsonData);
            parameters.push(para);
            db_library
                .execute("[IJPS].[UpdateAutomationIdtoArticleByGUID]", parameters, db_library.query_type.SP).then((value) => {
                    resolve(true);
                }).catch(err => {
                    reject(err)
                });
        }
    });
}

exports.update_article_title_and_abstract = async (title, abstract, article_guid) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('title', sqlType.NVarChar, title);
        parameters.push(para);
        para = new param('abstract', sqlType.NVarChar, abstract);
        parameters.push(para);
        para = new param('article_guid', sqlType.NVarChar, article_guid);
        parameters.push(para);
        db_library
            .execute("[IJPS].[UpdateArticleTitleAndAbstract]", parameters, db_library.query_type.SP).then((value) => {
                resolve(true);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_metadata_from_iAuthor = async (xmlblobpath) => {
    return await new Promise(async (resolve, reject) => {
        let externalApis = require("../config/externalApis")
        let url = externalApis.GetMetaDataFromiAuthor;
        let params = {};
        params.blobpath = xmlblobpath;
        await common.CallPostAPI(url, params)
            .then((value) => {
                resolve(value)
            })
            .catch((err) => {
                reject(err)
            })
    });
}


exports.put_metadata_to_iAuthor = async (params) => {
    return await new Promise(async (resolve, reject) => {
        let externalApis = require("../config/externalApis")
        let url = externalApis.PutMetaDataToiAuthor;
        await common.CallPostAPI(url, params)
            .then((value) => resolve(value)).catch((err) => reject(err))
    });
}


exports.get_article_by_status = async (params, jid = 0) => {
    let parameters = [];
    para = new param('status', sqlType.NVarChar, params);
    parameters.push(para);
    para = new param('journalId', sqlType.Int, jid);
    parameters.push(para);
    return await db_library.execute_await("[IJPS].[GetArticleByStatus]", parameters, db_library.query_type.SP)
}