var sqlType = require('mssql');
const path = require("path");
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');
const _mailOptions = require("../../../helpers/mailOptions");
const _mailer = require("../../../helpers/mailer");
const rsalib = require("../../../helpers/rsalib");
const activity_actions_repo = require('../../irights/repository/activity_actions');
const config = require('../../../../config/env/config.json');
const modeconfig = require('../../../../config/env/env_mode.json');
const ENV_MODE = modeconfig.ENVMODE;
const iPubWebsite = config[ENV_MODE]["iPubWebsite"];

let postAuthorPublisher = async (authorId, authorUserId, publisherId, organisationId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        parameters.push(new param('authorId', sqlType.Int, authorId));
        parameters.push(new param('authorUserId', sqlType.Int, authorId));
        parameters.push(new param('publisherUserId', sqlType.Int, publisherId));
        parameters.push(new param('organisationId', sqlType.Int, organisationId));
        db_library
            .execute("[IJPS].[AddLinkAuthorToPublisher]", parameters, db_library.query_type.SP).then((value) => {
                console.log('AddLinkAuthorToPublisher Response', value.recordsets)
                resolve(value.recordsets);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.postPublisherInviteAuthor = async (userId, organisationId, authorList) => {
    for(let i = 0; i< authorList.length; i++){
        let response = await mailLinkInvitaionToAuthor(authorList[i], organisationId, userId);
        if(i == authorList.length - 1){
            return response;
        }
    }
    
}

var updatePublisherInviteAuthor = async (transactionId, publisherId) => {
    let authorPublisherParams = [
        new param('id', sqlType.Int, transactionId),
        new param('userId', sqlType.Int, publisherId),
    ];
    let response = await db_library.execute_await("[IJPS].[EditPubslisherInviteAuthor]", authorPublisherParams, db_library.query_type.SP);
    return true;
}

exports.getAuthorAcceptInvitaion = async (id) => {
    let authorPublisherParams = [
        new param('id', sqlType.Int, id)
    ];

    let authorPublisherResponse = await db_library.execute_await("[IJPS].[GetPubslisherInviteAuthor]", authorPublisherParams, db_library.query_type.SP);
    console.log('authorPublisherResponse', authorPublisherResponse);
    if(authorPublisherResponse.recordsets.length == 0){
        // input id is invalid
        return false;
    }
    let {emailId, organisationId, publisherId, name, inviteStatus, transactionId} = authorPublisherResponse.recordsets[0][0];
    //author disaggreed our invitation
    if(inviteStatus == 0){
        return await updatePublisherInviteAuthor(transactionId, publisherId);
    }

    //author invitation accepts update 
    let authorAcceptanceResponse = await updatePublisherInviteAuthor(transactionId, publisherId);

    let parameters = [
        new param('emailId', sqlType.NVarChar, emailId),
        new param('organisationId', sqlType.Int, organisationId)
    ];
    let result = await db_library.execute_await("[IJPS].[GetCheckAuthorIsExist]", parameters, db_library.query_type.SP);
    console.log('result', result.recordsets);
    if (result.recordsets[0].length > 0 && result.recordsets[0][0].authorUserId != null && result.recordsets[0][0].authorUserId != undefined) {
        let authorId = result.recordsets[0][0].authorId;
        if(authorId == null || authorId == '' || authorId == undefined){
            let authorParameters = [
                new param('name', sqlType.NVarChar, name),
                new param('emailId', sqlType.NVarChar, emailId),
                new param('role', sqlType.NVarChar, 8),
                new param('userId', sqlType.NVarChar, publisherId),
            ];
            let authorResult = await db_library.execute_await('[IJPS].[AddAuthor]', authorParameters, db_library.query_type.SP);
            authorId = authorResult.recordsets[0][0].authorId;
        }
        return await postAuthorPublisher(authorId, result.recordsets[0][0].authorUserId, publisherId, organisationId)
    }
    else {
        let parameters = [
            new param('UserCode', sqlType.VarChar, emailId),
            new param('UserFName', sqlType.NVarChar, name),
            new param('UserEmailID', sqlType.NVarChar, emailId),
            new param('UpdatedBy', sqlType.Int, 1),
            new param('isInternalUser', sqlType.Bit, false),
            new param('Password', sqlType.NVarChar, 'Password@123'),
            new param('OrgID', sqlType.Int, organisationId),
            new param('OrgDivID', sqlType.Int, 2)
        ];
        let userResult = await db_library.execute_await('[IPS].[AddEditUser]', parameters, db_library.query_type.SP);
        console.log('userResult', userResult);
        if (userResult.recordsets.length > 0) {
            //set user Id after user created
            let userId = userResult.returnValue;
            let roleParameters = [
                new param('UpdaterID', sqlType.Int, 1),
                new param('UserID', sqlType.Int, userId),
                new param('RoleID', sqlType.Int, 8)
            ];
            let roleResult = await db_library.execute_await('[IRS].[AddeditUserRole]', roleParameters, db_library.query_type.SP);
            var options = await activity_actions_repo.get_mail_template(22, userId);
            options.to = emailId
            options.html = options.html.replace('##name##', name)
            options.html = options.html.replace('##loginId##', emailId)
            options.html = options.html.replace('##password##', 'Password@123');
            _mailer.sendMail(options);
            let authorParameters = [
                new param('name', sqlType.NVarChar, name),
                new param('emailId', sqlType.NVarChar, emailId),
                new param('role', sqlType.NVarChar, 8),
                new param('userId', sqlType.NVarChar, publisherId),
            ];
            let authorResult = await db_library.execute_await('[IJPS].[AddAuthor]', authorParameters, db_library.query_type.SP);
            let authorId = authorResult.recordsets[0][0].authorId;
            return await postAuthorPublisher(authorId, userId, publisherId, organisationId);
        }
    }
}


var mailLinkInvitaionToAuthor = async (authorData, organisationId, publisherId) => {
    return await new Promise(async (resolve, reject) => {
        try {

            // let value = await rsalib.encryptString({
            //     "emailId": authorData.emailId,
            //     "name": authorData.name,
            //     "organisationId": organisationId,
            //     "publisherId": publisherId
            // });
            let invitaionLinkUrl = path.join(iPubWebsite, "author");
            let parameters = [];
            parameters.push(new param('emailId', sqlType.NVarChar, authorData.emailId));
            parameters.push(new param('name', sqlType.NVarChar, authorData.name));
            parameters.push(new param('publisherId', sqlType.Int, publisherId));
            parameters.push(new param('organisationId', sqlType.Int, organisationId));
            parameters.push(new param('linkUrl', sqlType.NVarChar, invitaionLinkUrl));
            let response = await db_library.execute_await("[IJPS].[AddPubslisherInvitAuthor]", parameters, db_library.query_type.SP);
            console.log('mail response', response);
            let aggreeLink = response.recordsets[0][0].inviteAcceptUrl;
            let disagreeLink = response.recordsets[0][0].inviteRejectUrl;
            console.log('aggreeLink', aggreeLink);
            console.log('disagreeLink', disagreeLink);
            aggreeLink = `<a href="${aggreeLink}">Click here</a>`;
            disagreeLink = `<a href="${disagreeLink}">Click here</a>`;
            let mailTemplate = await activity_actions_repo.get_mail_template(23, publisherId);
            let mailContent = mailTemplate.html;
            mailContent = mailContent.replace("##name##", authorData.name);
            mailContent = mailContent.replace("##agreelink##", aggreeLink);
            mailContent = mailContent.replace("##disagreelink##", disagreeLink);
            var options = new _mailOptions();
            options.bcc = mailTemplate.bcc;
            options.cc = mailTemplate.cc;
            options.from = mailTemplate.from;
            options.html = mailContent;
            options.subject = mailTemplate.subject;
            options.to = authorData.emailId;
            _mailer.sendMail(options);
            resolve(true);

        } catch (error) {
            reject(error)
        }
    });
}