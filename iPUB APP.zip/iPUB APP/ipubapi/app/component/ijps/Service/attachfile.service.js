var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');

exports.add_attachment_files = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[AddAttachFiles]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.delete_attachment_files = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('userid', sqlType.Int, Data.user_id);
        parameters.push(para);
        para = new param('orgid', sqlType.Int, Data.org_id);
        parameters.push(para);
        para = new param('ArticleGUID', sqlType.NVarChar, Data.ArticleGUID);
        parameters.push(para);
        para = new param('AttachID', sqlType.Int, Data.AttachID);
        parameters.push(para);
        db_library
            .execute("[IJPS].[DeleteAttachmentFiles]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_attachment_files = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('userid', sqlType.Int, Data.user_id);
        parameters.push(para);
        para = new param('orgid', sqlType.Int, Data.org_id);
        parameters.push(para);
        para = new param('ArticleGUID', sqlType.NVarChar, Data.ArticleGUID);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetAttachmentfiles]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_attach_filetoBlob = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetAttachPathBlob]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].resource_path);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_soft_attch_details = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IPS].[Get_Soft_attach_detail]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}