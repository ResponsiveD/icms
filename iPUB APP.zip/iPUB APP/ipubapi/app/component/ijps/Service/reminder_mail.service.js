const db_library = require("../../../../config/lib/db_library");

exports.getReminderMailDetails = async () => {
  return await new Promise((resolve, reject) => {
    db_library
      .execute(`[IJPS].[GetReminderMailDetails]`)
      .then(value => {
        resolve(value);
      })
      .catch(err => {
        reject(err);
      });
  });
}


