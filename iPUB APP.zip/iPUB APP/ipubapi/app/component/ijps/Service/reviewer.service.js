var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');
const activity_actions_repo = require('../../irights/repository/activity_actions');
const _mailer = require("../../../helpers/mailer");
const output = require("../../../models/Output");
const rsalib = require("../../../helpers/rsalib")
const modeconfig = require('../../../../config/env/env_mode.json');
const config = require('../../../../config/env/config.json');
const ENV_MODE = modeconfig.ENVMODE;
const iPubWebsite = config[ENV_MODE]["iPubWebsite"];
const path = require("path")
const article_controller = require("../controllers/article.controller");
const reviewer_service = require("../Service/reviewer.service");


exports.reviewerAcceptInvitation = async (Data) => {
    try {

        if (Data.UserId == 0 || Data.UserId == undefined) {
            let parameters = [];
            let para = new param('UserCode', sqlType.VarChar, Data.email);
            parameters.push(para);
            para = new param('UserFName', sqlType.NVarChar, Data.name);
            parameters.push(para);
            para = new param('UserEmailID', sqlType.NVarChar, Data.email);
            parameters.push(para);
            para = new param('UpdatedBy', sqlType.Int, 1);
            parameters.push(para);
            para = new param('isInternalUser', sqlType.Bit, false);
            parameters.push(para);
            para = new param('Password', sqlType.NVarChar, 'Password@123');
            parameters.push(para);
            para = new param('OrgID', sqlType.Int, 2);
            parameters.push(para);
            para = new param('OrgDivID', sqlType.Int, 2);
            parameters.push(para);
            let result = await db_library.execute_await('[IPS].[AddEditUser]', parameters, db_library.query_type.SP);
            if (result.recordsets.length > 0) {

                //set user Id after user created
                Data.UserId = result.returnValue;
                let roleParameters = [];
                let rolePara = new param('UpdaterID', sqlType.Int, 1);
                roleParameters.push(rolePara);
                rolePara = new param('UserID', sqlType.Int, result.returnValue);
                roleParameters.push(rolePara);
                rolePara = new param('RoleID', sqlType.Int, 8);
                roleParameters.push(rolePara);
                let roleResult = await db_library.execute_await('[IRS].[AddeditUserRole]', roleParameters, db_library.query_type.SP);

                var options = await activity_actions_repo.get_mail_template(22, Data.UserId);
                options.to = Data.email
                options.html = options.html.replace('##name##', Data.name)
                options.html = options.html.replace('##loginId##', Data.email)
                options.html = options.html.replace('##password##', 'Password@123');
                _mailer.sendMail(options);
            }
        }
        return await AcceptOrReject(Data);
    } catch (error) {
        return error
    }
}

var AcceptOrReject = async function (Data) {
    try {
        var _output = new output();

        let _parameters = [];

        let para = new param('userEmail', sqlType.NVarChar, Data.email);
        _parameters.push(para);

        para = new param('articleID', sqlType.Int, Data.article_id);
        _parameters.push(para);

        para = new param('AtyID', sqlType.Int, Data.aty_id);
        _parameters.push(para);

        para = new param('userID', sqlType.Int, Data.UserId);
        _parameters.push(para);

        para = new param('AID', sqlType.Int, Data.Aid);
        _parameters.push(para);

        para = new param('Accept', sqlType.Bit, Data.isAccept);
        _parameters.push(para);

        let result = await db_library.execute_await('[IJPS].[reviewerAcceptOrReject]', _parameters, db_library.query_type.SP)
        if (result.recordsets[0].length > 0) {
            _output.is_success = true;
            _output.message = result.recordsets[0][0].result;
        } else {
            _output.is_success = false;
            _output.message = "Somthing went worng.";
        }
        return _output
    } catch (error) {
        return error
    }
}

exports.get_reviewer_for_article = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        if (Data.article_guid == undefined || Data.article_guid == '') { reject({ message: "article_guid must be provided." }) }
        if (Data.aty_id == undefined || Data.aty_id == '') { reject({ message: "aty_id must be provided." }) }
        else {
            let JsonData = JSON.stringify(Data);
            let para = new param('JsonData', sqlType.NVarChar, JsonData);
            parameters.push(para);
            db_library
                .execute("[IJPS].[getUsersForArticleActivity]", parameters, db_library.query_type.SP).then((value) => {
                    resolve(value.recordsets[0]);
                }).catch(err => {
                    reject(err)
                });
        }
    });
}

var MailLinkToReviewer = async (Data, outData) => {
    return await new Promise(async (resolve, reject) => {
        try {
            const _mailOptions = require("../../../helpers/mailOptions");
            const _mailer = require("../../../helpers/mailer");
            let parameters = [];
            let para = new param('ArticleGUID', sqlType.NVarChar, Data.article_guid);
            parameters.push(para);
            para = new param('UserId', sqlType.Int, Data.user_id);
            parameters.push(para);
            para = new param('NotificationID', sqlType.Int, 8);
            parameters.push(para);
            let mailTemplate = await db_library.execute_await("[IJPS].[GetMailTemplate]", parameters, db_library.query_type.SP);
            if (mailTemplate.recordsets[0].length > 0) {
                mailTemplate = mailTemplate.recordsets[0][0];

                for (let i = 0; i < outData.length; i++) {
                    let aceptlink = '';
                    let rejectlink = '';

                    let parametersLink = [];
                    let paraLink = new param('email', sqlType.NVarChar, outData[i].email_id);
                    parametersLink.push(paraLink);

                    let link = await db_library.execute_await("[IJPS].[getreviewerlink]", parametersLink, db_library.query_type.SP);
                    let linkData = link.recordsets[0]
                    if (linkData.length > 0) {
                        if (linkData[0].Status == 11) {
                            aceptlink = path.join(iPubWebsite, "Review?id=" + linkData[0].Id)
                        } else if (linkData[0].Status == 12) {
                            rejectlink = path.join(iPubWebsite, "Review?id=" + linkData[0].Id)
                        }

                        if (linkData[1].Status == 11) {
                            aceptlink = path.join(iPubWebsite, "Review?id=" + linkData[1].Id)
                        } else if (linkData[1].Status == 12) {
                            rejectlink = path.join(iPubWebsite, "Review?id=" + linkData[1].Id)
                        }
                    }

                    let MailContent = mailTemplate.MailContent
                    MailContent = MailContent.replace("##Reviewername##", outData[i].name)
                    MailContent = MailContent.replace("##date##", outData[i].DueDate)

                    MailContent = MailContent.replace("##Agreed##", aceptlink)
                    MailContent = MailContent.replace("##Declined##", rejectlink)
                    MailContent = MailContent.replace("##AgreedLink##", aceptlink)
                    MailContent = MailContent.replace("##DeclinedLink##", rejectlink)

                    MailContent = MailContent.replace("##articletitle##", outData[i].ArticleTitle)
                    MailContent = MailContent.replace("##author##", outData[i].author)
                    MailContent = MailContent.replace("##abstract##", outData[i].Abstract)

                    var options = new _mailOptions();
                    options.bcc = mailTemplate.BCCMailID;
                    options.cc = mailTemplate.CCMailID;
                    options.from = mailTemplate.FromMailID;
                    options.html = MailContent;
                    options.subject = mailTemplate.Subject;
                    options.to = mailTemplate.ToMailID + ';' + Data.users[i].email_id;
                    _mailer.sendMail(options);
                }
                resolve(true);
            }
        } catch (error) {
            reject(error)
        }
    });
}

exports.addEdit_reviewer_for_article = async (Data) => {
    return await new Promise(async (resolve, reject) => {
        let parameters = [];
        if (Data.article_guid == undefined || Data.article_guid == '') { reject({ message: "article_guid must be provided." }) }
        if (Data.aty_id == undefined || Data.aty_id == '') { reject({ message: "aty_id must be provided." }) }
        if (Data.users == undefined || Data.users == '' || Data.users.length < 1) { reject({ message: "users details must be provided." }) }
        else {
            let JsonData = JSON.stringify(Data);
            // let reviewerLst = await reviewer_service.get_reviewer_for_article(Data)
            // if(reviewerLst == undefined||reviewerLst.length>0)
            // {
            //     article_controller.Submit_activity(Data);
            // }
            let para = new param('JsonData', sqlType.NVarChar, JsonData);
            parameters.push(para);
            db_library
                .execute("[IJPS].[AddEditUsersForArticleActivity]", parameters, db_library.query_type.SP).then(async (value) => {
                    await MailLinkToReviewer(Data, value.recordsets[0]);
                    resolve(value.recordsets[0]);
                }).catch(err => {
                    reject(err)
                });
        }
    });
}

exports.update_reviewer_action = async (Data) => {
    return await new Promise(async (resolve, reject) => {
        try {
            if (Data.article_guid == undefined || Data.article_guid == '') { reject({ message: "article_guid must be provided." }) }
            if (Data.aty_id == undefined || Data.aty_id == '') { reject({ message: "aty_id must be provided." }) }
            if (Data.email_id == undefined || Data.email_id == '') { reject({ message: "email_id must be provided" }) }
            if (Data.is_rejected == undefined || Data.is_rejected == '') { reject({ message: "is_rejected must be provided" }) }
            if (Data.is_accepted == undefined || Data.is_accepted == '') { reject({ message: "is_accepted must be provided" }) }
            else {
                let parameters = [];
                let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(Data));
                parameters.push(para);
                let result = await db_library("[IJPS].[UpdateReviewerAction]", parameters, db_library.query_type.SP)
                resolve(true);
            }
        } catch (error) {
            reject(error);
        }
    });
}

exports.add_sugg_comment = async (Data) => {
    return await new Promise((resolve, reject) => {
        try {
            if (Data.ArticleGUID == undefined || Data.ArticleGUID == '') {
                reject({
                    message: "ArticleGUID must be provided."
                })
            }
            else if (Data.activity_id == undefined || Data.activity_id == '') {
                reject({
                    message: "activity_id must be provided."
                })
            } else {
                let parameters = [];
                let JsonData = JSON.stringify(Data);
                let para = new param('JsonData', sqlType.NVarChar, JsonData);
                parameters.push(para);
                db_library
                    .execute("[IJPS].[AddSuggComment]", parameters, db_library.query_type.SP).then((value) => {
                        resolve(value.recordsets[0]);
                    }).catch(err => {
                        reject(err)
                    });
            }
        } catch (error) {
            reject(error)
        }
    });
}

exports.get_sugg_comment = async (Data) => {
    return await new Promise((resolve, reject) => {
        if (Data.ArticleGUID == undefined || Data.ArticleGUID <= 0) {
            reject({
                message: 'ArticleGUID must be provided'
            })
        } else {
            let parameters = [];
            let para = new param('UserID', sqlType.Int, Data.user_id);
            parameters.push(para);
            para = new param('OrgID', sqlType.Int, Data.org_id);
            parameters.push(para);
            para = new param('ArticleGUID', sqlType.NVarChar, Data.ArticleGUID);
            parameters.push(para);
            para = new param('activity_id', sqlType.Int, Data.activity_id);
            parameters.push(para);
            db_library
                .execute("[IJPS].[GetSuggComment]", parameters, db_library.query_type.SP).then((value) => {
                    let results = {
                        suggestion: value.recordsets[0],
                        comment: value.recordsets[1]
                    };
                    resolve(results);
                }).catch(err => {
                    reject(err)
                });
        }
    });
}

exports.getInvitationDetails = async (id) => {
    try {
        let parameters = [];
        let para = new param('id', sqlType.Int, id);
        parameters.push(para);
        return db_library.execute_await("[IJPS].[getInvitationDetails]", parameters, db_library.query_type.SP);
    } catch (e) {
        return e;
    }
}
