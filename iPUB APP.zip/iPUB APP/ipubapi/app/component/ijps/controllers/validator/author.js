const { check } = require('express-validator/check');

module.exports.postPublisherInviteAuthor = [
    // author is required
    check('author').exists()
];