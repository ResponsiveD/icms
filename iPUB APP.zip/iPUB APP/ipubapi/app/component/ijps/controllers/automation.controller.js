
const automation_repository = require("../../../repository/automation.service");
const output = require("../../../models/Output");
const common = require("../../../helpers/common")
const article_service = require("../Service/article.service");


exports.word_to_xml_automation_entry = async function (req, res, next) {
    var _output = new output();
    try {
        let data = req.body;
        data = await common.getTokenUserDetail(req, data);
        data.automation_id = 1
        if (data.article_guid == undefined || data.article_guid == '') { throw { "message": "article_guid must be provided." } }
        else {
            let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
            data.article_id = input.article_id;
            let uniqueFolder = common.guid();
            data.in_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/input.zip';
            data.out_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/output.zip';
            const path = require('path');
            let ext = path.extname(input.file_path);
            input.xmlpath = input.file_path.split('/').slice(1).join('/').replace(ext, '.xml')
            input.resourcePath = path.join(input.file_path.split('/').slice(1, 6).join('/'), 'Resources')
            let output = automation_repository.createiAMetaForIpubsuite(input)
            let files = [];
            files.push({ "file_content": output.XMLContent, "file_name": "JobInfo.xml" })
            input.files = files
            input.file_paths = []
            input.file_paths.push(input.file_path)
            let FileuploadedPath = await automation_repository.add_blob_to_zip_stream(input, data.in_path)
            data.file_name = path.basename(input.file_path)
            let result = await automation_repository.add_automation_entry(data);
            data.id = result;
            await article_service.update_automation_id_to_article(data);
            _output.data = data;
            _output.is_success = true;
            _output.message = "Automation entry updated";
        }
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}

exports.iCoreToXML = async function (req, res, next) {
    var _output = new output();
    try {
        let data = req.body;
        data = await common.getTokenUserDetail(req, data);
        data.automation_id = 2
        if (data.article_guid == undefined || data.article_guid == '') { throw { "message": "article_guid must be provided." } }
        else {
            let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
            let uniqueFolder = common.guid();
            data.in_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/input.zip';
            data.out_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/output.zip';
            const path = require('path');
            let ext = path.extname(input.file_path);
            input.file_path = input.file_path.replace(ext, '.xml')
            input.xmlpath = input.file_path.replace("Input", "Output").split('/').slice(1).join('/').replace(ext, '.xml')
            input.resourcePath = path.join(input.file_path.split('/').slice(1, 6).join('/'), 'Resources')
            let output = automation_repository.createiAMetaForIpubsuite(input)
            let files = [];
            files.push({ "file_content": output.XMLContent, "file_name": "JobInfo.xml" })
            input.files = files
            input.file_paths = []
            input.file_paths.push(input.file_path)
            let FileuploadedPath = await automation_repository.add_blob_to_zip_stream(input, data.in_path)
            data.file_name = path.basename(input.file_path)
            let result = await automation_repository.add_automation_entry(data);
            data.id = result;
            await article_service.update_automation_id_to_article_by_article_guid(data);
            _output.data = data;
            _output.is_success = true;
            _output.message = "Automation entry updated";
        }
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}

exports.iCoreToPDF = async function (req, res, next) {
    var _output = new output();
    try {
        let data = req.body;
        data = await common.getTokenUserDetail(req, data);
        data.automation_id = 3
        if (data.article_guid == undefined || data.article_guid == '') { throw { "message": "article_guid must be provided." } }
        else {
            let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
            let uniqueFolder = common.guid();
            data.in_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/input.zip';
            data.out_path = input.file_path.split('/')[1] + '/' +
                input.job_guid + '/Engine/In/' +
                uniqueFolder + '/output.zip';
            const path = require('path');
            let ext = path.extname(input.file_path);
            input.file_path = input.file_path.replace(ext, '.xml')
            input.xmlpath = input.file_path.replace("Input", "Output").split('/').slice(1).join('/').replace(ext, '.xml')
            input.pdfpath = input.file_path.replace("Input", "Output").split('/').slice(1).join('/').replace(ext, '.pdf')
            input.resourcePath = path.join(input.file_path.split('/').slice(1, 6).join('/'), 'Resources')
            let output = automation_repository.createiAMetaForIpubsuite(input)
            let files = [];
            files.push({ "file_content": output.XMLContent, "file_name": "JobInfo.xml" })
            input.files = files
            input.file_paths = []
            input.file_paths.push(input.file_path)
            let FileuploadedPath = await automation_repository.add_blob_to_zip_stream(input, data.in_path)
            data.file_name = path.basename(input.file_path)
            let result = await automation_repository.add_automation_entry(data);
            data.id = result;
            await article_service.update_automation_id_to_article_by_article_guid(data);
            _output.data = data;
            _output.is_success = true;
            _output.message = "Automation entry updated";
        }
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}

exports.get_metadata_from_iAuthor = async function (req, res, next) {
    var _output = new output();
    try {
        let data = req.body;
        data = await common.getTokenUserDetail(req, data);
        if (data.article_guid == undefined || data.article_guid == '') { throw { "message": "article_guid must be provided." } }
        else {
            let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
            const path = require('path');
            let ext = path.extname(input.file_path);
            let file_path = input.file_path.split('/').slice(1).join('/').replace(ext, '.xml')
            let output = await article_service.get_metadata_from_iAuthor(file_path);
            output = JSON.parse(output);
            let Result = [];
            if (output.isSuccess == true) {
                output = output.result;
                let title = '';
                let abstract = '';
                let key_word_groups = [];
                title = await article_title(output);
                abstract = await article_abstract(output);
                await article_service.update_article_title_and_abstract(title, abstract, data.article_guid)
                let Data = {};
                Data.key_word_groups = await article_kewwords(output);
                Data.user_id = data.user_id;
                Data.article_id = data.article_id
                Data.org_id = data.org_id
                Data.article_guid = data.article_guid
                Result = await article_service.add_article_keyword(Data);
                _output.data = Result;
                _output.is_success = true;
                _output.message = "Metadata from iAuthor.";
            }
            else {
                throw { message: 'Received error from iAuthor while requesting metadata.' }
            }
        }
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}

var article_abstract = function (output) {
    return new Promise((resolve, reject) => {
        let abstract = ''
        if (output.objAbstract.isAbstractAvailable == true) {
            for (let i = 0; i < output.objAbstract.AbstractInnerHTMLArray.length; i++) {
                abstract = abstract + output.objAbstract.AbstractInnerHTMLArray[i].Content
                if (i == output.objAbstract.AbstractInnerHTMLArray.length - 1) {
                    resolve(abstract)
                }
            }
        }
        else {
            resolve(abstract)
        }
    });
}


var article_title = function (output) {
    return new Promise((resolve, reject) => {
        let title = ''
        if (output.objTitle.isTitleAvailable == true) {
            title = output.objTitle.TitleInnerHTMLArray[0].Content
            resolve(title);
        }
        else {
            resolve(title);
        }
    });
}

var article_kewwords = function (output) {
    return new Promise((resolve, reject) => {
        if (output.objKeyWord.isKeywordAvailable == true) {
            let key_word_groups = [];
            if (output.objKeyWord.keyWordInnerHTMLArray.length > 0) {
                for (let i = 0; i < output.objKeyWord.keyWordInnerHTMLArray.length; i++) {
                    let key_word_group = {}
                    key_word_group.key_word_group_id = 0;
                    key_word_group.key_word_group_name = output.objKeyWord.keyWordInnerHTMLArray[i].kwdg_title;
                    key_word_group.is_active = 1;
                    key_word_group.key_words = [];
                    for (let j = 0; j < output.objKeyWord.keyWordInnerHTMLArray[i].keys.length; j++) {
                        let key = {}
                        key.key_word_id = 0;
                        key.key_word = output.objKeyWord.keyWordInnerHTMLArray[i].keys[j].kwd
                        key.is_active = 1
                        key_word_group.key_words.push(key);
                    }
                    key_word_groups.push(key_word_group);
                    if (i == output.objKeyWord.keyWordInnerHTMLArray.length - 1) { resolve(key_word_groups); }
                }
            }
            else {
                resolve(key_word_groups)
            }
        }
        else {
            reject({ message: 'Keyword is not available' })
        }
    });
}


exports.put_metadata_to_iAuthor = async function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        data = await common.getTokenUserDetail(req, data);
        data.article_guid = req.query.article_guid;
        if (data.article_guid == undefined || data.article_guid == '') { throw { "message": "article_guid must be provided." } }
        else {
            let input = await article_service.get_article_main_file_path_using_Article_GUID(data.article_guid, data.org_id, data.user_id)
            const path = require('path');
            let ext = path.extname(input.file_path);
            let file_path = input.file_path.split('/').slice(1).join('/').replace(ext, '.html')
            let Result = {};
            Result.key_word_groups = [];
            Result.article_guid = data.article_guid
            let output = await article_service.get_article_keywords(data);
            let rst = {};
            rst.objTitle = output.article_details.objTitle
            rst.objAbstract = output.article_details.objAbstract
            rst.htmlPath = file_path;
            rst.objKeyWord = []
            if (output.key_word_groups != undefined && output.key_word_groups.length > 0) {
                for (let i = 0; i < output.key_word_groups.length; i++) {
                    const _ = require("lodash");
                    let _out = {};
                    _out.kwdg_title = output.key_word_groups[i].key_word_group_name
                    _out.keys = _.filter(output.key_words, ['key_word_group_id', _out.key_word_group_id]).forEach(ele => {
                        ele.kwdtxt = ele.Key_word
                        delete ele.Key_word
                    })
                    rst.objKeyWord.push(_out);
                    if (i == output.key_word_groups.length - 1) {
                        _output.data = rst;
                        _output.is_success = true;
                        _output.message = "Getting Article Keywords";
                        let output = await article_service.put_metadata_to_iAuthor(rst);
                        res.send(output);
                    }
                }
            } else {
                _output.data = rst;
                _output.is_success = true;
                _output.message = "Getting Article Keywords";
                let output = await article_service.put_metadata_to_iAuthor(rst);
                res.send(output);
            }
        }
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
        res.send(_output);
    }
}