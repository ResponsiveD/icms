'use strict'
const reviewer_service = require("../Service/reviewer.service");
const article_controller = require("../controllers/article.controller");
const output = require("../../../models/Output");
const common = require("../../../helpers/common");
const rasLib = require("../../../helpers/rsalib");
const HttpStatus = require('http-status-codes');
const article_service = require("../Service/article.service");


exports.reviewerAcceptOrReject = async function (req, res, next) {
  var _output = new output();
  try {
    if (req.query.id) {
      let invitataton = await reviewer_service.getInvitationDetails(req.query.id);
      if (invitataton.recordsets[0].length > 0) {
        let data = invitataton.recordsets[0][0];
        if (data.isAccepted == 0) {
          // let reviewerLst = await reviewer_service.get_reviewer_for_article(data)
          // if (reviewerLst == undefined || reviewerLst.length < 1) {
          // await article_controller.Submit_activitys(req, res, next);
          // }
          req.User = {}
          req.User.UserID = 1;
          req.User.OrgID = 2;
          req.body.aty_id = data.aty_id;
          req.body.article_guid = data.article_guid;
          data.aty_id = data.aty_id;
          await Submit_activitys(req);
          data.aty_id = 23;
          _output = await reviewer_service.reviewerAcceptInvitation(data);
        } else {
          _output.is_success = false;
          _output.message = "This Article already assigned";
        }
      } else {
        _output.is_success = false;
        _output.message = "Invalide Id";
      }
    } else {
      _output.is_success = false;
      _output.message = "Id not fount";
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_reviewer_for_article = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let result = await reviewer_service.get_reviewer_for_article(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Reviewer details.";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
  }
  res.send(_output);
}


var Submit_activitys = async function (req) {
  return new Promise(async (resolve, reject) => {
    var _output = new output();
    try {
      let data = {};
      data = req.body;
      data = await common.getTokenUserDetail(req, data);
      let submitstatus = await article_service.Submit_activity(data);
      let getmaildetails = await article_service.get_mail_detail(data);
      if (req.body.aty_id > 0) {
        let getnextactivity = await article_service.get_nextactivity_detail(data);
        if (getnextactivity.nxtaty > 0 && getnextactivity.status == 1) {
          let getfilepath = await common.ListAllFilesPath(getnextactivity.path);
          let moveddata = await common.Listdatamovetodest(getfilepath, getnextactivity.curtaty, getnextactivity.nxtaty);
          let getdata = await common.get_blob_data(getnextactivity.pathhis);
          let final = await common.BlobUpload(getnextactivity.pathatlin, getdata, getdata.length);
        }
        //let getmaildetails = await article_service.get_mail_detail(data);
        if (!(getmaildetails == undefined || getmaildetails.content == undefined || getmaildetails.content == '')) {
          const _mailOptions = require("../../../helpers/mailOptions");
          var options = new _mailOptions();
          options.from = getmaildetails.fromid;
          options.to = getmaildetails.toid;
          options.cc = "";
          options.bcc = getmaildetails.bcc;
          options.html = getmaildetails.content;
          options.subject = getmaildetails.subject;
          let mail = await mailer.sendMail(options);
          resolve(true);
        } else {
          resolve(true);
        }
      } else {
        reject({
          "message": "Aty_id must be provided."
        })
      }
    } catch (error) {
      reject(error)
    }
  });
}


exports.addEdit_reviewer_for_article = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    let JsonData = JSON.stringify(data);
    let reviewerLst = await reviewer_service.get_reviewer_for_article(data)
    if (reviewerLst == undefined || reviewerLst.length == 0) {
      await Submit_activitys(req);
    }
    data = await common.getTokenUserDetail(req, data);
    let result = await reviewer_service.addEdit_reviewer_for_article(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Reviewer details updated.";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
  }
  res.send(_output);
}

exports.update_reviewer_action = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let result = await reviewer_service.update_reviewer_action(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Reviewer action updated.";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
  }
  res.send(_output);
}

exports.add_sugg_comment = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await reviewer_service.add_sugg_comment(data);
    _output.is_success = true;
    _output.message = "Successfully updated Suggestion and Comment";
    let submitData = [];
    submitData.body = data;
    let submitstatus = article_controller.Submit_activitys(submitData);
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_sugg_comment = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.ArticleGUID = req.query.ArticleGUID;
    data.activity_id = req.query.activity_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await reviewer_service.get_sugg_comment(data);
    _output.is_success = true;
    _output.message = "Getting Suggestion and comment";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}