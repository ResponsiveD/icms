'use strict'
const article_service = require("../Service/article.service");
const exception_repo = require("../../../middleware/exception/exception");
const output = require("../../../models/Output");
const common = require("../../../helpers/common");
const mailer = require("../../../helpers/mailer");
const HttpStatus = require('http-status-codes');
const loginService_repo = require('../../../repository/login.service');

exports.get_journal_type_value = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.cust_id = req.query.cust_id;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID     
    _output.data = await article_service.get_journal_type(data);
    _output.is_success = true;
    _output.message = "Getting journal type Successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.add_edit_author = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.add_edit_authors(data);
    _output.is_success = true;
    _output.message = "co-author updated Successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.add_article_details = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.add_article_detail(data);
    _output.is_success = true;
    _output.message = "Article updated successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.add_article_attachments = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.add_article_attachment(data);
    if (req.body.files.length > 0) {
      for (let index = 0; index < req.body.files.length; index++) {
        const element = req.body.files[index];
        if (element.is_active != true) {
          let filePath = element.path.split('/').splice(4).join('/');
          let result = await common.get_blob_data(filePath);
          await common.BlobDelete(filePath, result, result.length);
        }
      }
    }
    _output.is_success = true;
    _output.message = "Article attachment updated successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.add_edit_article_coauthors = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.add_edit_article_coauthor(data);
    _output.is_success = true;
    _output.message = "Article co-author updated Successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.add_edit_article_conforms = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.add_edit_article_conform(data);
    _output.is_success = true;
    _output.message = "Article conforms successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.add_article_keywords = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let output = await article_service.add_article_keyword(data);
    let Result = {};
    Result.key_word_groups = [];
    Result.article_id = data.article_id
    if (output.keyword_group == undefined) {
      throw ({ "message": "check input" });
    }
    for (let i = 0; i < output.keyword_group.length; i++) {
      const _ = require("lodash");
      let _out = {};
      _out.key_word_group_id = output.keyword_group[i].key_word_group_id
      _out.key_word_group_name = output.keyword_group[i].key_word_group_name
      _out.is_active = 1
      _out.key_words = _.filter(output.keywords, ['key_word_group_id', _out.key_word_group_id])
      Result.key_word_groups.push(_out);
      if (i == output.keyword_group.length - 1) {
        _output.data = Result;
        _output.is_success = true;
        _output.message = "Article keywords updated successfully";
        res.send(_output);
      }
    }
  }
  catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    res.send(_output);
  }

}

exports.main_upload_files = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let file = req.files["file"];
    data.filename = file.name;
    let path = await article_service.main_upload_file(data);
    _output.data = { "path": await common.blobFileUpload(file, path), "size": common.bytesToSize(file.data.length) }
    _output.is_success = true;
    _output.message = "File uploaded successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);

}

exports.supplementary_upload_files = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let file = req.files["file"];
    data.filename = file.name;
    let path = await article_service.supplementary_upload_file(data);
    _output.data = { "path": await common.blobFileUpload(file, path), "size": common.bytesToSize(file.data.length) }
    _output.is_success = true;
    _output.message = "File uploaded successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);

}

exports.get_article_attachments = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_article_attachment(data);
    _output.is_success = true;
    _output.message = "Getting article attachments successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_author_details = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.author_id = req.query.author_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_author_detail(data);
    _output.is_success = true;
    _output.message = "Getting author details successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_author_emails = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_author_email(data);
    _output.is_success = true;
    _output.message = "Getting author Emails successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_conform_details = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.cust_id = req.query.cust_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_conform_detail(data);
    _output.is_success = true;
    _output.message = "Getting Conform Details successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_coauthor_details = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_coauthor_detail(data);
    _output.is_success = true;
    _output.message = "Getting coauthor Details Successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_salutation_details = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_salutation_detail(data);
    _output.is_success = true;
    _output.message = "Getting salutation Details Successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_service_details = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.comp_id = 2;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_service_detail(data);
    _output.is_success = true;
    _output.message = "Getting Service Details Successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_workflow_details = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.ser_id = req.query.ser_id;
    data = await common.getTokenUserDetail(req, data);
    _output.data = await article_service.get_workflow_detail(data);
    _output.is_success = true;
    _output.message = "Getting Workflow Details Successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.Submit_activitys = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let submitstatus = await article_service.Submit_activity(data);
    let getmaildetails = await article_service.get_mail_detail(data);
    if (req.body.aty_id > 0) {
      let getnextactivity = await article_service.get_nextactivity_detail(data);
      if (getnextactivity.nxtaty > 0 && getnextactivity.status == 1) {
        let getfilepath = await common.ListAllFilesPath(getnextactivity.path);
        let moveddata = await common.Listdatamovetodest(getfilepath, getnextactivity.curtaty, getnextactivity.nxtaty);
        let getdata = await common.get_blob_data(getnextactivity.pathhis);
        let final = await common.BlobUpload(getnextactivity.pathatlin, getdata, getdata.length);
      }
      //let getmaildetails = await article_service.get_mail_detail(data);
      if (!(getmaildetails == undefined || getmaildetails.content == undefined || getmaildetails.content == '')) {
        const _mailOptions = require("../../../helpers/mailOptions");
        var options = new _mailOptions();
        options.from = getmaildetails.fromid;
        options.to = getmaildetails.toid;
        options.cc = "";
        options.bcc = getmaildetails.bcc;
        options.html = getmaildetails.content;
        options.subject = getmaildetails.subject;
        let mail = await mailer.sendMail(options);
        _output.data = { "Notify": getmaildetails.notify }
      }
      else {
        _output.data = { "Notify": "Success." }
      }
    }
    _output.data = { "Notify": getmaildetails.notify }
    _output.is_success = true;
    _output.message = "Submit activity completed Successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_metadata_details = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID     
    _output.data = await article_service.get_metadata_details(data);
    _output.is_success = true;
    _output.message = "Getting Metadata Details";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_article_keywords = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID    
    let Result = {};
    Result.key_word_groups = [];
    Result.article_id = data.article_id
    let output = await article_service.get_article_keywords(data);
    if (output.key_word_groups != undefined && output.key_word_groups.length > 0) {
      for (let i = 0; i < output.key_word_groups.length; i++) {
        const _ = require("lodash");
        let _out = {};
        _out.key_word_group_id = output.key_word_groups[i].key_word_group_id
        _out.key_word_group_name = output.key_word_groups[i].key_word_group_name
        _out.is_active = 1
        _out.key_words = _.filter(output.key_words, ['key_word_group_id', _out.key_word_group_id])
        Result.key_word_groups.push(_out);
        if (i == output.key_word_groups.length - 1) {
          _output.data = Result;
          _output.is_success = true;
          _output.message = "Getting Article Keywords";
          res.send(_output);
        }
      }
    } else {
      _output.data = [];
      _output.is_success = true;
      _output.message = "Getting Article Keywords";
      res.send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    res.send(_output);
  }
}

exports.get_article_conforms = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID     
    _output.data = await article_service.get_article_conform(data);
    _output.is_success = true;
    _output.message = "Getting Article conforms";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.getJobDetails = async function (req, res, next) {
  let _output = new output();
  try {
    let result = await article_service.getJobDetails(req.query.docid, req.query.atyid, req.User.UserID, req.User.OrgID);
    if (result.recordset.length > 0) {
      res.status(HttpStatus.OK);
      let resultObject = {}
      let name = Object.keys(result.recordset[0])[0]; // Get the first item of the list;  = key name
      let JsonData = result.recordset[0][name];
      if (JsonData != '' && JsonData != undefined) {
        resultObject['sMessage'] = "Content Found for GUID : " + req.query.docid;
        resultObject['is_success'] = true;
        let resultarray = JSON.parse(JsonData);
        resultObject['oData'] = resultarray[0];
      } else {
        resultObject['sMessage'] = "Content not found for GUID : " + req.query.docid;
        resultObject['oData'] = JsonData;
        resultObject['is_success'] = false;
      }

      res.send(resultObject);
    } else {
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send();
    }
  } catch (error) {
    await exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.query), error);
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    res.status(HttpStatus.INTERNAL_SERVER_ERROR).send(_output);
  }
}

exports.save_article_historys = async function (req, res, next) {
  let _output = new output();
  try {
    let data = {};
    data = req.body;
    data = await common.getTokenUserDetail(req, data);
    let histguid = await article_service.save_article_history(data);
    if (histguid.status == 'true') {
      res.status(HttpStatus.OK);
      let blobdata = {};
      blobdata.byte = req.body.htmlcontent
      blobdata.path = histguid.Path_History;
      _output.data = await common.blobByteUpload(blobdata);
      _output.is_success = true;
      _output.message = "Saved Successfully";

    } else {
      _output.data =
        _output.is_success = false;
      _output.message = "Not saved Successfully";
    }
  } catch (error) {
    await exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.query), error);
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.getSuggestionId = async function (req, res, next) {
  var _output = new output();
  try {
    let result = await article_service.get_suggestionID();
    if (result.recordset.length > 0) {
      _output.data = result.recordset;
      _output.is_success = true;
      _output.message = "Suggestion List";
      res.status(HttpStatus.OK).send(_output);
    } else {
      _output.is_success = true;
      _output.message = "Result not found";
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }

  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    res.status(HttpStatus.INTERNAL_SERVER_ERROR).send(_output);
  }
}

exports.check_automation_status_of_article = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.article_id = req.query.article_id;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID     
    _output.data = await article_service.check_automation_status_of_article(data);
    _output.is_success = true;
    _output.message = "article word to icore xml conversion status.";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_article_keywords_for_iAuthor = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data.article_guid = req.query.article_guid;
    data = await common.getTokenUserDetail(req, data);
    //req.User.UserID    
    let Result = {};
    Result.key_word_groups = [];
    Result.article_guid = data.article_guid
    let output = await article_service.get_article_keywords(data);
    let rst = {};
    rst.objTitle = output.article_details.objTitle
    rst.objAbstract = output.article_details.objAbstract
    rst.objKeyWord = []
    if (output.key_word_groups != undefined && output.key_word_groups.length > 0) {
      for (let i = 0; i < output.key_word_groups.length; i++) {
        const _ = require("lodash");
        let _out = {};
        _out.kwdg_title = output.key_word_groups[i].key_word_group_name
        _out.keys = _.filter(output.key_words, ['key_word_group_id', _out.key_word_group_id]).forEach(ele => {
          ele.kwdtxt = ele.Key_word
          delete ele.Key_word
        })
        rst.objKeyWord.push(_out);
        if (i == output.key_word_groups.length - 1) {
          _output.data = rst;
          _output.is_success = true;
          _output.message = "Getting Article Keywords";
          res.send(_output);
        }
      }
    } else {
      _output.data = rst;
      _output.is_success = true;
      _output.message = "Getting Article Keywords";
      res.send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    await exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.query), error);
    res.status(HttpStatus.INTERNAL_SERVER_ERROR).send(_output);
  }
}


exports.get_article_by_status = async function (req, res, next) {
  var _output = new output();
  try {
    let IDs = ''
    if (req.query.id != undefined) {

      if (req.query.id.length > 0) {
        let id_array = req.query.id;
        for (var k in id_array) {
          if (id_array.hasOwnProperty(k)) {
            if (k != 0) {
              IDs = IDs + ',' + id_array[k];
            } else {
              IDs = id_array[k];
            }
          }
        }
      } else {
        IDs = req.query.id
      }
    } else {
      IDs = 0
    }

    let result = await article_service.get_article_by_status(IDs,req.query.jid);
    if (result.recordset.length > 0) {
      _output.data = result.recordset;
      _output.is_success = true;
      _output.message = "Article List";
      res.status(HttpStatus.OK).send(_output);
    } else {
      _output.is_success = false;
      _output.message = "Somthing went worng";
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }

  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    await exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.query), error);
    res.status(HttpStatus.INTERNAL_SERVER_ERROR).send(_output);
  }
}

exports.getMetaJobDetails = async function (req, res, next) {
  var _output = new output();
  try {
    let docDetails = await loginService_repo.getDocDeailsByDocID(req.query.docid);
    if (docDetails.recordset.length > 0) {
      _output.data = docDetails.recordset[0];
      _output.is_success = true;
      _output.message = "Doc ID is found.";
      res.status(HttpStatus.OK).send(_output);
    } else {
      _output.is_success = false;
      _output.message = "Doc ID is not found.";
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(_output);
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
    res.send(_output);
  }
}