const output = require("../../../models/Output");
//Repository
const get_dashboard_iopp_repo = require("../Service/dashboard.iopp");

exports.get_dashboard_publisher = async function (req, res, next) {
    var _output = new output();
    try {
        let user_id = req.User.UserID;
        let result = await get_dashboard_iopp_repo.get_dashboard_publisher(user_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Get Dashboard Publisher";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}

exports.get_dashboard_auth_rev = async function (req, res, next) {
    var _output = new output();
    try {
        let user_id = req.User.UserID;
        let result = await get_dashboard_iopp_repo.get_dashboard_auth_rev(user_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Get Dashboard Author Reviewer";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}