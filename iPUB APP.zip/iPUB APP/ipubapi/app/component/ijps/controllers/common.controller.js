'use strict'
const common_service = require("../Service/common.service");
const output = require("../../../models/Output");

exports.get_country_details = async function (req, res, next) {
    var _output = new output();
    try {
      let result = await common_service.get_country_detail();
      _output.data = result;
      _output.is_success = true;
      _output.message = "Customer Country Details";
    } catch (error) {
      _output.data = "";
      _output.is_success = false;
      _output.message = error.message;
    }
    res.send(_output);
  }

  exports.get_state_details = async function (req, res, next) {
    var _output = new output();
    try {
      let country_id = req.query.country_id;
      let result = await common_service.get_state_details(country_id);
      _output.data = result;
      _output.is_success = true;
      _output.message = "Customer State Details";
    } catch (error) {
      _output.data = "";
      _output.is_success = false;
      _output.message = error.message;
    }
    res.send(_output);
  }

  exports.get_city_details = async function (req, res, next) {
    var _output = new output();
    try {
      let state_id = req.query.state_id;
      let result = await common_service.get_city_details(state_id);
      _output.data = result;
      _output.is_success = true;
      _output.message = "Customer City Details";
    } catch (error) {
      _output.data = "";
      _output.is_success = false;
      _output.message = error.message;
    }
    res.send(_output);
  }