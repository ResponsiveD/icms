const file_upload = require('../../../helpers/common');
const exception_repo = require('../../../middleware/exception/exception')
const output = require("../../../models/Output");

exports.file_byteupload = async function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        data.byte = req.body.byte
        data.path = req.body.path;
        let result = await file_upload.blobByteUpload(data);
        _output.data = { Path: result };
        _output.is_success = true;
        _output.message = "File Uploaded in blob";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
        await exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.body), error);
    }
    res.send(_output);
}

exports.file_blob_moves = async function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        data.start = req.body.start
        data.dest = req.body.dest;
        let result = await file_upload.get_blob_data(data.start);
        let final = await file_upload.BlobUpload(data.dest, result, result.length);
        _output.data = { Path: final };
        _output.is_success = true;
        _output.message = "File Uploaded in blob";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
    }
    res.send(_output);
}

exports.file_blob_delete = async function (req, res, next) {
    var _output = new output();
    try {
        const filePath = req.body.file_path;
        let result = await file_upload.get_blob_data(filePath);
        let final = await file_upload.BlobDelete(filePath, result, result.length);
        _output.data = { Path: final };
        _output.is_success = true;
        _output.message = "File deleted from blob storage";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
    }
    res.send(_output);
}

exports.ListAllFilesInPaths = async function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        data.path = req.body.path
        let final = await file_upload.ListAllFilesPath(data.path);
        _output.data = { Path: final };
        _output.is_success = true;
        _output.message = "File Uploaded in blob";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
    }
    res.send(_output);
}

exports.get_blob_datas = async function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        data.start = req.body.path
        let result = await file_upload.get_blob_data(data.start);
        _output.data = result;
        _output.is_success = true;
        _output.message = "getting file in blob successfully";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error;
    }
    res.send(_output);
}

