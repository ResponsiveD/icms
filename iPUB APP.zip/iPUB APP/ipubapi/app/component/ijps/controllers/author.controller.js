const httpStatus = require('http-status-codes');
const { check, validationResult } = require('express-validator/check');

const authorService = require("../Service/author.service");
const output = require("../../../models/Output");
const common = require("../../../helpers/common");
const rsalib = require("../../../helpers/rsalib");

exports.postPublisherInviteAuthor = async function (req, res, next) {
    // Finds the validation errors in this request and wraps them in an object with handy functions
    const errors = validationResult(req);
    var _output = new output();
    if (!errors.isEmpty()) {
        _output.data = "";
        _output.is_success = false;
        _output.message = errors.array();
        res.send(_output);
    }

    try {
        let authorList = []
        let userId = req.User.UserID;
        let organisationId = req.User.OrgID;
        let { author } = req.body;
        if (author.length > 0) {
            author.map((a) => {
                authorList.push({ "emailId": a.emailId, "name": a.name });
            });
        }

        let result = await authorService.postPublisherInviteAuthor(userId, organisationId, authorList);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Authors invited successfully.";
    }
    catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}

exports.getAuthorAcceptInvitaion = async function(req, res, next){
    // Finds the validation errors in this request and wraps them in an object with handy functions
    const errors = validationResult(req);
    var _output = new output();
    if (!errors.isEmpty()) {
        _output.data = "";
        _output.is_success = false;
        _output.message = errors.array();
        res.send(_output);
    }

    try {
        // let authorChiperText = req.query.id;
        // let authorPlainText = await rsalib.decryptString(authorChiperText);
        // let authorData = JSON.parse(authorPlainText);
        // console.log('authorData', authorData);
        // let { organisationId, publisherId, emailId, name } = authorData;

        let result = await authorService.getAuthorAcceptInvitaion(req.query.id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Author invited successfully.";
    }
    catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}