const getReminderMailService = require("../Service/reminder_mail.service");
const _mailOptions = require("../../../helpers/mailOptions");
const _mailer = require("../../../helpers/mailer");

exports.getReminderMailDetails = async (req, res, next) => {
  try {
    let finalReminderResult = await getReminderMailService.getReminderMailDetails();
    if (finalReminderResult.recordset != 0) {
      finalReminderResult.recordset.map(value => {
        let options = new _mailOptions();
        options.bcc = value.BCCMailID;
        options.cc = value.CCMailID;
        options.from = value.FromMailID;
        options.html = value.MailContent;
        options.subject = value.Subject;
        options.to = value.UserEmailID;
        _mailer.sendMail(options);
      });
    }
  } catch (error) {}
};
