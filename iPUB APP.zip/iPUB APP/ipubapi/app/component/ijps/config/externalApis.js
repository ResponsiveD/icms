const config = require('./externalApis.json');
const modeconfig = require('../../../../config/env/env_mode.json')
const ENV_MODE = modeconfig.ENVMODE;
const GetMetaDataFromiAuthor = config[ENV_MODE]["GetMetaDataFromiAuthor"];
const PutMetaDataToiAuthor = config[ENV_MODE]["PutMetaDataToiAuthor"];

module.exports = {
    GetMetaDataFromiAuthor,
    PutMetaDataToiAuthor
};