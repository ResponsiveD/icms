"use strict";
const express = require("express");
const router = express.Router();

const middelware = require('../../../middleware/auth/auth.middelware');
//controller
const article_controller = require("../controllers/article.controller");
const fileoperation_controller = require("../controllers/fileoperation.controller")
const dashboard_iopp_controller = require("../controllers/dashboard.iopp");
const reviewer_controller = require('../controllers/reviewer.controller');
const automation_controller = require('../controllers/automation.controller');
const common_controller = require("../controllers/common.controller");
const feedbackApiValidation = require('../controllers/validator/feedback');
const feedbackController = require('../controllers/feedback.controller');
const authorController = require('../controllers/author.controller');
const authorValidation = require('../controllers/validator/author');
const attachfile_controller = require('../controllers/attachfile.controller');

router.get("/get-dashboard-publisher", middelware.userAuth, dashboard_iopp_controller.get_dashboard_publisher);
router.get("/get-dashboard-auth-rev", middelware.userAuth, dashboard_iopp_controller.get_dashboard_auth_rev);

//article action
router.get("/get-journal-type", middelware.userAuth, article_controller.get_journal_type_value)
router.post("/add-edit-author", middelware.userAuth, article_controller.add_edit_author)
router.post("/add-art-detail", middelware.userAuth, article_controller.add_article_details)
router.post("/add-art-attach", middelware.userAuth, article_controller.add_article_attachments)
router.post("/add-edit-art-coauthor", middelware.userAuth, article_controller.add_edit_article_coauthors)
router.post("/add-edit-art-conform", middelware.userAuth, article_controller.add_edit_article_conforms)
router.post("/add-art-keyword", middelware.userAuth, article_controller.add_article_keywords)
router.post("/main-upload-files", middelware.userAuth, article_controller.main_upload_files)
router.post("/supplementary-upload-files", middelware.userAuth, article_controller.supplementary_upload_files)
router.get("/get-art-attach", middelware.userAuth, article_controller.get_article_attachments)
router.get("/get-author-detail", middelware.userAuth, article_controller.get_author_details)
router.get("/get-author-email", middelware.userAuth, article_controller.get_author_emails)
router.get("/get-conform-detail", middelware.userAuth, article_controller.get_conform_details)
router.get("/get-coauthor-detail", middelware.userAuth, article_controller.get_coauthor_details)
router.get("/get-sal-detail", middelware.userAuth, article_controller.get_salutation_details)
router.get("/get-service-detail", middelware.userAuth, article_controller.get_service_details)
router.get("/get-wf-detail", middelware.userAuth, article_controller.get_workflow_details)
router.get("/get-article-conform", middelware.userAuth, article_controller.get_article_conforms)
router.post("/Submit-activity", middelware.userAuth, article_controller.Submit_activitys)
router.post("/save-article-history", middelware.userAuth, article_controller.save_article_historys)
router.get("/check-automation-status-of-article", middelware.userAuth, article_controller.check_automation_status_of_article)
router.get("/get-article-keyword-details", middelware.userAuth, article_controller.get_article_keywords_for_iAuthor)
router.get('/status/getarticle', middelware.userAuth,  article_controller.get_article_by_status)

//file operation
router.post("/file-byteupload", middelware.userAuth, fileoperation_controller.file_byteupload)
router.post("/word-to-xml-automation", middelware.userAuth, automation_controller.word_to_xml_automation_entry)
router.post("/icore_to_pdf", middelware.userAuth, automation_controller.iCoreToPDF)
router.post("/icore_to_xml", middelware.userAuth, automation_controller.iCoreToXML)
router.post("/file-blob-move", middelware.userAuth, fileoperation_controller.file_blob_moves)
router.post("/get-file-data", middelware.userAuth, fileoperation_controller.get_blob_datas)
router.post("/list-blob-file", middelware.userAuth, fileoperation_controller.ListAllFilesInPaths)
router.post("/file-blob-delete", middelware.userAuth, fileoperation_controller.file_blob_delete)

//kewords
router.get("/get-metadata-details", middelware.userAuth, article_controller.get_metadata_details)
router.get("/get-article-keywords", middelware.userAuth, article_controller.get_article_keywords)

//i-Author 
router.get("/getjobdetails", middelware.userAuth, article_controller.getJobDetails)

router.get("/get-country", middelware.userAuth, common_controller.get_country_details)
router.get("/get-state", middelware.userAuth, common_controller.get_state_details)
router.get("/get-city", middelware.userAuth, common_controller.get_city_details)

//reviewer
router.get("/reviewer/accept", reviewer_controller.reviewerAcceptOrReject)
router.post("/addEdit-reviewer-for-article", middelware.userAuth, reviewer_controller.addEdit_reviewer_for_article)
router.post("/get-reviewer-for-article", middelware.userAuth, reviewer_controller.get_reviewer_for_article)
router.post("/update-reviewer-action", middelware.userAuth, reviewer_controller.update_reviewer_action)
router.post("/add-sugg-comment", middelware.userAuth, reviewer_controller.add_sugg_comment)
router.get("/get-sugg-comment", middelware.userAuth, reviewer_controller.get_sugg_comment)

//feedback api operation
router.post('/feedbackuser', middelware.userAuth, feedbackApiValidation.postFeedbackUser, feedbackController.postFeedbackUser);
router.get('/feedbackuser', middelware.userAuth, feedbackApiValidation.getFeedbackUser, feedbackController.getFeedbackUser);
router.get('/feedback', middelware.userAuth, feedbackController.getFeedback);

//Suggestion
router.get('/getsuggestionIds', middelware.userAuth, article_controller.getSuggestionId);

//Attachment File
router.post('/add-attach-file', middelware.userAuth, attachfile_controller.add_attachment_files);
router.get('/get-attach-file', middelware.userAuth, attachfile_controller.get_attachment_files);
router.get('/delete-attach-file', middelware.userAuth, attachfile_controller.delete_attachment_files);
router.get('/get-softattch-detail', middelware.userAuth, attachfile_controller.get_soft_attch_detail);

//author api opration
router.post('/inviteauthor', middelware.userAuth, authorValidation.postPublisherInviteAuthor, authorController.postPublisherInviteAuthor);
router.get('/authoracceptinvitation', middelware.userAuth, authorController.getAuthorAcceptInvitaion);

router.post('/get-metadata-from-iAuthor', middelware.userAuth, automation_controller.get_metadata_from_iAuthor);
router.post('/put-metadata-to-iAuthor', middelware.userAuth, automation_controller.put_metadata_to_iAuthor);

//Login Session
router.get('/get-jobdetails', article_controller.getMetaJobDetails);


module.exports = router;
