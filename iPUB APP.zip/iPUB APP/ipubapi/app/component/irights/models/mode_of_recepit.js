"use strict";
function mode_of_receipt() {
  this.mode_of_receipt_name = "";
  this.mode_of_receipt_id = "";
}

mode_of_receipt.prototype.mode_of_receipt_name = function(
  mode_of_receipt_name
) {
  this.mode_of_receipt_name = mode_of_receipt_name;
};
mode_of_receipt.prototype.mode_of_receipt_id = function(mode_of_receipt_id) {
  this.mode_of_receipt_id = mode_of_receipt_id;
};

module.exports = mode_of_receipt;
