"use strict";
function text_clearance() {
  this.text_clearance_id = "";
  this.type = "";
  this.date = "";
  this.source_validity = "";
  this.credit_line = "";
  this.actual_cost = "";
  this.status = "";
  this.comments = "";
  this.attachment = "";
}

text_clearance.prototype.text_clearance_id = function(text_clearance_id) {
  this.text_clearance_id = text_clearance_id;
};
text_clearance.prototype.type = function(type) {
  this.type = type;
};
text_clearance.prototype.date = function(date) {
  this.date = date;
};
text_clearance.prototype.source_validity = function(source_validity) {
  this.source_validity = source_validity;
};
text_clearance.prototype.credit_line = function(credit_line) {
  this.credit_line = credit_line;
};
text_clearance.prototype.actual_cost = function(actual_cost) {
  this.actual_cost = actual_cost;
};
text_clearance.prototype.status = function(status) {
  this.status = status;
};
text_clearance.prototype.comments = function(comments) {
  this.comments = comments;
};
text_clearance.prototype.attachment = function(attachment) {
  this.attachment = attachment;
};
module.exports = text_clearance;
