"use strict";
const get_service_details = {
    service_details,
    service_docs,
    chapter_docs,
    chapter_details,
    service,
    task_details,
    task_spec_details    
}
function service() {
    this.project_id = "";
    this.service_details = [];
}
function service_details() {
    this.proj_ser_id = "";
    this.project_id = "";
    this.service_name = "";
    this.status_id = "";
    this.status = "";
    this.Comments = "";
    this.is_active = "";
    this.service_docs = [];
    this.chapter_details = [];
    this.service_guid="";
}

function service_docs() {
    this.attr_id = "";
    this.proj_ser_id = "";
    this.file_url = "";
    this.file_name = "";
    this.is_active = "";
}
function chapter_details() {
    this.chapter_id = "";
    this.batch_id = "";
    this.seq_id = "";
    this.total_page = "";
    this.is_active = "";
    this.proj_ser_id = "";
    this.status_id = "";
    this.status_name = "";
    this.chapter_name = "";
    this.chapter_docs = [];
    this.task_details = [];
}
function chapter_docs() {
    this.file_id = "";
    this.chapter_id = "";
    this.file_name = "";
    this.file_url = "";
    this.is_active = 1;
}
function task_details() {
    this.task_id = "";
    this.tl_commands = "";
    this.asign_date = "";
    this.due_Date = "";
    this.comp_date = "";
    this.status_id = "";
    this.is_active = "";
    this.resource_id = "";
    this.assigned_to = "";
    this.task_spec_details=[];
    this.no_source=0;
    this.is_allocated=0;
}
function task_spec_details() {
    this.s_id = "";
    this.spec_id = "";
    this.no_source="";
    this.no_source_commets="";
    this.hi_res_download="";
    this.hi_res_url="";
    this.comments="";
    this.spec_desc = "";
    this.page_no = "";
    this.status_id = "";
    this.photo_id = "";
    this.is_active = "";
    this.is_allocated=0;
}
module.exports = get_service_details;