"use strict";
function role() {
  this.role_name = "";
  this.role_id = "";
}

role.prototype.role_name = function(role_name) {
  this.role_name = role_name;
};
role.prototype.role_id = function(role_id) {
  this.role_id = role_id;
};
module.exports = role;
