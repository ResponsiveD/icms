"use strict";

function project_full_details() {
  this.project_id = "";
  this.project_code = "";
  this.project_title = "";
  this.project_author = "";
  this.project_lead_name = "";
  this.project_lead_id = "";
  this.edition = "";
  this.ISBN = "";
  this.short_title = "";
  this.copyright_year = "";
  this.no_of_chapters = "";
  this.project_description = "";
  this.receipt_date = "";
  this.mode_of_receipt = "";
  this.mode_of_receipt_id = "";
  this.publication_date = "";
  this.permission_due_date = "";
  this.hires_due_date = "";
  this.file_to_print_date = "";
  this.closing_date = "";
  this.customer_id = "";
  this.customer_code = "";
  this.customer_name = "";
  this.customer_email_id = "";
  this.customer_location_id = "";
  this.customer_location = "";
  this.customer_category_id = "";
  this.customer_category = "";
  this.customer_sub_category_id = "";
  this.customer_sub_category = "";
  this.currency = "";
  this.currency_id="";
  this.comments = "";
  this.customer_access = [];
  this.services = [];
  this.project_files = [];
  this.photo_budget="";
  this.text_budget="";
  this.media_budget="";
  this.total_budget="";
  this.is_draft = "";
  this.status_id = "";
  this.status_code = "";
  this.user_id="";
  this.link="";
  this.user_name="";
  this.password="";
  this.ftp_id=0;
  this.project_guid="";
}
project_full_details.prototype.link = function(link) {
  this.link = link;
};
project_full_details.prototype.user_name = function(user_name) {
  this.user_name = user_name;
};
project_full_details.prototype.password = function(password) {
  this.password = password;
};
project_full_details.prototype.ftp_id = function(ftp_id) {
  this.ftp_id = ftp_id;
};
project_full_details.prototype.user_id = function (user_id) {
  this.user_id = user_id;
};
project_full_details.prototype.is_draft = function (is_draft) {
  this.is_draft = is_draft;
};
project_full_details.prototype.status_id = function (status_id) {
  this.status_id = status_id;
};
project_full_details.prototype.status_code = function (status_code) {
  this.status_code = status_code;
};
project_full_details.prototype.photo_budget = function (photo_budget) {
  this.photo_budget = photo_budget;
};
project_full_details.prototype.text_budget = function (text_budget) {
  this.text_budget = text_budget;
};
project_full_details.prototype.media_budget = function (media_budget) {
  this.media_budget = media_budget;
};
project_full_details.prototype.total_budget = function (total_budget) {
  this.total_budget = total_budget;
};
project_full_details.prototype.ISBN = function (ISBN) {
  this.ISBN = ISBN;
};
project_full_details.prototype.project_id = function (project_id) {
  this.project_id = project_id;
};
project_full_details.prototype.project_code = function (project_code) {
  this.project_code = project_code;
};
project_full_details.prototype.project_title = function (project_title) {
  this.project_title = project_title;
};
project_full_details.prototype.project_author = function (project_author) {
  this.project_author = project_author;
};
project_full_details.prototype.project_lead_name = function (project_lead_name) {
  this.project_lead_name = project_lead_name;
};
project_full_details.prototype.project_lead_id = function (project_lead_id) {
  this.project_lead_id = project_lead_id;
};
project_full_details.prototype.edition = function (edition) {
  this.edition = edition;
};
project_full_details.prototype.short_title = function (short_title) {
  this.short_title = short_title;
};
project_full_details.prototype.copyright_year = function (copyright_year) {
  this.copyright_year = copyright_year;
};
project_full_details.prototype.no_of_chapters = function (no_of_chapters) {
  this.no_of_chapters = no_of_chapters;
};
project_full_details.prototype.project_description = function (project_description) {
  this.project_description = project_description;
};
project_full_details.prototype.receipt_date = function (receipt_date) {
  this.receipt_date = receipt_date;
};
project_full_details.prototype.mode_of_receipt = function (mode_of_receipt) {
  this.mode_of_receipt = mode_of_receipt;
};
project_full_details.prototype.mode_of_receipt_id = function (mode_of_receipt_id) {
  this.mode_of_receipt_id = mode_of_receipt_id;
};
project_full_details.prototype.publication_date = function (publication_date) {
  this.publication_date = publication_date;
};
project_full_details.prototype.permission_due_date = function (permission_due_date) {
  this.permission_due_date = permission_due_date;
};
project_full_details.prototype.hires_due_date = function (hires_due_date) {
  this.hires_due_date = hires_due_date;
};
project_full_details.prototype.file_to_print_date = function (file_to_print_date) {
  this.file_to_print_date = file_to_print_date;
};
project_full_details.prototype.closing_date = function (closing_date) {
  this.closing_date = closing_date;
};
project_full_details.prototype.customer_code = function (customer_code) {
  this.customer_code = customer_code;
};
project_full_details.prototype.customer_id = function (customer_id) {
  this.customer_id = customer_id;
};
project_full_details.prototype.customer_name = function (customer_name) {
  this.customer_name = customer_name;
};
project_full_details.prototype.customer_email_id = function (customer_email_id) {
  this.customer_email_id = customer_email_id;
};
project_full_details.prototype.customer_location_id = function (customer_location_id) {
  this.customer_location_id = customer_location_id;
};
project_full_details.prototype.customer_location = function (customer_location) {
  this.customer_location = customer_location;
};
project_full_details.prototype.customer_category_id = function (customer_category_id) {
  this.customer_category_id = customer_category_id;
};
project_full_details.prototype.customer_category = function (customer_category) {
  this.customer_category = customer_category;
};
project_full_details.prototype.customer_sub_category_id = function (customer_sub_category_id) {
  this.customer_sub_category_id = customer_sub_category_id;
};
project_full_details.prototype.customer_sub_category = function (customer_sub_category) {
  this.customer_sub_category = customer_sub_category;
};
project_full_details.prototype.currency = function (currency) {
  this.currency = currency;
};
project_full_details.prototype.currency_id = function (currency_id) {
  this.currency_id = currency_id;
};
project_full_details.prototype.comments = function (comments) {
  this.comments = comments;
};
project_full_details.prototype.services = function (services) {
  this.services = services;
};
project_full_details.prototype.customer_access = function (customer_access) {
  this.customer_access = customer_access;
};
project_full_details.prototype.project_files = function (project_files) {
  this.project_files = project_files;
};
module.exports = project_full_details;