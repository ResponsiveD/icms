"use strict";
function selection_full_detail() {
  this.project_id = "";
  this.chapter_id = "";
  this.chapter_name = "";
  this.selection_id = "";
  this.selection_description = "";
  this.copyright_year = "";
  this.source_chapter = "";
  this.source_total_page = "";
  this.no_of_words = "";
  this.source_page = "";
  this.source_isbn = "";
  this.source_description = "";
  this.source_copyright_year = "";
  this.figure_no = "";
  this.website_url = "";
  this.clearance_required = "";
  this.rights_type = "";
  this.comment = "";
  this.permission_needed = "";
  this.permission_status = "";
  this.total_page_request = "";
  this.rights_holder_details = [];
  this.service_guid="";
}

selection_full_detail.prototype.project_id = function(project_id) {
  this.project_id = project_id;
};
selection_full_detail.prototype.chapter_id = function(chapter_id) {
  this.chapter_id = chapter_id;
};
selection_full_detail.prototype.chapter_name = function(chapter_name) {
  this.chapter_name = chapter_name;
};
selection_full_detail.prototype.selection_id = function(selection_id) {
  this.selection_id = selection_id;
};
selection_full_detail.prototype.selection_description = function(
  selection_description
) {
  this.selection_description = selection_description;
};
selection_full_detail.prototype.copyright_year = function(copyright_year) {
  this.copyright_year = copyright_year;
};
selection_full_detail.prototype.source_chapter = function(source_chapter) {
  this.source_chapter = source_chapter;
};
selection_full_detail.prototype.source_total_page = function(source_total_page) {
  this.source_total_page = source_total_page;
};
selection_full_detail.prototype.no_of_word = function(no_of_word) {
  this.no_of_word = no_of_word;
};
selection_full_detail.prototype.source_page = function(source_page) {
  this.source_page = source_page;
};
selection_full_detail.prototype.source_isbn = function(source_isbn) {
  this.source_isbn = source_isbn;
};
selection_full_detail.prototype.source_description = function(
  source_description
) {
  this.source_description = source_description;
};
selection_full_detail.prototype.source_copyright_year = function(
  source_copyright_year
) {
  this.source_copyright_year = source_copyright_year;
};
selection_full_detail.prototype.figure_no = function(figure_no) {
  this.figure_no = figure_no;
};
selection_full_detail.prototype.website_url = function(website_url) {
  this.website_url = website_url;
};
selection_full_detail.prototype.clearance_required = function(
  clearance_required
) {
  this.clearance_required = clearance_required;
};
selection_full_detail.prototype.rights_type = function(rights_type) {
  this.rights_type = rights_type;
};
selection_full_detail.prototype.comment = function(comment) {
  this.comment = comment;
};
selection_full_detail.prototype.permission_needed = function(permission_needed) {
  this.permission_needed = permission_needed;
};
selection_full_detail.prototype.permission_status = function(permission_status) {
  this.permission_status = permission_status;
};
selection_full_detail.prototype.total_page_request = function(
  total_page_request
) {
  this.total_page_request = total_page_request;
};
selection_full_detail.prototype.rights_holder_details = function(
  rights_holder_details
) {
  this.rights_holder_details = rights_holder_details;
};
module.exports = selection_full_detail;
