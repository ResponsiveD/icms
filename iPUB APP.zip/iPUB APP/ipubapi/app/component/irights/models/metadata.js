"use strict";
function metadata() {
    this.spec_description = "";
    this.source = "";
    this.source_url = "";
    this.photo_grapher_name = "";
    this.keywords = "";
    this.rights_type = "";
    this.image_type = "";
    this.source_type = "";
    this.usage_restriction = "";
    this.image_cost = "";
    this.currency = "";
    this.model_release = "";
    this.property_release = "";
    this.clearance_type = "";
    this.comments = "";
    this.rights_holder_details = [];
    this.unique_id ="";
}

metadata.prototype.unique_id = function (unique_id) {
    this.unique_id = unique_id;
};
metadata.prototype.spec_description = function (spec_description) {
    this.spec_description = spec_description;
};
metadata.prototype.source = function (source) {
    this.source = source;
};
metadata.prototype.source_url = function (source_url) {
    this.source_url = source_url;
};
metadata.prototype.photo_grapher_name = function (photo_grapher_name) {
    this.photo_grapher_name = photo_grapher_name;
};
metadata.prototype.keywords = function (keywords) {
    this.keywords = keywords;
};
metadata.prototype.rights_type = function (rights_type) {
    this.rights_type = rights_type;
};
metadata.prototype.image_type = function (image_type) {
    this.image_type = image_type;
};
metadata.prototype.source_type = function (source_type) {
    this.source_type = source_type;
};
metadata.prototype.usage_restriction = function (usage_restriction) {
    this.usage_restriction = usage_restriction;
};
metadata.prototype.image_cost = function (image_cost) {
    this.image_cost = image_cost;
};
metadata.prototype.currency = function (currency) {
    this.currency = currency;
};
metadata.prototype.model_release = function (model_release) {
    this.model_release = model_release;
};
metadata.prototype.property_release = function (property_release) {
    this.property_release = property_release;
};
metadata.prototype.clearance_type = function (clearance_type) {
    this.clearance_type = clearance_type;
};
metadata.prototype.comments = function (comments) {
    this.comments = comments;
};
metadata.prototype.rights_holder_details = function (rights_holder_details){
    this.rights_holder_details = rights_holder_details;
}
module.exports = metadata;
