"use strict";
function selection_basic_detail() {
  this.service_name = "";
  this.service_id = "";
}

selection_basic_detail.prototype.service_name = function(service_name) {
  this.service_name = service_name;
};
selection_basic_detail.prototype.service_id = function(service_id) {
  this.service_id = service_id;
};
module.exports = selection_basic_detail;
