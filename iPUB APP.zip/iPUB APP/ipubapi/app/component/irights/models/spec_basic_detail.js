"use strict";
function spec_basic_detail() {
  this.spec = "";
  this.spec_id = "";
  this.photo_no = "";
}

spec_basic_detail.prototype.spec = function(spec) {
  this.spec = spec;
};
spec_basic_detail.prototype.spec_id = function(spec_id) {
  this.spec_id = spec_id;
};
spec_basic_detail.prototype.photo_no = function(photo_no) {
  this.photo_no = photo_no;
};
module.exports = spec_basic_detail;
