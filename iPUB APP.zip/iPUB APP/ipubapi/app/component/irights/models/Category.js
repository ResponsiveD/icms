"use strict";

function category() {
  this.category_name = "";
  this.category_id = "";
}

category.prototype.category_name = function(category_name) {
  this.category_name = category_name;
};

category.prototype.category_id = function(category_id) {
  this.category_id = category_id;
};
module.exports = category;
