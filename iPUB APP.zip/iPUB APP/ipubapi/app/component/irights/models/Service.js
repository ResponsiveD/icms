"use strict";
function service() {
  this.service_name = "";
  this.service_id = "";
}

service.prototype.service_name = function(service_name) {
  this.service_name = service_name;
};
service.prototype.service_id = function(service_id) {
  this.service_id = service_id;
};
module.exports = service;
