"use strict";
function user_rights() {
  this.updater_id="";
  this.user_code = "";
  this.user_id = "";
  this.user_email = "";
  this.role_name = "";
  this.role_id = "";
  this.sub_role = [];
  this.activity = [];
}
user_rights.prototype.user_code = function(user_code) {
  this.user_code = user_code;
};
user_rights.prototype.updater_id = function(updater_id) {
  this.updater_id = updater_id;
};
user_rights.prototype.user_id = function(user_id) {
  this.user_id = user_id;
};
user_rights.prototype.user_email = function(user_email) {
  this.user_email = user_email;
};
user_rights.prototype.role_name = function(role_name) {
  this.role_name = role_name;
};
user_rights.prototype.role_id = function(role_id) {
  this.role_id = role_id;
};
user_rights.prototype.sub_role = function(sub_role) {
  this.sub_role = sub_role;
};
user_rights.prototype.activity = function(activity) {
  this.activity = activity;
};
module.exports = user_rights;
