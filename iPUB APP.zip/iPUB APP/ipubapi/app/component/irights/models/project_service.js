"use strict";
function project_service() {
  this.service_id = "";
  this.service_name = "";
  this.no_of_chapters = "";
  this.attachments = [];
  this.due_date = "";
  this.comment = "";
  this.pr_ser_id="";
  this.status_id="";
  this.wf_id="";
  this.is_active=true;
  this.project_lead_id="";
  this.service_guid="";
}

project_service.prototype.wf_id = function(wf_id) {
  this.wf_id = wf_id;
};
project_service.prototype.service_guid = function(service_guid) {
  this.service_guid = service_guid;
};
project_service.prototype.project_lead_id = function(project_lead_id) {
  this.project_lead_id = project_lead_id;
};
project_service.prototype.is_active = function(is_active) {
  this.is_active = is_active;
};
project_service.prototype.service_id = function(service_id) {
  this.service_id = service_id;
};
project_service.prototype.status_id = function(status_id) {
  this.status_id = status_id;
};
project_service.prototype.pr_ser_id = function(pr_ser_id) {
  this.pr_ser_id = pr_ser_id;
};
project_service.prototype.service_name = function(service_name) {
  this.service_name = service_name;
};
project_service.prototype.no_of_chapters = function(no_of_chapters) {
  this.no_of_chapters = no_of_chapters;
};
project_service.prototype.attachments = function(attachments) {
  this.attachments = attachments;
};
project_service.prototype.due_date = function(due_date) {
  this.due_date = due_date;
};
project_service.prototype.comment = function(comment) {
  this.comment = comment;
};

module.exports = project_service;
