"use strict";
function rights_holder() {
  this.rights_holder_name = "";
  this.rights_holder_id = "";
  this.contact_name = "";
  this.address = "";
  this.city = "";
  this.country = "";
  this.zip_code = "";
  this.phone_no1 = "";
  this.phone_no2 = "";
  this.email_id1 = "";
  this.email_id2 = "";
  this.fax_no = "";
  this.ssn = "";
  this.federal_id_no = "";
  this.vat_no = "";
}

rights_holder.prototype.rights_holder_name = function(rights_holder_name) {
  this.rights_holder_name = rights_holder_name;
};
rights_holder.prototype.rights_holder_id = function(rights_holder_id) {
  this.rights_holder_id = rights_holder_id;
};
rights_holder.prototype.contact_name = function(contact_name) {
  this.contact_name = contact_name;
};
rights_holder.prototype.address = function(address) {
  this.address = address;
};
rights_holder.prototype.city = function(city) {
  this.city = city;
};
rights_holder.prototype.country = function(country) {
  this.country = country;
};
rights_holder.prototype.zip_code = function(zip_code) {
  this.zip_code = zip_code;
};
rights_holder.prototype.phone_no1 = function(phone_no1) {
  this.phone_no1 = phone_no1;
};
rights_holder.prototype.phone_no2 = function(phone_no2) {
  this.phone_no2 = phone_no2;
};
rights_holder.prototype.email_id1 = function(email_id1) {
  this.email_id1 = email_id1;
};
rights_holder.prototype.email_id2 = function(email_id2) {
  this.email_id2 = email_id2;
};
rights_holder.prototype.fax_no = function(fax_no) {
  this.fax_no = fax_no;
};
rights_holder.prototype.ssn = function(ssn) {
  this.ssn = ssn;
};
rights_holder.prototype.federal_id_no = function(federal_id_no) {
  this.federal_id_no = federal_id_no;
};
rights_holder.prototype.vat_no = function(vat_no) {
  this.vat_no = vat_no;
};
module.exports = rights_holder;
