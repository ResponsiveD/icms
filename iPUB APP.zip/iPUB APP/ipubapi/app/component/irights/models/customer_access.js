"use strict";

function customer_access() {
    this.customer_access_id = "";
    this.customer_access_name = "";
    this.customer_access_email = "";
    this.customer_access_roletype_id = "";
    this.customer_access_roletype = "";
}

customer_access.prototype.customer_access_name = function (customer_access_name) {
    this.customer_access_name = customer_access_name;
};

customer_access.prototype.customer_access_id = function (customer_access_id) {
    this.customer_access_id = customer_access_id;
};

customer_access.prototype.customer_access_roletype = function (customer_access_roletype) {
    this.customer_access_roletype = customer_access_roletype;
};

customer_access.prototype.customer_access_roletype_id = function (customer_access_roletype_id) {
    this.customer_access_roletype_id = customer_access_roletype_id;
};

customer_access.prototype.customer_access_email = function (customer_access_email) {
    this.customer_access_email = customer_access_email;
};
module.exports = customer_access;