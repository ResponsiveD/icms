"use strict";
function attachment() {
  this.file_id = "";
  this.file_name = "";
  this.created_on = "";
  this.file_uri = "";
  this.is_active = true;
}

attachment.prototype.file_id = function(file_id) {
  this.file_id = file_id;
};

attachment.prototype.is_active = function(is_active) {
  this.is_active = is_active;
};

attachment.prototype.file_name = function(file_name) {
  this.file_name = file_name;
};

attachment.prototype.created_on = function(created_on) {
  this.created_on = created_on;
};

attachment.prototype.file_uri = function(file_uri) {
  this.file_uri = file_uri;
};

module.exports = attachment;
