"use strict";


function chapter_file() {
    this.file_id = "";
  this.file_name = "";
  this.created_on = "";
  this.file_uri = "";
  this.is_active = true;
}


chapter_file.prototype.file_id = function(file_id) {
    this.file_id = file_id;
  };
  chapter_file.prototype.file_name = function(file_name) {
    this.file_name = file_name;
  };
  chapter_file.prototype.created_on = function(created_on) {
    this.created_on = created_on;
  };
  chapter_file.prototype.file_uri = function(file_uri) {
    this.file_uri = file_uri;
  };
  module.exports = chapter_file;