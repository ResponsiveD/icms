module.exports = {
    PhotoResearch :1
} 