'use strict'

const update_text_clearance_data = require("../data/input_rights_holders_details.json");
const task_list_for_activity_repo = require("./task_list_for_activity");
var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');

exports.get_text_list = async function (user_id, activity_id, chapter_id, is_spec = 0) {
    return await new Promise(async (resolve, reject) => {
        try {
            await task_list_for_activity_repo.activity_task_list(user_id, activity_id, chapter_id, undefined, is_spec).then((value) => {
                resolve(value);
            }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};

exports.get_selections = async function (task_id) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('TaskID', sqlType.Int, task_id);
            parameters.push(para);
            await db_library
                .execute('[IRS].[GetSelectionList]', parameters, db_library.query_type.SP).then((value) => {
                    resolve(value);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};
exports.get_chapter_selections = async function (chapter_id) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('ChapterID', sqlType.Int, chapter_id);
            parameters.push(para);
            await db_library
                .execute('[IRS].[GetChapterSelectionList]', parameters, db_library.query_type.SP).then((value) => {
                    resolve(value);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};
exports.get_chapter_taskid = async function (chapter_id) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('ChapterID', sqlType.Int, chapter_id);
            parameters.push(para);
            await db_library
                .execute('[IRS].[GetChapterTaskID]', parameters, db_library.query_type.SP).then((value) => {
                    resolve(value);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};

exports.get_selections_details = async function (selection_id) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('selection_id', sqlType.Int, selection_id);
            parameters.push(para);
            await db_library
                .execute('[IRS].[GetSelectionDetails]', parameters, db_library.query_type.SP).then((value) => {
                    if (value.recordsets[0].length > 0)
                        value.recordsets[0][0].right_holder_details = value.recordsets[1];
                    else {
                        value.recordsets[0][0].right_holder_details = [];
                    }
                    resolve(value.recordsets[0][0]);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};
exports.update_selection = async function (data) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            data.right_holder_details_count = data.right_holder_details.length;
            let para = new param('JsonValue', sqlType.NVarChar, JSON.stringify(data));
            parameters.push(para);
            await db_library
                .execute('[IRS].[AddEditSelectionDetails]', parameters, db_library.query_type.SP).then((value) => {
                    resolve(value.recordsets[0][0].id);
                }).catch(err => {
                    reject(err)
                });
        } catch (error) {
            reject(error);
        }
    });
};
exports.get_permission_needed = async function () {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            await db_library
                .execute('[IRS].[GetPermissionNeeded]', parameters, db_library.query_type.SP).then((value) => {
                    resolve(value.recordsets[0]);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};
exports.get_permission_status = async function () {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            await db_library
                .execute('[IRS].[GetPermissionStatus]', parameters, db_library.query_type.SP).then((value) => {
                    resolve(value.recordsets[0]);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};

exports.get_project_selections = async function (data) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('JsonValue', sqlType.NVarChar, JSON.stringify(data));
            parameters.push(para);
            await db_library
                .execute('[IRS].[GetFullSelectionOnProject]', parameters, db_library.query_type.SP).then((value) => {
                    var _ = require('lodash');
                    var Result = value.recordsets[0]
                    Result.forEach(element => {
                        element.attachments = _.filter(value.recordsets[1], ['chapter_id', element.chapter_id]);
                        element.data = _.filter(value.recordsets[2], ['chapter_id', element.chapter_id]);
                    });
                    resolve(Result);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};

exports.get_project_selections_full = async function (data) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            // if (data.status_id == undefined) {
            //     data.status_id = 1;
            // }
            let para = new param('JsonValue', sqlType.NVarChar, JSON.stringify(data));
            parameters.push(para);
            await db_library
                .execute('[IRS].[GetFullSelectionOnProjectReview]', parameters, db_library.query_type.SP).then((value) => {
                    var _ = require('lodash');
                    var Result = value.recordsets[0]
                    Result.forEach(element => {
                        element.attachments = _.filter(value.recordsets[1], ['chapter_id', element.chapter_id]);
                        element.data = _.filter(value.recordsets[2], ['chapter_id', element.chapter_id]);
                        element.data.forEach(ele => {
                            ele.data = _.filter(value.recordsets[3], ['unique_id', ele.unique_id]);
                        });
                    });
                    resolve(Result);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};

exports.get_selection_rights_holder = async function (UniqueID) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('UniqueID', sqlType.NVarChar, UniqueID);
            parameters.push(para);
            await db_library
                .execute('[IRS].[GetRightsHolderForSelection]', parameters, db_library.query_type.SP).then((value) => {
                    var _ = require('lodash');
                    var Result = value.recordsets[0]
                    resolve(Result);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};

exports.validate_rh_follow_up_for_chapter = async function (ChapterID) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('ChapterID', sqlType.NVarChar, ChapterID);
            parameters.push(para);
            await db_library
                .execute('[IRS].[ValidateRHFollowUpsForChapter]', parameters, db_library.query_type.SP).then((value) => {
                    var Result = {"primary":value.recordsets[0][0],"secondary":value.recordsets[1]};
                    resolve(Result);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};

exports.validate_rh_follow_up_for_spec = async function (specId) {
    return await new Promise(async (resolve, reject) => {
        try {
            let parameters = [];
            let para = new param('SpecId', sqlType.NVarChar, specId);
            parameters.push(para);
            await db_library
                .execute('[IRS].[ValidateRHFollowUpsForSpec]', parameters, db_library.query_type.SP).then((value) => {
                    var Result = {"primary": value.recordsets[0][0], "secondary": value.recordsets[1]};
                    resolve(Result);
                }).catch(err => reject(err));
        } catch (error) {
            reject(error);
        }
    });
};