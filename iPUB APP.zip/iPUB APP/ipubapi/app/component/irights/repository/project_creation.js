"use strict";
const Request = require("request");
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');
const activity_actions_repo = require('../repository/activity_actions')
const project_basic_details = require('../models/project_basic_details');
const _mailOptions = require("../../../helpers/mailOptions");
const _mailer = require("../../../helpers/mailer");
const file_upload = require('../repository/file_upload');

var sqlType = require('mssql');

exports.addedit_cust_user = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('JsonValue', sqlType.NVarChar, data);
      parameters.push(para);
      db_library
        .execute('[IRS].[AddEditProjectDetails]', parameters, db_library.query_type.SP).then((value) => {
          var ProjectID = value.recordset[0].ProjectID;
          resolve(ProjectID);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.create_user = async function (data, updater_id) {
  try {
    let parameters = [];
    let para = new param('UserCode', sqlType.NVarChar, data.user_code);
    parameters.push(para);
    db_library
      .execute('[IPS].[GetUserid]', parameters, db_library.query_type.SP).then(async (value) => {
        var userid = value.recordset[0].userid;
        if (userid == 0) {
          parameters = [];
          para = new param('UserCode', sqlType.VarChar, data.customer_access_email.toLowerCase());
          parameters.push(para);
          para = new param('UserFName', sqlType.NVarChar, data.customer_access_name);
          parameters.push(para);
          para = new param('UserEmailID', sqlType.NVarChar, data.customer_access_email.toLowerCase());
          parameters.push(para);
          para = new param('UpdatedBy', sqlType.Int, updater_id);
          parameters.push(para);
          para = new param('isInternalUser', sqlType.Bit, false);
          parameters.push(para);
          para = new param('OrgID', sqlType.Int, 0);
          parameters.push(para);
          para = new param('OrgDivID', sqlType.Int, 0);
          parameters.push(para);
          let temppass = await file_upload.guid()
          //temppass = 'Temp#'+temppass;
          para = new param('Password', sqlType.NVarChar, temppass);
          parameters.push(para);
          await db_library
            .execute('[IRS].[AddEditCustomer]', parameters, db_library.query_type.SP).then(async (value) => {
              var options = await activity_actions_repo.get_mail_template(1, updater_id);
              options.to = data.customer_access_email.toLowerCase();
              options.html = options.html.replace('##name##', data.customer_access_name)
              options.html = options.html.replace('##email##', data.customer_access_email.toLowerCase())
              options.html = options.html.replace('##password##', temppass);
              _mailer.sendMail(options);
            }).catch(
              err => {
                console.log(err);
              });
        }
      }).catch((error) => {
        console.log(error);
      });
  } catch (error) {
    console.log(error);
  }
}

exports.add_edit_project_details = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('JsonValue', sqlType.NVarChar, data);
      parameters.push(para);
      db_library
        .execute('[IRS].[AddEditProjectDetails]', parameters, db_library.query_type.SP).then((value) => {
          var ProjectID = value.recordset[0].ProjectID;
          resolve(ProjectID);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.get_project_services = async function () {
  return await new Promise((resolve, reject) => {
    try {
      var val = [];
      db_library
        .execute('[IRS].[GetiRightsService]', undefined, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "Service": element.SerName, "id": element.SerID });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.get_project_modeofreceipts = async function () {
  return await new Promise((resolve, reject) => {
    try {
      var val = [];
      db_library
        .execute('[IPS].[GetModeOfReceipt]', undefined, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "ModeOfReceipt": element.ReceivedMode, "id": element.ModeID });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.get_project_roletypes = async function () {
  return await new Promise((resolve, reject) => {
    try {
      var val = [];
      db_library
        .execute('[IRS].[GetProjectCustomerRole]', undefined, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "RoleType": element.CustRole, "id": element.CustRoleID });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.get_customer_location = async function () {
  return await new Promise((resolve, reject) => {
    try {
      var val = [];
      db_library
        .execute('[IPS].[GetCountry]', undefined, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "Location": element.CountryName, "id": element.CountyID });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.get_customer_category = async function (customer_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      var val = [];
      let para = new param('CustID', sqlType.Int, customer_id);
      parameters.push(para);
      db_library
        .execute('[IPS].[GetCategorys]', parameters, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "Category": element.VtlName, "id": element.VtlID });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.get_customer_subcategory = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('VtlID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IPS].[GetSubCategorys]', parameters, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "SubCategory": element.DiscpName, "id": element.DiscpID });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.Get_ProjectLead = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IPS].[GetProjectLead]', parameters, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "name": element.name, "id": element.id });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}
exports.Get_Customer = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, data);
      parameters.push(para);
      db_library
        .execute('[IPS].[GetCustomer]', parameters, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "code": element.Code, "name": element.name, "id": element.id });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.Get_customer_email = async function (data) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('CustomerMailId', sqlType.NVarChar, data);
      parameters.push(para);
      db_library
        .execute('[IPS].[GetCustomerDetailsByMail]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}


exports.get_customer_currency = async function () {
  return await new Promise((resolve, reject) => {
    try {
      var val = [];
      db_library
        .execute('[IPS].[GetCurrency]', undefined, db_library.query_type.SP).then((value) => {
          value.recordset.forEach(element => {
            val.push({ "Currency": element.CurrencyName, "id": element.CurrID });
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}
exports.getProjectCurrentStatus = async function (project_id){
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('ProjectID', sqlType.Int, project_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetCurrentProjectStatus]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets[0][0].StatusID);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}
exports.get_project_full_details = async function (project_id) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('ProjectID', sqlType.Int, project_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[GetProjectFullDetails]', parameters, db_library.query_type.SP).then((value) => {
          resolve(value.recordsets);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}
exports.Get_projectList = async function (user_id,aty_id = 0,sptype) {
  return await new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let val = [];
      let para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('AtyID', sqlType.Int, aty_id);
      parameters.push(para);
      let spname = ""
      if (sptype == 1) { spname = '[IRS].[WipProjectList]' };
      if (sptype == 2) { spname = '[IRS].[GetProjectsForReviewer]' };
      if (sptype == 3) { spname = '[IRS].[WipPLProjectList]' };
      db_library
        .execute(spname, parameters, db_library.query_type.SP).then((value) => {
          value.recordsets[0].forEach(element => {
            var _project_basic_details = new project_basic_details();
            _project_basic_details.created_on = element.CreatedDate;
            _project_basic_details.customer = element.CustomerName;
            _project_basic_details.project_id = element.ProjectID;
            _project_basic_details.closing_date = element.ProjectClosingDate;
            _project_basic_details.project_title = element.ProjectTitle;
            _project_basic_details.project_code = element.ProjectCode;
            _project_basic_details.Status = element.Status;
            _project_basic_details.StatusID = element.StatusID;
            val.push(_project_basic_details);
          });
          resolve(val);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}

exports.addedit_project_service = async function (project_serices, ProjectID, user_id) {
  return new Promise(async (resolve, reject) => {
    try {
      project_serices = await FServices(project_serices, ProjectID, user_id);
      resolve(project_serices);
    } catch (error) {
      reject(error);
    }
  });
}
async function FServices(project_serices, ProjectID, user_id) {
  return new Promise((resolve, reject) => {
    let i = 0;
    if (project_serices.services.length == 0 || project_serices === undefined) { resolve(project_serices.services); }
    project_serices.services.forEach(async (element, index, arrray) => {
      let parameters = [];
      let para = new param('projSerID', sqlType.Int, element.service_id || 0);
      parameters.push(para);
      para = new param('IRSProjID', sqlType.Int, ProjectID);
      parameters.push(para);
      para = new param('SerID', sqlType.Int, element.pr_ser_id || 1);
      parameters.push(para);
      para = new param('SerName', sqlType.NVarChar, element.service_name);
      parameters.push(para);
      element.status_id = element.status_id === undefined ? 1 : element.status_id;
      para = new param('StatusID', sqlType.Int, element.status_id);
      parameters.push(para);
      para = new param('DueDate', sqlType.DateTime, new Date(element.due_date));
      parameters.push(para);
      para = new param('Comments', sqlType.NVarChar, element.comment);
      parameters.push(para);
      para = new param('NoOfChapters', sqlType.Int, element.no_of_chapters);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('isActive', sqlType.Bit, element.is_active || 1);
      parameters.push(para);
      para = new param('ProjectLeadID', sqlType.Int, project_serices.project_lead_id);
      parameters.push(para);
      para = new param('ProjSerGUID', sqlType.NVarChar, project_serices.service_guid);
      parameters.push(para);
      await db_library
        .execute('[IRS].[AddEditService]', parameters, db_library.query_type.SP).then(async (value) => {
          element.service_id = value.recordsets[0][0].ProjSerID;
          element.attachments = await Fserice_file(element.attachments, element.service_id, ProjectID, user_id);
          i += 1;
        }).catch((error) => {
          reject(error);
        });
      if (arrray.length == i) {
        resolve(project_serices.services);
      }
    });
  });
}

async function Fserice_file(service_files, service_id, ProjectID, user_id) {
  return new Promise((resolve, reject) => {
    if (service_files === undefined || service_files.length == 0) { resolve(service_files); }
    service_files.forEach(async (elemt, index, arrray) => {
      let parameters = [];
      let para = new param('projSerID', sqlType.Int, service_id || 0);
      parameters.push(para);
      para = new param('SerAttID', sqlType.Int, elemt.file_id);
      parameters.push(para);
      para = new param('FileName', sqlType.NVarChar, elemt.file_name);
      parameters.push(para);
      para = new param('FileURL', sqlType.NVarChar, elemt.file_uri);
      parameters.push(para);
      para = new param('ProjectID', sqlType.Int, ProjectID);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      para = new param('isActive', sqlType.Bit, elemt.is_active);
      parameters.push(para);
      await db_library
        .execute('[IRS].[AddEditSerAttachment]', parameters, db_library.query_type.SP).then((val) => {
          elemt.file_id = val.recordsets[0][0].SerAttID;
          if ((arrray.length - 1) == index) {
            resolve(arrray);
          }
        }).catch((error) => {
          reject(error);
        });
    });
  });
}

exports.Fproject_files = async function (project_files, ProjectID, user_id) {
  return new Promise((resolve, reject) => {
    if (project_files.length == 0) { resolve(project_files); }
    project_files.forEach(async (element, index, arrray) => {
      let parameters = [];
      let para = new param('DocID', sqlType.Int, element.file_id);
      parameters.push(para);
      para = new param('FileName', sqlType.NVarChar, element.file_name);
      parameters.push(para);
      para = new param('FilePath', sqlType.VarChar, element.file_uri);
      parameters.push(para);
      para = new param('IRSProjID', sqlType.Int, ProjectID);
      parameters.push(para);
      para = new param('UserID', sqlType.Int, user_id);
      parameters.push(para);
      await db_library
        .execute('[IRS].[AddEditProjectAttachment]', parameters, db_library.query_type.SP).then((attach) => {
          element.file_id = attach.recordsets[0][0].DocID;
          if ((arrray.length - 1) == index) {
            resolve(arrray);
          }
        }).catch((error) => {
          reject(error);
        });
    });
  });
}

async function custloop(arr, ProjectID, user_id) {
  return new Promise((resolve, reject) => {
    if (arr.length == 0) { resolve(arr); }
    else {
      arr.forEach(async (element, index, arrray) => {
        let parameters = [];
        let para = new param('ProjectID', sqlType.Int, ProjectID);
        parameters.push(para);
        para = new param('Name', sqlType.NVarChar, element.customer_access_name);
        parameters.push(para);
        para = new param('EmailID', sqlType.NVarChar, element.customer_access_email);
        parameters.push(para);
        para = new param('CustRoleID', sqlType.Int, element.customer_access_roletype_id);
        parameters.push(para);
        para = new param('SaID', sqlType.Int, element.customer_access_id || 0);
        parameters.push(para);
        para = new param('UserID', sqlType.Int, user_id);
        parameters.push(para);
        await db_library.execute('[IRS].[AddEditProjectCustomer]', parameters, db_library.query_type.SP).then((value) => {
          element.customer_access_id = value.recordsets[0][0].said;
          if ((arrray.length - 1) == index) {
            resolve(arrray);
          }
        }).catch((err) => {
          reject(err);
        });

        /* EXPERIMENTAL PHASE FOR PROMISE ARRAY
 
         promises.push( db_library.execute('[IRS].[AddEditProjectCustomer]', parameters, db_library.query_type.SP).then((value) => {
           console.log(value.recordsets[0].said);
           return value.recordsets[0].said;
         }).catch((err) => {
           console.log(err);
           return err;
         }));
         console.log(promises.length);
 
          */
      });
    }
  });
}

exports.addedit_project_customer = async function (customer_access, ProjectID, user_id) {
  return await new Promise((resolve, reject) => {
    try {
      custloop(customer_access, ProjectID, user_id).then((arr) => {
        resolve(arr);
      });
    } catch (error) {
      reject(error);
    }
  });
}

exports.create_project = async function (_project_creation_model) {
  return new Promise((resolve, reject) => {
    try {
      let parameters = [];
      let para = new param('ProjectID', sqlType.Int, _project_creation_model.project_id);
      parameters.push(para);
      para = new param('ProjectCode', sqlType.NVarChar, _project_creation_model.project_code);
      parameters.push(para);
      para = new param('ProjectTitle', sqlType.NVarChar, _project_creation_model.project_title);
      parameters.push(para);
      para = new param('AuthorName', sqlType.NVarChar, _project_creation_model.project_author);
      parameters.push(para);
      para = new param('CustomerID', sqlType.Int, _project_creation_model.customer_id || null);
      parameters.push(para);
      para = new param('ShortTitle', sqlType.NVarChar, _project_creation_model.short_title);
      parameters.push(para);
      para = new param('NoOfChapter', sqlType.Int, _project_creation_model.no_of_chapters || null);
      parameters.push(para);
      para = new param('ProjDesc', sqlType.NVarChar, _project_creation_model.project_description);
      parameters.push(para);
      para = new param('ReceiptDate', sqlType.DateTime, _project_creation_model.receipt_date == null ? null : new Date(_project_creation_model.receipt_date));
      parameters.push(para);
      para = new param('UserID', sqlType.Int, _project_creation_model.user_id);
      parameters.push(para);
      para = new param('ModeOfReceiptID', sqlType.Int, _project_creation_model.mode_of_receipt_id || null);
      parameters.push(para);
      para = new param('Edition', sqlType.SmallInt, _project_creation_model.edition || null);
      parameters.push(para);
      para = new param('ISBN', sqlType.BigInt, _project_creation_model.ISBN || null);
      parameters.push(para);
      para = new param('CopyrightYear', sqlType.SmallInt, _project_creation_model.copyright_year || null);
      parameters.push(para);
      para = new param('PublicationDate', sqlType.DateTime, _project_creation_model.publication_date == null ? null : new Date(_project_creation_model.publication_date));
      parameters.push(para);
      para = new param('PermsDueDate', sqlType.DateTime, _project_creation_model.permission_due_date == null ? null : new Date(_project_creation_model.permission_due_date));
      parameters.push(para);
      para = new param('HiresDueDate', sqlType.DateTime, _project_creation_model.hires_due_date == null ? null : new Date(_project_creation_model.hires_due_date));
      parameters.push(para);
      para = new param('PrinterDate', sqlType.DateTime, _project_creation_model.file_to_print_date == null ? null : new Date(_project_creation_model.file_to_print_date));
      parameters.push(para);
      para = new param('ClosingDate', sqlType.DateTime, _project_creation_model.closing_date == null ? null : new Date(_project_creation_model.closing_date));
      parameters.push(para);
      para = new param('Comments', sqlType.NVarChar, _project_creation_model.comments);
      parameters.push(para);
      para = new param('CurrencyID', sqlType.Int, _project_creation_model.currency_id || null);
      parameters.push(para);
      para = new param('PhotoBudget', sqlType.Decimal, _project_creation_model.photo_budget || null);
      parameters.push(para);
      para = new param('TextBudget', sqlType.Decimal, _project_creation_model.text_budget || null);
      parameters.push(para);
      para = new param('MediaBudget', sqlType.Decimal, _project_creation_model.media_budget || null);
      parameters.push(para);
      para = new param('TotalBudget', sqlType.Decimal, _project_creation_model.total_budget || null);
      parameters.push(para)
      para = new param('ProjectManagerID', sqlType.Decimal, _project_creation_model.project_lead_id || null);
      parameters.push(para);
      para = new param('Link', sqlType.NVarChar, _project_creation_model.link || '');
      parameters.push(para);
      para = new param('UserName', sqlType.NVarChar, _project_creation_model.user_name || '');
      parameters.push(para);
      para = new param('Password', sqlType.NVarChar, _project_creation_model.password || '');
      parameters.push(para);
      para = new param('FTPID', sqlType.Int, _project_creation_model.ftp_id || 0);
      parameters.push(para);
      para = new param('CustLocID', sqlType.Int, _project_creation_model.customer_location_id || null);
      parameters.push(para);
      para = new param('VertID', sqlType.Int, _project_creation_model.customer_category_id || null);
      parameters.push(para);
      para = new param('DisciplineID', sqlType.Int, _project_creation_model.customer_sub_category_id || null);
      parameters.push(para);
      para = new param('CustMailID', sqlType.NVarChar, _project_creation_model.customer_email_id);
      parameters.push(para);
      para = new param('ProjGUID', sqlType.NVarChar, _project_creation_model.project_guid);
      parameters.push(para);
      _project_creation_model.status_id = _project_creation_model.is_draft ? 5 : _project_creation_model.status_id;
      _project_creation_model.status_id = _project_creation_model.status_id === undefined ? 1 : _project_creation_model.status_id;
      para = new param('StatusID', sqlType.Int, _project_creation_model.status_id);
      parameters.push(para);
      db_library
        .execute('[IRS].[AddEditProject]', parameters, db_library.query_type.SP).then(async (value) => {
          var ProjectID = value.recordset[0].ProjectID;
          _project_creation_model.project_id = value.recordset[0].ProjectID;
          _project_creation_model.project_code = value.recordset[0].ProjectCode;
          //_project_creation_model.project_files = await Fproject_files(_project_creation_model.project_files, ProjectID, _project_creation_model.user_id);
          // var _mailOptions = new mailOptions;
          // _mailOptions.from='';
          // _mailOptions.to='';
          // _mailOptions.text='';
          // _mailOptions.subject='';
          // mailer.sendMail(mailOptions);
          resolve(_project_creation_model);
        }).catch((error) => {
          reject(error);
        });
    } catch (error) {
      reject(error);
    }
  });
}