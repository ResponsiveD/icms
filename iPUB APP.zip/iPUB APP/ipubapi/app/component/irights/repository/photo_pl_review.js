"use strict";
//const photo_pl_review = require("../../irights/data/photo_pl_review.json");

exports.photo_pl_review = function (project_id) {
    try {
        return {};
    } catch (error) {
        throw error;
    }
};