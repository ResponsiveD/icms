var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');

exports.activity_task_list = async (user_id, activity_id,chapter_id,customer_reviewer,is_spec,is_clearance) => {
  return await new Promise((resolve, reject) => {
    if (chapter_id==undefined)
    {
      chapter_id =0;
    }
    let parameters = [];
    let para = new param('UserID', sqlType.Int, user_id);
    parameters.push(para);
    para = new param('AtyID', sqlType.Int, activity_id);
    parameters.push(para);
    para = new param('ChapterID', sqlType.Int, chapter_id);
    parameters.push(para);
    para = new param('CustomerReviewer', sqlType.Bit, customer_reviewer);
    parameters.push(para);
    para = new param('isSpec', sqlType.Bit, (is_spec==undefined?1:is_spec));
    parameters.push(para);
    para = new param('isClearance', sqlType.Bit, (is_clearance==undefined?0:is_clearance));
    parameters.push(para);
    db_library
      .execute('[IRS].[GetTaskForUserForActivity]', parameters, db_library.query_type.SP).then((value) => {
        var results = value.recordsets[0];
        resolve(results);
      }).catch(err => reject(err));
  });
}