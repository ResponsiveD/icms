'user strict'

const azure = require('azure');
let Duplex = require('stream').Duplex;
var path = require('path')
const file_upload_config = require('../config/file_upload_config')
const _mailer = require("../../../helpers/mailer");
const accessKey = file_upload_config.CloudCredentials().accessKey;
const storageAccount = file_upload_config.CloudCredentials().storageAccount;
const containerName = file_upload_config.CloudCredentials().containerName;
const basepath = file_upload_config.CloudCredentials().cloudBasePath;

var blobService = azure.createBlobService(storageAccount, accessKey);

exports.guid = function () {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return (s4() + s4());
}
async function bufferToStream(buffer) {
    return await new Promise((resolve, reject) => {
        try {
            let stream = new Duplex();
            stream.push(buffer);
            stream.push(null);
            resolve(stream);
        } catch (err) { reject(err); }
    });
}
BlobUpload = async (Path, data, length) => {
    return await new Promise(async(resolve, reject) => {
        var datas = await bufferToStream(data);
        blobService.createBlockBlobFromStream(
            containerName,
            Path,
            datas,
            length,
            function (error) {
                if (error) {
                    reject(error);
                } else {
                    resolve(Path);
                }
            }
        )
    });
};
exports.UploadFile = async function (req, Path) {
    return new Promise(async (resolve, reject) => {
        try {
            let file = req.files["file"];
            var CheckMimeType = file_upload_config.AllowedFileType.indexOf(req.files.file.mimetype);
            var CheckExtension = file_upload_config.AllowedFileExtension.indexOf(path.extname(req.files.file.name));
            if (CheckMimeType == -1 || CheckExtension == -1) {
                let activity_actions_repo = require("../repository/activity_actions");
                var options = await activity_actions_repo.get_mail_template(7,1);
                options.html = options.html.replace('##fileformate##',req.files.file.mimetype);
                setTimeout(function(){ 
                    _mailer.sendMail(options); 
                }, 3000);
                throw 'Please upload only following file format: .jpeg,.pdf,.png,.tiff,.tif,.msg,postscript and ms office file format\'s ';
            }
            await BlobUpload(Path, file.data, file.data.length).then(
                (Path) => {
                    resolve(basepath + Path);
                }).catch(
                    (err) => {
                        throw err;
                    });
        } catch (error) {
            reject(error);
        }
    });
}