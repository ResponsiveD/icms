"use strict";
const customer_text_approval_details= require("../../irights/data/customer_text_approval.json");
const customer_text_approval_status= require("../../irights/data/customer_text_approval_status.json");
exports.customer_text_approval = function(project_id) {
    try {
     return customer_text_approval_details;
    } catch (error) {
      throw error;
    }
  };


  exports.customer_text_approval_status = function(project_id) {
    try {
     return customer_text_approval_status;
    } catch (error) {
      throw error;
    }
  };