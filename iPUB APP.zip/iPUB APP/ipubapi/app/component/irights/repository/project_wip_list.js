"use strict";

const wip_list_data =require('../../irights/data/project_list.json');
const get_projectdetails =require('../../irights/data/get_project_list.json');

exports.wip_list = function(data) {
  try {
    return wip_list_data;
  } catch (error) {
    return error;
  }
};

exports.get_project_details = function(data) {
  try {
    return get_projectdetails;
  } catch (error) {
    return error;
  }
};
