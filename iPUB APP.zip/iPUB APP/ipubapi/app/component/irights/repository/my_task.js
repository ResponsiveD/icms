'use strict'

const get_selection_details_data = require("../data/get_selection_details.json");

exports.get_selection = function (data) {
  try {
    return [{
        "SessionName": "<sessionname>",
        "SessionID": "<sessionid>"
      },
      {
        "SessionName": "<sessionname>",
        "SessionID": "<sessionid>"
      },
    ];
  } catch (error) {
    throw error;
  }
};

exports.get_selection_details = function (data) {
  try {
    return get_selection_details_data;
  } catch (error) {
    throw error;
  }
};