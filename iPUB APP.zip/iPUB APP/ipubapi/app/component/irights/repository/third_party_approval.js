'use strict'

const third_party_approval_data = require("../data/project_list.json");
const third_party_approval_details_data = require("../data/third_party_pl_details.json");

exports.third_party_approval = function (data) {
    try {
        return third_party_approval_data;
    } catch (error) {
        throw data;
    }
}

exports.third_party_approval_details = function (data) {
    try {
        return third_party_approval_details_data;
    } catch (error) {
        throw data;
    }
}