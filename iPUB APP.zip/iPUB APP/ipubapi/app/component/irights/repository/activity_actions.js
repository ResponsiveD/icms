var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library')
const param = require('../models/parameter_input');

exports.activity_action = async (data, cust) => {
  return await new Promise((resolve, reject) => {
    let parameters = [];
    let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
    parameters.push(para);
    let actionsp = '[IRS].[Updateactivitystatus]';
    if (cust == true) {
      actionsp = '[IRS].[Custupdateactivitystatus]';
    }
    db_library
      .execute(actionsp, parameters, db_library.query_type.SP).then((value) => {
        var results = {
          status_message: value.recordsets[0][0].status_message,
          result: value.recordsets[0][0].status
        }
        resolve(results);
      }).catch(err => {
        reject(err)
      });
  });
}
exports.get_process_detail_for_task = async (task_id) => {
  return await new Promise((resolve, reject) => {
    let parameters = [];
    let para = new param('TaskID', sqlType.Int, task_id);
    parameters.push(para);
    db_library
      .execute("[IRS].[GetProcessDetailForTask]", parameters, db_library.query_type.SP).then((value) => {
        var results = value.recordsets[0]
        resolve(results);
      }).catch(err => {
        reject(err)
      });
  });
}

exports.get_update_status_for_clearance = async (project_id, user_id) => {
  return await new Promise((resolve, reject) => {
    let parameters = [];
    let para = new param('IRSProjID', sqlType.Int, project_id);
    parameters.push(para);
    para = new param('UserID', sqlType.Int, user_id);
    parameters.push(para);
    db_library
      .execute("[IRS].[UpdateClearanceProcess]", parameters, db_library.query_type.SP).then((value) => {
        var results = true
        resolve(results);
      }).catch(err => {
        reject(err)
      });
  });
}

exports.get_reject_reason = async (user_id) => {
  return await new Promise((resolve, reject) => {
    let parameters = [];
    let para = new param('UserID', sqlType.Int, user_id);
    parameters.push(para);
    db_library
      .execute("[IRS].[GetRejectReasons]", parameters, db_library.query_type.SP).then((value) => {
        var results = value.recordsets[0];
        //results.push({"id":0,"reason":"Others"})
        resolve(results);
      }).catch(err => {
        reject(err)
      });
  });
}
exports.put_pending_for_user = async (user_id) => {
  return await new Promise((resolve, reject) => {
    let parameters = [];
    let para = new param('UserID', sqlType.Int, user_id);
    parameters.push(para);
    db_library
      .execute("[IRS].[UpdatePendingStatusForUser]", parameters, db_library.query_type.SP).then((value) => {
        var results = true;
        //results.push({"id":0,"reason":"Others"})
        resolve(results);
      }).catch(err => {
        reject(err)
      });
  });
}
exports.get_mail_template = async (template_id,user_id) => {
  return await new Promise(async(resolve, reject) => {
    let parameters = [];
    let para = new param('MailID', sqlType.Int, template_id);
    parameters.push(para);
    para = new param('UserID', sqlType.Int, user_id);
    parameters.push(para);
    db_library
      .execute("[IPS].[GetMailTemplate]", parameters, db_library.query_type.SP).then((value) => {
        var results = value.recordsets[0][0];
        const _mailOptions = require("../../../helpers/mailOptions");
        var options = new _mailOptions();
        options.bcc = results.bcc;
        options.cc = results.cc;
        options.from = results.from;
        options.html = results.html;
        options.subject = results.subject;
        options.to = results.to;
        resolve(results);
      }).catch(err => {
        reject(err)
      });
  });
}