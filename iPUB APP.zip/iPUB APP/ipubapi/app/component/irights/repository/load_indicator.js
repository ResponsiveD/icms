
const param = require('../models/parameter_input');

exports.load_indicator = () => {
    let data = {
        sections: [{
                key: 1,
                label: "James Smith"
            },
            {
                key: 2,
                label: "John Williams "
            },
            {
                key: 3,
                label: "David Miller"
            },
            {
                key: 4,
                label: "Linda Brown"
            },
            {
                key: 5,
                label: "Brown"
            },
            {
                key: 6,
                label: "Miller"
            },
            {
                key: 7,
                label: "Linda"
            },
            {
                key: 8,
                label: "Brown"
            },
            {
                key: 9,
                label: "Brown"
            },
            {
                key: 10,
                label: "Miller"
            },
            {
                key: 11,
                label: "Linda"
            },
            {
                key: 12,
                label: "Brown"
            }
        ],

        schedulerData: [{
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "8 Spec",
                user_id: 1,
                subject: 'normal'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "8 Spec",
                user_id: 2,
                subject: 'normal'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "8 Spec",
                user_id: 3,
                subject: 'normal'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "8 Spec",
                user_id: 4,
                subject: 'normal'
            },
            {
                start_date: "2018-05-29 00:00",
                end_date: "2018-05-29 24:00",
                text: "8 Spec",
                user_id: 4,
                subject: 'normal'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "8 Spec",
                user_id: 5,
                subject: 'normal'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "15 Spec",
                user_id: 6,
                subject: 'load'
            },
            {
                start_date: "2018-05-29 00:00",
                end_date: "2018-05-29 24:00",
                text: "15 Spec",
                user_id: 6,
                subject: 'load'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "8 Spec",
                user_id: 7,
                subject: 'normal'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "8 Spec",
                user_id: 8,
                subject: 'normal'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "8 Spec",
                user_id: 9,
                subject: 'normal'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "20 Spec",
                user_id: 10,
                subject: 'delay'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "8 Spec",
                user_id: 11,
                subject: 'adjustment'
            },
            {
                start_date: "2018-05-28 00:00",
                end_date: "2018-05-28 24:00",
                text: "8 Spec",
                user_id: 12,
                subject: 'adjustment'
            }
        ]
    };
    return data;
}
