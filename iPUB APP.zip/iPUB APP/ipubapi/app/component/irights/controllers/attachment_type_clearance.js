"use strict";
const attachment_type_clearance_repo = require("../repository/attachment_type_clearance");
const output = require("../models/output");

exports.attachment_type_clearance = async function (req, res, next){
    var _output = new output();
    try {
        _output.data = await attachment_type_clearance_repo.attachment_type_clearance()
        _output.is_success = true;
        _output.message = "Attachment Type list";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}