'use strict'
//added by Nisar
const text_pending_task_repo = require("../repository/text_pending_task");
const output = require("../models/output");

exports.text_pending_task = function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        let result = text_pending_task_repo.text_pending_task(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Get text pending tasks";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}

exports.text_pending_task_details = function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        let result = text_pending_task_repo.text_pending_task_details(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Get text pending tasks details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}