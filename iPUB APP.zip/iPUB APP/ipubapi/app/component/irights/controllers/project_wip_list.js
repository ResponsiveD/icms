const project_wip_list_repo = require("../repository/project_wip_list");
const output = require("../models/output");

exports.wip_list = async function(req, res, next) {
  try {
    let data = req.body;
    let result = await project_wip_list_repo.wip_list(data.user_id);
    var _output = new output();
    _output.data = result;
    _output.is_success = true;
    _output.message = "Role based wip list";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }

  res.send(_output);
};




exports.get_project_details = function(req, res, next) {
  var _output = new output();
  try {
    let data = {project_id:"1"};
    let result = project_wip_list_repo.get_project_details(data);
    
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project Details is listed Successfully";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }

  res.send(_output);
};