"use strict";
const user_access_repo = require("../repository/user_access");
const output = require("../models/output");
var helper = require("../helpers/json-serialize");
var user_rights = require("../models/user_rights");

exports.get_roles = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.user_id;
    let result = await user_access_repo.get_roles(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "User Access roles";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
};

exports.get_research_type = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.user_id;
    let result = await user_access_repo.get_research_type(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "User Access research type";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
};

exports.get_allactivities = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.user_id;
    let result = await user_access_repo.get_allactivities(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "User Access activities";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
};

exports.get_activities_based_on_role = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.user_id;
    let result = await user_access_repo.get_activities_based_on_role(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Activities Based on Role";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
};
exports.get_activity_rights_on_user = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.user_id;
    let result = await user_access_repo.get_activity_rights_on_user(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "User current Activity rights";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
};


exports.user_list = async function (req, res, next) {
  var _output = new output();
  try {
    let result = await user_access_repo.user_list(req.query.user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "User List";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
  }
  res.send(_output);
};

exports.create_external_user = async function (req, res, next) {
  var _output = new output();
  try {
    let updater_id = req.body.updater_id;
    let user_email = req.body.user_email;
    let user_name = req.body.user_name;
    if (updater_id == '' || updater_id == undefined || updater_id == 'null') { throw 'updater_id not provided'; }
    if (user_email == '' || user_email == undefined || user_email == 'null') { throw 'user_email not provided'; }
    if (user_name == '' || user_name == undefined || user_name == 'null') { throw 'user_name not provided'; }
    let result = await user_access_repo.create_external_user(updater_id, user_email, user_name);
    _output.data = {result };
    _output.is_success = true;
    _output.message = "User Created Successfully!";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }

  res.send(_output);
}
exports.user_menu = async function (req, res, next) {
  try {
    var _output = new output();
    let user_id = req.query.user_id;
    if (user_id == '' || user_id == undefined || user_id == 'null') { throw 'User_id not provided'; }
    let result = await user_access_repo.user_menu(user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Menu for user";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }

  res.send(_output);
};

exports.deactivate_user =async function (req, res, next) {
  try {
    var _output = new output();
    let user_id = req.query.user_id;
    if (user_id == '' || user_id == undefined || user_id == 'null') { throw 'User_id not provided'; }
    let result = await user_access_repo.UpdateUserStatus(user_id,0);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Deactivated the user";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }

  res.send(_output);
};

exports.activate_user =async function (req, res, next) {
  try {
    var _output = new output();
    let user_id = req.query.user_id;
    if (user_id == '' || user_id == undefined || user_id == 'null') { throw 'User_id not provided'; }
    let result = await user_access_repo.UpdateUserStatus(user_id,1);
    _output.data = result;
    _output.is_success = true;
    _output.message = "activated the user";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }

  res.send(_output);
};

exports.get_sub_roles = async function (req, res, next) {
  try {
    var _output = new output();
    let user_id = req.query.user_id;
    let role_id = req.query.role_id;
    if (role_id == '' || role_id == undefined || role_id == 'null') { throw 'role_id not provided'; }
    if (user_id == '' || user_id == undefined || user_id == 'null') { throw 'User_id not provided'; }
    let result = await user_access_repo.get_sub_roles(user_id, role_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Sub Roles with Role ID";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }

  res.send(_output);
};
exports.update_user_access = async function (req, res, next) {
  var _output = new output();
  try {
    //let update_user_access_details = helper.serialize(user_rights, req.body, "");
    let result = await user_access_repo.update_user_rights(req.body);
    _output.data = result;
    _output.is_success = true;
    _output.message = "User Access is updated Successfully!";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }

  res.send(_output);
};
