"use strict";
const photo_research_repo = require("../repository/photo_research");
const update_asset_details = require("../models/spec_details");
const output = require("../models/output");
var helper = require("../helpers/json-serialize");


// exports.get_spec_list = async function (req, res, next) {
//     var _output = new output();
//     try {
//         let data = req.query.user_id;
//         data = req.query.activity_id;
//         let result = await photo_research_repo.get_spec_list( req.query.user_id,req.query.activity_id);
//         _output.data = result;
//         _output.is_success = true;
//         _output.message = "Photo Research task for this user";
//     } catch (error) {
//         _output.data = "";
//         _output.is_success = false;
//         _output.message = error.message;
//     }
//     res.send(_output);
// };
exports.get_spec_list = async function (req, res, next) {
    var _output = new output();
    try {
        let user_id = req.query.user_id;
        let activity_id = req.query.activity_id;
        let chapter_id = req.query.chapter_id;
        let customer_reviewer=0;
        let result = await photo_research_repo.get_spec_list(user_id,activity_id,chapter_id,customer_reviewer);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Photo Research task for this user";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};
exports.get_spec_list_reviewer= async function (req, res, next) {
    var _output = new output();
    try {
        let user_id = req.query.user_id;
        let activity_id = req.query.activity_id;
        let chapter_id = req.query.chapter_id;
        let customer_reviewer=1;
        let result = await photo_research_repo.get_spec_list(user_id,activity_id,chapter_id,customer_reviewer);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Photo Research task for this user";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};
exports.get_spec_list_clearance_reviewer = async function (req, res, next) {
    var _output = new output();
    try {
        let user_id = req.query.user_id;
        let activity_id = req.query.activity_id;
        let chapter_id = req.query.chapter_id;
        let customer_reviewer=1;
        let is_clearance=1;
        let result = await photo_research_repo.get_spec_list(user_id,activity_id,chapter_id,customer_reviewer,is_clearance);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Photo Research task for this user";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};
exports.put_select_approve_reject = async function (req,res,next)
{
    var _output = new output();
    try {
        let result = await photo_research_repo.put_select_approve_reject(req.body);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Photo Research task for this user";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}
exports.get_spec_details = async function (req, res, next) {
    var _output = new output();
    try {
        let data = req.body;
        let task_id = data.task_id;
        let proj_ser_id = data.proj_ser_id;
        let task_record_id = data.task_record_id;
        if (task_id == undefined || task_id == "" || task_id == "null") {
            throw "task_id must be passed";
        }
        if (proj_ser_id == undefined || proj_ser_id == "" || proj_ser_id == "null") {
            throw "proj_ser_id must be passed";
        }
        if (task_record_id == undefined || task_record_id == "" || task_record_id == "null") {
            throw "task_record_id must be passed";
        }
        let result = await photo_research_repo.get_spec_details(task_id, proj_ser_id, task_record_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Specific details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};
exports.get_spec_details_export = async function (req, res, next) {
    var _output = new output();
    try {
        let data = req.body;
        let task_id = data.task_id;
        let proj_ser_id = data.proj_ser_id;
        let task_record_id = data.task_record_id;
        if (task_id == undefined || task_id == "" || task_id == "null") {
            throw "task_id must be passed";
        }
        if (proj_ser_id == undefined || proj_ser_id == "" || proj_ser_id == "null") {
            throw "proj_ser_id must be passed";
        }
        if (task_record_id == undefined || task_record_id == "" || task_record_id == "null") {
            throw "task_record_id must be passed";
        }
        let result = await photo_research_repo.get_spec_details_export(task_id, proj_ser_id, task_record_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Specific details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.get_spec_clearance_details = function (req, res, next) {
    var _output = new output();
    try {
        let data = {  spec_id: 1 };
        let result = photo_research_repo.get_spec_clearance_details(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Photo Research Clearance is created successfully";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
};

exports.update_spec_details = async function (req, res, next) {

    var _output = new output();
    try {
        let data = await helper.serialize_type(update_asset_details, req.body, "")
        let task_id = data.task_id;
        let proj_ser_id = data.proj_ser_id;
        let task_record_id = data.spec.task_record_id;
        let s_id = data.s_id;
        data.spec.uploaded_asset_count = data.spec.uploaded_asset.length;
        data.spec.uploaded_asset.s_id = s_id;
        data.spec.uploaded_asset.forEach(element => {
            element.rights_holder_count = element.rights_holder_details.length
        });
        _output.data = await photo_research_repo.update_spec_details(data).catch(err=>
        {
            
            throw err;
        });
        // _output.data = await photo_research_repo.get_spec_details(task_id, proj_ser_id, task_record_id).catch(err=>{
        //     throw err;
        // });
        _output.is_success = true;
        _output.message = "Upload spec details is listed";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
};

exports.get_rights_type = async function (req, res, next){
    var _output = new output();
    try {
        _output.data = await photo_research_repo.get_rights_type(req.query.user_id)
        _output.is_success = true;
        _output.message = "image src list";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}
exports.get_image_src = async function (req, res, next){
    var _output = new output();
    try {
        _output.data = await photo_research_repo.get_image_src(req.query.user_id)
        _output.is_success = true;
        _output.message = "image src list";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}
exports.get_image_type = async function (req, res, next){
    var _output = new output();
    try {
        _output.data = await photo_research_repo.get_image_type(req.query.user_id)
        _output.is_success = true;
        _output.message = "image src list";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}

exports.model_release = async function (req, res, next){
    var _output = new output();
    try {
        _output.data = await photo_research_repo.get_model_release()
        _output.is_success = true;
        _output.message = "model release list";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}

exports.property_release = async function (req, res, next){
    var _output = new output();
    try {
        _output.data = await photo_research_repo.get_property_release()
        _output.is_success = true;
        _output.message = "property release list";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}

exports.add_rights_req = async function (req, res, next){
    var _output = new output();
    try {
        _output.data = await photo_research_repo.add_rights_req()
        _output.is_success = true;
        _output.message = "add rights req list";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}

// exports.get_spec_details = async function (req, res, next) {
//     var _output = new output();
//     try {
//         let data = req.query.spec_id;
//         if (!data) { throw 'SpecID not provided'; }
//         let result = await photo_research_repo.get_spec_details(data);
//         var update_asset_dtls = new update_asset_details();
//        var _chapter_file= [];
//        var _uploaded_asset = [];
//        var _metadata = [];
//        var _right_holders = [];

//        if (result[1]) {
//         result[1].forEach(element => {
//           var _Attachment = new chapter_file();
//           _Attachment.file_uri = element.FilePath
//           _Attachment.file_name = element.FileName
//           _Attachment.file_id = element.ID
//           _chapter_file.push(_Attachment)
//         });
//       }
//       if (result[2]) {
//         result[2].forEach(element => {
//           var metadata = new customer_access();
//           metadata.source = element.SaID;
//           metadata.customer_access_name = element.Name;
//           metadata.customer_access_email = element.EmailID;
//           metadata.customer_access_roletype = element.CustRole;
//           customer_access.customer_access_roletype_id = element.CustRoleID;
//           _metadata.push(metadata);
//         });
//       }

//         let rights_holder_details = [];
//         let rights_holder = req.body["rights_holder_details"];
//         if (rights_holder)
//             for (let j = 0; j < rights_holder.length; j++) {
//                 let irights_holder_details = new irights_holder();
//                 irights_holder_details.rights_holder_id = rights_holder.rights_holder_id;
//                 irights_holder_details.rights_holder_name = rights_holder.rights_holder_name;
//                 irights_holder_details.contact_name = rights_holder.contact_name;
//                 irights_holder_details.address = rights_holder.address;
//                 irights_holder_details.city = rights_holder.city;
//                 irights_holder_details.country = rights_holder.country;
//                 irights_holder_details.zip_code = rights_holder.zip_code;
//                 irights_holder_details.phone_no1 = rights_holder.phone_no1;
//                 irights_holder_details.phone_no2 = rights_holder.phone_no2;
//                 irights_holder_details.email_id1 = rights_holder.email_id1;
//                 irights_holder_details.email_id2 = rights_holder.email_id2;
//                 irights_holder_details.fax_no = rights_holder.fax_no;
//                 irights_holder_details.ssn = rights_holder.ssn;
//                 irights_holder_details.federal_id_no = rights_holder.federal_id_no;
//                 irights_holder_details.vat_no = rights_holder.vat_no;
//                 rights_holder_details.push(irights_holder_details);
//             }
//         update_asset_dtls.rights_holder_details = rights_holder_details;
//         let result = photo_research_repo.update_asset_details(update_asset_dtls);

//         _output.data = result;
//         _output.is_success = true;
//         _output.message = "Photo Research for update asset details";
//     } catch (error) {
//         _output.data = "";
//         _output.is_success = false;
//         _output.message = error.message;
//     }

//     res.send(_output);
// };

