'use strict'

const customer_repository = require("../repository/customer");
const output = require("../models/output");

exports.customer_selection = function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        let result = customer_repository.customer_selection(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Customer Selection";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}

exports.customer_approval = function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        let result = customer_repository.customer_approval(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Customer Approval";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}

exports.customer_review = function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        let result = customer_repository.customer_review(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Customer Review";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}