"use strict";
const customer_text_approval_repo = require("../repository/customer_text_approval");
const output = require("../models/output");
var helper = require("../helpers/json-serialize");
var selection_full_details = require("../models/selection_full_details");

exports.customer_text_approval = function (req, res, next) {
    var _output = new output();
    try {
        let data = { project_id: 1};
        let result = customer_text_approval_repo.customer_text_approval(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Customer Text Approval is listed Successfully";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
};

exports.customer_text_approval_status = function (req, res, next) {
    var _output = new output();
    try {
        let customer_text_approval_details = helper.serialize(selection_full_details, req.body, "");
        let result = customer_text_approval_repo.customer_text_approval_status(customer_text_approval_details);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Customer Text Approval and Reject Status is updated";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
};

