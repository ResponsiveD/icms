"use strict";
const text_pl_review_repository = require("../repository/text_pl_review");
const output = require("../models/output");

exports.text_pl_review = function (req, res, next) {
    var _output = new output();
    try {
        let data = {
            "status_id": 1,
            "status": true,
            "reason": "success",
            "commands": "created"
        };
        let result = text_pl_review_repository.text_pl_review(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Text Project Lead Review is Successfully Created";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
};
