"use strict";
const photo_clearance_repo = require("../repository/photo_clearance");
const output = require("../models/output");
var helper = require("../helpers/json-serialize");
//var clearance = require("../models/clearance");



exports.get_rights_holder_followup = async function (req, res, next) {
    var _output = new output();
    try {
        let t_rights_holder_id = req.query.t_rights_holder_id;
        let result = await photo_clearance_repo.get_rights_holder_followup(t_rights_holder_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "rights holder follow up details.";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.update_rights_holder_followup = async function (req, res, next) {
    var _output = new output();
    try {
        let req_body = req.body;
        req_body["attachment_length"] = req.body.attachment.length;
        let data = JSON.stringify(req_body);
        let result = await photo_clearance_repo.update_rights_holder_followup(data);
        _output.data = result;
        _output.is_success = true;
        _output.message = "rights holder follow up details.";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};
exports.get_clearance_status = async function (req, res, next) {
    var _output = new output();
    try {
        let result = await photo_clearance_repo.get_clearance_status();
        _output.data = result;
        _output.is_success = true;
        _output.message = "clearance status details.";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.update_highres_status = async function (req, res, next) {
    var _output = new output();
    try {
        let hi_res = req.body.hi_res;
        let s_id = req.body.s_id;
        let comments=req.body.comments;
        let result = await photo_clearance_repo.update_highres_status(hi_res,s_id,comments);
        _output.data = result;
        _output.is_success = true;
        _output.message = "high res status details.";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};