const dashboard_repo = require("../repository/dashboard");
const output = require("../models/output");

exports.get_task_status_for_user = async function (req, res, next) {
  var _output = new output();
  try {
    let atyid = req.body.activity_id;
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_for_user(atyid, start, end, user_id, 0);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_r = async function (req, res, next) {
  var _output = new output();
  try {
    let atyid = req.body.activity_id;
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_for_user_r(atyid, start, end, user_id, 0);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_report_for_user_r = async function (req, res, next) {
  var _output = new output();
  try {
    let atyid = req.body.activity_id;
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_report_for_user_r(atyid, start, end, user_id, 0);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_delay = async function (req, res, next) {
  var _output = new output();
  try {
    let atyid = req.body.activity_id;
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_for_user(atyid, start, end, user_id, 2);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_ontrack = async function (req, res, next) {
  var _output = new output();
  try {
    let atyid = req.body.activity_id;
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_for_user(atyid, start, end, user_id, 1);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_delay_r = async function (req, res, next) {
  var _output = new output();
  try {
    let atyid = req.body.activity_id;
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_for_user_r(atyid, start, end, user_id, 2);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_report_for_user_delay_r = async function (req, res, next) {
  var _output = new output();
  try {
    let atyid = req.body.activity_id;
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_report_for_user_r(atyid, start, end, user_id, 2);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_ontrack_r = async function (req, res, next) {
  var _output = new output();
  try {
    let atyid = req.body.activity_id;
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_for_user_r(atyid, start, end, user_id, 1);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_task_status_report_for_user_ontrack_r = async function (req, res, next) {
  var _output = new output();
  try {
    let atyid = req.body.activity_id;
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_report_for_user_r(atyid, start, end, user_id, 1);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_report_pl = async function (req, res, next) {
  var _output = new output();
  try {
    let customer_id = req.body.customer_id;
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_for_user_report_pl(atyid, customer_id, start, end, user_id, 0);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_delay_report_pl = async function (req, res, next) {
  var _output = new output();
  try {
    let customer_id = req.body.customer_id;
    let start = req.body.activity_id;
    let atyid = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_for_user_report_pl(atyid, customer_id, start, end, user_id, 2);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_ontrack_report_pl = async function (req, res, next) {
  var _output = new output();
  try {
    let customer_id = req.body.customer_id;
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_status_for_user_report_pl(atyid, customer_id, start, end, user_id, 1);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_pl = async function (req, res, next) {
  var _output = new output();
  try {
    let customer_id = req.body.customer_id;
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_pl(atyid, customer_id, start, end, user_id, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_clearance_r = async function (req, res, next) {
  var _output = new output();
  try {
    let user_id = req.body.user_id;
    let activity_id = req.body.activity_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_clearance_r(user_id, service_id, activity_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_clearance_r_delay = async function (req, res, next) {
  var _output = new output();
  try {
    let user_id = req.body.user_id;
    let activity_id = req.body.activity_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_clearance_r_delay(user_id, service_id, activity_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_clearance_r_ontrack = async function (req, res, next) {
  var _output = new output();
  try {
    let user_id = req.body.user_id;
    let activity_id = req.body.activity_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_clearance_r_ontrack(user_id, service_id, activity_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_clearance_PL = async function (req, res, next) {
  var _output = new output();
  try {
    let customer_id = req.body.customer_id;
    let user_id = req.body.user_id;
    let activity_id = req.body.activity_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_clearance_PL(customer_id, user_id, service_id, activity_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_clearance_PL_delay = async function (req, res, next) {
  var _output = new output();
  try {
    let customer_id = req.body.customer_id;
    let user_id = req.body.user_id;
    let activity_id = req.body.activity_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_clearance_PL_delay(customer_id, user_id, service_id, activity_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_clearance_PL_ontrack = async function (req, res, next) {
  var _output = new output();
  try {
    let customer_id = req.body.customer_id;
    let user_id = req.body.user_id;
    let activity_id = req.body.activity_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_clearance_PL_ontrack(customer_id, user_id, service_id, activity_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_c = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_c(atyid, start, end, user_id, 0, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_report_c = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_report_c(atyid, start, end, user_id, 0, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_delay_c = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_c(atyid, start, end, user_id, 2, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_delay_report_c = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_report_c(atyid, start, end, user_id, 2, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_ontrack_c = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_c(atyid, start, end, user_id, 1, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_ontrack_report_c = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_c(atyid, start, end, user_id, 1, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_delay_pl = async function (req, res, next) {
  var _output = new output();
  try {
    let customer_id = req.body.customer_id;
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_delay_pl(atyid, customer_id, start, end, user_id, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_status_for_user_ontrack_pl = async function (req, res, next) {
  var _output = new output();
  try {
    let customer_id = req.body.customer_id;
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_ontrack_pl(atyid, customer_id, start, end, user_id, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_primary_task_status = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_primary_task_status(start, end, user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "primary data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_primary_task_status_pl_ontrack = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_primary_task_status_pl_ontrack(start, end, user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "primary data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_primary_task_status_pl = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_primary_task_status_pl(start, end, user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "primary data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_primary_task_status_c = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_primary_task_status_c(start, end, user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "primary data";;
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_primary_task_status_pl_delay = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_primary_task_status_pl_delay(start, end, user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "primary data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_primary_task_status_tr = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_primary_task_status_tr(start, end, user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "primary data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_primary_task_status_pr = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_primary_task_status_pr(start, end, user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "primary data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_pr = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let customer_id = req.body.customer_id;
    let atyid = req.body.activity_id;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_clearance_status_pr(atyid, start, end, user_id, customer_id, 0);
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_c_pr = async function (req, res, next) {
  var _output = new output();
  try {
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_clearance_status_c_pr(user_id, 0, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_delay_c_pr = async function (req, res, next) {
  var _output = new output();
  try {
    let service_id = req.body.service_id;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_clearance_status_c_pr(user_id, 2, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_ontrack_c_pr = async function (req, res, next) {
  var _output = new output();
  try {
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_clearance_status_c_pr(user_id, 1, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_c_tr = async function (req, res, next) {
  var _output = new output();
  try {
    let service_id = req.body.service_id;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_clearance_status_c_tr(user_id, 0, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_delay_c_tr = async function (req, res, next) {
  var _output = new output();
  try {
    let service_id = req.body.service_id;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_clearance_status_c_tr(user_id, 2, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_ontrack_c_tr = async function (req, res, next) {
  var _output = new output();
  try {
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_clearance_status_c_tr(user_id, 1, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_delay_pr = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let atyid = req.body.activity_id;
    let customer_id = req.body.customer_id;
    let result = await dashboard_repo.get_task_clearance_status_pr(atyid, start, end, user_id, customer_id, 2);
    _output.data = result;
    _output.is_success = true;
    _output.message = "clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_ontrack_pr = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let customer_id = req.body.customer_id;
    let atyid = req.body.activity_id;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_clearance_status_pr(atyid, start, end, user_id, customer_id, 1);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_tr = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let atyid = req.body.activity_id;
    let customer_id = req.body.customer_id;
    let result = await dashboard_repo.get_task_clearance_status_tr(atyid, start, end, user_id, customer_id, 0);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_delay_tr = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let customer_id = req.body.customer_id;
    let atyid = req.body.activity_id;
    let result = await dashboard_repo.get_task_clearance_status_tr(atyid, start, end, user_id, customer_id, 2);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status_ontrack_tr = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let customer_id = req.body.customer_id;
    let atyid = req.body.activity_id;
    let result = await dashboard_repo.get_task_clearance_status_tr(atyid, start, end, user_id, customer_id, 1);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Clearance data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}
exports.get_task_clearance_status = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let result = await dashboard_repo.get_task_clearance_status(start, end, user_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Clearance status";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_task_status_for_user_customer_photo = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_customer_photo(atyid, start, end, user_id, 0, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_task_status_for_user_customer_photo_delay = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_customer_photo(atyid, start, end, user_id, 2, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_task_status_for_user_customer_photo_ontrack = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_customer_photo(atyid, start, end, user_id, 1, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_task_status_for_user_customer_text = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_customer_text(atyid, start, end, user_id, 0, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_task_status_for_user_customer_text_delay = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_customer_text(atyid, start, end, user_id, 2, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_task_status_for_user_customer_text_ontrack = async function (req, res, next) {
  var _output = new output();
  try {
    let start = req.body.start_date;
    let atyid = req.body.activity_id;
    let end = req.body.end_date;
    let user_id = req.body.user_id;
    let service_id = req.body.service_id;
    let result = await dashboard_repo.get_task_status_for_user_customer_text(atyid, start, end, user_id, 1, service_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "task data";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}