"use strict";

const project_creation_repository = require("../repository/project_creation");
const project_creation_model = require("../models/project_full_details");
const customer_access = require('../models/customer_access');
const output = require("../models/output");
const helper = require("../helpers/json-serialize");
const Attachment = require('../models/Attachment');
const project_service = require('../models/project_service');
const _mailOptions = require("../../../helpers/mailOptions");
const _mailer = require("../../../helpers/mailer");

exports.get_project_services = async function (req, res, next) {
  var _output = new output();
  try {
    let result = await project_creation_repository.get_project_services();
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project Services";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_project_modeofreceipts = async function (req, res, next) {
  var _output = new output();
  try {
    let result = await project_creation_repository.get_project_modeofreceipts();
    _output.data = result;
    _output.is_success = true;
    _output.message = "Mode of Receipt";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }

  res.send(_output);
}

exports.get_project_roletypes = async function (req, res, next) {
  var _output = new output();
  try {
    let result = await project_creation_repository.get_project_roletypes();
    _output.data = result;
    _output.is_success = true;
    _output.message = "Role Types";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_customer_location = async function (req, res, next) {
  var _output = new output();
  try {
    let result = await project_creation_repository.get_customer_location();
    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer Location";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_customer_category = async function (req, res, next) {
  var _output = new output();
  try {
    let customer_id = req.query.customer_id;
    let result = await project_creation_repository.get_customer_category(customer_id);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer Category";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_customer_subcategory = async function (req, res, next) {
  var _output = new output();
  try {
    let VtlID = req.query.id
    let result = await project_creation_repository.get_customer_subcategory(VtlID);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer Subcategory";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_customer_currency = async function (req, res, next) {
  var _output = new output();
  try {
    let result = await project_creation_repository.get_customer_currency();
    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer Currency";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.get_project_full_details = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.project_id;
    if (!data) { throw 'ProjectID not provided'; }
    _output.data = await getProjectDetails(data);
    _output.is_success = true;
    _output.message = "Project Details";

  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}


async function getProjectDetails(project_id) {
  let result = await project_creation_repository.get_project_full_details(project_id);
  var _project_creation_model = new project_creation_model();
  var _customer_accesslst = [];
  var _project_file = [];
  var _project_servicelst = [];
  if (result[1]) {
    result[1].forEach(element => {
      var _Attachment = new Attachment();
      _Attachment.file_uri = element.FilePath
      _Attachment.file_name = element.FileName
      _Attachment.file_id = element.ID
      _project_file.push(_Attachment)
    });
  }
  if (result[2]) {
    result[2].forEach(element => {
      var _customer_access = new customer_access();
      _customer_access.customer_access_id = element.SaID;
      _customer_access.customer_access_name = element.Name;
      _customer_access.customer_access_email = element.EmailID;
      _customer_access.customer_access_roletype = element.CustRole;
      _customer_access.customer_access_roletype_id = element.CustRoleID;
      _customer_access.is_active = element.isactive
      _customer_accesslst.push(_customer_access);
    });
  }
  if (result[3]) {
    result[3].forEach(element => {
      var _project_service = new project_service();
      _project_service.comment = element.Comments;
      _project_service.due_date = element.DueDate;
      _project_service.no_of_chapters = element.NoOfChapters;
      _project_service.service_id = element.ProjSerID;
      _project_service.pr_ser_id = element.PrSerID;
      _project_service.status_id = element.StatusID;
      _project_service.service_name = element.ServiceName;
      _project_service.service_guid = element.ProjSerGUID;
      if (result[4]) {
        result[4].forEach(elem => {
          if (elem.ServiceID === element.ProjSerID) {
            var _Attachment = new Attachment();
            _Attachment.file_uri = elem.FileURL
            _Attachment.file_name = elem.FileName
            _Attachment.file_id = elem.SerAttID
            _project_service.attachments.push(_Attachment)
          }
        });
      }
      _project_servicelst.push(_project_service);
    });
  }
  _project_creation_model.project_id = result[0][0].ProjectID;
  _project_creation_model.project_code = result[0][0].ProjectCode;
  _project_creation_model.project_title = result[0][0].ProjectTitle;
  _project_creation_model.project_author = result[0][0].ProjectAuthor;
  _project_creation_model.project_lead_name = result[0][0].ProjectLeadName;
  _project_creation_model.project_lead_id = result[0][0].ProjectLeadID;
  _project_creation_model.edition = result[0][0].Edition;
  _project_creation_model.ISBN = result[0][0].ISBN;
  _project_creation_model.short_title = result[0][0].ShortTitle;
  _project_creation_model.copyright_year = result[0][0].CopyrightYear;
  _project_creation_model.no_of_chapters = result[0][0].NoOfChapter;
  _project_creation_model.project_description = result[0][0].ProjectDescription;
  _project_creation_model.receipt_date = result[0][0].ReceiptDate;
  _project_creation_model.mode_of_receipt_id = result[0][0].ModeOfReceiptID;
  _project_creation_model.mode_of_receipt = result[0][0].ModeOfReceipt;
  _project_creation_model.publication_date = result[0][0].PublicationDate;
  _project_creation_model.permission_due_date = result[0][0].PermissionDueDate;
  _project_creation_model.hires_due_date = result[0][0].HiresDuedate;
  _project_creation_model.file_to_print_date = result[0][0].PrinterDate;
  _project_creation_model.closing_date = result[0][0].ClosingDate;
  _project_creation_model.customer_id = result[0][0].CustomerID;
  _project_creation_model.customer_code = result[0][0].CustCode;
  _project_creation_model.customer_name = result[0][0].CustomerName;
  _project_creation_model.customer_email_id = result[0][0].CustomerEmail;
  _project_creation_model.customer_location_id = result[0][0].CustomerLocationID;
  _project_creation_model.customer_location = result[0][0].CustomerLocation;
  _project_creation_model.customer_category_id = result[0][0].CustomerCategoryID;
  _project_creation_model.customer_category = result[0][0].CustomerCategory;
  _project_creation_model.customer_sub_category_id = result[0][0].CustomerSubCategoryID;
  _project_creation_model.customer_sub_category = result[0][0].CustomerSubCategory;
  _project_creation_model.currency_id = result[0][0].CurrencyID;
  _project_creation_model.currency = result[0][0].CurrencyName;
  _project_creation_model.comments = result[0][0].Comments;
  _project_creation_model.customer_access = _customer_accesslst;
  _project_creation_model.photo_budget = result[0][0].PhotoBudget;
  _project_creation_model.text_budget = result[0][0].TextBudget;
  _project_creation_model.media_budget = result[0][0].MediaBudget;
  _project_creation_model.total_budget = result[0][0].TotalBudget;
  _project_creation_model.services = _project_servicelst;
  _project_creation_model.project_files = _project_file;
  _project_creation_model.status_id = result[0][0].StatusID;
  _project_creation_model.link = result[0][0].Link;
  _project_creation_model.user_name = result[0][0].UserName;
  _project_creation_model.password = result[0][0].Password;
  _project_creation_model.ftp_id = result[0][0].FTPID;
  _project_creation_model.status_code = result[0][0].Status;
  _project_creation_model.is_draft = result[0][0].StatusID === 5 ? true : false;
  _project_creation_model.project_guid = result[0][0].ProjGUID;
  return _project_creation_model;
}
exports.Get_projectList = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.user_id;
    if (!data) { throw 'user_id not provided'; }
    var result = await project_creation_repository.Get_projectList(data,0, 1);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project List";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
  }
  res.send(_output);
}
exports.Get_ProjectPLList = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.user_id;
    let atyID = req.query.aty_id != undefined ? req.query.aty_id : 0 ;
    if (!data) { throw 'user_id not provided'; }
    if (!atyID) { throw 'Activity Id not provided'; }
    var result = await project_creation_repository.Get_projectList(data,atyID,3);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project List";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
  }
  res.send(_output);
}
exports.Get_projectListForReviewer = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.user_id;
    if (!data) { throw 'user_id not provided'; }
    var result = await project_creation_repository.Get_projectList(data, 0,2);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project List";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
  }
  res.send(_output);
}

exports.Get_ProjectLead = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.user_id;
    if (!data) { throw 'user_id not provided'; }
    var result = await project_creation_repository.Get_ProjectLead(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Project Lead List";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
  }
  res.send(_output);
}

exports.Get_Customer = async function (req, res, next) {
  var _output = new output();
  try {
    let data = req.query.user_id;
    if (!data) { throw 'user_id not provided'; }
    var result = await project_creation_repository.Get_Customer(data);
    _output.data = result;
    _output.is_success = true;
    _output.message = "Customer List";
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error;
  }
  res.send(_output);
}

exports.customer_email_check = async function (req, res, next) {
  var _output = new output();
  try {
    let result = await project_creation_repository.Get_customer_email(req.body.email);
    if(result.recordset.length > 0){
      _output.data = result.recordset;
      _output.is_success = true;
      _output.message = "customer found";
    }else{
    _output.is_success = false;
    _output.message = "customer not found";
    }
    
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.create_project = async function (req, res, next) {
  var _output = new output();
  let data = req.body;
  try {
    let project_creation_data = await helper.serialize_type(project_creation_model, req.body, "");
    if (project_creation_data.project_files) {
      project_creation_data.project_files_count = project_creation_data.project_files.length

    }
    if (project_creation_data.services) {
      project_creation_data.services_count = project_creation_data.services.length
      project_creation_data.services.forEach(element => {
        if (element.attachments) {
          element.attachments_count = element.attachments.length
        }
      });
    }
    if (project_creation_data.customer_access) {
      project_creation_data.customer_access_count = project_creation_data.customer_access.length
    }
    let previousstatus = await project_creation_repository.getProjectCurrentStatus(project_creation_data.project_id);
    let project_id = await project_creation_repository.add_edit_project_details(JSON.stringify(project_creation_data));

    // await project_creation_repository.create_project(project_creation_data).then(async (value) => {
    //   project_creation_data = value;
    //   project_creation_data.project_files = await project_creation_repository.Fproject_files(_project_creation_model.project_files, ProjectID, _project_creation_model.user_id);
    //   project_creation_data.customer_access = await project_creation_repository.addedit_project_customer(project_creation_data.customer_access, project_creation_data.project_id, project_creation_data.user_id)
    //   project_creation_data.services = await project_creation_repository.addedit_project_service(project_creation_data, project_creation_data.project_id, project_creation_data.user_id)
    // }).catch((err) => { throw err; });
    _output.data = await getProjectDetails(project_id);//{ ProjectID: result };
    _output.is_success = true;
    _output.message = "Project created successfully";
    const activity_actions_repo = require("../repository/activity_actions");
    if ((req.body.project_id == 0 && req.body.status_id == 1) || (req.body.project_id > 0 && previousstatus == 5)) {
      var options = await activity_actions_repo.get_mail_template(1, project_creation_data.user_id);
      options.to = _output.data.customer_email_id;
      options.subject = options.subject.replace('##title##', _output.data.project_title);
      options.html = options.html.replace('##customer##', _output.data.customer_name);
      options.html = options.html.replace('##title##', _output.data.project_title);
      options.html = options.html.replace('##code##', _output.data.project_code);
      _mailer.sendMail(options);
    }
    if (project_creation_data.customer_access) {
      project_creation_data.customer_access.forEach(async (element) => {
        if (element.customer_access_id == 0) {
          await project_creation_repository.create_user(element, project_creation_data.user_id);
          options = await activity_actions_repo.get_mail_template(3, project_creation_data.user_id);
          options.to = element.customer_access_email;
          options.subject = options.subject.replace('##title##', _output.data.project_title);
          options.html = options.html.replace('##customer##', _output.data.customer_name);
          options.html = options.html.replace('##title##', _output.data.project_title);
          options.html = options.html.replace('##code##', _output.data.project_code);
          options.html = options.html.replace('##role##', element.customer_access_roletype);
          _mailer.sendMail(options);
        }
      });
    }
  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
};