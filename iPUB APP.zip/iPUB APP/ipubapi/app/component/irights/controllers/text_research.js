const text_research_repo = require("../repository/text_research");
const output = require("../models/output");
var helper = require("../helpers/json-serialize");

exports.get_text_list = async function (req, res, next) {
    var _output = new output();
    try {
        let user_id = req.query.user_id;
        let activity_id = req.query.activity_id;
        let chapter_id = req.query.chapter_id;
        let is_spec = 0;
        let result = await text_research_repo.get_text_list(user_id, activity_id, chapter_id, is_spec);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text Research task for this user";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.get_selections_list = async function (req, res, next) {
    var _output = new output();
    try {
        let task_id = req.query.task_id;
        if (task_id == undefined || task_id == "" || task_id == "null") {
            throw "task_id must be passed";
        }
        let result = await text_research_repo.get_selections(task_id);
        _output.data = {
            "selections_list": result.recordsets[0],
            "chapter_attachments": result.recordsets[1]
        };
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.get_chapter_selections_list = async function (req, res, next) {
    var _output = new output();
    try {
        let chapter_id = req.query.chapter_id;
        if (chapter_id == undefined || chapter_id == "" || chapter_id == "null") {
            throw "task_id must be passed";
        }
        let result = await text_research_repo.get_chapter_selections(chapter_id);
        _output.data = {
            "selections_list": result.recordsets[0],
            "chapter_attachments": result.recordsets[1]
        };
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};
exports.get_chapter_taskid = async function (req, res, next) {
    var _output = new output();
    try {
        let chapter_id = req.query.chapter_id;
        if (chapter_id == undefined || chapter_id == "" || chapter_id == "null") {
            throw "task_id must be passed";
        }
        let result = await text_research_repo.get_chapter_taskid(chapter_id);
        _output.data = result.recordset[0];
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.get_selections_details = async function (req, res, next) {
    var _output = new output();
    try {
        let selection_id = req.query.selection_id;
        if (selection_id == undefined || selection_id == "" || selection_id == "null") {
            throw "selection_id must be passed";
        }
        let result = await text_research_repo.get_selections_details(selection_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.update_selection = async function (req, res, next) {
    var _output = new output();
    try {
        let data = req.body;
        let user_id = data.user_id;
        if (user_id == undefined || user_id == "" || user_id == "null") {
            throw "user_id must be passed";
        }
        let result = await text_research_repo.update_selection(data);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.get_permission_status = async function (req, res, next) {
    var _output = new output();
    try {
        let result = await text_research_repo.get_permission_status();
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.get_permission_needed = async function (req, res, next) {
    var _output = new output();
    try {
        let result = await text_research_repo.get_permission_needed();
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};
exports.get_project_selections = async function (req, res, next) {
    var _output = new output();
    try {
        if (req.body.project_id == undefined) { throw { "message": "should pass project_id" } }
        if (req.body.activity_id == undefined) { throw { "message": "should pass activity_id" } }
        let result = await text_research_repo.get_project_selections(req.body);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.get_project_selections_full = async function (req, res, next) {
    var _output = new output();
    try {
        if (req.body.project_id == undefined) { throw { "message": "should pass project_id" } }
        let data = req.body;
        if (data.status_id == undefined) {
            data.status_id = 1;
        }
        let result = await text_research_repo.get_project_selections_full(data);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};
exports.get_project_selections_review = async function (req, res, next) {
    var _output = new output();
    try {
        if (req.body.project_id == undefined) { throw { "message": "should pass project_id" } }
        let data = req.body;
        if (data.status_id == undefined) {
            data.status_id = 4;
        }
        let result = await text_research_repo.get_project_selections_full(data);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};
exports.get_selection_rights_holder = async function (req, res, next) {
    var _output = new output();
    try {
        if (req.body.unique_id == undefined) { throw { "message": "should pass unique_id" } }
        let result = await text_research_repo.get_selection_rights_holder(req.body.unique_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "text details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.validate_rh_follow_up_for_chapter = async function (req, res, next) {
    var _output = new output();
    try {
        if (req.body.chapter_id == undefined) { throw { "message": "should pass chapter_id" } }
        let result = await text_research_repo.validate_rh_follow_up_for_chapter(req.body.chapter_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "RH validation details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

exports.validate_rh_follow_up_for_spec = async function (req, res, next) {
    var _output = new output();
    try {
        if (req.body.spec_id == undefined) { throw { "message": "should pass spec_id" } }
        let result = await text_research_repo.validate_rh_follow_up_for_spec(req.body.spec_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "RH validation details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
};

