'use strict'

const text_clearance_repository = require("../repository/text_clearance");
const get_selection_details_model = require("../models/text_clearance_for_selection");
const output = require("../models/output");
const helper = require("../helpers/json-serialize");

exports.get_text_clearance = function (req, res, next) {
    var _output = new output();
    try {
        let data = {
            "ProjectID": "1",
            "ChapterID": "1",
            "SessionID": "1",
            "RightsHolderID": "iRights"
        };
        let result = text_clearance_repository.get_text_clearance(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Get Text Clearance details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}

exports.update_text_clearance = function (req, res, next) {
    var _output = new output();
    try {
        let selection_details = helper.serialize_type(get_selection_details_model, req.body, "");

        let result = text_clearance_repository.update_text_clearance(selection_details);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Update Text Clearance";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
}