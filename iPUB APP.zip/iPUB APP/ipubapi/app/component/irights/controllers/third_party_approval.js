'use strict'

const third_party_approval_repo = require("../repository/third_party_approval");
const output = require("../models/output");

exports.third_party_approval = function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        let result = third_party_approval_repo.third_party_approval(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Get Third Party PL";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}

exports.third_party_approval_details = function (req, res, next) {
    var _output = new output();
    try {
        let data = {};
        let result = third_party_approval_repo.third_party_approval_details(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Get Third Party PL";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}