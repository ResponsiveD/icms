"use strict";
const text_qc_repository = require("../repository/text_qc");
const output = require("../models/output");

exports.text_quality_check = function (req, res, next) {
    var _output = new output();
    try {
        let data = {
            "status_id": 1,
            "status": true,
            "reason": "success",
            "commands": "created"
        };
        let result = text_qc_repository.text_quality_check(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Text Quality Check is Successfully Created";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
};
