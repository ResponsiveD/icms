"use strict";
const load_indicator_repo = require("../repository/load_indicator");
const output = require("../models/output");

exports.load_indicator = function (req, res, next) {
    var _output = new output();
    try {
        let result = load_indicator_repo.load_indicator();

        _output.data = result;
        _output.is_success = true;
        _output.message = "Photo Quality Check is Successfully Created";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
};
