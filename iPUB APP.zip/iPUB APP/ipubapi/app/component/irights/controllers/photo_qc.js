"use strict";
const photo_qc_repo = require("../repository/photo_qc");
const output = require("../models/output");

exports.photo_quality_check = function (req, res, next) {
    var _output = new output();
    try {
        let data = {
            "status_id": 1,
            "status": true,
            "reason": "success",
            "commands": "created"
        };
        let result = photo_qc_repo.photo_quality_check(data);

        _output.data = result;
        _output.is_success = true;
        _output.message = "Photo Quality Check is Successfully Created";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
};
