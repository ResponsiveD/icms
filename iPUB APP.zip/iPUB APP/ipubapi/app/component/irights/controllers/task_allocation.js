'use strict'

const task_allocation_repository = require("../repository/task_allocation");
const output = require("../models/output");

exports.get_tasks = async function (req, res, next) {
    var _output = new output();
    try {
        let user_id = req.query.user_id;
        let project_id = req.query.project_id;
        let result = await task_allocation_repository.get_tasks(user_id,project_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "get task allocation details";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }

    res.send(_output);
};

exports.get_resource_name = async function (req, res, next) {
    var _output = new output();
    try {
        let user_id = req.query.user_id;
        let result = await task_allocation_repository.get_resource_name(user_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Resource Name";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}
exports.get_resource_name_on_activity = async function (req, res, next) {
    var _output = new output();
    try {
        let user_id = req.query.user_id;
        let result = await task_allocation_repository.get_resource_name_on_activity(user_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Resource Name";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}
exports.post_tasks = async function (req, res, next) {
    var _output = new output();
    try {
        let data = (req.body.data);
        let user_id = req.body.user_id;
        //let project_id = req.body.project_id;
        let result = await task_allocation_repository.post_tasks(data,user_id);
       // result = await task_allocation_repository.get_tasks(result,project_id);
        _output.data = result;
        _output.is_success = true;
        _output.message = "Post task allocation";
    } catch (error) {
        _output.data = "";
        _output.is_success = false;
        _output.message = error.message;
    }
    res.send(_output);
}
