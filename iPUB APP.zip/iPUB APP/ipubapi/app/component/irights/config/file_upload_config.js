const env_mode = require('../../../../config/env/env_mode.json')

exports.CloudCredentials = () => {
    if (env_mode.ENVMODE == "dev") {
        return { accessKey : '86NuRWfrPuRPi/QM7RYWy3x3g9tQdL6F7aecafPv6T3D9TjibM8RSCD1RTjpMspg/M/jXf8hChA5scKCd3penA==',
        storageAccount : 'ipubsuitedev',
        containerName : 'ipubsuite',
        cloudBasePath : 'https://ipubsuitedev.blob.core.windows.net/ipubsuite/'
    }
    }
    else if (env_mode.ENVMODE == "test") {
        return { accessKey : 'u/Enms2E+ffFdWNynpELYZZARsLgx6e5uAXRI3AT0rzeA3zThUSx5mn4mKh8adw7JpHfeEvgdJpIVaJZdenQoA==',
        storageAccount : 'ipubsuitetest',
        containerName : 'ipubsuite',
        cloudBasePath : 'https://ipubsuitetest.blob.core.windows.net/ipubsuite/'
    }
    }
    else if (env_mode.ENVMODE == "live") {
        return { accessKey : '',
        storageAccount : '',
        containerName : '',
        cloudBasePath : ''
    }
    }
}

exports.AllowedFileType = ['application/vnd.openxmlformats-officedocument.wordprocessingml.document',
'image/jpeg', 
'application/pdf', 
'application/msword', 
'image/png', 
'application/vnd.ms-excel', 
'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
'application/postscript',
'application/vnd.ms-powerpoint', 
'application/vnd.openxmlformats-officedocument.presentationml.presentation',
'application/octet-stream'
];

exports.AllowedFileExtension = [
'.jpeg', 
'.jpg',
'.pdf', 
'.png',
'.doc',
'.docx',
'.xls',
'.xlsx',
'.xlsb',
'.ppt',
'.pptx',
'.msg'
];