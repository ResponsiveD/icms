'use strict'

const exception_repo = require("../../../middleware/exception/exception");
const output = require("../../../models/Output");
const file_service = require("../Service/file.service");
const common = require("../../../helpers/common");
const HttpStatus = require('http-status-codes');


exports.getJobDetails = async function (req, res, next) {
  let _output = new output();
  // try {
    let mock = '{ "sMessage": "Content Found for GUID : 15987524", "nCode": 1, "sType": "Information", "nType": 2, "oData": {   "jobdetails": {     "JobGUID": "15987524",     "BookName": "CUPSample",     "BookCode": "CUPS",     "OveralJobStatus": "WIP",     "ProofType": "B",     "Customer": "cup",     "ResourcePath": "ibps/15987524/Data/Resources",     "HasTrack": "True",     "HasContentAccess": "True",    "RevisionCount": 0,     "CustomerID": 9,    "CommentEditable": "True",     "isOnshore": false   },   "ActivtyDetails": {     "ActivityID": 55,     "ActivityName": "Author",    "roleID": 12,     "userDetails": {       "roleName": "copy editor",       "Name": "Prabakaran.R",       "Email": "prabakaran.ravy@integra.co.in"     },     "ActivitySequence": 2   },   "chapterdetails": [     {       "ChapterGUID": "11111111",       "ChapterId": 1,       "ChapterName": "Chapter1",                  "ChapterTitle": "Chapter1",       "ChapSeq": 1,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111111/System/Input/Chapter1.html",       "OutputPath": "ibps/15987524/Data/55/11111111/System/OutPut/Chapter1.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111111/System/Resources"     },     {       "ChapterGUID": "22222222",       "ChapterId": 2,       "ChapterName": "Chapter2",                  "ChapterTitle": "Chapter2",       "ChapSeq": 2,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/22222222/System/Input/Chapter2.html",       "OutputPath": "ibps/15987524/Data/55/22222222/System/OutPut/Chapter2.xml",       "ChpResourcePath": "ibps/15987524/Data/55/22222222/System/Resources"     },     {       "ChapterGUID": "33333333",       "ChapterId": 3,       "ChapterName": "Chapter3",                  "ChapterTitle": "Chapter3",       "ChapSeq": 3,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/33333333/System/Input/Chapter3.html",       "OutputPath": "ibps/15987524/Data/55/33333333/System/OutPut/Chapter3.xml",       "ChpResourcePath": "ibps/15987524/Data/55/33333333/System/Resources"     },    {       "ChapterGUID": "44444444",       "ChapterId": 4,       "ChapterName": "Chapter4",                  "ChapterTitle": "Chapter4",       "ChapSeq": 4,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/44444444/System/Input/Chapter4.html",       "OutputPath": "ibps/15987524/Data/55/44444444/System/OutPut/Chapter4.xml",       "ChpResourcePath": "ibps/15987524/Data/55/44444444/System/Resources"     },    {       "ChapterGUID": "55555555",       "ChapterId": 5,       "ChapterName": "Chapter5",                  "ChapterTitle": "Chapter5",       "ChapSeq": 5,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/55555555/System/Input/Chapter5.html",       "OutputPath": "ibps/15987524/Data/55/55555555/System/OutPut/Chapter5.xml",       "ChpResourcePath": "ibps/15987524/Data/55/55555555/System/Resources"     },    {       "ChapterGUID": "66666666",       "ChapterId": 6,       "ChapterName": "Chapter6",                  "ChapterTitle": "Chapter6",       "ChapSeq": 6,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/66666666/System/Input/Chapter6.html",       "OutputPath": "ibps/15987524/Data/55/66666666/System/OutPut/Chapter6.xml",       "ChpResourcePath": "ibps/15987524/Data/55/66666666/System/Resources"     },    {       "ChapterGUID": "77777777",       "ChapterId": 7,       "ChapterName": "Chapter7",                  "ChapterTitle": "Chapter7",       "ChapSeq": 7,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/77777777/System/Input/Chapter7.html",       "OutputPath": "ibps/15987524/Data/55/77777777/System/OutPut/Chapter7.xml",       "ChpResourcePath": "ibps/15987524/Data/55/77777777/System/Resources"     },    {       "ChapterGUID": "88888888",       "ChapterId": 8,       "ChapterName": "Chapter8",                  "ChapterTitle": "Chapter8",       "ChapSeq": 8,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/88888888/System/Input/Chapter8.html",       "OutputPath": "ibps/15987524/Data/55/88888888/System/OutPut/Chapter8.xml",       "ChpResourcePath": "ibps/15987524/Data/55/88888888/System/Resources"     },    {       "ChapterGUID": "99999999",       "ChapterId": 9,       "ChapterName": "Chapter9",                  "ChapterTitle": "Chapter9",       "ChapSeq": 9,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/99999999/System/Input/Chapter9.html",       "OutputPath": "ibps/15987524/Data/55/99999999/System/OutPut/Chapter9.xml",       "ChpResourcePath": "ibps/15987524/Data/55/99999999/System/Resources"     },    {       "ChapterGUID": "11111112",       "ChapterId": 10,       "ChapterName": "Chapter10",                  "ChapterTitle": "Chapter10",       "ChapSeq": 10,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111112/System/Input/Chapter10.html",       "OutputPath": "ibps/15987524/Data/55/11111112/System/OutPut/Chapter10.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111112/System/Resources"     },    {       "ChapterGUID": "11111113",       "ChapterId": 11,       "ChapterName": "Chapter11",                  "ChapterTitle": "Chapter11",       "ChapSeq": 11,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111113/System/Input/Chapter11.html",       "OutputPath": "ibps/15987524/Data/55/11111113/System/OutPut/Chapter11.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111113/System/Resources"     },    {       "ChapterGUID": "11111114",       "ChapterId": 12,       "ChapterName": "Index",                  "ChapterTitle": "Index",       "ChapSeq": 12,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111114/System/Input/Index.html",       "OutputPath": "ibps/15987524/Data/55/11111114/System/OutPut/Index.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111114/System/Resources"     },    {       "ChapterGUID": "11111115",       "ChapterId": 13,       "ChapterName": "Prelims",                  "ChapterTitle": "Prelims",       "ChapSeq": 13,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111115/System/Input/Prelims.html",       "OutputPath": "ibps/15987524/Data/55/11111115/System/OutPut/Prelims.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111115/System/Resources"     },    {       "ChapterGUID": "11111116",       "ChapterId": 14,       "ChapterName": "Chapter12",                  "ChapterTitle": "Chapter12",       "ChapSeq": 14,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111116/System/Input/Chapter12.html",       "OutputPath": "ibps/15987524/Data/55/11111116/System/OutPut/Chapter12.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111116/System/Resources"     },    {       "ChapterGUID": "11111117",       "ChapterId": 15,       "ChapterName": "Chapter13",                  "ChapterTitle": "Chapter13",       "ChapSeq": 15,       "StatusName": "YTS",       "InputPath": "ibps/15987524/Data/55/11111117/System/Input/Chapter13.html",       "OutputPath": "ibps/15987524/Data/55/11111117/System/OutPut/Chapter13.xml",       "ChpResourcePath": "ibps/15987524/Data/55/11111117/System/Resources"     }   ] }}';
    res.send(JSON.parse(mock));
  //   let result = await file_service.getJobDetails(req.query.docid, req.query.atyid, req.User.UserID, req.User.OrgID, req.body.fileGUIDS);
  //   if (result.recordset.length > 0) {
  //     res.status(HttpStatus.OK);

  //     let resultObject = {}
  //     let name = Object.keys(result.recordset[0])[0]; // Get the first item of the list;  = key name
  //     let JsonData = result.recordset[0][name];

  //     if (JsonData != '' && JsonData != undefined) {
  //       resultObject['sMessage'] = "Content Found for GUID : " + req.query.docid;
  //       resultObject['is_success'] = true;
  //       let resultarray = JSON.parse(JsonData);
  //       resultObject['oData'] = resultarray[0];
  //     } else {
  //       resultObject['sMessage'] = "Content not found for GUID : " + req.query.docid;
  //       resultObject['oData'] = JsonData;
  //       resultObject['is_success'] = false;
  //     }
  //     res.send(resultObject);
  //   } else {
  //     res.status(HttpStatus.UNPROCESSABLE_ENTITY).send();
  //   }
  // } catch (error) {
  //   await exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.query), error);
  //   _output.data = "";
  //   _output.is_success = false;
  //   _output.message = error.message;
  //   res.status(HttpStatus.INTERNAL_SERVER_ERROR).send(_output);
  // }
}

exports.wms_createjob_book = async function (req, res, next) {
  var _output = new output();
  try {
    let data = {};
    data = req.body;
    //data = await common.getTokenUserDetail(req, data);
    let validate_lstFileToUpload = req.body.lstFileToUpload.some(function (data) {
      if (data.Filenamewithextension != null && data.Filenamewithextension != undefined && data.FileContent != null && data.FileContent != undefined && data.Code != null && data.Code != undefined) {
        return false;
      }
      else {
        return true;
      }
    });

    let validate_workflowATY = req.body.workflowDetails.SequenceDetails.some(function (data) {
      if (data.ActivityID != null && data.ActivityID != undefined && data.RoleID != null && data.RoleID != undefined && data.ActivityName != null && data.ActivityName != undefined && data.userDetails[0].UserName != null && data.userDetails[0].UserName != undefined && data.userDetails[0].Email != null && data.userDetails[0].Email != undefined) {
        return false;
      }
      else {
        return true;
      }
    });

    let validate_booktoc = req.body.BookDetails.booktoc.some(function(data){
      if(data.FileName != null && data.FileName != undefined && data.Code != null && data.Code != undefined &&  data.title != null && data.title != undefined &&  data.IsOnshore != null && data.IsOnshore != undefined)
      {
        return false;
      }
      else
      {
        return true;
      }

    });

    let validate_cusid = req.body.CustomerID;
    let validate_wfid = req.body.workflowDetails.WorkflowID;
    let validate_bookcode = req.body.BookDetails.bookcode;
    let validate_bookname = req.body.BookDetails.bookname;
    let WFaty = req.body.workflowDetails;
    let validate_prooftype = req.body.ProofType;

    if (validate_lstFileToUpload) {
      throw { "message": "Check lstFileToUpload Input" };
    }
    else if (validate_prooftype == null || validate_prooftype == undefined) {
      throw { "message": "Check Proof Type Input" };
    }
    else if (validate_workflowATY) {
      throw { "message": "Check WF Activity Input" };
    }
    else if (validate_cusid == null || validate_cusid == undefined) {
      throw { "message": "Check CustomerID Input" };
    }
    else if (validate_wfid == null || validate_wfid == undefined) {
      throw { "message": "Check WorkflowID Input" };
    }
    else if (validate_bookcode == null || validate_bookcode == undefined) {
      throw { "message": "Check journalcode Input" };
    }
    else if (validate_bookname == null || validate_bookname == undefined) {
      throw { "message": "Check journalname Input" };
    }
    else if (validate_booktoc == null || validate_booktoc == undefined) {
      throw { "message": "Check booktoc Input" };
    }    
    else if (1 != await file_service.Check_WF_activity(WFaty)) {
      throw { "message": "Check WF Activity has mismatch Input" };
    }
    else {     
    }

  } catch (error) {
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}

exports.save_article_historys = async function (req, res, next) {
  let _output = new output();
  try {
    if (req.body.htmlcontent != null && req.body.htmlcontent != null && req.body.htmlcontent != '') {
      let data = {};
      data = req.body;
      data = await common.getTokenUserDetail(req, data);
      let histguid = await file_service.save_article_history(data);
      if (histguid.status == 'true') {
        res.status(HttpStatus.OK);
        let blobdata = {};
        blobdata.byte = req.body.htmlcontent;
        blobdata.path = histguid.Path_History;
        _output.data = await common.blobByteUpload(blobdata);
        _output.is_success = true;
        _output.message = "Saved Successfully";

      } else {
        _output.data =
          _output.is_success = false;
        _output.message = "Not saved Successfully";
      }
    }
    else {
      throw { "message": "Check html content Input" };
    }
  } catch (error) {
    await exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.query), error);
    _output.data = "";
    _output.is_success = false;
    _output.message = error.message;
  }
  res.send(_output);
}