var sqlType = require('mssql');
const db_library = require('../../../../config/lib/db_library');
const param = require('../../../models/parameter_input');
let common = require('../../../helpers/common');

exports.save_article_history = async (Data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        parameters.push(para);
        db_library
            .execute("[IBPS].[saveArticlehistory]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0]);
            }).catch(err => {
                reject({ "message": "There is error on occurred in database, Please contact administrator " })
            });
    });
}

exports.Check_WF_activity = async (Data) => {
    return await new Promise((resolve, reject) => {
        let _parameters = [];
        let JsonData = JSON.stringify(Data);
        let para = new param('JsonData', sqlType.NVarChar, JsonData);
        _parameters.push(para);
        db_library
            .execute("[IPS].[CheckActivitywithWF]", _parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0][0].status);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.getJobDetails = async (docId, atyId, UserID, OrgID) => {
    try {
        let _parameters = [];
        let para = new param('DocID', sqlType.NVarChar, docId);
        _parameters.push(para);
        para = new param('AtyID', sqlType.Int, atyId);
        _parameters.push(para);
        para = new param('userid', sqlType.Int, UserID);
        _parameters.push(para);
        para = new param('orgid', sqlType.Int, OrgID);
        _parameters.push(para);
        return await db_library.execute_await('[IPS].[GetJobDetails]', _parameters, db_library.query_type.SP)
    } catch (error) {
        return { "message": "There is error on occurred in database, Please contact administrator " };
    }
}
