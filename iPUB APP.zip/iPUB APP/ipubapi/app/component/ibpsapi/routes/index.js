"use strict";
const express = require("express");
const router = express.Router();

//Middelware
const middelware = require('../../../middleware/auth/auth.middelware');

//controller
const file_controller = require("../controllers/file.controller");
const fileoperation_controller = require("../controllers/fileoperation.controller");

//file operation
router.post("/file-byteupload", middelware.userAuthOrSecreat, fileoperation_controller.file_byteupload);
router.post("/get-file-data", middelware.userAuthOrSecreat, fileoperation_controller.get_blob_datas);

//Chapter operation
router.post("/save-file-history", middelware.userAuth, file_controller.save_article_historys)

//i-Author 
router.get("/getjobdetails", middelware.userAuth, file_controller.getJobDetails)

module.exports = router;