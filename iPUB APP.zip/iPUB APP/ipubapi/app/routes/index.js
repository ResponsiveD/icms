"use strict";
const express = require("express");
const router = express.Router();
const home_controller = require("../controllers/login.controller");
const application_controller = require("../controllers/application.controller");
const application_pipe = require("../pipe/application.pipe");
const middelware = require('../middleware/auth/auth.middelware');
const automation_controller = require('../controllers/automation.controller');
const user_access_controller = require('../controllers/userAccess.controller');
const access_log_api_system = require('../controllers/access_log');
const activity_stream_controller = require('../controllers/activityStream.controller');

//API Validation library 
const schemaBodyValidator = require('../helpers/pipeLib');
const schemas = require('../pipe/schemas');

// We are using the formatted Joi Validation error
const validateRequest = schemaBodyValidator.bodyValidation(true, schemas);

/** welcome service  */
router.get('/', home_controller.welcome);

/** init service  */
router.post('/init', application_pipe.init, application_controller.init);

/** external client init service  */
router.post('/client/init', application_controller.externalClientInit);

/** refresh token  */
router.post('/token/renewal', middelware.refreshAuth, application_controller.tokenRenewal);

/** iPubSuite Accunt web service */
router.post("/login", middelware.appAthu, validateRequest, home_controller.login);
router.get("/logout", middelware.userAuth, home_controller.logOut);
router.post("/forgot-password", middelware.appAthu, home_controller.forgot_password);
router.post("/change-password", middelware.userAuth, home_controller.change_password);
router.post("/register", middelware.appAthu, home_controller.register);

//external Login
router.post("/client/login", middelware.apiKeyAuth, home_controller.on_primis_login);

/**Automation urls */
router.post("/get-automation-file", automation_controller.get_automation_file);
router.post("/get-automation-list", automation_controller.get_automation_list);
router.get("/getAPI", function (req, res, next) { res.send("Hi From ipubsuite") });
router.post("/lock-automation-file", automation_controller.lock_automation_file);
router.post("/update-automation-status", automation_controller.update_automation_status);
router.post("/get-automation-file-path", automation_controller.get_automation_file_path)

/**enCryption and Decryption urls */
router.post("/encrypt", application_controller.encrypt);
router.get("/decrypt", application_controller.decrypt);

//user access
router.get("/get-user-access-dtl", middelware.userAuth, user_access_controller.get_user_access);
router.post("/addedit-user-access-dtl", middelware.userAuth, user_access_controller.addedit_user_access_dtl);

router.post("/client/mail", middelware.apiKeyAuth, validateRequest, application_controller.clientSendMail);

//access_log_api_system
router.post('/getusersyslog', middelware.userAuth, access_log_api_system.usersystemaccesslog);
router.post('/getuserapilog', middelware.userAuth, access_log_api_system.userapiaccesslog);
router.post('/getcolumns', middelware.userAuth, access_log_api_system.getcolumns);
router.post('/insertmasterdetails', middelware.userAuth, access_log_api_system.insertmastertables);


router.post("/query-report", middelware.userAuth, application_controller.getReport);

router.post("/get-dashboard-data-stream", middelware.userAuth, activity_stream_controller.get_dashboard_data_stream);
router.post("/download-files-from-blob", middelware.userAuth, activity_stream_controller.download_files_from_blob);
router.post("/upload-files-to-blob", middelware.userAuth, activity_stream_controller.upload_files_to_blob);
router.get("/get-all-customer", middelware.userAuth, activity_stream_controller.get_all_customer);
router.get("/get-all-journal", middelware.userAuth, activity_stream_controller.get_all_journal);
router.get("/get-all-book", middelware.userAuth, activity_stream_controller.get_all_book);
router.get("/get-all-article", middelware.userAuth, activity_stream_controller.get_all_article);
router.get("/get-all-activity", middelware.userAuth, activity_stream_controller.get_all_activity);

module.exports = router;
