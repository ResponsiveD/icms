"use strict";

module.exports = [
 {
    "code": 1000 ,
    "message": "body not found"
 },
 {
    "code": 1001 ,
    "message": "There is an error occurred in interface, Please contact administrator"
 },
 {
    "code": 1002 ,
    "message": "There is error on occurred in database, Please contact administrator"
 },
 {
    "code": 1001 ,
    "message": ""
 },
 {
    "code": 1001 ,
    "message": ""
 },
 {
    "code": 1001 ,
    "message": ""
 },
 {
    "code": 1001 ,
    "message": ""
 },
 {
    "code": 1001 ,
    "message": ""
 },
 {
    "code": 1001 ,
    "message": ""
 },
 {
    "code": 1001 ,
    "message": ""
 }
]