"use strict";


const jwtlib = require('./lib/jwtlib');
const application_repo = require("../../repository/application.service");
const HttpStatus = require('http-status-codes');
const exception_repo = require("../exception/exception");

exports.appAthu = async function (req, res, next) {
    try {
        let token = jwtlib.jwtFetch(req);
        if (token) {
            await jwtlib.verifyToken(req, res, token, false);
            if (req.User != undefined) {
                req.User.startTime = new Date();
                let appTokenCheck = await application_repo.checkAppToken(req.User.ID, req.User.ClientKey);
                if (appTokenCheck.recordsets[0].length > 0) {
                    next();
                } else {
                    res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
                }
            }
        } else {
            res.status(HttpStatus.BAD_REQUEST).send("token not found.");
        }
    } catch (error) {
        exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.body), error, 0);
        res.status(HttpStatus.BAD_REQUEST).send(error);
    }
};

exports.appAndUserAthu = async function (req, res, next) {
    try {
        let token = jwtlib.jwtFetch(req);
        if (token) {
            await jwtlib.verifyToken(req, res, token, true);
            if (req.User != undefined) {
                req.User.startTime = new Date();
                if (req.User.Auth == 0 && req.User.LoginID == 0) {
                    next();
                } else if (req.User.UserID) {
                    let appTokenCheck = await application_repo.checkUserToken(req.User.UserID, req.User.LoginID);
                    if (appTokenCheck.recordsets[0].length > 0) {
                        next();
                    } else {
                        res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
                    }
                } else if (req.User.ClientKey) {
                    let appTokenCheck = await application_repo.checkAppToken(req.User.ID, req.User.ClientKey);
                    if (appTokenCheck.recordsets[0].length > 0) {
                        next();
                    } else {
                        res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
                    }
                } else {
                    res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
                }
            }
        } else {
            res.status(HttpStatus.BAD_REQUEST).send("token not found.");
        }
    } catch (error) {
        exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.body), error, 0);
        res.status(HttpStatus.BAD_REQUEST).send(error);
    }
};

exports.userAuth = async function (req, res, next) {
    try {
        let token = jwtlib.jwtFetch(req);
        if (token) {
            await jwtlib.verifyToken(req, res, token, true);
            if (req.User != undefined) {
                req.User.startTime = new Date();
                if (req.User.Auth == 0 && req.User.LoginID == 0) {
                    next();
                } else if (req.User.UserID) {
                    let userTokenCheck = await application_repo.checkUserToken(req.User.UserID, req.User.LoginID);
                    if (userTokenCheck.recordsets[0].length > 0) {
                        if (userTokenCheck.recordsets[0][0].session > 0) {
                            next();
                        } else {
                            res.status(HttpStatus.UNAUTHORIZED).send("expired session.");
                        }
                    } else {
                        res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
                    }
                } else {
                    res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
                }
            }
        } else {
            res.status(HttpStatus.BAD_REQUEST).send("token not found.");
        }
    } catch (error) {
        exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.body), error, 0);
        res.status(HttpStatus.BAD_REQUEST).send(error);
    }
};

exports.userAuthOrSecreat = async function (req, res, next) {
    try {
        let token = jwtlib.jwtFetch(req);
        if (token) {
            await jwtlib.verifyToken(req, res, token, true);
            if (req.User != undefined) {
                req.User.startTime = new Date();
                if (req.User.Auth == 0 && req.User.LoginID == 0) {
                    next();
                } else if (req.User.UserID) {
                    let userTokenCheck = await application_repo.checkUserToken(req.User.UserID, req.User.LoginID);
                    if (userTokenCheck.recordsets[0].length > 0) {
                        if (userTokenCheck.recordsets[0][0].session > 0) {
                            next();
                        } else {
                            res.status(HttpStatus.UNAUTHORIZED).send("expired session.");
                        }
                    } else {
                        res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
                    }
                } else {
                    res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
                }
            }
        } else if (req.headers.apikey != undefined) {
            req.User = {};
            req.User.startTime = new Date();
            let apiKey = req.headers.apikey;
            let clientid = req.headers.clientid;
            let appTokenCheck = await application_repo.checkAppKeyExists(apiKey, clientid);
            if (appTokenCheck.recordsets[0].length > 0) {
                next();
            } else {
                res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
            }
        } else {
            res.status(HttpStatus.BAD_REQUEST).send("token not found.");
        }
    } catch (error) {
        exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.body), error, 0);
        res.status(HttpStatus.BAD_REQUEST).send(error);
    }
};

exports.apiKeyAuth = async function (req, res, next) {
    try {
        if (req.headers.apikey != undefined) {
            req.User = {};
            req.User.startTime = new Date();
            let apiKey = req.headers.apikey;
            let clientid = req.headers.clientid;
            let appTokenCheck = await application_repo.checkAppKeyExists(apiKey, clientid);
            if (appTokenCheck.recordsets[0].length > 0) {
                req.User = {
                    "org_id": 1,
                    "org_div_id": 1
                }
                next();
            } else {
                res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
            }
        } else {
            res.status(HttpStatus.BAD_REQUEST).send("token not found.");
        }
    } catch (error) {
        exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.body), error, 0);
        res.status(HttpStatus.BAD_REQUEST).send(error);
    }
};

exports.refreshAuth = async function (req, res, next) {
    try {
        let token = jwtlib.jwtFetch(req);
        if (token) {
            await jwtlib.verifyToken(req, res, token, true);
            if (req.User != undefined) {
                req.User.startTime = new Date();
                if (req.User.UserID) {
                    let refresTokenCheck = await application_repo.checkUserToken(req.User.UserID, req.User.LoginID);
                    if (refresTokenCheck.recordsets[0].length > 0) {
                        next();
                    } else {
                        res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
                    }
                } else {
                    res.status(HttpStatus.UNAUTHORIZED).send("invalid token.");
                }
            }
        } else {
            res.status(HttpStatus.BAD_REQUEST).send("token not found.");
        }
    } catch (error) {
        exception_repo.exception_DB_log(1, 1, 1, 1, req.method, req.originalUrl, JSON.stringify(req.body), error, 0);
        res.status(HttpStatus.BAD_REQUEST).send(error);
    }
};