"use strict";
const db_library = require('../../config/lib/db_library');
const param = require('../models/parameter_input');
const sqlType = require('mssql');
const JSZip = require('JSZip');
const common = require('../helpers/common');
const file_upload_config = require("../../config/file_upload_config");
const basepath = file_upload_config.CloudCredentials().cloudBasePath;

exports.download_files_from_blob = async (data) => {
  try {
    let _parameters = [];
    let para = new param('CustID', sqlType.Int, data.cust_id);
    _parameters.push(para);
    para = new param('Type', sqlType.NVarChar, data.type);
    _parameters.push(para);
    para = new param('JournalID', sqlType.Int, data.journal_id);
    _parameters.push(para);
    para = new param('BookID', sqlType.Int, data.book_id);
    _parameters.push(para);
    para = new param('ArticleGUID', sqlType.NVarChar, data.article_guid);
    _parameters.push(para);
    para = new param('AtyID', sqlType.Int, data.aty_id);
    _parameters.push(para);
    return db_library.execute_await("[IPS].[spGetFilesFromBlob]", _parameters, db_library.query_type.SP);

  } catch (error) {
    return {
      "message": "There is error on occurred in database, Please contact administrator "
    };
  }
}

exports.add_blob_to_zip_with_path = async (input, Path) => {
  return new Promise((resolve, reject) => {
    try {
      var FetchStream = require("fetch").FetchStream;
      var zip = new JSZip();
      input.forEach(element => {
        let fullpath = basepath + element;
        let readStream = new FetchStream(fullpath);
        zip.file(element, readStream);
      });
      zip.generateAsync({
        type: "base64"
      }).then(async function (content) {
        content = Buffer.from(content, 'base64')
        await common.BlobUpload(Path, content, content.byteLength).then(
          (Path) => {
            resolve(Path);
          }).catch(
          (err) => {
            reject(err);
          });
      }).catch(err => {
        reject(err)
      })
    } catch (err) {
      reject(err);
    }
  });
}

exports.upload_files_to_blob = async (data) => {
  try {
    let _parameters = [];
    let para = new param('CustID', sqlType.Int, data.cust_id);
    _parameters.push(para);
    para = new param('ExtnType', sqlType.NVarChar, data.extn_type);
    _parameters.push(para);
    para = new param('UserID', sqlType.Int, data.user_id);
    _parameters.push(para);
    para = new param('OrgID', sqlType.Int, data.org_id);
    _parameters.push(para);
    para = new param('ArticleGUID', sqlType.NVarChar, data.article_guid);
    _parameters.push(para);
    para = new param('AtyID', sqlType.Int, data.aty_id);
    _parameters.push(para);
    if (data.type.toLocaleLowerCase() === 'journal') {
      return db_library.execute_await("[IJPS].[spGetUploadPathForAtyStream]", _parameters, db_library.query_type.SP);
    } else if (data.type.toLocaleLowerCase() === 'book') {
      return db_library.execute_await("[IBPS].[spGetUploadPathForAtyStream]", _parameters, db_library.query_type.SP);
    } else {

    }
  } catch (error) {
    return {
      "message": "There is error on occurred in database, Please contact administrator "
    };
  }
}

exports.get_all_customer = async (data) => {
  return new Promise((resolve, reject) => {
    let _parameters = [];
    let para = new param('CompID', sqlType.Int, data.comp_id);
    _parameters.push(para);
    db_library.execute_await("[IPS].[spGetAllCustomer]", _parameters, db_library.query_type.SP).then((result) => {
      resolve(result.recordsets[0]);
    }).catch((err) => {
      reject(err);
    });
  })
}

exports.get_all_journal = async (data) => {
  return new Promise((resolve, reject) => {
    let _parameters = [];
    let para = new param('CustID', sqlType.Int, data.cust_id);
    _parameters.push(para);
    db_library.execute_await("[IPS].[spGetAllJournal]", _parameters, db_library.query_type.SP).then((result) => {
      resolve(result.recordsets[0]);
    }).catch((err) => {
      reject(err);
    });
  })
}

exports.get_all_book = async (data) => {
  return new Promise((resolve, reject) => {
    let _parameters = [];
    let para = new param('CustID', sqlType.Int, data.cust_id);
    _parameters.push(para);
    db_library.execute_await("[IPS].[spGetAllBook]", _parameters, db_library.query_type.SP).then((result) => {
      resolve(result.recordsets[0]);
    }).catch((err) => {
      reject(err);
    });
  })
}

exports.get_all_article = async (data) => {
  return new Promise((resolve, reject) => {
    let _parameters = [];
    let para = new param('Type', sqlType.VarChar, data.type);
    _parameters.push(para);
    para = new param('JournalID', sqlType.Int, data.journal_id);
    _parameters.push(para);
    para = new param('BookID', sqlType.Int, data.book_id);
    _parameters.push(para);
    db_library.execute_await("[IPS].[spGetArticleName]", _parameters, db_library.query_type.SP).then((result) => {
      resolve(result.recordsets[0]);
    }).catch((err) => {
      reject(err);
    });
  })
}

exports.get_all_activity = async (data) => {
  return new Promise((resolve, reject) => {
    let _parameters = [];
    let para = new param('JournalID', sqlType.Int, data.journal_id);
    _parameters.push(para);
    para = new param('BookID', sqlType.Int, data.book_id);
    _parameters.push(para);
    para = new param('Type', sqlType.VarChar, data.type);
    _parameters.push(para);
    para = new param('ArticleID', sqlType.Int, data.article_id);
    _parameters.push(para);
    db_library.execute_await("[IPS].[spGetActivityName]", _parameters, db_library.query_type.SP).then((result) => {
      resolve(result.recordsets[0]);
    }).catch((err) => {
      reject(err);
    });
  })
}

exports.get_dashboard_data_stream = async (data) => {
  return new Promise((resolve, reject) => {
    let _parameters = [];
    let para = new param('Type', sqlType.VarChar, data.type);
    _parameters.push(para);
    para = new param('CustID', sqlType.Int, data.cust_id);
    _parameters.push(para);
    para = new param('CompID', sqlType.Int, data.comp_id);
    _parameters.push(para);
    para = new param('JournalID', sqlType.Int, data.journal_id);
    _parameters.push(para);
    para = new param('BookID', sqlType.Int, data.book_id);
    _parameters.push(para);
    para = new param('Limit', sqlType.Int, data.limit);
    _parameters.push(para);
    para = new param('Page', sqlType.Int, data.page);
    _parameters.push(para);
    db_library.execute_await("[IPS].[spGetDashboardStream]", _parameters, db_library.query_type.SP).then((result) => {
      resolve({
        streams: result.recordsets[0],
        pagedetails: result.recordsets[1][0]
      });
    }).catch((err) => {
      reject(err);
    });
  })
}