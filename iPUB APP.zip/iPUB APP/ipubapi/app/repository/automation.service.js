var sqlType = require('mssql');
const db_library = require('../../config/lib/db_library')
const param = require('../models/parameter_input');
const common = require('../helpers/common');
var JSDOM = require("jsdom")
var JSZip = require('JSZip')



exports.get_automation_list = async (data, cust) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        db_library
            .execute('[IPS].[GetAutomationList]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0]
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_automation_entry = async (data, cust) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
        parameters.push(para);
        db_library
            .execute('[IPS].[AddAutomationEntry]', parameters, db_library.query_type.SP).then(async (value) => {
                var results = value.recordsets[0][0];
                //if (data.automation_id == 2) {
                try {
                    await common.SendSocketObjectToAutomation({
                        product: "iPUb",
                        AutomationId: data.automation_id
                    })
                } catch (err) {}
                resolve(results);
                //}
                // else {
                //    resolve(results);
                // }
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_automation_file_path = async (data, cust) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
        parameters.push(para);
        db_library
            .execute('[IPS].[AddAutomationEntry]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0][0].token_id
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.add_blob_to_zip_stream = async (input, Path) => {
    return new Promise(async (resolve, reject) => {
        try {
            var FetchStream = require("fetch").FetchStream;
            var path = require('path')
            var zip = new JSZip();
            if (input.file_paths != undefined) {
                for (let inpt = 0; inpt < input.file_paths.length; inpt++) {
                    let element = input.file_paths[inpt];
                    let paths = input.base_path + element;
                    let checkPath = element.split("/");
                    checkPath.shift();
                    checkPath = checkPath.join('/');
                    let isExists = await common.doesBlobExist(checkPath);
                    if (!isExists) {
                        reject({
                            "message": "Main file not found in blob."
                        })
                    }
                    let temp = {}
                    temp.paths = paths;
                    //let readStream = await common.getBlobToStream(checkPath);//new FetchStream(JSON.parse(JSON.stringify(temp)).paths);
                    let readStream = new FetchStream(JSON.parse(JSON.stringify(temp)).paths);
                    let file_name = path.basename(element);
                    zip.file(file_name, readStream);
                }
            }
            // input.file_paths.forEach(async element => {
            //     let paths = input.base_path + element;
            //     let checkPath = element.split("/");
            //     checkPath.shift();
            //     checkPath = checkPath.join('/'); 
            //     let isExists = await common.doesBlobExist(checkPath);
            //     if(!isExists){
            //         reject({"message":"Main file not found in blob."})
            //     }
            //     let readStream = new FetchStream(paths);
            //     let file_name = path.basename(element)
            //     zip.file(file_name, readStream);
            // });

            if (input.images != undefined) {
                for (let iInpt = 0; iInpt < input.images.length; iInpt++) {
                    let element = input.images[iInpt];
                    let paths = element;
                    let readStream = new FetchStream(paths);
                    let file_name = path.basename(element)
                    zip.file("graphic/" + file_name, readStream);
                }
                // input.images.forEach(element => {
                //     let paths = element;
                //     let readStream = new FetchStream(paths);
                //     let file_name = path.basename(element)
                //     zip.file("graphic/" + file_name, readStream);
                // });
            }
            if (input.files != undefined) {
                for (let iFnpt = 0; iFnpt < input.files.length; iFnpt++) {
                    let element = input.files[iFnpt];
                    zip.file(element.file_name, element.file_content);
                }
            }
            // input.files.forEach((element) => {
            //     zip.file(element.file_name, element.file_content);
            // })
            zip.generateAsync({
                type: "base64"
            }).then(async function (content) {
                content = new Buffer(content, 'base64')
                await common.BlobUpload(Path, content, content.byteLength).then(
                    (Path) => {
                        resolve(Path);
                    }).catch(
                    (err) => {
                        reject(err);
                    });
            });
        } catch (err) {
            reject(err);
        }
    });
}

exports.createiAMetaForIpubsuite = (JSONParam) => {
    try {
        let path = require("path");
        let fs = require("fs");
        let xmlcontent = "";
        let xmlDom;
        let document;
        xmlcontent = fs.readFileSync(path.join(path.parse(__dirname).dir, "/component/ijps/data/ipubsuitejobinfo.xml"), "utf-8");
        xmlDom = new JSDOM.JSDOM(xmlcontent);
        document = xmlDom.window.document;
        document.querySelector("ActivityId").innerHTML = 5614;
        document.querySelector("ActivityName").innerHTML = "L1";
        document.querySelector("StageID").innerHTML = 328;
        document.querySelector("xmlBlobPath").innerHTML = JSONParam.xmlpath;
        document.querySelector("MainFileBlobPath").innerHTML = JSONParam.file_path
        document.querySelector("resourceBlobPath").innerHTML = JSONParam.resourcePath;
        document.querySelector("StageName").innerHTML = "Pre-Editing";
        document.querySelector("Jobcardid").innerHTML = JSONParam.job_guid;
        document.querySelector("XMLConvertEXE").innerHTML = JSONParam.XMLConvertEXE;
        if (JSONParam.EngineDetails != undefined) {
            document.querySelector("EngineName").innerHTML = JSONParam.EngineDetails.EngineName
            document.querySelector("InPath").innerHTML = JSONParam.EngineDetails.InPath
            document.querySelector("OutPath").innerHTML = JSONParam.EngineDetails.OutPath
            document.querySelector("ActivityId").innerHTML = JSONParam.EngineDetails.ActivityId
        }
        var retContent = '<?xml version="1.0" standalone="yes"?>\n' + document.body.innerHTML
        return {
            "XMLContent": retContent
        }
    } catch (error) {
        console.log(error);
    }
}

exports.get_automation_file = async (automation_id) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('automation_id', sqlType.Int, automation_id);
        parameters.push(para);
        db_library
            .execute('[IPS].[GetAutomatonFiles]', parameters, db_library.query_type.SP).then((value) => {
                var results = value.recordsets[0]
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_automation_paths = async (data) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        if (data.article_guid == undefined || data.article_guid == '') {
            reject({
                'message': 'article_guid must be provided.'
            })
        }
        if (data.automation_id == undefined || data.automation_id == '') {
            reject({
                'message': 'article_guid must be provided.'
            })
        } else {
            let para = new param('JsonData', sqlType.NVarChar, JSON.stringify(data));
            parameters.push(para);
            db_library
                .execute('[IJPS].[getautomationfilepath]', parameters, db_library.query_type.SP).then((value) => {
                    var results = value.recordsets[0][0];
                    resolve(results);
                }).catch(err => {
                    reject(err)
                });
        }
    });
}

exports.lock_automation_file = async (id, engine) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('id', sqlType.Int, id);
        parameters.push(para);
        para = new param('engine', sqlType.NVarChar, engine);
        parameters.push(para);
        db_library
            .execute('[IPS].[LockAutomatonFile]', parameters, db_library.query_type.SP).then((value) => {
                var results = "updated successfully"
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.update_automation_status = async (id, engine, remark, status) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('id', sqlType.Int, id);
        parameters.push(para);
        para = new param('engine', sqlType.NVarChar, engine);
        parameters.push(para);
        para = new param('remark', sqlType.NVarChar, remark);
        parameters.push(para);
        para = new param('status', sqlType.NVarChar, status);
        parameters.push(para);
        db_library
            .execute('[IPS].[UpdateAutomatonStatus]', parameters, db_library.query_type.SP).then((value) => {
                var results = "updated successfully"
                resolve(results);
            }).catch(err => {
                reject(err)
            });
    });
}

exports.get_automation_file_path = async (Id, OrgId, UserId) => {
    return await new Promise((resolve, reject) => {
        let parameters = [];
        let para = new param('Id', sqlType.NVarChar, Id);
        parameters.push(para);
        para = new param('OrgId', sqlType.NVarChar, OrgId);
        parameters.push(para);
        para = new param('UserId', sqlType.NVarChar, UserId);
        parameters.push(para);
        db_library
            .execute("[IJPS].[GetAutomationFilePaths]", parameters, db_library.query_type.SP).then((value) => {
                resolve(value.recordsets[0]);
            }).catch(err => {
                reject(err)
            });
    });
}
exports.add_blob_to_zip_with_path = async (input, Path) => {
    return new Promise((resolve, reject) => {
        try {
            var FetchStream = require("fetch").FetchStream;
            var zip = new JSZip();
            input.forEach(element => {
                let readStream = new FetchStream(element);
                zip.file(element, readStream);
            });
            zip.generateAsync({
                type: "base64"
            }).then(async function (content) {
                content = new Buffer(content, 'base64')
                await common.BlobUpload(Path, content, content.byteLength).then(
                    (Path) => {
                        resolve(Path);
                    }).catch(
                    (err) => {
                        reject(err);
                    });
            }).catch(err => {
                reject(err)
            })
        } catch (err) {
            reject(err);
        }
    });
}

exports.add_blob_to_zip = async (input, Path) => {
    return new Promise((resolve, reject) => {
        try {
            var FetchStream = require("fetch").FetchStream;
            var path = require('path')
            var zip = new JSZip();
            input.forEach(element => {
                let paths = element;
                let readStream = new FetchStream(paths);
                let file_name = path.basename(element)
                zip.file(file_name, readStream);
            });

            zip.generateAsync({
                type: "base64"
            }).then(async function (content) {
                content = new Buffer(content, 'base64')
                await common.BlobUpload(Path, content, content.byteLength).then(
                    (Path) => {
                        resolve(Path);
                    }).catch(
                    (err) => {
                        reject(err);
                    });
            });
        } catch (err) {
            reject(err);
        }
    });
}


exports.alert_xml_to_html_failure = async (article_guid, aty_id, user_id, org_id, error) => {
    let parametersMail = [];
    let paraMail = new param('ArticleGUID', sqlType.NVarChar, data.article_guid);
    parametersMail.push(paraMail);
    paraMail = new param('UserId', sqlType.Int, user_id);
    parametersMail.push(paraMail);
    paraMail = new param('NotificationID', sqlType.Int, 19);
    parametersMail.push(paraMail);
    let mailTemplate = await db_library.execute_await("[IJPS].[GetMailTemplate]", parametersMail, db_library.query_type.SP);
    if (mailTemplate.recordsets[0].length > 0) {
        let _mailOptions = require("../helpers/mailOptions");
        let _mailer = require("../helpers/mailer");
        mailTemplate = mailTemplate.recordsets[0][0];
        let MailContent = mailTemplate.MailContent
        MailContent = MailContent.replace("##ArticleGUID##", article_guid)
        MailContent = MailContent.replace("##Error##", error.message)
        var options = new _mailOptions();
        options.bcc = mailTemplate.BCCMailID;
        options.cc = mailTemplate.CCMailID;
        options.from = mailTemplate.FromMailID;
        options.html = MailContent;
        options.subject = mailTemplate.Subject.replace("##ArticleGUID##", article_guid);
        options.to = mailTemplate.ToMailID;
        // options.compid = getcompid.ijps.compID;
        _mailer.sendMail(options);
    }
}


exports.alert_automation_failure = async (id, user_id, org_id, error) => {

    let parameters = [];
    let para = new param('Id', sqlType.Int, id);
    parameters.push(para);
    para = new param('UserId', sqlType.Int, user_id);
    parameters.push(para);
    para = new param('OrgId', sqlType.Int, org_id);
    parameters.push(para);
    let AutomationData = await db_library.execute_await("[IJPS].[AutomationFailureMsgData]", parameters, db_library.query_type.SP)
    AutomationData = AutomationData.recordsets[0][0];
    let parametersMail = [];
    let paraMail = new param('ArticleGUID', sqlType.NVarChar, AutomationData.article_guid);
    parametersMail.push(paraMail);
    paraMail = new param('UserId', sqlType.Int, user_id);
    parametersMail.push(paraMail);
    paraMail = new param('NotificationID', sqlType.Int, 20);
    parametersMail.push(paraMail);
    let mailTemplate = await db_library.execute_await("[IJPS].[GetMailTemplate]", parametersMail, db_library.query_type.SP);
    if (mailTemplate.recordsets[0].length > 0) {
        let _mailOptions = require("../helpers/mailOptions");
        let _mailer = require("../helpers/mailer");
        mailTemplate = mailTemplate.recordsets[0][0];
        let MailContent = mailTemplate.MailContent
        MailContent = MailContent.replace("##Automation Name##", AutomationData.automation_name)
        MailContent = MailContent.replace("##Filename##", AutomationData.article_name)
        MailContent = MailContent.replace("##Error##", error)
        var options = new _mailOptions();
        options.bcc = mailTemplate.BCCMailID;
        options.cc = mailTemplate.CCMailID;
        options.from = mailTemplate.FromMailID;
        options.html = MailContent;
        mailTemplate.Subject = mailTemplate.Subject.replace("##Automation Name##", AutomationData.automation_name);
        options.subject = mailTemplate.Subject.replace("##Filename##", AutomationData.article_name);
        options.to = mailTemplate.ToMailID;
        // options.compid = getcompid.ijps.compID;
        _mailer.sendMail(options);
    }
}

exports.Alert_Manuscript_Upload = async (data, author_name) => {
    let parametersMail = [];
    let paraMail = new param('ArticleGUID', sqlType.NVarChar, data.article_guid);
    parametersMail.push(paraMail);
    paraMail = new param('UserId', sqlType.Int, data.user_id);
    parametersMail.push(paraMail);
    paraMail = new param('NotificationID', sqlType.Int, 18);
    parametersMail.push(paraMail);
    let mailTemplate = await db_library.execute_await("[IJPS].[GetMailTemplate]", parametersMail, db_library.query_type.SP);
    if (mailTemplate.recordsets[0].length > 0) {
        let _mailOptions = require("../helpers/mailOptions");
        let _mailer = require("../helpers/mailer");
        mailTemplate = mailTemplate.recordsets[0][0];

        let MailContent = mailTemplate.MailContent

        MailContent = MailContent.replace("##Filename##", data.file_name)
        MailContent = MailContent.replace("##Author Name##", author_name)

        var options = new _mailOptions();
        options.bcc = mailTemplate.BCCMailID;
        options.cc = mailTemplate.CCMailID;
        options.from = mailTemplate.FromMailID;
        options.html = MailContent;
        options.subject = mailTemplate.Subject.replace("##Filename##", data.file_name);
        options.to = mailTemplate.ToMailID;
        // options.compid = getcompid.ijps.compID;
        _mailer.sendMail(options);
    }
}