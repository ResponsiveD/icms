"use strict";
const HttpStatus = require('http-status-codes');
const exception_repo = require("../middleware/exception/exception");


exports.init = async function (req, res, next) {
    try {
      let data = req.body;
      if(data){
            next()
      }else{
        res.status(HttpStatus.UNPROCESSABLE_ENTITY).send("validation error");
      }
    } catch (error) {
      exception_repo.exception_DB_log(req.User.OrgID ? req.User.OrgID : 0, 2, req.User.UserID ? req.User.UserID : 0, 0,req.method, req.originalUrl,req.body, error ? error : 0, 0,  0);
      res.send(error);
    }
  };