"use strict";
const HttpStatus = require('http-status-codes');
const exception_repo = require("../../../middleware/exception/exception");
const exception = require("../exception/exception");


exports.validate_object_json = async function (obj, rule) {
    try {
        let error = [];
        if (data === undefined) {
            error.push(await exception.getException(2089));
        }
    } catch (error) {
        exception_repo.exception_DB_log(1, 1, 1, 1, 'pipe', "validate_object_json", "validation", error);
        throw
    }
};