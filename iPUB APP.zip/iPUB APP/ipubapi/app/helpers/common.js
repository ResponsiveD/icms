const azure = require('azure');
const fs = require('fs');
let Duplex = require('stream').Duplex;
const file_upload_config = require("../../config/file_upload_config");
const accessKey = file_upload_config.CloudCredentials().accessKey;
const storageAccount = file_upload_config.CloudCredentials().storageAccount;
const containerName = file_upload_config.CloudCredentials().containerName;
const cloudBasePath = file_upload_config.CloudCredentials().cloudBasePath;
var blobService = azure.createBlobService(storageAccount, accessKey);

var Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
    encode: function (e) {
        var t = "";
        var n, r, i, s, o, u, a;
        var f = 0;
        e = Base64._utf8_encode(e);
        while (f < e.length) {
            n = e.charCodeAt(f++);
            r = e.charCodeAt(f++);
            i = e.charCodeAt(f++);
            s = n >> 2;
            o = (n & 3) << 4 | r >> 4;
            u = (r & 15) << 2 | i >> 6;
            a = i & 63;
            if (isNaN(r)) {
                u = a = 64
            } else if (isNaN(i)) {
                a = 64
            }
            t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a)
        }
        return t
    },
    decode: function (e) {
        var t = "";
        var n, r, i;
        var s, o, u, a;
        var f = 0;
        e = e.replace(/[^A-Za-z0-9+/=]/g, "");
        while (f < e.length) {
            s = this._keyStr.indexOf(e.charAt(f++));
            o = this._keyStr.indexOf(e.charAt(f++));
            u = this._keyStr.indexOf(e.charAt(f++));
            a = this._keyStr.indexOf(e.charAt(f++));
            n = s << 2 | o >> 4;
            r = (o & 15) << 4 | u >> 2;
            i = (u & 3) << 6 | a;
            t = t + String.fromCharCode(n);
            if (u != 64) {
                t = t + String.fromCharCode(r)
            }
            if (a != 64) {
                t = t + String.fromCharCode(i)
            }
        }
        t = Base64._utf8_decode(t);
        return t
    },
    _utf8_encode: function (e) {
        e = e.replace(/rn/g, "n");
        var t = "";
        for (var n = 0; n < e.length; n++) {
            var r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r)
            } else if (r > 127 && r < 2048) {
                t += String.fromCharCode(r >> 6 | 192);
                t += String.fromCharCode(r & 63 | 128)
            } else {
                t += String.fromCharCode(r >> 12 | 224);
                t += String.fromCharCode(r >> 6 & 63 | 128);
                t += String.fromCharCode(r & 63 | 128)
            }
        }
        return t
    },
    _utf8_decode: function (e) {
        var t = "";
        var n = 0;
        var r = c1 = c2 = 0;
        while (n < e.length) {
            r = e.charCodeAt(n);
            if (r < 128) {
                t += String.fromCharCode(r);
                n++
            } else if (r > 191 && r < 224) {
                c2 = e.charCodeAt(n + 1);
                t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                n += 2
            } else {
                c2 = e.charCodeAt(n + 1);
                c3 = e.charCodeAt(n + 2);
                t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                n += 3
            }
        }
        return t
    }
}
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;

const PACKAGE = require('../../package.json')
const config = require('../../config/env/config.json')
var ipswitch = config[PACKAGE.environment]["IPSWITCH"];

async function bufferToStream(buffer) {
    return await new Promise((resolve, reject) => {
        try {
            let stream = new Duplex();
            if (buffer.length) {
                buffer = new Buffer.from(buffer)
            }
            stream.push(buffer);
            stream.push(null);
            resolve(stream);
        } catch (err) {
            reject(err);
        }
    });
}

var BlobUpload = async (Path, data, length) => {
    return await new Promise(async (resolve, reject) => {
        try {
            var datas = await bufferToStream(data);
            blobService.createBlockBlobFromStream(
                containerName,
                Path,
                datas,
                length,
                function (error) {
                    if (error) {
                        reject(error);
                    } else {
                        resolve(Path);
                    }
                }
            )
        } catch (e) {
            reject(e)
        }
    });
};

var BlobTextUpload = async (Path, data) => {
    return await new Promise(async (resolve, reject) => {
        try {
            blobService.createBlockBlobFromText(
                containerName,
                Path,
                data,
                function (error) {
                    if (error) {
                        reject(error);
                    } else {
                        resolve(Path);
                    }
                }
            )
        } catch (e) {
            reject(e)
        }
    });
};

var BlobDelete = async (filePath, data, length) => {
    return await new Promise(async (resolve, reject) => {
        var streamData = await bufferToStream(data);
        let rest = filePath.substring(0, filePath.lastIndexOf("/") + 1);
        let last = filePath.substring(filePath.lastIndexOf("/") + 1, filePath.length);
        let fullPath = rest + "trash/" + last;
        blobService.createBlockBlobFromStream(containerName, fullPath, streamData, length,
            function (error) {
                if (error) {
                    reject(error);
                } else {
                    blobService.deleteBlobIfExists(containerName, filePath, err => {
                        if (err) {
                            reject(err);
                        } else {
                            resolve(fullPath);
                        }
                    });
                }
            }
        )
    });
};

var blobFileUpload = async function (file, Path) {
    return new Promise(async (resolve, reject) => {
        try {

            const basepath = file_upload_config.CloudCredentials().cloudBasePath;
            await BlobUpload(Path, file.data, file.data.length).then(
                (Path) => {
                    resolve(basepath + Path);
                }).catch(
                (err) => {
                    throw err;
                });
        } catch (error) {
            reject(error);
        }
    });
}

var blobByteUpload = async function (data) {
    return new Promise(async (resolve, reject) => {
        try {
            const basepath = file_upload_config.CloudCredentials().cloudBasePath;
            await BlobUpload(data.path, data.byte.data, data.byte.data.length).then(
                (Path) => {
                    resolve(basepath + Path);
                }).catch(
                (err) => {
                    throw err;
                });
        } catch (error) {
            reject(error);
        }
    });
}

var getBlobFile = async (Path) => {
    return await new Promise(async (resolve, reject) => {
        var datas = await bufferToStream(data);
        let stream = fs.createReadStream(Path);
        blobService.getBlobToStream(
            containerName,
            Path,
            stream,
            function (error) {
                if (error) {
                    reject(error);
                } else {
                    resolve(Path);
                }
            }
        )
    });
};

var getTokenUserDetail = async (req, data) => {
    try {
        return await new Promise(async (resolve, reject) => {
            data.user_id = req.User.UserID || 0
            data.org_id = req.User.OrgID || 0
            resolve(data);
        });
    } catch (err) {
        reject(err);
    }
}

var get_blob_data = async function (data) {
    return new Promise(async (resolve, reject) => {
        try {

            var stream = blobService.createReadStream(containerName, data);
            stream.on('error', function (datas) {
                reject(datas);
            });
            stream.on('data', async function (datas) {
                resolve(datas);
            });

        } catch (error) {
            reject(error);
        }
    });
}

var ListAllFilesPath = async (path) => {
    //return await new Promise((resolve, reject) => {
    return new Promise(async (resolve, reject) => {
        try {
            blobService.listBlobsSegmentedWithPrefix(containerName, path, null, {
                delimiter: "",
                maxResults: 10000
            }, function (err, result) {
                let PathArray = [];
                if (err) {
                    reject(err);
                } else {
                    if (result.entries.length > 0) {
                        for (let i = 0; i < result.entries.length; i++) {
                            PathArray.push(result.entries[i].name);
                            if (i == result.entries.length - 1) {
                                resolve(PathArray);
                            }
                        }
                    } else {
                        resolve(PathArray);
                    }
                }
                resolve(PathArray)
            });
        } catch (error) {
            reject(error)
        }
    });
}

var Listdatamovetodest = async function (data, cur, nxt) {
    return new Promise(async (resolve, reject) => {
        try {
            for (let index = 0; index < data.length; index++) {
                let element = data[index];
                var source = element;
                var dest = element.replace('/' + cur + '/', '/' + nxt + '/');
                let result = await get_blob_data(source);
                await BlobUpload(dest, result, result.length);
                if (index == data.length - 1) {
                    resolve(true);
                }
            }


        } catch (error) {
            reject(error);
        }
    });
}


var bytesToSize = function (bytes) {
    var sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    if (bytes == 0) return '0 Byte';
    var i = parseInt(Math.floor(Math.log(bytes) / Math.log(1024)));
    return Math.round(bytes / Math.pow(1024, i), 2) + ' ' + sizes[i];
};

var guid = function () {
    function s4() {
        return Math.floor((1 + Math.random()) * 0x10000)
            .toString(16)
            .substring(1);
    }
    return (s4() + s4());
}

var SendSocketObjectToAutomation = function (Socket_Msg) {
    return new Promise((resolve, reject) => {
        try {
            const Socket_Io = require("socket.io-client");
            const Socket_Io_Obj = Socket_Io('https://isocket.integra.co.in/integra', {
                transports: ["websocket"]
            });
            Socket_Io_Obj.on('connect', () => {
                //Socket_Msg = { product: "iPUb", AutomationId: 1 }
                console.log("Socket Connected");
            });
            Socket_Io_Obj.emit("joinIPub", JSON.stringify(Socket_Msg));
            Socket_Io_Obj.on("joinIPub", (data) => {
                if (data != undefined) {
                    Socket_Io_Obj.emit("sendProduct", JSON.stringify(Socket_Msg));
                    resolve(true);
                }
            });
            /* Socket_Io_Obj.on('disconnect', (Message) => {
                 console.log("Socket disconnected");
                 resolve(false);
             });*/
        } catch (error) {
            reject(error);
        }
    });
}

var CallPostAPI = async function postAPI(url, params = {}, contentType = "", headers = []) {
    return new Promise((resolve, reject) => {
        try {
            let xhttp = new XMLHttpRequest();
            xhttp.timeout = 60000
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    resolve(this.responseText);
                } else if (this.readyState == 4 && (this.status == 400 || this.status == 404)) {
                    reject(this.responseText);
                }
            };
            xhttp.open("POST", url, true);
            contentType = contentType ? contentType : "application/json";
            xhttp.setRequestHeader("Content-Type", contentType);
            params ? xhttp.send(JSON.stringify(params)) : xhttp.send();
        } catch (error) {
            reject(error);
        }
    });
}

var CallEncodePostAPI = async function postAPI(url, data = {}, contentType = "", headers = []) {
    const request = require('request');
    return new Promise((resolve, reject) => {
        try {
            request.post({
                url: url,
                form: { data }
            }, function (err, httpResponse, body) {
                resolve(JSON.parse(body));
            });
        } catch (error) {
            reject(error);
        }
    });
}

var CallWMSPostAPI = async function postAPI(url, params = {}, contentType = "") {
    return new Promise((resolve, reject) => {
        try {
            let xhttp = new XMLHttpRequest();
            xhttp.timeout = 60000
            xhttp.onreadystatechange = function () {
                if (this.readyState == 4 && this.status == 200) {
                    resolve(this.responseText);
                }
            };
            xhttp.open("POST", url, true);
            contentType = contentType ? contentType : "application/json";
            xhttp.setRequestHeader("Content-Type", contentType);
            xhttp.setRequestHeader("iEndPointKey", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJpcHVic3VpdGUifQ.yE5i_9182suTu3g2mV1NHq0xkzWZtyQ3biNK8rpW2vI")
            //changed the endpoint based on WMS team request
            //  xhttp.setRequestHeader("iendpointname","ipubsuite_push-job-to-wms")
            let externalApis = require("../component/ijps/config/externalApis")
            xhttp.setRequestHeader("iendpointname", externalApis.DoveEndPoint)
            params ? xhttp.send(JSON.stringify(params)) : xhttp.send();
        } catch (error) {
            reject(error);
        }
    });
}

var ListAllblobPathURI = async (path) => {
    return new Promise(async (resolve, reject) => {
        try {
            blobService.listBlobsSegmentedWithPrefix(containerName, path, null, {
                delimiter: "",
                maxResults: 10000
            }, function (err, result) {
                let PathArray = [];
                if (err) {
                    reject(err);
                } else {
                    if (result.entries.length > 0) {
                        for (let i = 0; i < result.entries.length; i++) {
                            PathArray.push(cloudBasePath + result.entries[i].name);
                            if (i == result.entries.length - 1) {
                                resolve(PathArray);
                            }
                        }
                    } else {
                        resolve(PathArray);
                    }
                }
            });
        } catch (error) {
            reject(error)
        }
    });
}
var ActiveIPSwitchURL = async function () {
    return await new Promise((resolve, reject) => {
        const Request = require("request");
        Request.get(ipswitch, (error, response, body) => {
            if (error) {
                reject('IPSwitchURL' + error);
            }
            resolve(body);
        });
    });
}

var doesBlobExist = async function (Path) {
    return await new Promise((resolve, reject) => {
        try {
            blobService.doesBlobExist(containerName, Path, function (error, result) {
                if (!error) {
                    if (result.exists) {
                        resolve(true);
                    } else {
                        resolve(false);
                    }
                }
            });
        } catch (error) {
            reject(error);
        }
    });
}

var getBlobToText = async function (Path) {
    return await new Promise((resolve, reject) => {
        try {
           
            blobService.getBlobToText(containerName, Path,{'disableContentMD5Validation': true},
                function (error, text) {
                    if (error) {
                        reject(error);
                    } else {
                        resolve(text);
                    }
                });
        } catch (error) {
            reject(error);
        }
    })
}

var getBlobToStream = async function (Path) {
    return await new Promise((resolve, reject) => {
        try {
            let readStream = blobService.createReadStream(containerName, Path, (err, res) => {
                if (err) {
                    reject(err);
                }
            });
            //   readStream.on('data', data => {
            //       resolve(data);
            //             });

            const chunks = [];
            readStream.on('data', (chunk) => {
              chunks.push(chunk.toString());
            });
            readStream.on('end', () => {
              resolve(chunks.join(''));
            });

            
        } catch (error) {
            reject(error);
        }
    })
}

var getBlobToStreamAndText = async function (Path) {
    return await new Promise((resolve, reject) => {
        try {
            let readStream = blobService.createReadStream(containerName, Path, (err, res) => {
                if (err) {
                    reject(err);
                }
            });
            

        } catch (error) {
            reject(error);
        }
    })
}

module.exports = {
    Base64,
    blobFileUpload,
    blobByteUpload,
    getTokenUserDetail,
    get_blob_data,
    BlobUpload,
    bytesToSize,
    ListAllFilesPath,
    Listdatamovetodest,
    guid,
    BlobDelete,
    CallPostAPI,
    CallEncodePostAPI,
    SendSocketObjectToAutomation,
    ListAllblobPathURI,
    ActiveIPSwitchURL,
    doesBlobExist,
    getBlobToText,
    CallWMSPostAPI,
    BlobTextUpload,
    getBlobToStream
};