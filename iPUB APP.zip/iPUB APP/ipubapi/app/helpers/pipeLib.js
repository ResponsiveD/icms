const _ = require('lodash');
const Joi = require('joi');

module.exports.bodyValidation = (useJoiError = false, Schemas) => {
    // useJoiError determines if we should respond with the base Joi error
    // boolean: defaults to false
    const _useJoiError = _.isBoolean(useJoiError) && useJoiError;

    // enabled HTTP methods for request data validation
    const _supportedMethods = ['post', 'put', 'get'];

    // Joi validation options
    const _validationOptions = {
        abortEarly: false, // abort after the last validation error
        allowUnknown: true, // allow unknown keys that will be ignored
        stripUnknown: true // remove unknown keys from the validated data
    };

    // return the validation middleware
    return (req, res, next) => {

        const route = req.route.path;
        const method = req.method.toLowerCase();

        if (_.includes(_supportedMethods, method) && _.has(Schemas, route)) {

            // get schema for the current route
            const _schema = _.get(Schemas, route);

            if (_schema) {
                let reqObject;
                switch (method) {
                    case 'post':
                        reqObject = req.body
                        break;

                    case 'get':
                        reqObject = req.query
                        break;
                }

                // Validate req.body using the schema and validation options
                return Joi.validate(reqObject, _schema, _validationOptions, (err, data) => {

                    if (err) {

                        let error = _.map(err.details, ({ message, type, context }) => ({
                            label: context.label,
                            message: message.replace(/['"]/g, '')
                        }))

                        //Send back the JSON error response
                        res.status(422).json(error);
                    } else {
                        // Replace req.body with the data after Joi validation
                        // req.body = data;
                        next();
                    }

                });

            }
        }
        next();
    };
};

module.exports.queryValidation = () => {

};




