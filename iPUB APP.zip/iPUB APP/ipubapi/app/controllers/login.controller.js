"use strict";
const login_repo = require("../repository/login.service");
const jwtLib = require('../middleware/auth/lib/jwtlib');
const exception_repo = require("../middleware/exception/exception");
const HttpStatus = require('http-status-codes');
const PACKAGE = require('../../package.json');

exports.login = async function (req, res, next) {
  let error = null; let result = null; try {

    let data = req.body;
    // var userSession = await login_repo.CheckUsersession(data);
    // if (userSession.recordsets[0].length > 0) {
    //   if (req.body.forcelogin) {
    //     await login_repo.LogInOut(userSession.recordsets[0][0].UserID, 0, 1, 0);
    //   } else {
    //     res.status(HttpStatus.UNPROCESSABLE_ENTITY).send({ "is_success": false, "message": "This user already have session.","statusCode": 1100 });
    //   }
    // }

    result = await login_repo.CredentialChecker(data);
    if (result.is_success = true) {
      if (result.data.CheckStatus = true) {
        let _LogInOut = await login_repo.LogInOut(result.data.UserID, 0, 0, 1);
        if (_LogInOut.recordsets[0].length > 0) {
          let tokenData = await login_repo.makeTokenData(result, _LogInOut.recordsets[0][0])
          result.token = await jwtLib.generateToken(tokenData, true);
          result.renewalToken = jwtLib.generateToken({ UserID: _LogInOut.recordsets[0][0].UserID, LoginID: _LogInOut.recordsets[0][0].LoginID }, false);
        }
      }
    }
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(result);
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};

exports.logOut = async (req, res, next) => {
  let error = null; let result = null; try {
    result = await login_repo.LogInOut(req.User.UserID, req.User.LoginID, 1, 0);
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(result);
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};

exports.forgot_password = async function (req, res, next) {
  let error = null; let result = null; try {
    result = await login_repo.forget_password(req.body.mail_id);
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(result);
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};

exports.change_password = async function (req, res, next) {
  let error = null; let result = null; try {

    let oldpassword = req.body.old_password;
    let newpassword = req.body.new_password;
    let user_id = req.body.user_id;
    result = await login_repo.change_password(oldpassword, newpassword, user_id);
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(result);

    //old password
    // let oldSalt = await login_repo.get_salt(req.User.UserID);
    // let oldHash = crypto.pbkdf2Sync(req.body.old_password, oldSalt, 1000, 64, `sha512`).toString(`hex`);
    // if(oldHash == undefined){
    //   res.status(HttpStatus.UNPROCESSABLE_ENTITY).send("old password not found");
    // }

    // //new password
    // let salt = crypto.randomBytes(16).toString('hex');
    // let newHash = crypto.pbkdf2Sync(req.body.new_password, salt, 1000, 64, `sha512`).toString(`hex`);

    // let result = await login_repo.change_password(oldHash, newHash, salt, req.User.UserID);
    // res.status(HttpStatus.OK).send(result);
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};

exports.register = function (req, res, next) {
  let data = {};
  login_repo.register(data);
};

exports.welcome = function (req, res, next) {
  let error = null;
  req.User = {};
  req.User.startTime = new Date();
  
  let result = 'Welcome to iPubSuite API(Integra) ' + PACKAGE.version;
  try {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    res.status(HttpStatus.OK).send(result);
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};

exports.on_primis_login = async function (req, res) {
  let error = null;
  let result = null;
  try {
    let data = req.body;
    result = await login_repo.on_primis_login_check(data, req.User);
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 1);
    if (result.is_success) {
      let _LogInOut = await login_repo.LogInOut(result.data.UserID, 0, 0, 1);
      if (_LogInOut.recordsets[0].length > 0) {
        let tokenData = await login_repo.makeTokenData(result, _LogInOut.recordsets[0][0])
        result.token = await jwtLib.generateToken(tokenData, true);
        delete result.data;
      }
      res.status(HttpStatus.OK).send(result);
    } else {
      res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(result);
    }
  } catch (error) {
    req.User.endTime = new Date();
    exception_repo.exception_DB_log(req, result, error, 0);
    res.status(HttpStatus.UNPROCESSABLE_ENTITY).send(error);
  }
};
