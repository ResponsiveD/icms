# How to contribute

## Creating an Issue

## Making Changes

## Commit Message Guidelines

## Submitting the Pull Request

## Documentation

## Generating a new Release