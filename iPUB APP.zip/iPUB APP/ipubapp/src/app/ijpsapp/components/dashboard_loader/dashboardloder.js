import React from 'react';


export  const DBLoader={
    DB_showLoader,
    DB_hideLoader,
    DB2_showLoader,
    DB2_hideLoader
};


function DB_showLoader() {
    document.getElementById('horizontal_loader').classList.add('active');
}

 function DB_hideLoader() {
    document.getElementById('horizontal_loader').classList.remove('active');
}



function DB2_showLoader() {
    document.getElementById('vertical_loader').classList.add('active');
}

 function DB2_hideLoader() {
    document.getElementById('vertical_loader').classList.remove('active');
}


class DashboardLoader extends React.Component {
    render() {
        return (
        <div id="horizontal_loader" className='dashboard_loader'>
            <ul>
                <li><div className="placeholder dash_beam"></div></li>
                <li><div className="placeholder dash_beam"></div></li>
                <li><div className="placeholder dash_beam"></div></li>
                <li><div className="placeholder dash_beam"></div></li>
                <li><div className="placeholder dash_beam"></div></li>
                <li><div className="placeholder dash_beam"></div></li>
                <li><div className="placeholder dash_beam"></div></li>
                <li><div className="placeholder dash_beam"></div></li>
                <li><div className="placeholder dash_beam"></div></li>
            </ul>
        </div> 
        )
    }
}



class Verticalloader extends React.Component {
    render() {
        return (
        <div id="vertical_loader" className='dashboard_loader'>
            <ul>
                <li><div className="placeholder dash_beam"></div></li>
                <li><div className="placeholder dash_beam"></div></li>
                
            </ul>
            <div className="placeholder vertical_size"></div>
        <div className="placeholder vertical_size"></div>
        <div className="placeholder vertical_size"></div>
        <div className="placeholder vertical_size"></div>
        <div className="placeholder vertical_size"></div>
        <div className="placeholder vertical_size"></div>
        <div className="clearfix"></div>
        </div> 
      
        )
    }
}


export {
    Verticalloader,DashboardLoader
}