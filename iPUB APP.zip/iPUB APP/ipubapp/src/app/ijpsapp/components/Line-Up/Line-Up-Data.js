import 'webix/webix.js';
import 'webix/webix.css';

export function save_button() {
	return {
		view: "toolbar", elements: [
			{
				view: "button", type: "icon", icon: "upload", label: "Submit", click: function () {
				}, tooltip: "Submit"
			}
		]
	}
};

// sum total start     
window.webix.ui.datafilter.myCustomSumm = window.webix.extend({
	refresh: function (master, node, value) {
		var result = 0;
		master.data.each(function (row) {
			var fieldValue = row[value.field] * 1;
			if (isFinite(fieldValue)) {
				result += fieldValue;
			}
		});
		if (value.format)
			result = value.format(result);
		if (value.template)
			result = value.template({ value: result });

		node.firstChild.innerHTML = + result;
	}
}, window.webix.ui.datafilter.summColumn);
// sum total end   
function numberchange(e) {

	if (event.target.checked) {
	  alert('checked');
	} else {
	  alert('not checked');
	}
  
  }
export function lineupone_datatable() {
	return {
		view: "treetable",
		rowHeight: 40,
		minHeight: 40,
		fixedRowHeight: false,
		tooltip: true,
		footer: true,
		editable:true,
		drag:"true", 
		id: "PaperQueueTableOne",
		select:"row",
		css:"PaperQueueTableOne",
		columns: [
			{
				id: "ArticleName", name: "ArticleName", header: "Paper Name", width: 400, sort: "string", css: "auto_table",
				tooltip: "<div class='tooltip-style'>#papername#</div>", footer: { text: "Total no. of pages" }, template: "{common.icon()} #ArticleName#"
			},
			{ id: "CastOff", name: "CastOff", editor:"text", header: "No. of Pages", width: 120, sort: "int", tooltip: false, footer: { content: "myCustomSumm", field: "CastOff" } },
			{ id: "PageRange", name: "PageRange", header: "Page Range", width: 120, sort: "string", tooltip: false },
			{ id: "ReceivedDate", name: "ReceivedDate", header: "Received Date", width: 130, sort: "int", tooltip: false },
			{ id: "PageType", name: "PageType", header: "Page Type", width: 150, sort: "string", tooltip: false },
			{ id: "options", name: "options", header: "Options", width: 380, tooltip: false }
		],
		data: [
			// { id: 1, papername: "Ancient near east / Classical antiquity", noofpage: '2', pagerange: "1 - 2", receiveddate: "19/11/2018", pagetype: 'Advert', options: '<ul class="action-list-table lineup"><li><i class="material-icons arrow-up" title="Move Up">arrow_upward</i></li><li><i class="material-icons arrow-down" title="Move Down">arrow_downward</i></li><li><i class="material-icons deleteicons" title="Delete">delete </i></li><li class="table-switch"><div class="check-switch file-content-size"><input  class="switch" id="full1" type="checkbox" checked/><label class="label-switch primary" for="full1"></label></div></li><li class="table-switch"><div class="check-switch file-content-num"><input  class="switch" id="num1" type="checkbox" checked/><label class="label-switch primary" for="num1"></label></div></li></ul>' },
			// { id: 2, papername: "Old testament / Deuterocanonical literature", noofpage: '5', pagerange: "3 - 7", receiveddate: "19/11/2018", pagetype: 'Advert', options: '<ul class="action-list-table lineup"><li><i class="material-icons arrow-up" title="Move Up">arrow_upward</i></li><li><i class="material-icons arrow-down" title="Move Down">arrow_downward</i></li><li><i class="material-icons deleteicons" title="Delete">delete </i></li><li class="table-switch"><div class="check-switch file-content-size"><input  class="switch" id="full2" type="checkbox" checked /><label class="label-switch primary" for="full2"></label></div></li><li class="table-switch"><div class="check-switch file-content-num"><input  class="switch" id="num2" type="checkbox" checked/><label class="label-switch primary" for="num2"></label></div></li></ul>' },
			// { id: 3, papername: "Paper0001", noofpage: '15', pagerange: "8 - 23", receiveddate: "20/11/2018", pagetype: 'Article', options: '<ul class="action-list-table lineup"><li><i class="material-icons arrow-up" title="Move Up">arrow_upward</i></li><li><i class="material-icons arrow-down" title="Move Down">arrow_downward</i></li><li><i class="material-icons drag" title="Drag & Drop">zoom_out_map</i></li><li class="table-switch"><div class="check-switch file-content-size"></li><li class="table-switch"><div class="check-switch file-content-num"><input  class="switch" id="num2" type="checkbox" checked/><label class="label-switch primary" for="num2"></label></div></li></ul>', 
			// "open": true, 
			// "data": [
			// 		{ id: "3.1", papername: "Paper0003", noofpage: "17", pagerange: "33 - 50", receiveddate: "21/11/2018", pagetype: "Article", options: '<ul class="action-list-table lineup"><li><i class="material-icons arrow-up" title="Move Up">arrow_upward</i></li><li><i class="material-icons arrow-down" title="Move Down">arrow_downward</i></li><li><i class="material-icons drag" title="Drag & Drop">zoom_out_map</i></li><li class="table-switch"></li><li class="table-switch"><div class="check-switch file-content-num"><input  class="switch" id="num1" type="checkbox" checked/><label class="label-switch primary" for="num1"></label></div></li></ul>' },
			// 		{ id: "3.2", papername: "Paper0004", noofpage: "5", pagerange: "51 - 55", receiveddate: "21/11/2018", pagetype: "Article", options: '<ul class="action-list-table lineup"><li><i class="material-icons arrow-up" title="Move Up">arrow_upward</i></li><li><i class="material-icons arrow-down" title="Move Down">arrow_downward</i></li><li><i class="material-icons drag" title="Drag & Drop">zoom_out_map</i></li><li class="table-switch"></li><li class="table-switch"><div class="check-switch file-content-num"><input  class="switch" id="num1" type="checkbox" checked/><label class="label-switch primary" for="num1"></label></div></li></ul>' },
			// 	]
			// },
			// { id: 4, papername: "Advert_U", noofpage: '2', pagerange: "56 - 57", receiveddate: "21/11/2018", pagetype: 'Advert', options: '<ul class="action-list-table lineup"><li><i class="material-icons arrow-up" title="Move Up">arrow_upward</i></li><li><i class="material-icons arrow-down" title="Move Down">arrow_downward</i></li><li><i class="material-icons deleteicons" title="Delete">delete </i></li><li class="table-switch"><div class="check-switch file-content-size"><input  class="switch" id="full2" type="checkbox" checked /><label class="label-switch primary" for="full2"></label></div></li><li class="table-switch"><div class="check-switch file-content-num"><input  class="switch" id="num2" type="checkbox" checked/><label class="label-switch primary" for="num2"></label></div></li></ul>' },
		],
		on:{
			onBeforeDrag:function(data, e){
			  return (e.target||e.srcElement).className == "material-icons drag";
			}
		},
		onClick: {
			"deleteicons": function (event, id, node) {
				var dtable = this;
				window.webix.confirm("Are you sure, to delete this?", function (action) {
					if (action === true) {
						dtable.remove(id.row);
					}
				});
				return true;
			},
			"arrow-up":function(ev, id){
				window.$$('PaperQueueTableOne').moveUp(id.row);
			},
   			 "arrow-down":function(ev, id){
				window.$$('PaperQueueTableOne').moveDown(id.row);
			}
		},
		on: {			
			onBeforeLoad: function () {
				this.showOverlay("Loading...");
			},
			onAfterLoad: function () {
				this.hideOverlay();
				if (!this.count()) {
					this.showOverlay("No Records Found");
				} else {
					this.hideOverlay();
				}
			}
		},
		ready: function () {
			if (!this.count()) {
				window.webix.extend(this, window.webix.OverlayBox);
				this.showOverlay("No Records Found");
			}
		},
		autoheight: true,
		scrollX: false,
		scrollY: true,
	}
}

// sum total start     
window.webix.ui.datafilter.myCustomSumm = window.webix.extend({
	refresh: function (master, node, value) {
		var result = 0;
		master.data.each(function (row) {
			var fieldValue = row[value.field] * 1;
			if (isFinite(fieldValue)) {
				result += fieldValue;
			}
		});
		if (value.format)
			result = value.format(result);
		if (value.template)
			result = value.template({ value: result });

		node.firstChild.innerHTML = + result;
	}
}, window.webix.ui.datafilter.summColumn);
// sum total end   

export function lineupone_datatable_two() {
	return {
		view: "treetable",
		footer: true,
		tooltip: true,
		rowHeight: 40,
		drag: true,
		id:"PaperQueueTableTwo",
		select:"row",
		css:"PaperQueueTableTwo",
		columns: [
			{
				id: "papername", name: "papername", header: "Paper Name", width: 400, sort: "string", css: "auto_table",
				tooltip: "<div class='tooltip-style'>#papername#</div>", footer: { text: "Total no. of pages" },
			},
			{ id: "noofpage", name: "noofpage", header: "No. of Pages", width: 240, sort: "int", tooltip: false, footer: { content: "myCustomSumm", field: "noofpage" } },
			//{ id: "pagerange", name: "pagerange", header: "Page Range",width: 120, sort: "string",tooltip:false},
			{ id: "receiveddate", name: "receiveddate", header: "Received Date", width: 130, sort: "int", tooltip: false },
			{ id: "pagetype", name: "pagetype", header: "Page Type", width: 150, sort: "string", tooltip: false },
			{ id: "options", name: "options", header: "Options", width: 380, tooltip: false }
		],
		data: [
			{ id: 1, papername: "Ancient near east / Classical antiquity", noofpage: '2', receiveddate: "19/11/2018", pagetype: 'Advert', options: '<ul class="action-list-table lineup"><li><i class="material-icons arrow-up" title="Move Up">arrow_upward</i></li><li><i class="material-icons arrow-down" title="Move Down">arrow_downward</i></li><li><i class="material-icons drag" title="Drag & Drop">zoom_out_map</i></li></ul>' },
			{ id: 2, papername: "Old testament / Deuterocanonical literature", noofpage: '5', receiveddate: "19/11/2018", pagetype: 'Advert', options: '<ul class="action-list-table lineup"><li><i class="material-icons arrow-up" title="Move Up">arrow_upward</i></li><li><i class="material-icons arrow-down" title="Move Down">arrow_downward</i></li><li><i class="material-icons drag" title="Drag & Drop">zoom_out_map</i></li></ul>' },
			
		],
		onClick: {
			"deleteicons": function (event, id, node) {
				var dtable = this;
				window.webix.confirm("Are you sure, to delete this?", function (action) {
					if (action === true) {
						dtable.remove(id.row);
					}
				});
				return true;
			},
			"arrow-up":function(ev, id){
				window.$$('PaperQueueTableTwo').moveUp(id.row);
			},
   			 "arrow-down":function(ev, id){
				window.$$('PaperQueueTableTwo').moveDown(id.row);
			}
			
		},
	
		autoheight: true,
		scrollX: false,
		scrollY: true,
	}
}


export function lineup_search() {
	return {
		view: "form",
		id: "lineupsearch",
		elements: [{
			view: "search",
			align: "center",
			name: "lineupsearch",
			placeholder: "Search..",
			id: "ulineupsearch",
			width: 300,
			height: 40,
			css: "search-dash-2",
			on: {
				onTimedKeyPress: function () {
					// window.webix.$$("PaperQueueTableOne").clearAll();
					// let searchKeyword = this.getValue().toLowerCase();
					// let allArticles = window.line_up_data;
					// let filteredArticles = []
					// for (let article of allArticles) {
					// 	let isTextPresent = false;
					// 	for (let key in article) {
					// 		let value = article[key];
					// 		if (value) {
					// 			if (typeof value == "string") {
					// 				if (value.toLowerCase().indexOf(searchKeyword) != -1) {
					// 					isTextPresent = true;
					// 					break;
					// 				}
					// 			} else {
					// 				if (value.toString().indexOf(searchKeyword) != -1) {
					// 					isTextPresent = true;
					// 					break;
					// 				}
					// 			}
					// 		}
					// 	}
					// 	if (isTextPresent) {
					// 		filteredArticles.push(article);
					// 	}
					// }
					// window.webix.$$("PaperQueueTableOne").parse(filteredArticles);
					var text = this.getValue().toLowerCase();
					var table = window.$$("PaperQueueTableOne");
					// var columns = table.config.columns;
					table.filter(function (obj) {
						// for (var i = 0; i < columns.length; i++)
						if (obj["ArticleName"].toString().toLowerCase().indexOf(text) !== -1) return true;
						// return false;
					})
					if (!window.$$("PaperQueueTableOne").count()) {
						window.$$("PaperQueueTableOne").showOverlay("No Records Found");
					} else {
						window.$$("PaperQueueTableOne").hideOverlay();
					}
				}
			}
		}]
	}
}

export function uploadpaper_first_main() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main_over' title='#title#'>#title# <span><i class='material-icons filter-arrow'>navigate_next</i></span></div>",
		data: [
			// { id: 1, title: "Status" },
			// { id: 2, title: "Stage" },
			{ id: 1, title: "Cast Off" }
		],
		on: {
			onItemClick: function (id, ev) {
				if (id == '1') {
					// document.getElementById('level3_1').classList.remove('hide');
					// document.getElementById('level3_2').classList.add('hide');
					document.getElementById('level3_3').classList.remove('hide');
				}
				else if (id == '2') {
					// document.getElementById('level3_1').classList.add('hide');
					// document.getElementById('level3_2').classList.remove('hide');
					document.getElementById('level3_3').classList.add('hide');
				}
				else if (id == '3') {
					// document.getElementById('level3_1').classList.add('hide');
					// document.getElementById('level3_2').classList.add('hide');
					document.getElementById('level3_3').classList.remove('hide');
				}
			}
		}
	}
}

export function uploadpaper_first_main2() {
	return {
		view: "list",
		id: "uploadpaper_first_main2",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 0, title: "All" },
			{ id: 1, title: "Completed" },
			{ id: 2, title: "In Progress" },
			{ id: 3, title: "Error" },
			{ id: 4, title: "Open" },
		],
		on: {
			onItemClick: function (id, ev, node) {
				let allArticles = window.$$("PaperQueueTableOne").serialize();
				window.webix.$$("PaperQueueTableOne").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				// let allArticles = window.line_up_data;
				let filteredArticles = [];
				if(searchKeyword == "all"){
					window.webix.$$("PaperQueueTableOne").parse(allArticles);
				} else {
					for (let article of allArticles) {
						let isTextPresent = false;
						for (let key in article) {
							let value = article[key];
							if (value) {
								if (typeof value == "string") {
									if (value.toLowerCase().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								} else {
									if (value.toString().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								}
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("PaperQueueTableOne").parse(filteredArticles);
				}
				// document.getElementById('level3_1').classList.add('hide');
				document.getElementById('level3_0').classList.add('hide');
				document.getElementById('level2_3').classList.add('hide');
			}
		}

	}
}
export function uploadpaper_first_main3() {
	return {
		view: "list",
		id: "uploadpaper_first_main3",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 0, title: "All" },
			{ id: 1, title: "Issue Proof" },

		],
		on: {
			onItemClick: function (id, ev, node) {
				let allArticles = window.$$("PaperQueueTableOne").serialize();
				window.webix.$$("PaperQueueTableOne").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				// let allArticles = window.line_up_data;
				let filteredArticles = [];
				if(searchKeyword == "all"){
					window.webix.$$("PaperQueueTableOne").parse(allArticles);
				} else {
					for (let article of allArticles) {
						let isTextPresent = false;
						for (let key in article) {
							let value = article[key];
							if (value) {
								if (typeof value == "string") {
									if (value.toLowerCase().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								} else {
									if (value.toString().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								}
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("PaperQueueTableOne").parse(filteredArticles);
				}
				// document.getElementById('level3_2').classList.add('hide');
				document.getElementById('level3_0').classList.add('hide');
				document.getElementById('level2_3').classList.add('hide');
			}
		}

	}
}
export function uploadpaper_first_main4() {
	return {
		view: "list",
		id: "uploadpaper_first_main3",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 0, title: "All" },
			{ id: 1, title: "< 100" },
			{ id: 2, title: "< 300" },
			{ id: 3, title: "< 500" },
			{ id: 4, title: "< 800" },
			{ id: 5, title: "< 1000" },
			{ id: 6, title: "1000 and above" }
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("PaperQueueTableOne").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.line_up_data;
				let filteredArticles = [];
				if (searchKeyword == "all") {
					window.webix.$$("PaperQueueTableOne").parse(allArticles);
				} else {
					for (let article of allArticles) {
						let isTextPresent = false;
						let value = parseInt(article.CastOff);
						if (value) {
							if (id == '1' && value <= 100) {
								isTextPresent = true;
							} else if (id == '2' && value <= 300) {
								isTextPresent = true;
							} else if (id == '3' && value <= 500) {
								isTextPresent = true;
							} else if (id == '4' && value <= 800) {
								isTextPresent = true;
							} else if (id == '5' && value <= 1000) {
								isTextPresent = true;
							} else if (id == '6' && value > 1000) {
								isTextPresent = true;
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("PaperQueueTableOne").parse(filteredArticles);
				}
				// document.getElementById('level3_2').classList.add('hide');
				document.getElementById('level3_0').classList.add('hide');
				// document.getElementById('level3_1').classList.add('hide');
			}
		}

	}
}

export function Upload_form_button() {
	return {
		view: "toolbar",
		width: 600,
		id: 'Upload_form_button',
		elements: [{
			view: "button",
			label: "Reset",
			autowidth: true,
			tooltip: "Reset",
			click: function () {
				document.getElementById('upload-popup').classList.add('hide');
			},
		},
		{
			view: "button",
			label: "Ok",
			autowidth: true,
			tooltip: "Ok",
			type: "form",
			click: function () {
				document.getElementById('upload-popup').classList.add('hide');
			}
		}]
	}
}


export function Gallery_Table() {
	return {
		view: "datatable",
		id: "gallerytable",
		columns: [
			{ id: "sno", name: "sno", header: "S. No", width: 80, sort: "int" },
			{ id: "advertname", name: "advertname", header: "Advert Name", width: 200, sort: "string" },
			{ id: "uploadedon", name: "uploadedon", header: "Uploaded on", width: 150, sort: "string" },
			{ id: "uploadedby", name: "uploadedby", header: "Uploaded by", width: 150, sort: "string" },
			{ id: "select", name: "select", header: "Select", width: 80, template: '<label class="table-checkbox"><input type="checkbox" checked="checked"><span class="checkmark"></span></label>' }
		],
		data: [
			{ sno: "1", advertname: "Advert 1", uploadedon: "19/11/2018", uploadedby: "Admin", },
			{ sno: "2", advertname: "Advert 2", uploadedon: "19/11/2018", uploadedby: "Admin", },
			{ sno: "3", advertname: "Advert 3", uploadedon: "20/11/2018", uploadedby: "Admin", },
			{ sno: "4", advertname: "Advert 4", uploadedon: "21/11/2018", uploadedby: "Admin", }
		],
		height: 250,
		minWidth: 800,
		scrollX: false,
		scrollY: true,
	}
}

export function addlineitemothers() {
	return {
		view: "form",
		minWidth: 800,
		id:"addlineitemothers",
		elements: [
			{ view: "text", label: "Lineitem Name", name: "lineitemname", id: "lineitemname", labelWidth: 200, },
			{
				view: "switch", id: "addlineitemothers", name: "requiredfiles", label: "Required files", labelWidth: 200,labelAlign:"left", onLabel: "On", offLabel:"Off", click: function () {
				}
			},
			{
				view: "uploader", id: "addlineitemothers_upload", css: "iopp uploads line-upload", align: "center", type: "iconButton", label: "Drag & Drop or Click to Browse", autosend: false, accept: ".doc,.docx", multiple: true,
			},
		]
	}
};

export function addlineitemindex() {
	return {
		view: "form",
		minWidth: 800,
		id:"addlineitemindex",
		elements: [
			{ view: "text", label: "Index Name", name: "indexname", id: "indexname", labelWidth: 200, },
			{
				view: "switch", id: "addlineitemindex", name: "requiredfilesindex", label: "Required files", labelWidth: 200,labelAlign:"left", onLabel: "On", offLabel:"Off", click: function () {
				}
			},
			{
				view: "uploader", id: "addlineitemindex_upload", css: "iopp uploads line-upload", align: "center", type: "iconButton", label: "Drag & Drop or Click to Browse", autosend: false, accept: ".doc,.docx", multiple: true,
			},
		]
	}
};

export function addlineitemuploadadvert() {
	return {
		view: "form",
		minWidth: 800,
		id:"addlineitemuploadadvert",
		elements: [
			
			{
				view: "uploader", id: "addlineitemuploadadvert", css: "iopp uploads line-upload", align: "center", type: "iconButton", label: "Drag & Drop or Click to Browse", autosend: false, accept: ".doc,.docx", multiple: true,
			},
		]
	}
};

export function lineup_search_popup() {
	return {
		view: "form",
		id: "lineup_search_popup(",
		elements: [{
			view: "search",
			align: "center",
			name: "lineup_search_popup",
			placeholder: "Search..",
			id: "lineup_search_popup",
			width: 300,
			height: 40,
			css: "search-dash-2",
			on: {
				onTimedKeyPress: function () {
					//window.webix.$$("dashboard_details").clearAll();
					// let searchKeyword = this.getValue().toLowerCase();
					// let allArticles = window.author_dashboard_articles;
					// let filteredArticles = []
					// for (let article of allArticles) {
					// 	let isTextPresent = false;
					// 	for (let key in article) {
					// 		let value = article[key];
					// 		if (value) {
					// 			if (typeof value == "string") {
					// 				if (value.toLowerCase().indexOf(searchKeyword) != -1) {
					// 					isTextPresent = true;
					// 					break;
					// 				}
					// 			} else {
					// 				if (value.toString().indexOf(searchKeyword) != -1) {
					// 					isTextPresent = true;
					// 					break;
					// 				}
					// 			}
					// 		}
					// 	}
					// 	if (isTextPresent) {
					// 		filteredArticles.push(article);
					// 	}
					// }
					// window.webix.$$("dashboard_details").parse(filteredArticles);

					var text = this.getValue().toLowerCase();
					var table = window.$$("lineupsearch");
					var columns = table.config.columns;
					table.filter(function (obj) {
						for (var i = 0; i < columns.length; i++) {
							if (obj[columns[i].id].toString().toLowerCase().indexOf(text) !== -1) {
								return true;
							} else {
								return false;
							}
						}

					})
				}
			}
		}]
	}
}

export function itemadd() {
	return {
		view: "list",
		scroll: false,
		select: true,
		minWidth:200,
		template: "<div class='filter_main_over' title='#title#'>#title# <span><i class='material-icons filter-arrow'>navigate_next</i></span></div>",
		data: [
			{ id: 1, title: "Status" },
			{ id: 2, title: "Stage" },
			{ id: 3, title: "Cast Off" },
		],
		on: {
			onItemClick: function (id, ev) {
				if (id == '1') {
					document.getElementById('level4_1').classList.remove('hide');
					document.getElementById('level4_2').classList.add('hide');
					document.getElementById('level4_3').classList.add('hide');
				}
				else if (id == '2') {
					document.getElementById('level4_1').classList.add('hide');
					document.getElementById('level4_2').classList.remove('hide');
					document.getElementById('level4_3').classList.add('hide');
				}
				else if (id == '3') {
					document.getElementById('level4_1').classList.add('hide');
					document.getElementById('level4_2').classList.add('hide');
					document.getElementById('level4_3').classList.remove('hide');
				}
			}
		}
	}
}

export function itemadd02() {
	return {
		view: "list",
		id: "itemadd02",
		scroll: false,
		select: true,
		minWidth:200,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "Completed" },
			{ id: 2, title: "In Progress" },
			{ id: 3, title: "Error" },
			{ id: 4, title: "Yet to start" },
		],
		on: {
			onItemClick: function (id, ev, node) {
				document.getElementById('level4_1').classList.add('hide');
				document.getElementById('level4_0').classList.add('hide');
				document.getElementById('level4_3').classList.add('hide');
			}
		}

	}
}
export function itemadd03() {
	return {
		view: "list",
		id: "itemadd03",
		scroll: false,
		select: true,
		minWidth:200,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "Issue Proof" },

		],
		on: {
			onItemClick: function (id, ev, node) {
				document.getElementById('level4_2').classList.add('hide');
				document.getElementById('level4_0').classList.add('hide');
				document.getElementById('level4_3').classList.add('hide');
			}
		}

	}
}
export function itemadd04() {
	return {
		view: "list",
		id: "itemadd04",
		scroll: false,
		select: true,
		minWidth:200,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "100" },

		],
		on: {
			onItemClick: function (id, ev, node) {
				document.getElementById('level4_2').classList.add('hide');
				document.getElementById('level4_0').classList.add('hide');
				document.getElementById('level4_1').classList.add('hide');
			}
		}

	}
}
