import React from 'react';
import Webix from '../../../../Webix';
import * as Data from './Line-Up-Data';
import excel_icon from '../../../../assets/images/icons/excel-ash.png';
import { Loader } from '../../../../components/Core/iCore';
import { PaperService } from '../../services';
import { LocalStorage } from '../../../../helpers';
let line_up_data = [];
import moment from 'moment';

export default class LineUp extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedProceeding: { ...this.props.selectedProceeding },
            // issues: [], 
            selectedIssue: { ...this.props.selectedIssue },
            selectedPaperQueue: null,
            openUplaodPopup: false
        }
    };

    search_box_open4() {
        // document.getElementById('search_box').classList.add('search-open');
        document.getElementById('search_box4').classList.add('active');
        document.getElementById('search_box_icon4').classList.add('hide');
        window.$$("ulineupsearch").focus('');
    }

    search_box_close4() {
        // document.getElementById('search_box').classList.remove('search-open');
        document.getElementById('search_box4').classList.remove('active');
        document.getElementById('search_box_icon4').classList.remove('hide');

    }
    search_box_open5() {
        // document.getElementById('search_box').classList.add('search-open');
        document.getElementById('search_box5').classList.add('active');
        document.getElementById('search_box_icon5').classList.add('hide');
        window.$$("lineup_search_popup").focus('');
    }
    search_box_close5() {
        // document.getElementById('search_box').classList.remove('search-open');
        document.getElementById('search_box5').classList.remove('active');
        document.getElementById('search_box_icon5').classList.remove('hide');

    }
    filter_option4() {
        document.getElementById('level3_0').classList.remove('hide');
        document.getElementById('level3_3').classList.add('hide');
    }
    filter_option5() {
        document.getElementById('level4_0').classList.remove('hide');
    }
    hideForm(_this, formID) {
        document.getElementById(_this).classList.add('hide');
    }
    showForm(_this, formID) {
        document.getElementById(_this).classList.remove('hide');
    }

    componentDidMount() {
        let { selectedIssue } = this.state;

        document.getElementById('level3_0').classList.add('hide');
        // document.getElementById('level3_1').classList.add('hide');
        // document.getElementById('level3_2').classList.add('hide');
        document.getElementById('level3_3').classList.add('hide');

        document.getElementById('level4_0').classList.add('hide');
        document.getElementById('level4_1').classList.add('hide');
        document.getElementById('level4_2').classList.add('hide');
        document.getElementById('level4_3').classList.add('hide');

        document.getElementById('lineup-popup').classList.add('hide');

        document.addEventListener("click", function (e) {
            if (e.target.closest('#search_box4')) {

            }
            else if (e.target.closest('#search_box_icon4')) {

            }
            else {
                if (document.getElementById('search_box4') != null) {
                    document.getElementById('search_box4').classList.remove('active');
                    document.getElementById('search_box_icon4').classList.remove('hide');
                }
            }

        });

        document.addEventListener("click", function (event) {
            if (event.target.closest('#filter_icon4')) {
                document.getElementById('filter_overall4').classList.remove('hide');
            }
            else if (!event.target.classList.contains('filter_main_over')) {
                if (document.getElementById('filter_overall4') != null) {
                    document.getElementById('filter_overall4').classList.add('hide');
                }
            }
        });
        document.addEventListener("click", function (e) {
            if (e.target.closest('#search_box5')) {

            }
            else if (e.target.closest('#search_box_icon5')) {

            }
            else {
                if (document.getElementById('search_box5') != null) {
                    document.getElementById('search_box5').classList.remove('active');
                    document.getElementById('search_box_icon5').classList.remove('hide');
                }
            }

        });

        document.addEventListener("click", function (event) {
            if (event.target.closest('#filter_icon5')) {
                document.getElementById('filter_overall5').classList.remove('hide');
            }
            else if (!event.target.classList.contains('filter_main_over')) {
                if (document.getElementById('filter_overall5') != null) {
                    document.getElementById('filter_overall5').classList.add('hide');
                }
            }
        });
        var tabbedContent = function () {
            //get all tab link elements
            var tab = document.getElementsByClassName("tab-link");
            //get all tab content elements
            var tabContent = document.getElementsByClassName("tab-content");
            //loop through each tab
            for (var i = 0; i < tab.length; i++) {
                //add click event listener to all tab links
                tab[i].addEventListener('click', function () {
                    //each time tab clicked remove all current classes
                    //remove 'current' class from all tabs
                    for (var i = 0; i < tab.length; i++) {
                        tab[i].classList.remove('current');
                    };
                    //remove 'current' class from all tab content
                    for (var i = 0; i < tabContent.length; i++) {
                        tabContent[i].classList.remove('current');
                    };
                    //add current class back to the clicked tab
                    this.className += ' current';
                    //get data-tab attribute of what has been clicked
                    var matchingTab = this.getAttribute('data-tab');
                    //add current class to the tabContent element thats id matches the data-tab of the clicked tab
                    document.getElementById(matchingTab).className += ' current';
                }, false);
            }
        }
        tabbedContent();

        Loader.showLoader();
        PaperService.issueLineup(selectedIssue.issue_id).then(res => {
            for (let index = 0; index < res.length; index++) {
                res[index].ReceivedDate = moment(new Date()).format("DD-MM-YYYY");
            }
            window.$$('PaperQueueTableOne').clearAll();
            window.$$('PaperQueueTableOne').parse(res);
            window.line_up_data = res;
            Loader.hideLoader();            
        })
    }
    render() {
        return (
            <div className="Right-Panel tandf lineup">
                {/* header */}
                <div className="secondary-header">
                    <div className="head-left">
                        <span className="se-panel-title">Issuse Line Up</span>
                        <div className="btn_fun">
                            <div id="service_btn" className="common_btn icon_buttons">
                                {/* <Webix ui={Data.save_button()} ></Webix> */}
                            </div>
                        </div>
                        <span title="Search" className="se-panel-icon iopp-top-icons tandf" id="iopp-top-icons3">
                            <i title="Close" className="material-icons close-btn-top iopp-editor-close iopp-top-icons-close" onClick={() => this.props.onPaperStepSelect(null)}>close</i>
                        </span>
                    </div>
                </div>
                {/* header */}
                <div className="iR-flex">
                    <div className="iR-col-12 tandf-inner-space paperqueue ">
                        <div className="widget">
                            <div className="widget_body">
                                <div className="widget-dashboard tandf">
                                    <div className="widget-dashboard-left">
                                        BATCH 1
                                    </div>
                                    <div className="widget-dashboard-right">
                                        <div className="filter_search">
                                            <div className="search-box2" id="search_box4">
                                                <Webix ui={Data.lineup_search()} ></Webix>
                                                <i title="Close" className="material-icons" onClick={this.search_box_close4.bind()}>close</i>
                                            </div>
                                            <span className="addline" onClick={this.showForm.bind(this, "lineup-popup")}><i className="material-icons">add</i>Add line item</span>
                                            <i className="material-icons" title="Search" id="search_box_icon4" onClick={this.search_box_open4.bind()}>search</i>
                                            <i className="material-icons" title="filter" id="filter_icon4" onClick={this.filter_option4.bind()}>filter_list</i>
                                        </div>
                                        <div id="filter_overall4">
                                            <div className="filter_option" id="level3_0"><Webix ui={Data.uploadpaper_first_main()} ></Webix></div>
                                            {/* <div className="filter_option level1" id="level3_1"><Webix ui={Data.uploadpaper_first_main2()} ></Webix></div> */}
                                            {/* <div className="filter_option level2" id="level3_2"><Webix ui={Data.uploadpaper_first_main3()} ></Webix></div> */}
                                            <div className="filter_option level1" id="level3_3"><Webix ui={Data.uploadpaper_first_main4()} ></Webix></div>
                                        </div>
                                    </div>
                                </div>
                                <Webix ui={Data.lineupone_datatable()}></Webix>
                            </div>
                        </div>
                        {/* <div className="widget batchtwo">
                            <div className="widget_body">
                                <div className="widget-dashboard tandf">
                                    <div className="widget-dashboard-left">
                                        BATCH 2
                                    </div>
                                </div>
                                <Webix ui={Data.lineupone_datatable_two()}></Webix>
                            </div>
                        </div> */}
                    </div>
                </div>
                <div className='alt_show_from overlay' id="lineup-popup">
                    <div className="iR-dialog dashbord-iopp-popup">
                        <div className="expand iopp-popup-header iR-window-header">
                            <h2>Add Line Item </h2>
                            <div className="pagesize">
                                Page size type
                                    <div className="check-switch file-content-size pagesizeinner">
                                    <input className="switch" id="pagesizetype" type="checkbox" defaultChecked />
                                    <label className="label-switch primary" htmlFor="pagesizetype"></label>
                                </div>
                            </div>

                            <i className="material-icons view_cls" title="Close" onClick={this.hideForm.bind(this, "lineup-popup")}>clear</i>
                        </div>
                        <div className="widget">
                            <div className="widget_body">
                                <ul className="tabmethodpopup">
                                    <li className="tab-link current" data-tab="tab1">
                                        UPLOAD ADVERT
                                    </li>
                                    <li className="tab-link" data-tab="tab2">
                                        ADVERT FROM GALLERY
                                    </li>
                                    <li className="tab-link" data-tab="tab3">
                                        INDEX
                                    </li>
                                    <li className="tab-link" data-tab="tab4">
                                        OTHERS
                                    </li>
                                </ul>
                                <div id="tab1" className="tab-content current">
                                    <div className="uploadadvert-div">
                                        <Webix ui={Data.addlineitemuploadadvert()} ></Webix>
                                    </div>
                                </div>
                                <div id="tab2" className="tab-content">
                                    <div className="filter_search">
                                        <div className="search-box2" id="search_box5">
                                            <Webix ui={Data.lineup_search_popup()} ></Webix>
                                            <i title="Close" className="material-icons" onClick={this.search_box_close5.bind()}>close</i>
                                        </div>
                                        <i className="material-icons" title="Search" id="search_box_icon5" onClick={this.search_box_open5.bind()}>search</i>
                                        <i className="material-icons" title="filter" id="filter_icon5" onClick={this.filter_option5.bind()}>filter_list</i>
                                    </div>
                                    <div id="filter_overall5">
                                        <div className="filter_option" id="level4_0"><Webix ui={Data.itemadd()} ></Webix></div>
                                        <div className="filter_option level1" id="level4_1"><Webix ui={Data.itemadd02()} ></Webix></div>
                                        <div className="filter_option level2" id="level4_2"><Webix ui={Data.itemadd03()} ></Webix></div>
                                        <div className="filter_option level3" id="level4_3"><Webix ui={Data.itemadd04()} ></Webix></div>
                                    </div>
                                    <div className="gallery-table">
                                        <Webix ui={Data.Gallery_Table()} ></Webix>
                                    </div>
                                </div>
                                <div id="tab3" className="tab-content">
                                    <div className="index-div other-div">
                                        <Webix ui={Data.addlineitemindex()} ></Webix>
                                    </div>
                                </div>
                                <div id="tab4" className="tab-content">
                                    <div className="other-div">
                                        <Webix ui={Data.addlineitemothers()} ></Webix>
                                    </div>
                                </div>
                            </div>
                            <div className="btn_fun">
                                <div id="service_btn" className="common_btn change_btn">
                                    <Webix ui={Data.Upload_form_button()} ></Webix>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        )
    }
};
