export function manuscripts_search() {
	return {
		view: "toolbar", id: "search_manuscript",
		cols: [
			{
				view: "search", align: "center", name: "search_manuscript_id", placeholder: "Search..", id: "search_manuscript_id", width: 300, height: 56,
				on: {
					onTimedKeyPress: function () {
						var value = this.getValue().toLowerCase();
						window.$$("manuscript_list_id").filter(function (obj) {
							return obj.article_name.toLowerCase().indexOf(value) != -1;
						})
					}
				}
			}
		]
	}
};

export function manuscript_list(onManuscriptSelect, getModifiedData) {
	return {
		view: "list",
		scroll: false,
		select: 1,
		id: "manuscript_list_id",
		css: "style-list iopp",
		template: `<div class='iR-project-list-item'> <div class='iR-litem-icon'> </div> <div class='iR-litem-detail'><h1 class='iR-title' title='#article_name#'>#article_name# </h1> <span class="list-status">#status_name# </span> <i title="Show" class='material-icons iR-rt-arrow'>chevron_right</i> <span title="#statustitle#">#icon#</span></div></div>`,
		onClick: {
			"iR-project-list-item": function (ev, id) {
				let validate = getModifiedData();			
				if (validate.isSaveNext) {
					window.webix.message({ text: "Please wait until the previous manuscript move to engine process Queue.", type: "error" });
					return false;
				}
				if (validate.isUploading) {
					window.webix.message({ text: "Please wait until upload to be completed", type: "error" });
					return false;
				  }
				if (validate.isModifiedData) {
					window.webix.message({ text: "Please save current selected article.", type: "error" });
					return false;
				}

				onManuscriptSelect(window.webix.$$("manuscript_list_id").getItem(id));
				window.$$("manuscript_list_id").select(id);
				var s = document.getElementsByClassName("IOPP");
				s[0].scrollLeft = 920;
			}
		}
	};
};

