import React, { Component } from 'react';
import Webix from '../../../../Webix';
import * as Data from './Manuscripts-Data';
import addmaterila from '../../../../assets/images/icons/add-material.png';

import SubmitManuscript from '../../components/Submit-Manuscript/Submit-Manuscript';

import { ArticleService } from '../../services';
import { Loader } from '../../../../components/Core/iCore';
import { connect } from 'react-redux';
import { submitManuscriptActions } from '../../../../redux/actions';

class Manuscripts extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedJournal: { ...this.props.selectedJournal },
      manuscriptList: [],
      isSaveNext: false,
      selectedManuscript: null,
      isPlusIconClick: false,
      selectedStep: "Upload",
      menuItem: this.props.MenuShown,
      isUploading: false,
      isModifiedData: false
    }
    this.onManuscriptSelect = this.onManuscriptSelect.bind(this);
    this.updateManuscript = this.updateManuscript.bind(this);
    this.updateMenuManuscript = this.updateMenuManuscript.bind(this);
    this.onSaveNext = this.onSaveNext.bind(this);
    this.getModifiedData = this.getModifiedData.bind(this);

  };

  componentDidMount() {
    Loader.showLoader();
    ArticleService.getArticles(this.state.selectedJournal.id, 5).then(manuscriptList => {
      this.setState({ manuscriptList });
      Loader.hideLoader();
      if (this.props.openAllPanelToSubmitManuscript) {
        this.onPlusIconClick();
      }
    }).catch(error => {
      Loader.hideLoader();
    });
  };

  componentWillReceiveProps(nextProps) {
    if (nextProps.openAllPanelToSubmitManuscript) {
      this.onPlusIconClick();
    }
  };

  componentWillUpdate() {
    window.webix.$$("manuscript_list_id").clearAll();
  };

  componentDidUpdate() {
    let { manuscriptList, selectedManuscript, isPlusIconClick } = this.state;
    let newlyAddedManuscript = manuscriptList.find(m => m.article_id == 0);
    if (isPlusIconClick && newlyAddedManuscript) {
      window.$$("manuscript_list_id").select(newlyAddedManuscript.id);
    }
    else if (selectedManuscript) {
      window.$$("manuscript_list_id").select(selectedManuscript.id);
    }
  };

  onSaveNext(isSaveNext = false, isUploading = false, isModifiedData = false) {
    this.setState({ "isSaveNext": isSaveNext, "isModifiedData": isModifiedData, "isUploading": isUploading });
  }

  getModifiedData() {
    let { isSaveNext, isUploading, isModifiedData } = this.state;
    return { isSaveNext, isUploading, isModifiedData };
  }

  onPlusIconClick = () => {
    this.props.MenuShownAction({
      journal: true,
      options: true,
      manuscript: true,
      selectedManuscript: true,
      fileUpload: true,
      submitted: true,
      submittedOption: true
    });
    let { selectedJournal, manuscriptList, isSaveNext } = this.state;

    if (isSaveNext) {
      window.webix.message({ text: "Please wait until the previous manuscript move to engine process Queue.", type: "error" });
      return false;
    }

    //maximum upload validation 
    let count = 0;
    for (let item of manuscriptList) {
      if (item.automation_status_id != 5) {
        count++
      }
    }
    if (count > 9) {
      window.webix.message({ text: "Maximum file upload are exceeded. Please submit the pending articles and proceed.", type: "error" });
      return false;
    }
    let newlyAddedManuscript = manuscriptList.find(m => m.article_id == 0);
    if (newlyAddedManuscript) {
      window.webix.message({ text: "Please save current selected article.", type: "error" });
      window.$$("manuscript_list_id").select(newlyAddedManuscript.id);
      this.setState({ isPlusIconClick: true, selectedManuscript: newlyAddedManuscript, selectedStep: "Upload" });
    } else {
      let manuscript = {
        journal_id: selectedJournal.id, article_id: 0, job_guid: "", article_guid: "", "article_name": "Manuscript 1", article_code: "",
        article_title: "", org_id: "", issue_id: "", author_id: 0, "is_active": "1", ser_id: "",
        "wfd_id": "", "abstract": "", user_id: 0, created: "", status_name: "Processing...",
        icon: "<i title='Processing' class='material-icons auto-icons'>autorenew</i>", automation_status_id: 0
      }
      manuscriptList.push(manuscript);
      this.setState({ manuscriptList, isPlusIconClick: true, selectedManuscript: manuscript, selectedStep: "Upload" });
    }
  };

  onManuscriptSelect(selectedManuscript) {
    this.props.MenuShownAction({
      journal: true,
      options: true,
      manuscript: true,
      selectedManuscript: true,
      fileUpload: true,
      submitted: true,
      submittedOption: true
    });
    if (selectedManuscript.article_id != 0) {
      Loader.showLoader();
      ArticleService.checkAutomationStatus(selectedManuscript.article_id).then(automationRes => {

        selectedManuscript.automation_status_id = automationRes ? automationRes.status : null;
        selectedManuscript.automation_remark = automationRes ? automationRes.remark : null;
        let selectedStep = "";
        if (selectedManuscript.automation_status_id == 4) {
          selectedStep = "Metadata";
        }
        else {
          selectedStep = "Upload";
        }
        // else if (selectedManuscript.automation_status_id == 5) {
        //   selectedStep = "Errorlog";
        // } else {
        //   selectedStep = "Upload";
        // }
        Loader.hideLoader();
        this.setState({ isPlusIconClick: false, selectedManuscript, selectedStep: selectedStep });

      }, error => {
        Loader.hideLoader();
        window.webix.message({ text: error, type: "error" });
      });
    }
    else {
      this.setState({ isPlusIconClick: false, selectedManuscript, selectedStep: "Upload" });
    }
    // window.$$("manuscript_list_id").unselectAll();
  };

  updateMenuManuscript = () => {

    let menuItem = { ...this.state.menuItem };
    menuItem.options = true;
    menuItem.manuscript = true;
    menuItem.selectedManuscript = false;
    menuItem.fileUpload = false;
    this.setState({ menuItem });
  }

  updateManuscript(articleDetails) {
    let { selectedManuscript, manuscriptList } = this.state;
    selectedManuscript.article_name = articleDetails.article_name;
    selectedManuscript.article_id = articleDetails.article_id;
    selectedManuscript.automation_status_id = articleDetails.automation_status_id;
    selectedManuscript.automation_remark = articleDetails.automation_remark;
    if (articleDetails.automation_status_id == 5) {
      selectedManuscript.icon = "<i title='Error' class='material-icons outline-icons'>error_outline</i>";
      this.setState({ selectedManuscript, isPlusIconClick: false, selectedStep: "Errorlog" });
    } else {
      selectedManuscript.icon = "<i class='material-icons auto-icons'>autorenew</i>";
      this.setState({ selectedManuscript, isPlusIconClick: false });
    }
  };

  search_box_open = () => {
    document.getElementById('PL_spec_Header3').classList.add('search-open');
    document.getElementById('iopp-top-icons3').classList.add('hide');
    window.$$("search_manuscript").focus('search_manuscript_id');
  };

  search_box_close = () => {
    document.getElementById('PL_spec_Header3').classList.remove('search-open');
    document.getElementById('iopp-top-icons3').classList.remove('hide');

    //clear search
    window.$$("search_manuscript_id").setValue("");
    //set journal again
    window.$$("manuscript_list_id").filter(function (obj) {
      return obj.article_name.toLowerCase().indexOf("") != -1;
    })

    let { selectedManuscript } = this.state;
    if (selectedManuscript) {
      //select previously selected item
      window.$$("manuscript_list_id").select(selectedManuscript.id);
    }
  };

  closeNextPanels = () => {
    if (this.state.isSaveNext) {
      window.webix.message({ text: "Please wait until the previous manuscript move to engine process Queue.", type: "error" });
      return false;
    }
    if (this.state.isUploading) {
      window.webix.message({ text: "Please wait until upload to be completed", type: "error" });
      return false;
    }
    if (this.state.isModifiedData === true) {
      window.webix.message({ text: "Please save current selected article.", type: "error" });
      return false;
    }

    this.props.MenuShown.options = true;
    this.props.MenuShown.manuscript = false;
    this.props.MenuShown.selectedManuscript = false;
    this.props.MenuShown.fileUpload = false;
    this.props.MenuShown.submitted = false;
    this.props.MenuShown.submittedOption = false;
    this.props.MenuShownAction(this.props.MenuShown);
    this.props.updateMenuJournalOption();
    this.setState({ selectedManuscript: null, isPlusIconClick: false });

  };

  render() {
    let { selectedJournal, manuscriptList, selectedManuscript, isPlusIconClick, selectedStep, isSaveNext, isModifiedData } = this.state;
    return (
      <React.Fragment>
        <div className="iopp seconday_sidebar single-border-RT">

          {/* search */}
          <div id="PL_spec_Header3" className="secondary-header">
            <span className="se-panel-title">Manuscripts</span>
            <div className="search-box search-open">
              <Webix ui={Data.manuscripts_search()} ></Webix>
              <i title="Close" className="material-icons" onClick={() => this.search_box_close()}>close</i>
            </div>
            <span title="Search" className="se-panel-icon iopp-top-icons" id="iopp-top-icons3">
              <i className="material-icons iR-book-search iopp-search" onClick={() => this.search_box_open()}>search</i>
              {/* {
                selectedManuscript || isPlusIconClick ? <i title="Close" className="material-icons close-btn-top iopp-editor-close iopp-top-icons-close" onClick={() => this.closeNextPanels()}>close</i> : null
              } */}
              <i title="Close" className="material-icons close-btn-top iopp-editor-close iopp-top-icons-close" onClick={() => this.closeNextPanels()}>close</i>
            </span>
            {/* <span title="Search" className="se-panel-icon"><i className="material-icons iR-book-search" onClick={() => search_box_open()}>search</i></span> */}
          </div>

          <div className="secondary-body iopp-icon iR-listing-data window-scroll-div-list">
            <Webix ui={Data.manuscript_list(this.onManuscriptSelect, this.getModifiedData)} data={manuscriptList}></Webix>
            <button type="button" id="add_sel_approv" className="alt-btn app_btn iopp" title="Submit Manuscript" onClick={() => this.onPlusIconClick()}><img src={addmaterila} alt="add to" /></button>
          </div>
        </div>
        {

          this.props.MenuShown.selectedManuscript ? selectedManuscript || isPlusIconClick ? <SubmitManuscript socket={this.props.socket} selectedJournal={selectedJournal} selectedManuscript={selectedManuscript} selectedStep={selectedStep} journals={this.props.journals} salutations={this.props.salutations} countries={this.props.countries} updateManuscript={this.updateManuscript} updateMenuManuscript={this.updateMenuManuscript} onSaveNext={this.onSaveNext} getModifiedData={this.getModifiedData} /> : null : null

          // selectedManuscript || isPlusIconClick ? <SubmitManuscript socket={this.props.socket} selectedJournal={selectedJournal} selectedManuscript={selectedManuscript} selectedStep={selectedStep} journals={this.props.journals} salutations={this.props.salutations} countries={this.props.countries} updateManuscript={this.updateManuscript} onSaveNext={this.onSaveNext} /> : null

        }
      </React.Fragment>
    )
  }
};



const mapStateToProps = (state) => {
  const MenuShown = state.MenuShown
  return {
    MenuShown
  }
};



const mapDispatchToProps = (dispatch) => {
  return {
    MenuShownAction: (menuItem) => dispatch(submitManuscriptActions.MenuShownAction(menuItem))
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(Manuscripts);