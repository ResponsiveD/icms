import 'webix/webix.js';
import 'webix/webix.css';

// search
export function save_button(resubmit) {
	return {
		view: "toolbar", elements: [
			{
				view: "button", type: "icon", icon: "reply", label: "Resubmit", tooltip: "Resubmit", click: function () {
					resubmit();
				}
			},
		]
	}
};
