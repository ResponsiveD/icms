import React, { Component } from 'react';
import Webix from '../../../../Webix';
import * as Data from './Errorlog-Data';


export default class submitted extends Component {
  constructor(props) {
    super(props);

  };
  render() {

    return (
      <div className="upload Right-Panel">
        <div className="secondary-header errorlog">
          <div className="head-left errorlog">
            <span className="se-panel-title">Errorlog</span>
            <Webix ui={Data.save_button(this.props.resubmit)} ></Webix>
            <i title="Close" className="material-icons close-btn-top">close</i>
            {/* <div className="se-panel-left"><i className="material-icons save-icon" title="save" >save</i> <span>Save & Next</span><i title="close" className="material-icons close-icon">close</i></div> */}
          </div>
        </div>
        <div className="widget errorlog-inner">
          <p>{this.props.articleDetails ? this.props.articleDetails.automation_remark:''}</p>
        </div>

      </div>
    )
  }
};
