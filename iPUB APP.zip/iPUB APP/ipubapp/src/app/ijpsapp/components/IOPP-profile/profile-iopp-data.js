import 'webix/webix.js';
import 'webix/webix.css';
import { Loader } from '../../../../components/Core/iCore';
import { ioppProfileService, CommonService } from '../../services';

export function edit_button() {
	return {
		view: "toolbar",
		elements: [{
			view: "button",
			type: "icon",
			icon: "pencil",
			css: "iopp-edit",
			label: "Edit",
			tooltip: "Edit",
			click: function () {
				document.getElementById('edit-btn').classList.add('hide');
                document.getElementById('save-cancel-btn').classList.remove('hide');
                window.$$('author_id').enable();
				window.$$('orc_id').enable();
				window.$$('sal_id').enable();
				window.$$('first_name').enable();
				window.$$('middle_name').enable();
				window.$$('last_name').enable();
				window.$$('email').enable();
				window.$$('institution_name').enable();
				window.$$('department').enable();
				window.$$('role').enable();
				window.$$('address_1').enable();
				window.$$('address_2').enable();
				window.$$('city').enable();
				window.$$('state').enable();
				window.$$('country').enable();
				window.$$('contact_no').enable();
			}
		}]
	}
}

export function save_button() {
	return {
		view: "toolbar",
		elements: [{
			view: "button",
			type: "icon",
			icon: "floppy-o",
			label: "Save & Next",
			tooltip: "Save & Next",
			click: function () {
				let isGeneralInformationFormValidated = false;
				let isInstitutuionInfoFormationFormValidated = false;
				if (window.$$("genralinfo").validate()) {
					isGeneralInformationFormValidated = true;
				}
				if (window.$$("institutuioninfo").validate()) {
					isInstitutuionInfoFormationFormValidated = true;
				}
				if (isGeneralInformationFormValidated && isInstitutuionInfoFormationFormValidated) {
					let data = {
						author_id: window.$$('author_id').getValue(),
						orc_id: window.$$('orc_id').getValue(),
						sal_id: window.$$('sal_id').getValue(),
						first_name: window.$$('first_name').getValue(),
						middle_name: window.$$('middle_name').getValue(),
						last_name: window.$$('last_name').getValue(),
						email: window.$$('email').getValue(),
						institution_name: window.$$('institution_name').getValue(),
						department: window.$$('department').getValue(),
						role: window.$$('role').getValue(),
						address_1: window.$$('address_1').getValue(),
						address_2: window.$$('address_2').getValue(),
						city: window.$$('city').getValue(),
						state: window.$$('state').getValue(),
						country: window.$$('country').getValue(),
						contact_no: window.$$('contact_no').getValue(),
					}
					Loader.showLoader();
					ioppProfileService.editProfileDetails(data).then(res => {
						Loader.hideLoader();
						window.$$("genralinfo").clear();
						window.$$("genralinfo").clearValidation();
						window.$$("institutuioninfo").clear();
						window.$$("institutuioninfo").clearValidation();
						window.webix.$$("genralinfo").parse(res.data);
						window.webix.$$("institutuioninfo").parse(res.data);
						document.getElementById('edit-btn').classList.remove('hide');
						document.getElementById('save-cancel-btn').classList.add('hide');
						window.$$('author_id').disable();
						window.$$('orc_id').disable();
						window.$$('sal_id').disable();
						window.$$('first_name').disable();
						window.$$('middle_name').disable();
						window.$$('last_name').disable();
						window.$$('email').disable();
						window.$$('institution_name').disable();
						window.$$('department').disable();
						window.$$('role').disable();
						window.$$('address_1').disable();
						window.$$('address_2').disable();
						window.$$('city').disable();
						window.$$('state').disable();
						window.$$('country').disable();
						window.$$('contact_no').disable();
						window.webix.message({ text: "Profile details updated successfully.", type: "success" });
						//window.webix.message({ text: res.message, type: "success" });
					}).catch(error => {
						Loader.hideLoader();
						window.webix.message({ text: error, type: "error" });
					});
				}
			}
		}]
	}
}

function removeSpaces(string) {
	return string.toString().trim();
}

export function Genral_info() {
	return {
		view: "form",
		id: "genralinfo",
		elements: [{
                view: "text",
                label: "Author",
                name: "author_id",
				id: "author_id",
				invalidMessage: "ORCID ID should not be empty",
                labelWidth: 200,
                hidden: true,
                disabled: true,
				type: "text"
            },
            {
				view: "text",
				label: "ORCID <span class='error_v'>*</span>",
				name: "orc_id",
				id: "orc_id",
                labelWidth: 200,
                disabled: true,
				type: "text",
				validateEvent: "blur",
				validate: function (value) {
					let regexp = /^[0-9]+$/;
					if (value.length !== 0) {
						if (value.length < 151 && regexp.test(value)) {
							return true;
						}
					}
					else {
						return false;
					}
				},
				invalidMessage: "Invalid ORCID"
			},
			{
				view: "combo",
				label: "Sal. <span class='error_v'>*</span>",
				name: "sal_id",
                id: "sal_id",
                disabled: true,
				labelWidth: 200,
				options: {
					body: {
						data: [],
						scheme: {
							$init: obj => {
								obj.value = obj.value,
									obj.id = obj.id
							}
						}
					}
				},
				on: { 
					onAfterRender: function () {
						Loader.showLoader();
						let sal_id = window.$$("sal_id").getPopup().getList();
						CommonService.getSalutations().then(res => {
							Loader.hideLoader();
							sal_id.parse(res);
						});
					}
				},
				validateEvent: "blur", 
				invalidMessage: "Salutation should not be empty",
				validate: window.webix.rules.isNotEmpty
			},
			{
				view: "text",
				label: "First (Given) Name <span class='error_v'>*</span>",
				name: "first_name",
                id: "first_name",
                disabled: true,
				labelWidth: 200,
				type: "text",
				invalidMessage: "First Name should not be empty", 
				onblur: 'this.value=removeSpaces(this.value);',
				validate: window.webix.rules.isNotEmpty, 
				attributes: { maxlength: 150 }, 
				validateEvent: "blur"
			},
			{
				view: "text",
				label: "Middle Name",
				name: "middle_name",
                id: "middle_name",
                disabled: true,
				labelWidth: 200,
				type: "text",
				attributes: { maxlength: 150 }, 
				validateEvent: "blur"
			},
			{
				view: "text",
				label: "Last (Family) Name",
				name: "last_name",
                id: "last_name",
				disabled: true,
				labelWidth: 200,
				type: "text",
				attributes: { maxlength: 150 }, 
				validateEvent: "blur"
			},
			{
				view: "text",
				label: "Email <span class='error_v'>*</span>",
				name: "email",
				id: "email",
				invalidMessage: "Invalid Email",
                disabled: true,
				labelWidth: 200,
				type: "email", 
				validate: window.webix.rules.isEmail, 
				attributes: { maxlength: 254 }, 
				validateEvent: "blur"
			},
		],
		rules: {
			first_name: removeSpaces
		},
		elementsConfig: {
			on: {
				onBlur() {
					this.validate();
				}
			}
		}
	}
};

export function institutuion_info() {
	return {
		view: "form",
		id: "institutuioninfo",
		elements: [{
				view: "text",
				label: "Institution Name <span class='error_v'>*</span>",
                name: "institution_name",
                id: "institution_name",
                disabled: true,
                labelWidth: 200,
				invalidMessage: "Institution Name should not be empty", 
				type: "text", 
				validate: window.webix.rules.isNotEmpty, 
				attributes: { maxlength: 250 }, 
				validateEvent: "blur",
				onblur: 'this.value=removeSpaces(this.value);',
			},
			{
				view: "text",
				label: "Department <span class='error_v'>*</span>",
                name: "department",
                id: "department",
                disabled: true,
				labelWidth: 200,
				invalidMessage: "Department should not be empty", 
				type: "text", 
				validate: window.webix.rules.isNotEmpty, 
				attributes: { maxlength: 250 }, 
				validateEvent: "blur",
				onblur: 'this.value=removeSpaces(this.value);',
			},
			{
				view: "text",
				label: "Role <span class='error_v'>*</span>",
                name: "role",
                id: "role",
                disabled: true,
				labelWidth: 200,
				invalidMessage: "Role should not be empty", 
				type: "text", 
				validate: window.webix.rules.isNotEmpty, 
				attributes: { maxlength: 250 }, 
				validateEvent: "blur",
				onblur: 'this.value=removeSpaces(this.value);',
			},
			{
				view: "text",
				label: "Address 1 <span class='error_v'>*</span>",
                name: "address_1",
                id: "address_1",
                disabled: true,
				labelWidth: 200,
				invalidMessage: "Address 1 should not be empty", 
				type: "text", 
				validate: window.webix.rules.isNotEmpty, 
				//attributes: { maxlength: 150 }, 
				validateEvent: "blur",
				onblur: 'this.value=removeSpaces(this.value);',
			},
			{
				view: "text",
				label: "Address 2",
                name: "address_2",
                id: "address_2",
                disabled: true,
				labelWidth: 200,
				type: "text",
				//attributes: { maxlength: 150 }
			},
			{
				view: "combo",
				label: "City <span class='error_v'>*</span>",
				name: "city",
                id: "city",
                disabled: true,
				labelWidth: 200,
				validateEvent: "blur", 
				invalidMessage: "City should not be empty",
				options: {
					body: {
						data: [],
						scheme: {
							$init: obj => {
								obj.value = obj.value,
									obj.id = obj.id
							}
						}
					}
				},
				validate: window.webix.rules.isNotEmpty
			},
			{
				view: "combo",
				label: "State / Province <span class='error_v'>*</span>",
				name: "state",
                id: "state",
                disabled: true,
				labelWidth: 200,
				validateEvent: "blur", 
				invalidMessage: "State / Province should not be empty",
				options: {
					body: {
						data: [],
						scheme: {
							$init: obj => {
								obj.value = obj.value,
									obj.id = obj.id
							}
						}
					}
				},
				on: {
					OnChange: function (newv, oldv) {
						Loader.showLoader();
						let city = window.$$("city").getPopup().getList();
						if((typeof newv == 'number') && (newv > 0)){
							ioppProfileService.getCity(newv).then(res => {
								Loader.hideLoader();
								city.clearAll();
								city.parse(res);
							});
						} else {
							Loader.hideLoader();
							// window.webix.message({
							// 	type: "error",
							// 	text: "Please select the State."
							// });
						}
					}
				},
				validate: window.webix.rules.isNotEmpty
			},
			{
				view: "combo",
				label: "Country <span class='error_v'>*</span>",
				name: "country",
                id: "country",
                disabled: true,
				labelWidth: 200,
				validateEvent: "blur", 
				invalidMessage: "Country should not be empty",
				options: {
					body: {
						data: [],
						scheme: {
							$init: obj => {
								obj.value = obj.value,
									obj.id = obj.id
							}
						}
					}
				},
				on: {
					OnChange: function (newv, oldv) {
						Loader.showLoader();
						let state = window.$$("state").getPopup().getList();
						if((typeof newv == 'number') && (newv > 0)){
							ioppProfileService.geState(newv).then(res => {
								Loader.hideLoader();
								state.clearAll();
								state.parse(res);
							});
						} else {
							Loader.hideLoader();
							// window.webix.message({
							// 	type: "error",
							// 	text: "Please select the Country."
							// });
						}
					},
					onAfterRender: function () {
						Loader.showLoader();
						let country = window.$$("country").getPopup().getList();
						ioppProfileService.getCountry().then(res => {
							Loader.hideLoader();
							country.parse(res);
						});
					}
				},
				validate: window.webix.rules.isNotEmpty
			},
			{
				view: "text",
				label: "Contact No.",
                name: "contact_no",
                id: "contact_no",
                disabled: true,
				labelWidth: 200,
				// validateEvent: "blur", 
				invalidMessage: "Invalid contact no.",
				type: "text", 
				attributes: { maxlength: 250 },
				// validate: function (val) {
				// 	if (val) {
				// 		return val.length == 12 ? true : false;
				// 	} else {
				// 		return true;
				// 	}
				// },
				validate: function (value) {
					let regexp = /^[0-9-()/+]+$/;
					if (value.trim().length !== 0) {
						if (regexp.test(value)) {
							if (value.trim().length <= 15) {
								return true;
							} else {
								window.webix.message({
									type: "error",
									text: "Contact Number should not more than 15 numbers."
								});
								return false;
							}
						} else {
							window.webix.message({
								type: "error",
								text: "Contact Number should contains only numbers and special characters +,-,(,), and /"
							});
							return false;
						}
					}
					else {
						return true;
					}
				},
				// pattern: { mask: '############', allow: /^[0-9-()/+]+$/ },
			},
		],
		rules: {
			institution_name: removeSpaces,
			department: removeSpaces,
			role: removeSpaces,
			address_1: removeSpaces
		},
		elementsConfig: {
			on: {
				onBlur() {
					this.validate();
				}
			}
		}
	}
};