import React from 'react';
import Webix from '../../../../Webix';
import * as data from './profile-iopp-data';
import './profile.css';
import { ioppProfileService } from '../../services';
import { Loader } from '../../../../components/Core/iCore';


export default class IOPP_Profile extends React.Component {

  constructor(props) {
    super(props);
  };
  componentDidMount() {
    document.getElementById('save-cancel-btn').classList.add('hide');
    this.getProfileDetails();
  }

  getProfileDetails() {
    Loader.showLoader();
    ioppProfileService.getProfileDetails().then(res => {
      Loader.hideLoader();
      window.webix.$$("genralinfo").parse(res);
      window.webix.$$("institutuioninfo").parse(res);
    });
  }
  render() {
    return (
      <div className="IOPP">

        <div className="iR-flex iR-col-12 iopp profile Right-Panel Metadata ">
          <div className="secondary-header">
            <div className="head-left profiles">
              <span className="se-panel-title">My Profile</span>
              <div className="edit-btn" id="edit-btn">
                <Webix ui={data.edit_button()} ></Webix>
              </div>
              <div className="save-cancel-btn" id="save-cancel-btn">
                <Webix ui={data.save_button()} ></Webix>
              </div>
              <i title="Close" className="material-icons close-btn-top">close</i>
              {/* <div className="se-panel-left"><i className="material-icons save-icon" title="save" >save</i> <span>Submit</span><i title="close" className="material-icons close-icon">close</i></div> */}
            </div>
          </div>
          <div className="data-scroll">
            <div className="widget">
              <div className="iopp widget_header profile-head">
                General info.
                        </div>
              <div className="widget_body">
                <Webix ui={data.Genral_info()} ></Webix>
              </div>
            </div>
            <div className="widget">
              <div className="iopp widget_header profile-head">
                Institution info.
                        </div>
              <div className="widget_body">
                <Webix ui={data.institutuion_info()} ></Webix>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
