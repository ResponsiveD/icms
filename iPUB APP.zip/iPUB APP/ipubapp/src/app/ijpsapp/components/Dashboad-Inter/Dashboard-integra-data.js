import 'webix/webix.js';
import 'webix/webix.css';

export function dashboard_details(onUploadFileClick) {
	return {
		responsive: "true",
		view: "datatable",
		id: "dashboard_details",
		rowHeight: 40,
		tooltip: true,
		css: "dashboard_details_inter",
		columns: [{
				id: "options",
				name: "options",
				header: "Options",
				css: "icon_styles",
				width: 100,
				tooltip: false
			},
			{
				id: "submissionId",
				name: "submissionId",
				header: "Submission ID",
				width: 125,
				sort: "int",
				tooltip: false
			},
			{
				id: "article_name",
				name: "article_name",
				header: "Article Name",
				// width: 200,
				minWidth: 80,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#article_name#</div>",
				fillspace: true
			},
			{
				id: "journal",
				name: "journal",
				header: "Journal",
				minWidth: 100,
				// width: 200,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#journal#</div>",
				fillspace: true
			},
			{
				id: "stage",
				name: "stage",
				header: "Stage",
				minWidth: 100,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#stage#</div>",
				fillspace: true
			},
			{
				id: "currentlyWith",
				name: "currentlyWith",
				header: "Currently With",
				width: 120,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#currentlyWith#</div>"
			},
			{
				id: "status",
				name: "status",
				header: "Status",
				width: 100,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#status#</div>",
				template: function (obj) {
					if (obj.track_status == "Delay") {
						if (status == true)
							return "<span class='details_check'>" + obj.status + "</span>";
						else return "<span class='details_uncheck'>" + obj.status + "</span>";
					} else return obj.status;
				}
			},
			{
				id: "dueDate",
				name: "dueDate",
				header: "Due Date",
				width: 125,
				sort: "string",
				css: "auto_table",
				tooltip: false
			},
			{
				id: "action",
				name: "action",
				header: "Action",
				width: 200,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#action#</div>"
			},
			{
				id: "upload",
				name: "upload",
				header: "Upload",
				width: 120,
				sort: "string",
				tooltip: false
			}
		],

		data: [],

		scheme: {
			$init: function (obj) {
				obj.index = this.count();
			}
		},
		on: {
			onAfterLoad: function () {
				if (this.count() == 0) {
					this.showOverlay("No Records Found");
				} else {
					this.hideOverlay();
				}
			}
		},
		onClick: {
			"upload": function (event, id, node) {
				// document.getElementById('upload-popup').classList.remove('hide');
				let item = window.$$('dashboard_details').getItem(id);
				onUploadFileClick(item, true);
			},

		},
		autoWidth: true,
		scroll: true,
		minHeight: 500,
	}
}

export function dashboard_details_search() {
	return {
		view: "form",
		id: "dashboard_details_search",
		elements: [{
			view: "search",
			align: "center",
			name: "search",
			placeholder: "Search..",
			id: "search",
			width: 300,
			height: 40,
			css: "search-dash-2",
			on: {
				onTimedKeyPress: function () {
					window.webix.$$("dashboard_details").clearAll();
					let searchKeyword = this.getValue().toLowerCase();
					let allArticles = window.integra_prod_data;
					let filteredArticles = []
					for (let article of allArticles) {
						let isTextPresent = false;
						for (let key in article) {
							let value = article[key];
							if (value) {
								if (typeof value == "string") {
									if (value.toLowerCase().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								} else {
									if (value.toString().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								}
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("dashboard_details").parse(filteredArticles);

				}
			}
		}]
	}
}

export function dashboard_details_main() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main_over' title='#title#'>#title# <span><i class='material-icons filter-arrow'>navigate_next</i></span></div>",
		data: [
			{ id: 1, title: "Currently With" },
			{ id: 2, title: "Status" },
			{ id: 3, title: "Stage" },
		],
		on: {
			onItemClick: function (id, ev) {
				if (id == '1') {
					document.getElementById('level1').classList.remove('hide');
					document.getElementById('level2').classList.add('hide');
					document.getElementById('level3').classList.add('hide');
				}
				else if (id == '2') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.remove('hide');
					document.getElementById('level3').classList.add('hide');
				}
				else if (id == '3') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.add('hide');
					document.getElementById('level3').classList.remove('hide');
				}

			}
		}
	}
}
export function dashboard_details_main2() {
	return {
		view: "list",
		id: "dashboard_details_main2",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "Author" },
			{ id: 2, title: "Publisher" },
			{ id: 3, title: "Reviewer" },
			{ id: 4, title: "Production Editor"},
			{ id: 5, title: "Integra Production"}
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.integra_prod_data;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.currentlyWith.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
	
				document.getElementById('level1').classList.add('hide');
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}
	}
}
export function dashboard_details_main3() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "In Progress" },
			{ id: 2, title: "Reviewer not assigned" },
			{ id: 3, title: "Awaiting response from reviewers" },
			{ id: 4, title: "No response - Invite more reviewers" },
			{ id: 5, title: "On time" },
			{ id: 6, title: "Overdue reviewer reports" },
			{ id: 7, title: "Overdue decision deadline" },
			{ id: 8, title: "Overdue revision deadline" },
			{ id: 9, title: "Overdue pre-publication checks" },
			{ id: 10, title: "Invitation" },
			{ id: 11, title: "In revision" },
			{ id: 12, title: "Completed" }
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.integra_prod_data;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.status.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level2').classList.add('hide');
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}

	}
}
export function dashboard_details_main4() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id:1, title: "Submission pending"},
			{ id:2, title: "Manuscript submitted"},
			{ id:3, title: "Out to reviewers"},
			{ id:4, title: "Awaiting reviewer report"},
			{ id:5, title: "Awaiting decision"},
			{ id:6, title: "In revision"},
			{ id:7, title: "Revision: manuscript submitted"},
			{ id:8, title: "Revision: Awaiting reviewer report"},
			{ id:9, title: "Revision: Awaiting decision"},
			{ id:10, title: "Revision: Out to reviewers"},
			{ id:11, title: "Send corrections to author"},
			{ id:12, title: "Layout Correction"},
			{ id:13, title: "Author final checks"},
			{ id:14, title: "Send for publication"}
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.integra_prod_data;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.stage.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				document.getElementById('level3').classList.add('hide');
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}

	}
}

export function Upload_form_queue(onSupportXmlFileUpload, selectedQueue) {
	return {
		view: "form", type: "line", id: "upload_uploadpapersecond_form",
		rows: [
			{
				view: "uploader", id: "upload_uploadpapersecond_1", css: "iopp uploads", align: "center", type: "iconButton", label: "Drag & Drop or Click to Browse", autosend: false, accept: ".pdf", multiple: false,
				on: {
					"onBeforeFileAdd": function (file) {
						let savedFiles = window.$$('Upload_form_list').serialize();
						if (savedFiles.filter(item => item.name == file.name).length > 0) {
							window.webix.message({ text: "Duplicate file with name " + file.name, type: "error" })
							return false;
						}

						if (file.size && file.size > 52428800) {
							window.webix.message({ text: "Maximum upload file size is 50 MB, above 50 MB file is not acceptable.", type: "error" })
							return false;
						};

						if (file.size != undefined && file.size != null && file.size == 0) {
							window.webix.message({ text: "Empty file cannot be uploaded.", type: "error" })
							return false;
						};

						if (file.name && file.name.indexOf(' ') !== -1) {
							window.webix.message({ text: "File name with space cannot be uploaded.", type: "error" })
							return false;
						};

						// if (file.name.substr(0, file.name.lastIndexOf('.')) != selectedPaperQueue.ArticleName.substr(0, selectedPaperQueue.ArticleName.lastIndexOf('.'))) {
						if (file.name.substr(0, file.name.lastIndexOf('.')) != selectedQueue.article_name) {
							//window.webix.message({ text: "File name is not matching with article name " + selectedPaperQueue.ArticleName.substr(0, selectedPaperQueue.ArticleName.lastIndexOf('.')), type: "error" })
							window.webix.message({ text: "File name is not matching with article name " + selectedQueue.article_name, type: "error" })
							return false;
						}

						let fileExtensions = file.name.slice((file.name.lastIndexOf(".") - 1 >>> 0) + 2).toLowerCase();
						// let isValidFileExtension = false;
						if (fileExtensions !== "pdf") {
							window.webix.message({ text: "Please upload file with the extension(.pdf)", type: "error" });
							return false;
						}
						// if (!isValidFileExtension) {
						// 	window.webix.message({ text: "Please upload file with the extension(.xml,.pdf)", type: "error" });
						// 	return false;
						// }
					},
					"onAfterFileAdd": function (file) {
						onSupportXmlFileUpload(file);
					}
				}
			}
		]
	};
};
export function Upload_form_button(onClearClick, onUploadPDFSupport) {
	return {
		view: "toolbar",
		width: 600,
		id: 'Upload_form_button',
		elements: [{
			view: "button",
			label: "Clear",
			autowidth: true,
			tooltip: "Clear",
			click: function () {
				// document.getElementById('upload-popup').classList.add('hide');
				window.$$("Upload_form_list").clearAll();
				onClearClick();
			},
		},
		{
			view: "button",
			label: "Save",
			autowidth: true,
			tooltip: "Save",
			type: "form",
			click: function () {
				// document.getElementById('upload-popup').classList.add('hide');
				if (window.webix.$$("Upload_form_list").count() == 0) {
					window.webix.message({ text: "Please upload PDF file.", type: "error" })
					return false;
				} else {
					// let xmlFileObj = window.$$("Upload_form_list").serialize().find(item => item.name.substr(item.name.lastIndexOf('.'), item.name.length).toLowerCase() == '.xml');
					let pdfFileObj = window.$$("Upload_form_list").serialize().find(item => item.name.substr(item.name.lastIndexOf('.'), item.name.length).toLowerCase() == '.pdf');
					// xmlFileObj = xmlFileObj != undefined ? xmlFileObj : 0;
					pdfFileObj = (pdfFileObj != undefined || pdfFileObj != '') ? pdfFileObj : 0;
					if(pdfFileObj){
						onUploadPDFSupport(pdfFileObj).then(uploadedFileileResponse => {
							window.webix.message({ text: "PDF file uploaded successfully.", type: "success" });
							onClearClick();
						}).catch(error => {
							window.webix.message({ text: error, type: "error" });
						});
					}
				}
			}
		}]
	}
}

export function Upload_form_file_list() {
	return {
		view: "list",
		autoheight: true,
		css: "download-list tandf",
		id: "Upload_form_list",
		template:`<div class='iopp2 iR-project-list-item'>#imgsrc#
					<div class='iopp-title iR-litem-detail'>
					<h1 class='iR-title overflow_text' title=#name#>#name#</h1>
					<span>#sizetext#, #created_on#</span>
					<i class='material-icons list-delete iopp' title='delete'>delete_outline</i></div></div>`,
		data:[],	
		scroll: true,
		onClick: {
			"list-delete": function (event, id, node) {
				var list_down = this;
				window.webix.confirm("Are you sure, to delete this?", function (action) {
					if (action === true) {
						list_down.remove(id);
						if (window.webix.$$("Upload_form_list").count() == 1) {
							window.webix.$$("upload_uploadpapersecond_1").disable();
						  } else {
							window.webix.$$("upload_uploadpapersecond_1").enable();
						  }
					}
				});
				return true;
			}
		}
	}
};