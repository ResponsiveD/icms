export function journal_option_search() {
	return {
		view: "toolbar", id: "journal_option_search",
		cols: [
			{
				view: "search", align: "center", name: "journal_option_search_id", placeholder: "Search..", id: "journal_option_search_id", width: 300, height: 56,
				on: {
					onTimedKeyPress: function () {
						var value = this.getValue().toLowerCase();
						window.$$("journal-option-list").filter(function (obj) {
							return obj.title.toLowerCase().indexOf(value) != -1;
						})
					}
				}
			}
		]
	}
};

export function journal_option(onOptionSelect) {
	return {
		view: "list",
		scroll: false,
		select: 1,
		id: "journal-option-list",
		css: "style-list iopp",
		template: "<div class='iopp iR-project-list-item'><div class='iopp iR-litem-detail'><h1 class='iR-title' title='#title#'> #title#</h1><i title='show' class='material-icons iR-rt-arrow'>chevron_right</i></div></div>",
		data: [
			{ id: 1, title: "Article Submission", },
			{ id: 2, title: "Submitted" },
		],
		onClick: {
			"iR-project-list-item": function (ev, id) {
				onOptionSelect(window.webix.$$("journal-option-list").getItem(id), true);
			}
		}
	};
};

