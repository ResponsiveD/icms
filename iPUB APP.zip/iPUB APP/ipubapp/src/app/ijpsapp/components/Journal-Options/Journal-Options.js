import React, { Component } from 'react';
import Webix from '../../../../Webix';
import * as Data from './Journal-Options-Data';
import Manuscripts from '../../components/Manuscripts/Manuscripts';
import Submitted from '../../components/Submitted/submitted';
import socketIOClient from 'socket.io-client';
import { connect } from 'react-redux';
import { submitManuscriptActions } from '../../../../redux/actions';

class JournalOptions extends Component {
  constructor(props) {
    super(props);
    this.socket = null;
    this.state = {
      selectedOption: null,
      socket: null,
      menuItem : this.props.MenuShown
    }
    this.onOptionSelect = this.onOptionSelect.bind(this);
    this.updateMenuJournalOption = this.updateMenuJournalOption.bind(this);
  };

  //used to handel click event of option list
  onOptionSelect(selectedOption, isOptionManuallySelected) {
    this.props.MenuShownAction({
      journal: true,
      options: true,
      manuscript: true,
      selectedManuscript: false,
      fileUpload: false,
      submitted : false,
      submittedOption : false
    });
    this.setState({ selectedOption });
    if (isOptionManuallySelected) {
      this.props.updateStateFromChild({ openAllPanelToSubmitManuscript: false })
    }

  };

  componentDidMount() {
    if (this.props.openAllPanelToSubmitManuscript) {
      this.selectDefaultOption();
    }

    this.socket = socketIOClient('https://isocket.integra.co.in/integra', { reconnect: true });
    this.socket.on('connect', res => {
      this.socket.emit('joinIPub', JSON.stringify({ product: "iPUb", AutomationId: 1 }));
      this.setState({ socket: this.socket });
    });
  };

  componentWillUnmount() {
    this.socket.on('disconnect', err => {
      //console.log('Socket disconnect'); 
    });
  }

  //used to to select default option
  selectDefaultOption = () => {
    this.onOptionSelect(window.webix.$$("journal-option-list").getItem(1));
    window.webix.$$("journal-option-list").select(1)
  };

  componentWillReceiveProps(nextProps) {
    if (this.props.selectedJournal.id != nextProps.selectedJournal.id) {
      this.setState({ selectedOption: null });
      window.$$("journal-option-list").unselectAll();
    }
    if (nextProps.openAllPanelToSubmitManuscript) {
      this.selectDefaultOption();
    }
  };

  closeNextPanels = () => {
    this.props.MenuShown.options = false;
    this.props.MenuShown.manuscript = false;
    this.props.MenuShown.selectedManuscript = false;
    this.props.MenuShown.fileUpload = false;
    this.props.MenuShown.submitted = false;
    this.props.MenuShown.submittedOption = false;
    this.props.MenuShownAction(this.props.MenuShown);
    this.props.updateMenuJournal()
    this.setState({ selectedOption: null });
    window.$$("journal-option-list").unselectAll();
  };

  updateMenuJournalOption = () => {
    let menuItem = {...this.state.menuItem};
    menuItem.options = true;
    menuItem.manuscript = false;
    menuItem.selectedManuscript = false;
    menuItem.fileUpload = false;
    menuItem.submitted = false;
    menuItem.submittedOption = false;
    this.setState({menuItem});
  }

  search_box_open = () => {
    document.getElementById('PL_spec_Header2').classList.add('search-open');
    document.getElementById('iopp-top-icons2').classList.add('hide');
    window.$$("journal_option_search").focus('journal_option_search_id');
  };

  search_box_close = () => {
    document.getElementById('PL_spec_Header2').classList.remove('search-open');
    document.getElementById('iopp-top-icons2').classList.remove('hide');
    window.$$("journal_option_search_id").setValue("");

    //set journal again
    window.$$("journal-option-list").filter(function (obj) {
      return obj.title.toLowerCase().indexOf("") != -1;
    })

    let { selectedOption } = this.state;
    if (selectedOption) {
      //select previously selected item
      window.$$("journal-option-list").select(selectedOption.id);
    }
  };

  render() {
    let { selectedOption } = this.state;
    return (
      <div className="iopp-sub">

        {/* left pannel start*/}
        <div className="iopp seconday_sidebar single-border-RT">

          {/* search */}
          <div id="PL_spec_Header2" className="secondary-header">
            <span className="se-panel-title">Options</span>
            <div className="search-box search-open">
              <Webix ui={Data.journal_option_search()} ></Webix>
              <i title="Close" className="material-icons" onClick={() => this.search_box_close()}>close</i>
            </div>
            <span title="Search" className="se-panel-icon iopp-top-icons" id="iopp-top-icons2">
              <i className="material-icons iR-book-search iopp-search" onClick={() => this.search_box_open()}>search</i>
              {/* {
                selectedOption ? <i title="Close" className="material-icons close-btn-top iopp-editor-close iopp-top-icons-close" onClick={() => this.closeNextPanels()}>close</i> : null
              } */}
              <i title="Close" className="material-icons close-btn-top iopp-editor-close iopp-top-icons-close" onClick={() => this.closeNextPanels()}>close</i> 
            </span>
            {/* <span title="Search" className="se-panel-icon"><i className="material-icons iR-book-search" onClick={() => search_box_open()}>search</i></span> */}
          </div>

          <div className="secondary-body iopp-icon iR-listing-data window-scroll-div-list">
            <Webix ui={Data.journal_option(this.onOptionSelect)} ></Webix>
          </div>
        </div>
        {
          this.props.MenuShown.manuscript ? selectedOption && selectedOption.id === 1 ? <Manuscripts socket={this.state.socket} openAllPanelToSubmitManuscript={this.props.openAllPanelToSubmitManuscript} journals={this.props.journals} salutations={this.props.salutations} countries={this.props.countries} selectedJournal={this.props.selectedJournal} updateMenuJournalOption={this.updateMenuJournalOption}  /> : null : null
        }
        {
          this.props.MenuShown.manuscript ? selectedOption && selectedOption.id === 2 ? <Submitted socket={this.state.socket} journals={this.props.journals} salutations={this.props.salutations} selectedJournal={this.props.selectedJournal} updateMenuJournalOption={this.updateMenuJournalOption}/> : null : null
        }
      </div>
    )
  }
};


const mapStateToProps = (state) => {
  const MenuShown = state.MenuShown
  return {
    MenuShown
  }
};



const mapDispatchToProps = (dispatch) => {
  return {
    MenuShownAction: (menuItem) => dispatch(submitManuscriptActions.MenuShownAction(menuItem))
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(JournalOptions);