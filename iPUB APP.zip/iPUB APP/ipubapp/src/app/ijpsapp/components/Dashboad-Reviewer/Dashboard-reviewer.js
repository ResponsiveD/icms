import React from 'react';
import Highcharts from 'highcharts';
import Webix from '../../../../Webix';
import * as data from './Dashboard-reviewer-data';
import { Loader } from '../../../../components/';
import { ReviewerDashboardService } from '../../services';
let reviewer_dashboard_articles = [],
unfilter_articles = [];

export default class Dashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      dataLength: 0,
    };
    this.getReviewerDetails = this.getReviewerDetails.bind(this);
  }

  search_box_open() {
    //  document.getElementById('search_box').classList.add('search-open');
    document.getElementById('search_box').classList.add('active');
    document.getElementById('search_box_icon').classList.add('hide');
    document.getElementById('clear_filter_button').classList.add('btn_fil');
    window.$$("search_fun").focus('search');
  }

  search_box_close() {
    // document.getElementById('search_box').classList.remove('search-open');
    document.getElementById('search_box').classList.remove('active');
    document.getElementById('search_box_icon').classList.remove('hide');
    document.getElementById('clear_filter_button').classList.remove('btn_fil');
  }

  hideForm(_this, formID) {
    document.getElementById(_this).classList.add('hide');
  }
  filter_option() {
    document.getElementById('level0').classList.remove('hide');
    document.getElementById('level1').classList.add('hide');
    document.getElementById('level2').classList.add('hide');
  }
  componentDidMount() {
    document.getElementById('jobinfo-popup').classList.add('hide');
    document.getElementById('accept-notification-popup').classList.add('hide');
    document.getElementById('reviewer-notification-popup').classList.add('hide');
    document.getElementById('decline-notification-popup').classList.add('hide');
    document.getElementById('level0').classList.add('hide');
    document.getElementById('level1').classList.add('hide');
    document.getElementById('level2').classList.add('hide');
    document.getElementById('level3').classList.add('hide');
    document.addEventListener("click", function (e) {
      if (e.target.closest('#search_box')) {

      }
      else if (e.target.closest('#search_box_icon')) {

      }
      else {
        if(document.getElementById('search_box')!= null){
          document.getElementById('search_box').classList.remove('active');
          document.getElementById('search_box_icon').classList.remove('hide');
        }
      }
    });
    this.getReviewerDetails();

    document.addEventListener("click", function (event) {
      if (event.target.closest('#clear_filter_button')) {
        if (document.getElementById('clear_filter_button') != null) {
          window.webix.$$("dashboard_details").clearAll();
          window.webix.$$("dashboard_details").parse(window.unfilter_articles);
          document.getElementById('clear_filter_button').classList.add('hide');
        }
      } else if (event.target.closest('#filter_icon')) {
        document.getElementById('filter_overall').classList.remove('hide');
      } else if (!event.target.classList.contains('filter_main_over')) {
        if (document.getElementById('filter_overall') != null) {
          document.getElementById('filter_overall').classList.add('hide');
        }
      }
    });
    document.querySelector(".metatitle .webix_richtext_editor").setAttribute('contenteditable','false');
    document.querySelector(".metatitle2 .webix_richtext_editor").setAttribute('contenteditable','false');
  }

  getReviewerDetails() {
    Loader.showLoader();
			ReviewerDashboardService.getReviewerDashboard().then(res => {
        Loader.hideLoader();
        window.reviewer_dashboard_articles = res;
        window.unfilter_articles = res;
        window.webix.$$("dashboard_details").parse(res);
        this.setState({ dataLength: res.length });
        document.getElementById('clear_filter_button').classList.add('hide');
			});
  }
  

  render() {
    let { dataLength } = this.state;
    return (
      <div className="iopp-dashbord-page">
        <div className="dashboard-chart details-tables">
          <div className="iR-col-12 dashboard-chart-inner chart-height table_shrink">
            <div className="widget-dashboard">
              <div className="widget-dashboard-left">
               Overall Job Queue [{dataLength}]
                </div>
              <div className="widget-dashboard-right">
                <div className="filter_search">
                  <div className="search-box2" id="search_box">
                    <Webix ui={data.dashboard_details_search()} ></Webix>
                    <i title="Close" className="material-icons" onClick={this.search_box_close.bind()}>close</i>
                  </div>
                  <div className="button_area_filter">
                  <div className="filterallbtn" id="clear_filter_button" title="Clear Filter"> <i class="material-icons">close</i> Clear Filters</div>
                    <i className="material-icons" title="Search" id="search_box_icon" onClick={this.search_box_open.bind()}>search</i>
                    <i className="material-icons" title="filter" id="filter_icon" onClick={this.filter_option.bind()}>filter_list</i>
                  </div>
                </div>
                <div id="filter_overall">
                  <div className="filter_option" id="level0"><Webix ui={data.dashboard_details_main()} ></Webix></div>
                  <div className="filter_option level1" id="level1"><Webix ui={data.dashboard_details_main1()} ></Webix></div>
                  <div className="filter_option level2" id="level2"><Webix ui={data.dashboard_details_main2()} ></Webix></div>
                  <div className="filter_option level3" id="level3"><Webix ui={data.dashboard_details_main3()} ></Webix></div>
                </div>
              </div>
            </div>
            <div className="clear-fix"></div>
            <div className="dashboard_deatils">
              <Webix ui={data.dashboard_details()}  ></Webix>
             </div>
          </div>
        </div>
        <div className='alt_show_from overlay' id="jobinfo-popup">
          <div className="iR-dialog dashbord-iopp-popup">
            <div className="expand iopp-popup-header iR-window-header">
              <h2>Job Info. </h2>
              <i className="material-icons view_cls" title="Close" onClick={this.hideForm.bind(this, "jobinfo-popup")}>clear</i>
            </div>
            <div className="widget">
              <div className="widget_body">
                <Webix ui={data.Metadata()}  ></Webix>
              </div>
              <div className="btn_fun">
                <div id="service_btn" className="common_btn change_btn jobinfo-btn">
                   <Webix ui={data.job_info_IOPP()} ></Webix>
                </div>
              </div>
            </div>

          </div>
        </div> 

        <div className='alt_show_from overlay' id="accept-notification-popup">
          <div className="iR-dialog notification-iopp-popup">
            <div className="expand iopp-popup-header iR-window-header">
              <h2>Notification </h2>
              <i className="material-icons view_cls" title="Close" onClick={this.hideForm.bind(this, "accept-notification-popup")}>clear</i>
              <hr></hr>
            </div>
            <div className="widget">
            {/* <p>
              Thank you for agreeing to review this article for Materials Research Express.
              Please complete your review by . You will also receive an email width further details of how to proceed.
            </p>
            <p className="notification-mail">Please contact our support team in case of any assistance</p>
            <p className="notification-mail">Mail to: <a href="#">mrx.iop.org</a></p> */}
             <Webix ui={data.accept_notifaction()} ></Webix>
              <div className="btn_fun">
                <div id="service_btn" className="common_btn change_btn notif-btn">
                   <Webix ui={data.accept_notif_IOPP(this.getReviewerDetails)} ></Webix>
                </div>
              </div>
            </div>
          </div>
        </div> 

        <div className='alt_show_from overlay' id="reviewer-notification-popup">
          <div className="iR-dialog notification-iopp-popup">
            <div className="expand iopp-popup-header iR-window-header">
              <h2>Notification </h2>
              <i className="material-icons view_cls" title="Close" onClick={this.hideForm.bind(this, "accept-notification-popup")}>clear</i>
              <hr></hr>
            </div>
            <div className="widget">
            {/* <p>
              Thank you for agreeing to review this article for Materials Research Express.
              Please complete your review by . You will also receive an email width further details of how to proceed.
            </p>
            <p className="notification-mail">Please contact our support team in case of any assistance</p>
            <p className="notification-mail">Mail to: <a href="#">mrx.iop.org</a></p> */}
             <Webix ui={data.reveiwer_notifaction()} ></Webix>
              <div className="btn_fun">
                <div id="service_btn" className="common_btn change_btn notif-btn">
                   <Webix ui={data.reveiwer_notif_IOPP(this.getReviewerDetails)} ></Webix>
                </div>
              </div>
            </div>
          </div>
        </div> 

         <div className='alt_show_from overlay' id="decline-notification-popup">
          <div className="iR-dialog notification-iopp-popup">
            <div className="expand iopp-popup-header iR-window-header">
              <h2>Notification </h2>
              <i className="material-icons view_cls" title="Close" onClick={this.hideForm.bind(this, "decline-notification-popup")}>clear</i>
              <hr></hr>
            </div>
            <div className="widget">
            {/* <p>
              Thank you for your valuable response.
            </p>
            <p className="notification-mail">Please contact our support team in case of any assistance</p>
            <p className="notification-mail">Mail to: <a href="#">mrx.iop.org</a></p> */}
            <Webix ui={data.decline_notifaction()} ></Webix>
              <div className="btn_fun">
                <div id="service_btn" className="common_btn change_btn notif-btn">
                   <Webix ui={data.decline_notif_IOPP(this.getReviewerDetails)} ></Webix>
                </div>
              </div>
            </div>
          </div>
        </div> 

      </div>
    )
  }
}
