import 'webix/webix.js';
import 'webix/webix.css';


import { Loader } from '../../../../components/Core/iCore';
import { LocalStorage } from '../../../../helpers';

export function save_button(onCompleteSubmissionStepSave) {
	return {
		view: "toolbar",
		css: "completed_btns",
		elements: [
			{
				// 	view:"button", type:"icon", icon:"reply", label:"Resubmit" ,tooltip:"Resubmit" ,click: function () {

				//   }
			},
			{
				view: "button", type: "icon", icon: "upload", css: "complete-upload", label: "Complete Upload", tooltip: "Complete Upload", click: function () {
					//Loader.showLoader();
					onCompleteSubmissionStepSave().then(response => {
						//window.webix.message({ text: "", type: "success" });
						//Loader.hideLoader();
						window.webix.confirm(`Your manuscript ${response} submission is in-progress, Please click the iAuthor link in Dashboard and complete your submission to Publisher.`, function (action) {
							if (action === true) {
								let res = LocalStorage.getLocOrSesData("role");
								let roleName = (res && (typeof (res) == "object")) ? res.join() : res;
								if (roleName && roleName == "Author,Reviewer") {
									window.location.href = '#/Dashboard-Reviewer'
								} else {
									window.location.href = '#/Dashboard-Author';
								}
							}
						});
						//navigateToSteps("Metadata");
					}).catch(error => {
						//Loader.hideLoader();
						window.webix.message({ text: error, type: "error" });
					});
				}
			}
		]
	}
};
