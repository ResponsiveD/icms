import React from 'react';
import Webix from '../../../../Webix';
import * as data from './Activity_Stream_Data';
import './activity_style.css';
import { Activitystream } from '../../services';
import { Loader } from '../../../../components/Core/iCore';
import { LocalStorage } from '../../../../helpers';
export default class ActivityStream extends React.Component {
  constructor(props) {
    super(props);
    this.state = {

    };
  }

  search_box_open() {
    //  document.getElementById('search_box').classList.add('search-open');
    document.getElementById('search_box').classList.add('active');
   // document.getElementById('search_box_icon').classList.add('hide');
    window.$$("search_fun").focus('search');
  }

  search_box_close() {
    // document.getElementById('search_box').classList.remove('search-open');
    document.getElementById('search_box').classList.remove('active');
    //document.getElementById('search_box_icon').classList.remove('hide');
  }

  hideForm(_this, formID) {
    document.getElementById(_this).classList.add('hide');
  }
  componentDidMount() {
    // document.addEventListener("click", function (e) {
    //   if (e.target.closest('#search_box')) {

    //   }
    //   else if (e.target.closest('#search_box_icon')) {

    //   }
    //   else {
    //     if (document.getElementById('search_box') != null) {
    //       document.getElementById('search_box').classList.remove('active');
    //       document.getElementById('search_box_icon').classList.remove('hide');
    //     }
    //   }
    // });
    document.getElementById('upload-popup').classList.add('hide');
    window.$$('customer_name').hide();
    window.$$('journal').hide();
    window.$$('article_name').hide();
    window.$$('activity').hide();
    window.$$('status').hide();
    window.$$('from_date').hide();
    window.$$('to_date').hide();
    window.$$('activity_search').hide();
    document.getElementById('excel_export').classList.add('hide');
    document.getElementById("pagenation").classList.add('hide');
    // window.$$('status').setValue("");


    // pagenation active
    var page_header = document.getElementById("pagenation");
    var btns = page_header.getElementsByClassName("btn");
    for (var i = 0; i < btns.length; i++) {
      btns[i].addEventListener("click", function () {
        let type_value = window.$$('customer_type').getText();
        let journalid = window.$$("journal").getValue();
        let custid = window.$$('customer_name').getValue();
        let limit = 100;
        let comp_id = window.comp_id;
        var current = document.getElementsByClassName("active");
        current[0].className = current[0].className.replace(" active", "");
        this.className += " active";
        let page = current[0].innerText;
        Loader.showLoader();
        data.getDashboardDetails(custid, type_value, journalid, comp_id, limit, page);
        var btnName = this.classList[1];
				if( btnName == "prev"){
				if(document.querySelectorAll('.pager')[0].innerText > 1){
					document.querySelectorAll('.pager')[0].innerText=(document.querySelectorAll('.pager')[0].innerText -1);	document.querySelectorAll('.pager')[1].innerText=(document.querySelectorAll('.pager')[1].innerText -1);	
					document.querySelectorAll('.pager')[2].innerText=(document.querySelectorAll('.pager')[2].innerText -1);	document.querySelectorAll('.pager')[3].innerText=(document.querySelectorAll('.pager')[3].innerText -1);
					document.querySelectorAll('.pager')[4].innerText=(document.querySelectorAll('.pager')[4].innerText -1);		
				}					
				}else if(btnName == "next"){
					document.querySelectorAll('.pager')[0].innerText=(Number(document.querySelectorAll('.pager')[0].innerText) +1);	document.querySelectorAll('.pager')[1].innerText=(Number(document.querySelectorAll('.pager')[1].innerText) +1);
					document.querySelectorAll('.pager')[2].innerText=(Number(document.querySelectorAll('.pager')[2].innerText) +1);document.querySelectorAll('.pager')[3].innerText=(Number(document.querySelectorAll('.pager')[3].innerText)  +1);
					document.querySelectorAll('.pager')[4].innerText=(Number(document.querySelectorAll('.pager')[4].innerText) +1);						
				}
				else{
					let pageNum = Number(page);
					if(pageNum > 3){
						var a1={"First":page-2,"second":page-1,"third":page,"fourth":page+1,"fifth":page+2};
						document.querySelector('.active').classList.remove('active');
						document.querySelectorAll('.pager')[2].classList.add('active');
						document.querySelectorAll('.pager')[0].innerText = a1.First;document.querySelectorAll('.pager')[1].innerText = a1.second;
						document.querySelectorAll('.pager')[2].innerText = a1.third;document.querySelectorAll('.pager')[3].innerText = a1.fourth;
						document.querySelectorAll('.pager')[4].innerText = a1.fifth;
					}else{
						var a1={"First":1,"second":2,"third":3,"fourth":4,"fifth":5};
						document.querySelectorAll('.pager')[0].innerText = a1.First;document.querySelectorAll('.pager')[1].innerText = a1.second;
						document.querySelectorAll('.pager')[2].innerText = a1.third;document.querySelectorAll('.pager')[3].innerText = a1.fourth;
						document.querySelectorAll('.pager')[4].innerText = a1.fifth;
					}
				}
      });
    }

    //tableheight
    var tableheight = document.querySelector('#details-tables').clientHeight - 20;
    window.$$('activity_details').define("height", tableheight);
    window.$$('activity_details').adjust();

    // let customerName = Activitystream.getCustomerName(this.state.loginUserID);
    // Promise.all([customerName])
    //   .then((values) => {
    //     window.$$("customer_name").getPopup().getList().parse(values[0]);
    //     Loader.hideLoader();
    //   })
    //   .catch(error => {
    //     Loader.hideLoader();
    //     window.webix.message({ text: error, type: "error" });
    //   });
  }
  export_fun() {
    let type_value = window.$$('customer_type').getText();
    Loader.showLoader();
    window.webix.toExcel(window.$$("activity_details"), {
      filename: type_value + " details",
      filterHTML: true,
      columns: {
        "cust_name": {
          header: "Customer Name",
          width: 250
        },
        "type": {
          header: "Type",
          width: 200
        },
        "article_name": {
          header: "Article Name",
          width: 100
        },
        "aty_name": {
          header: "Activity Name",
          width: 200
        },
        "status": {
          header: "Status",
          width: 200
        },
        "completeddate": {
          header: "Last updated by",
          width: 200
        },
        "completedtime": {
          header: "Last updated time",
          width: 200
        }
      },
    });
    Loader.hideLoader();
  }
  render() {
    return (
      <div className="activitystream_page">
        {/* <div className="activity_header">
          <h2>ACTIVITY STREAM</h2>
          <p>Choose the filters to view the data</p>
        </div> */}
        <div className="widget_filter ">
          <div className="filterOption_area">
            <div className="filterOption_area_option">
              <Webix ui={data.activitystream_form()}></Webix>
            </div>
            <div className="filterOption_area_count common_btn">
              <Webix ui={data.activitystream_button()}></Webix>
            </div>
          </div>
        </div>
        <div className="dashboard-chart details-tables" id="details-tables">
          <div className="iR-col-12 dashboard-chart-inner chart-height table_shrink">
            <div className="widget-dashboard">
              <div className="widget-dashboard-left" id="dashboard_count">

              </div>
              <div className="widget-dashboard-right">
                <div className="filter_search">
                  <div className="search-box2" id="search_box">
                    <Webix ui={data.activity_details_search()} ></Webix>
                    <i title="Close" className="material-icons" onClick={this.search_box_close.bind()}>close</i>
                  </div>
                  <div className="button_area_filter">
                    {/* <i className="material-icons" title="Search" id="search_box_icon" onClick={this.search_box_open.bind()}>search</i> */}
                    <div className="activity_export" title="Export" id="excel_export" onClick={() => this.export_fun()}></div>
                  </div>
                </div>
              </div>
            </div>
            <div className="clear-fix"></div>
            <div className="dashboard_deatils">
              <Webix ui={data.Activity_Table()}  ></Webix>
            </div>
            <ul className="pagenation" id="pagenation">
              <li className="btn"> <i className="fa fa-angle-double-left" aria-hidden="true"></i></li>
              <li className="btn active"> 1 </li>
              <li className="btn"> 2 </li>
              <li className="btn"> 3 </li>
              <li className="btn"> 4 </li>
              <li className="btn"> 5 </li>
              <li className="btn"><i className="fa fa-angle-double-right" aria-hidden="true"></i></li>
            </ul>
          </div>
          <div className='alt_show_from overlay2' id="upload-popup">
            <div className="iR-dialog dashbord-iopp-popup">
              <div className="expand iopp-popup-header iR-window-header">
                <h2>Upload</h2>
                <i className="material-icons view_cls" title="Close" onClick={this.hideForm.bind(this, "upload-popup")}>clear</i>
              </div>
              <div className="widget">
                <div className="widget_body">
                  <Webix ui={data.uploadtype_form()}></Webix>
                  <div className="activity_uploader">
                    <Webix ui={data.activity_uploader()} ></Webix>
                  </div>
                  <div id="down-list-iopp" className="down-list-supplementry iopp-downlist">
                    <Webix ui={data.display_uploader_file()}>
                    </Webix>
                  </div>
                </div>
                <div className="btn_fun">
                  <div className="common_btn">
                    <Webix ui={data.upload_button()}></Webix>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    )
  }
}
