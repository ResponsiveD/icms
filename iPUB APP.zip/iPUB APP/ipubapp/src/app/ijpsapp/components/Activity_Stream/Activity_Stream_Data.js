import 'webix/webix.js';
import 'webix/webix.css';
import { Loader } from '../../../../components/Core/iCore';
import { Activitystream } from '../../services';
import { LocalStorage, FileService } from '../../../../helpers';
import { CommonHelper } from '../../helpers';
import moment from 'moment';
import { func } from 'prop-types';
var UploadFiles = [];
var extn_type = "";
var booklist = [];
var journallist = [];
var customerlist = [];
var uploadartilceguid = "";
var uploadactivityid = "";
var articlelist = [];
export function Activity_Table() {
	return {
		responsive: "true",
		view: "datatable",
		id: "activity_details",
		rowHeight: 40,
		tooltip: true,
		columns: [
			{
				id: "options",
				name: "action",
				header: "Action",
				css: "icon_styles",
				width: 70,
				tooltip: false
			},
			{
				id: "cust_name",
				name: "customername",
				header: "Customer Name",
				minWidth: 100,
				fillspace: true,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#cust_name#</div>",
			},
			{
				id: "type",
				name: "type",
				header: "Type",
				width: 100,
				sort: "string",
				tooltip: false
			},
			{
				id: "article_name",
				name: "articlename",
				header: "Article Name",
				minWidth: 100,
				fillspace: true,
				sort: "int",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#article_name#</div>",
			},
			{
				id: "aty_name",
				name: "activityname",
				header: "Activity Name",
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#aty_name#</div>",
				minWidth: 100,
				fillspace: true
			},
			{
				id: "status",
				name: "status",
				header: "Status",
				width: 130,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#status#</div>",
				template: function (obj) {
					if (obj.status) {
						if (obj.status == "Overdue") {
							return "<span class='details_uncheck'>" + obj.status + "</span>";
						}
						else {
							return "<span>" + obj.status + "</span>";
						}
					}

				}
			},
			{
				id: "completeddate",
				name: "lastupdatedby",
				header: "Last updated by",
				width: 180,
				sort: "string",
				tooltip: "<div class='tooltip-style'>#completeddate#</div>",
			},
			{
				id: "completedtime",
				name: "lastupdatedtime",
				header: "Last updated time",
				width: 200,
				sort: "string",
				tooltip: false,
			},
			{
				id: "actionicon",
				name: "actionicon",
				header: "Action",
				width: 120,
				tooltip: false,
			}
		],
		data: [],
		onClick: {
			"file_upload": function (ev, id) {
				document.getElementById('upload-popup').classList.remove('hide');
				let uploaddata = window.$$('activity_details').getItem(id);
				uploadactivityid = uploaddata.aty_id;
				uploadartilceguid = uploaddata.article_guid;
			},
			"zip_down": function (ev, id) {
				let downloadzipdata = window.$$('activity_details').getItem(id);
				let journalid = window.$$("journal").getValue();
				let type_value = window.$$('customer_type').getText();
				let activity_id = downloadzipdata.aty_id;
				let article_guid = downloadzipdata.article_guid;
				if (type_value === "Book") {
					for (let index = 0; index < booklist.length; index++) {
						if (journalid === booklist[index].id)
							var custid = booklist[index].cust_id;
					}
				}
				if (type_value === "Journal") {
					for (let index = 0; index < journallist.length; index++) {
						if (journalid === journallist[index].id)
							var custid = journallist[index].cust_id;
					}
				}
				Loader.showLoader();
				Activitystream.downloadFilesFromBlob(custid, type_value, journalid, article_guid, activity_id).then(res => {
					Loader.hideLoader();
					window.location = res;
				}).catch(err => {
					Loader.hideLoader();
					window.webix.message({ text: err, type: "error" })
				});
			}
		},
		on: {
			onAfterLoad: function () {
				if (this.count() == 0) {
					this.showOverlay("No Records Found");
				} else {
					this.hideOverlay();
				}
			}
		},
		autoWidth: true,
		scroll: true,
		height: 790,
	}
};
export function activity_details_search() {
	return {
		view: "form",
		id: "search_fun",
		elements: [{
			view: "search",
			align: "center",
			name: "search",
			placeholder: "Search..",
			id: "search",
			width: 300,
			height: 40,
			css: "search-dash-2",
			on: {
				onTimedKeyPress: function () {
					window.webix.$$("activity_details").clearAll();
					let searchKeyword = this.getValue().toLowerCase();
					let allArticles = window.reviewer_activity_articles;
					let filteredArticles = []
					for (let article of allArticles) {
						let isTextPresent = false;
						for (let key in article) {
							let value = article[key];
							if (value) {
								if (typeof value == "string") {
									if (value.toLowerCase().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								} else {
									if (value.toString().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								}
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("activity_details").parse(filteredArticles);
				}
			}
		}]
	}
}


export function activitystream_form() {
	return {
		view: "form",
		css: "textFilter_form_area activitystream",
		rows: [
			{
				view: "combo", width: 200,
				label: '', name: "type",
				placeholder: "Type", css: "form_area_inner form_area_inner_two",
				id: "customer_type",
				options: [
					{ id: 1, value: "Book" },
					{ id: 2, value: "Journal" }
				],
				on: {
					onChange: function (newv, oldv) {
						let type_value = window.$$('customer_type').getText();
						Loader.showLoader();
						if (type_value === "Book") {
							let comp_id = 3;
							var rlist = [];
							let customerDetails = window.$$("customer_name").getPopup().getList();
							Activitystream.getCustomerName(type_value, comp_id).then(res => {
								for (let index = 0; index < res.length; index++) {
									const element = res[index];
									customerlist.push(res[index]);
									rlist.push({ id: element.id, name: element.name });
								}
								customerDetails.clearAll();
								customerDetails.parse(rlist);
								Loader.hideLoader();
							});
						}
						else {
							let customerDetails = window.$$("customer_name").getPopup().getList();
							Loader.showLoader();
							let comp_id = 2;
							var rlist = [];
							Activitystream.getCustomerName(type_value, comp_id).then(res => {
								for (let index = 0; index < res.length; index++) {
									const element = res[index];
									customerlist.push(res[index]);
									rlist.push({ id: element.id, name: element.name });
								}
								customerDetails.clearAll();
								customerDetails.parse(rlist);
								Loader.hideLoader();
							});
						}
						window.$$('customer_name').show();
						window.$$('article_name').hide();
						window.$$('activity').hide();
						window.$$('status').hide();
						window.$$('from_date').hide();
						window.$$('to_date').hide();
						window.$$('journal').hide();
						window.$$('customer_name').setValue("Customer Name");
						window.$$("activity_details").clearAll();
					},
				},
			},
			{
				view: "combo", width: 200,
				label: '', name: "customername",
				placeholder: "Customer Name", css: "form_area_inner form_area_inner_two",
				id: "customer_name",
				options: {
					body: {
						data: [],
						scheme: {
							$init: obj => {
								obj.value = obj.name,
									obj.id = obj.id
							}
						}
					}
				},
				on: {
					onChange: function (newv, oldv) {
						let customerType = window.$$("customer_type").getValue();
						let customer_Type = window.$$("customer_name").getValue();
						let type_value = window.$$('customer_type').getText();
						if (customerType.length === 0) {
							window.webix.message({ text: "Please select type", type: "error" });
							return false;
						}
						Loader.showLoader();
						if (type_value === "Book") {
							for (let index = 0; index < customerlist.length; index++) {
								if (customer_Type === customerlist[index].id)
									var custid = customerlist[index].cust_id;
							}
							var rlist = [];
							let getBookDetails = window.$$("journal").getPopup().getList();
							Activitystream.getAllBook(custid).then(res => {
								Loader.hideLoader();
								if (res.length === 0) {
									window.webix.message({ text: "No records found!", type: "error" });
									window.$$('journal').hide();
									window.$$('article_name').hide();
									window.$$('status').hide();
									window.$$('from_date').hide();
									window.$$('to_date').hide();
									window.$$('activity').hide();
									return false;
								}
								for (let index = 0; index < res.length; index++) {
									const element = res[index];
									booklist.push(res[index]);
									rlist.push({ id: element.id, name: element.name });
								}
								getBookDetails.clearAll();
								getBookDetails.parse(rlist);
								window.$$('journal').show();
								window.$$('journal').setValue("Journals");
								Loader.hideLoader();
							});
						}
						else {
							let getJournalDetails = window.$$("journal").getPopup().getList();
							for (let index = 0; index < customerlist.length; index++) {
								if (customer_Type === customerlist[index].id)
									var custid = customerlist[index].cust_id;
							}
							Loader.showLoader();
							if (type_value === "Journal") {
								var rlist = [];
								Activitystream.getJournal(custid).then(res => {
									Loader.hideLoader();
									if (res.length === 0) {
										window.webix.message({ text: "No records found!", type: "error" });
										window.$$('journal').hide();
										window.$$('article_name').hide();
										window.$$('status').hide();
										window.$$('from_date').hide();
										window.$$('to_date').hide();
										window.$$('activity').hide();
										return false;
									}
									for (let index = 0; index < res.length; index++) {
										const element = res[index];
										journallist.push(res[index]);
										rlist.push({ id: element.id, name: element.name });
									}
									getJournalDetails.clearAll();
									getJournalDetails.parse(rlist);
									window.$$('journal').show();
									window.$$('journal').setValue("Journals");
									Loader.hideLoader();
								});
							}
						}
					},
				},

			},
			{
				view: "combo", width: 200,
				label: '', name: "journals",
				placeholder: "Journals", css: "form_area_inner form_area_inner_two",
				id: "journal",
				options: {
					body: {
						data: [],
						scheme: {
							$init: obj => {
								obj.value = obj.name,
									obj.id = obj.id
							}
						}
					}
				},
				on: {
					onChange: function (newv, oldv) {
						let type_value = window.$$('customer_type').getText();
						Loader.showLoader();
						let getArticleName = window.$$("article_name").getPopup().getList();
						let journal_value = window.$$('journal').getValue();
						if (type_value === "Book") {
							allArticleName(type_value, getArticleName, journal_value);
							window.$$('activity_search').show();
							window.$$('article_name').hide();
							window.$$('status').hide();
							window.$$('from_date').hide();
							window.$$('to_date').hide();
							window.$$('activity').hide();
							window.$$("activity_details").clearAll();
							// window.$$('article_name').show();
							// window.$$('article_name').setValue("Article Name");
						}
						else {
							if (type_value === "Journal") {
								allArticleName(type_value, getArticleName, journal_value);
								window.$$('activity_search').show();
								window.$$('article_name').hide();
								window.$$('status').hide();
								window.$$('from_date').hide();
								window.$$('to_date').hide();
								window.$$('activity').hide();
								window.$$("activity_details").clearAll();
								// window.$$('article_name').show();
								// window.$$('article_name').setValue("Article Name");
							}
						}


					},
				},
			},
			{
				view: "combo", width: 200,
				label: '', name: "articlename",
				placeholder: "Article Name", css: "form_area_inner form_area_inner_two",
				id: "article_name",
				options: {
					body: {
						data: [],
						scheme: {
							$init: obj => {
								obj.value = obj.name,
									obj.id = obj.id
							}
						}
					}
				},
				on: {
					onChange: function (newv, oldv) {
						let type_value = window.$$('customer_type').getText();
						Loader.showLoader();
						let getActivityName = window.$$("activity").getPopup().getList();
						let journal_value = window.$$('journal').getValue();
						let article_value = window.$$('article_name').getValue();
						let articleText = window.$$('article_name').getText();
						if (type_value === "Book") {
							for (let index = 0; index < booklist.length; index++) {
								if (journal_value === booklist[index].id)
									var custid = booklist[index].cust_id;
							}
							for (let index = 0; index < articlelist.length; index++) {
								if (article_value === articlelist[index].id)
									var article_id = articlelist[index].article_id;
							}
							allActivityName(getActivityName, journal_value, article_id, type_value);
						}
						else {
							if (type_value === "Journal") {
								for (let index = 0; index < journallist.length; index++) {
									if (journal_value === journallist[index].id)
										var custid = journallist[index].cust_id;
								}
								for (let index = 0; index < articlelist.length; index++) {
									if (article_value === articlelist[index].id)
										var article_id = articlelist[index].article_id;
								}
								allActivityName(getActivityName, journal_value, article_id, type_value);
							}
						}
						articleFilter(articleText);
						window.$$('activity').show();
						window.$$('status').show();
						window.$$('from_date').show();
						window.$$('to_date').show();
					},
				},
			},
			{
				view: "combo", width: 200,
				label: '', name: "activity",
				placeholder: "Activity", css: "form_area_inner form_area_inner_two",
				id: "activity",
				options: {
					body: {
						data: [],
						scheme: {
							$init: obj => {
								obj.value = obj.atyname,
									obj.id = obj.id
							}
						}
					}
				},
				on: {
					onChange: function (newv, oldv) {
						let activityText = window.$$('activity').getText();
						let articleText = window.$$('article_name').getText();
						let searchText = window.$$('status').getText();
						let fromDateText = window.$$('from_date').getText();
						let toDateText = window.$$('to_date').getText();
						//activityFilter(articleText, activityText);
						filterAll(articleText, activityText, searchText, fromDateText, toDateText);
					},
				},
			},
			{
				view: "combo", width: 200,
				label: '', name: "status",
				placeholder: "Status", css: "form_area_inner form_area_inner_two",
				id: "status",
				options: [
					{ id: 1, value: "Open" },
					{ id: 2, value: "In Progress" },
					{ id: 3, value: "Completed" },
				],
				on: {
					onChange: function (newv, oldv) {
						let activityText = window.$$('activity').getText();
						let articleText = window.$$('article_name').getText();
						let searchText = window.$$('status').getText();
						let fromDateText = window.$$('from_date').getText();
						let toDateText = window.$$('to_date').getText();
						filterAll(articleText, activityText, searchText, fromDateText, toDateText);
					},
				},
			},
			{
				view: "datepicker", label: "", name: "fromdate", value: "", id: "from_date", placeholder: "From Date", width: 200, css: "form_area_inner form_area_inner_two",
				on: {
					onChange: function (newv, oldv) {
						let activityText = window.$$('activity').getText();
						let articleText = window.$$('article_name').getText();
						let searchText = window.$$('status').getText();
						let fromDateText = window.$$('from_date').getText();
						let toDateText = window.$$('to_date').getText();
						filterAll(articleText, activityText, searchText, fromDateText, toDateText);
					},
				},
			},
			{
				view: "datepicker", label: "", name: "todate", value: "", id: "to_date", placeholder: "To Date", width: 200, css: "form_area_inner form_area_inner_two", on: {
					onChange: function (newv, oldv) {
						let activityText = window.$$('activity').getText();
						let articleText = window.$$('article_name').getText();
						let searchText = window.$$('status').getText();
						let fromDateText = window.$$('from_date').getText();
						let toDateText = window.$$('to_date').getText();
						filterAll(articleText, activityText, searchText, fromDateText, toDateText);
					},
				},
			},

		]
	}
}
export function activitystream_button() {
	return {
		view: 'toolbar',
		width: 100,
		css: "activitystream_button",
		elements: [
			{
				view: 'button',
				label: 'Search',
				type: 'form',
				id: "activity_search",
				click: function (id) {
					let customerName = window.$$("customer_name").getText();
					let journalValue = window.$$("journal").getText();
					let type_value = window.$$('customer_type').getText();
					let customerValue = window.$$("customer_name").getValue();
					let journalid = window.$$("journal").getValue();
					let limit = 100;
					let page = 1;
					if (customerName.length === 0) {
						window.webix.message({ text: "Please select customer name", type: "error" });
						return false;
					}
					if (type_value.length === 0) {
						window.webix.message({ text: "Please select type", type: "error" });
						return false;
					}
					if (journalValue.length === 0) {
						window.webix.message({ text: "Please select journal", type: "error" });
						return false;
					}
					if (type_value === "Book") {
						for (let index = 0; index < booklist.length; index++) {
							if (journalid === booklist[index].id)
								var custid = booklist[index].cust_id;
						}
						for (let index = 0; index < customerlist.length; index++) {
							if (customerValue === customerlist[index].id) {
								var comp_id = customerlist[index].comp_id;
								window.comp_id = comp_id;
							}
						}
					}
					if (type_value === "Journal") {
						for (let index = 0; index < journallist.length; index++) {
							if (journalid === journallist[index].id) {
								var custid = journallist[index].cust_id;
							}
						}
						for (let index = 0; index < customerlist.length; index++) {
							if (customerValue === customerlist[index].id) {
								var comp_id = customerlist[index].comp_id;
								window.comp_id = comp_id;
							}
						}
					
					}
					Loader.showLoader();
					getDashboardDetails(custid, type_value, journalid, comp_id, limit, page);
					document.getElementById('excel_export').classList.remove('hide');
					window.$$('article_name').show();
					document.getElementById("pagenation").classList.remove('hide');
				}, tooltip: 'Search',
			}

		]
	};
}

export function uploadtype_form() {
	return {
		view: "form",
		css: "uploadtype_form",
		rows: [
			{
				view: "combo", width: 200,
				label: 'File Type', name: "filetype", id: "filetype",
				options: [
					{ id: 1, value: "xml" },
					{ id: 2, value: "pdf" },
					{ id: 3, value: "doc" },
					{ id: 4, value: "docx" },
				]
			},
		]
	}
}

export function upload_button() {
	return {
		view: 'toolbar',
		width: 300,
		elements: [
			{
				view: 'button',
				label: 'Cancel',
				autowidth: true,
				click: function (id, event) {
					document.getElementById('upload-popup').classList.add('hide');
					window.$$('filetype').setValue('');
					window.webix.$$("display_uploader_file").clearAll();
				},
				tooltip: 'cancel'
			},
			{
				view: 'button',
				label: 'Submit',
				type: 'form',
				autowidth: true,
				click: function (id, event) {
					document.getElementById('upload-popup').classList.add('hide');
					let journalid = window.$$("journal").getValue();
					let type_value = window.$$('customer_type').getText();
					let fileTypes = window.$$('filetype').getText();
					let files = UploadFiles[0].file;
					if (type_value === "Book") {
						for (let index = 0; index < booklist.length; index++) {
							if (journalid === booklist[index].id)
								var custid = booklist[index].cust_id;
						}
					}
					if (type_value === "Journal") {
						for (let index = 0; index < journallist.length; index++) {
							if (journalid === journallist[index].id)
								var custid = journallist[index].cust_id;
						}
					}
					Loader.showLoader();
					Activitystream.uploadFilestoBlob(custid, type_value, journalid, uploadartilceguid, uploadactivityid, fileTypes, files).then(result => {
						window.$$('filetype').setValue('');
						window.webix.$$("display_uploader_file").clearAll();
						window.webix.$$("file_uploader").enable();
						window.$$('filetype').enable();
						window.webix.message({ text: "File uploaded successfully", type: "success" });
						Loader.hideLoader();
					}).catch(error => {
						window.webix.message({ text: error, type: "error" })
						Loader.hideLoader();
					});
				},
				tooltip: 'Submit'
			}
		]
	};
}
export function activity_uploader() {
	return {
		view: 'form',
		type: 'line',
		id: 'activity_uploader',
		rows: [
			{
				view: 'uploader',
				id: 'file_uploader',
				height: 80,
				align: 'center',
				type: 'iconButton',
				icon: 'upload',
				label: 'Drag and Drop your files here',
				autosend: false,
				accept: '.xml, .pdf, .doc, .docx',
				on: {

					"onBeforeFileAdd": function (file) {
						let fileTypes = window.$$('filetype').getValue();
						if (fileTypes.length === 0) {
							window.webix.message({ text: "Please select file type", type: "error" })
							return false;
						}

						if (file.size && file.size > 52428800) {
							window.webix.message({ text: "Maximum upload file size is 50 MB, above 50 MB file is not acceptable.", type: "error" })
							return false;
						};

						if (file.size != undefined && file.size != null && file.size == 0) {
							window.webix.message({ text: "Empty file cannot be uploaded.", type: "error" })
							return false;
						};

						if (file.name && file.name.indexOf(' ') !== -1) {
							window.webix.message({ text: "File name with space cannot be uploaded.", type: "error" })
							return false;
						};

						let type = window.$$('customer_type').getText();
						extn_type = window.$$('filetype').getText();
						if (extn_type !== file.type) {
							window.webix.message({ text: "File type and upload file should be same", type: "error" });
							return false;
						}
					},
					"onAfterFileAdd": function (file) {
						Loader.showLoader();
						UploadFiles = [];
						let fileIcon = CommonHelper.getFileIcon(file.name);
						UploadFiles.push({
							file_id: 0,
							name: file.name,
							created_on: moment(new Date()).format("DD-MM-YYYY"),
							sizetext: file.sizetext,
							imgsrc: fileIcon,
							file: file,
							is_active: true
						});
						window.webix.$$("display_uploader_file").clearAll();
						window.webix.$$("display_uploader_file").parse(UploadFiles);

						if (window.webix.$$("display_uploader_file").count() == 1) {
							window.webix.$$("file_uploader").disable();
							window.$$('filetype').disable();
						}
						else {
							window.webix.$$("file_uploader").enable();
							window.$$('filetype').enable();
						}
						Loader.hideLoader();

					}
				}
			}
		]
	};
}

export function display_uploader_file() {
	return {
		view: "list",
		autoheight: true,
		css: "download-list uploader_file",
		template: `<div class='iopp2 iR-project-list-item'>#imgsrc#
		<div class='iopp-title iR-litem-detail'>
		<h1 class='iR-title overflow_text' title=#name#>#name#</h1>
		<span>#sizetext#, #created_on#</span>
		<i class='material-icons list-delete iopp' title='delete'>delete_outline</i></div></div>`,
		scroll: true,
		id: "display_uploader_file",
		data: [],
		onClick: {
			"list-delete": function (event, id, node) {
				var list_down = this;
				window.webix.confirm("Are you sure, to delete this?", function (action) {
					if (action === true) {
						let index = -1;
						for (let file of UploadFiles.filter(s => s.is_active)) {
							index += 1;
							if (file.name == window.$$("display_uploader_file").getItem(id).name) {
								file.is_active = false;
								break;
							}
						}
						list_down.remove(id);
						window.webix.$$("file_uploader").enable();
						window.$$('filetype').enable();
						window.$$('filetype').setValue('');
					}
				});
			}
		}
	}
};

export function allArticleName(type_value, getArticleName, journal_value) {
	var rlist = [];
	Activitystream.getArticleName(type_value, journal_value).then(res => {
		Loader.hideLoader();
		if (res.length === 0) {
			window.webix.message({ text: "No records found!", type: "error" });
			window.$$('article_name').hide();
			window.$$('status').hide();
			window.$$('from_date').hide();
			window.$$('to_date').hide();
			return false;
		}
		for (let index = 0; index < res.length; index++) {
			const element = res[index];
			articlelist.push(res[index]);
			rlist.push({ id: element.id, name: element.name });
		}
		getArticleName.clearAll();
		getArticleName.parse(rlist);
		Loader.hideLoader();
	});
}

export function allActivityName(getActivityName, journal_value, article_id, type_value) {
	var rlist = [];
	Activitystream.getActivityName(journal_value, article_id, type_value).then(res => {
		for (let index = 0; index < res.length; index++) {
			const element = res[index];
			rlist.push({ id: element.id, atyname: element.atyname });
		}
		getActivityName.clearAll();
		getActivityName.parse(rlist);
		Loader.hideLoader();
	}).catch(err => {
		Loader.hideLoader();
		window.webix.message({ text: err, type: "error" })
	});
}

export function getDashboardDetails(custid, type_value, journalid, comp_id, limit, page) {
	Activitystream.getDashboardDataStream(custid, type_value, journalid, comp_id, limit, page).then(res => {
		Loader.hideLoader();
		if (res.streams.length === 0) {
			window.webix.message({ text: "No records found!", type: "error" });
			return false;
		}
		window.$$("activity_details").clearAll();
		window.$$("activity_details").parse(res.streams);
		document.getElementById("dashboard_count").innerHTML = 'Queue ' + [res.pagedetails.total_count];
		Loader.hideLoader();
	}).catch(err => {
		Loader.hideLoader();
		window.webix.message({ text: err, type: "error" })
	});
}

function articleFilter(articleText) {
	if (!articleText) return window.$$("activity_details").filter();
	window.$$("activity_details").filter(function (obj) {  // grid is a dataTable instance
		return obj.article_name == articleText;
	})
}

function activityFilter(articleText, activityText) {
	if (!articleText && !activityText) return window.$$("activity_details").filter();
	window.$$("activity_details").filter(function (obj) {  // grid is a dataTable instance
		return obj.aty_name == activityText;
	})
}

function searchFilter(searchText) {
	if (!searchText) return window.$$("activity_details").filter();
	window.$$("activity_details").filter(function (obj) {  // grid is a dataTable instance
		return obj.status == searchText;
	})
}

function lastUpdatedDateFilter(fromDateText) {
	if (!fromDateText) return window.$$("activity_details").filter();
	window.$$("activity_details").filter(function (obj) {  // grid is a dataTable instance
		return obj.completeddate == fromDateText;
	})
}

function lastUpdatedTimeFilter(toDateText) {
	if (!toDateText) return window.$$("activity_details").filter();
	window.$$("activity_details").filter(function (obj) {  // grid is a dataTable instance
		return obj.completeddate == toDateText;
	})
}

function filterAll(articleText = '', activityText = '', searchText = '', fromDateText = '', toDateText = '') {
	if (!articleText || !activityText || !searchText || !fromDateText || !toDateText) return window.$$("activity_details").filter();
	window.$$("activity_details").filter(function (obj) {
		return (obj.article_name == articleText && obj.aty_name == activityText && obj.status == searchText && obj.completeddate == fromDateText && obj.completeddate == toDateText);
	})
}