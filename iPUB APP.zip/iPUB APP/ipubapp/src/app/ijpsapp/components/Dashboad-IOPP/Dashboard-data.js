import "webix/webix.js";
import "webix/webix.css";

export function dashboard_details(authorLink) {
	return {
		responsive: "true",
		view: "datatable",
		id: "dashboard_details",
		//css: "dashboard_height",
		rowHeight: 40,
		tooltip: true,
		columns: [
			{
				id: "options",
				name: "options",
				header: "Options",
				css:"icon_styles",
				width: 125,
				tooltip: false
			},
			{
				id: "submissionId",
				name: "submissionId",
				header: "Submission ID",
				width: 120,
				sort: "int",
				tooltip: false
			},
			{
				id: "article_name",
				name: "article_name",
				header: "Article Name",
				//width: 200,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#article_name#</div>",
				minWidth: 80,
				fillspace: true,
			},
			{
				id: "journal",
				name: "journal",
				header: "Journal",
				//width: 200,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#journal#</div>",
				minWidth: 100,
				fillspace: true,
			},
			{
				id: "role",
				name: "role",
				header: "Role",
				//width: 100,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#role#</div>",
				minWidth: 100,
				fillspace: true,
			},
			{
				id: "user_name",
				name: "user_name",
				header: "Currently With",
				//width: 140,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#user_name#</div>",
				minWidth: 100,
				fillspace: true,
			},
			{
				id: "status",
				name: "status",
				header: "Status",
				//width: 100,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#status#</div>",
				template: function (obj) {
					if (obj.track_status == "Delay") {
						if (status == true)
							return "<span class='details_check'>" + obj.status + "</span>";
						else return "<span class='details_uncheck'>" + obj.status + "</span>";
					} else return obj.status;
				},
				minWidth: 100,
				fillspace: true,
			},
			{
				id: "duedate",
				name: "duedate",
				header: "Due Date",
				width: 125,
				sort: "string",
				tooltip: false
			},
			{
				id: "action",
				header: "Action",
				minWidth: 180,
				sort: "string",
				css: "auto_table",
				tooltip: "<div class='tooltip-style'>#action#</div>",
				fillspace: true
			}
		],
		data: [],
		scheme:{
			$init:function(obj){ 
				obj.index = this.count(); 
			}
		},
		on: {
			onAfterLoad: function () {
				if (this.count() == 0) {
					this.showOverlay("No Records Found");
				} else {
					this.hideOverlay();
				}
			}
		},
		onClick: {
			"authorLink": function (event, id, node) {
				var item = this.getItem(id);
				authorLink(item);
			},
			// "dashboard-icon-xml": function (event, id, node) {
			// 	var item = this.getItem(id);
			// 	if (item.xmlStatusID == 1) {
			// 		event.preventDefault();
			// 		window.webix.message({
			// 			text: "XML conversion process is in queue.",
			// 			type: "error"
			// 		});
			// 	} else if (item.xmlStatusID == 2) {
			// 		event.preventDefault();
			// 		window.webix.message({
			// 			text: "XML conversion is In-progress.",
			// 			type: "error"
			// 		});
			// 	} else if (item.xmlStatusID == 5) {
			// 		event.preventDefault();
			// 		window.webix.message({
			// 			text: 'Error in generationg the XML file. Error Log: ' + item.xmlRemark,
			// 			type: "error"
			// 		});
			// 	} else if (item.xmlStatusID == null) {
			// 		event.preventDefault();
			// 		window.webix.message({
			// 			text: 'Error in generationg the XML file. Error Log: ' + item.xmlRemark,
			// 			type: "error"
			// 		});
			// 	}
			// },
			// "dashboard-icon-pdf": function (event, id, node) {
			// 	var item = this.getItem(id);
			// 	if (item.pdfStatusID == 1) {
			// 		event.preventDefault();
			// 		window.webix.message({
			// 			text: "PDF conversion process is in queue.",
			// 			type: "error"
			// 		});
			// 	} else if (item.pdfStatusID == 2) {
			// 		event.preventDefault();
			// 		window.webix.message({
			// 			text: "PDF conversion is In-progress.",
			// 			type: "error"
			// 		});
			// 	} else if (item.pdfStatusID == 5) {
			// 		event.preventDefault();
			// 		window.webix.message({
			// 			text: 'Error in generationg the PDF file. Error Log: ' + item.pdfRemark,
			// 			type: "error"
			// 		});
			// 	} else if (item.pdfStatusID == null) {
			// 		event.preventDefault();
			// 		window.webix.message({
			// 			text: 'Error in generationg the PDF file. Error Log: ' + item.pdfRemark,
			// 			type: "error"
			// 		});
			// 	}
			// }
		},
		//autoheight: true,
		//autowidth: true,
		//scroll: false
		//   minHeight: 450,
		//autoheight: true,
		autoWidth: true,
		scroll: true,
		minHeight: 500,
	};
}
 
export function dashboard_details_search() {
	return {
		view: "form",
		id: "search_fun",
		elements: [{
			view: "search",
			align: "center",
			name: "search",
			placeholder: "Search..",
			id: "search",
			width: 300,
			height: 40,
			css: "search-dash-2",
			on: {
				onTimedKeyPress: function () {
					window.webix.$$("dashboard_details").clearAll();
					let searchKeyword = this.getValue().toLowerCase();
					let allArticles = window.publisher_dashboard_articles;
					let filteredArticles = []
					for (let article of allArticles) {
						let isTextPresent = false;
						for (let key in article) {
							let value = article[key];
							if (value) {
								if (typeof value == "string") {
									if (value.toLowerCase().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								} else {
									if (value.toString().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								}
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("dashboard_details").parse(filteredArticles);
					// var text = this.getValue().toLowerCase();
					// var table = window.$$("dashboard_details");
					// var columns = table.config.columns;
					// table.filter(function (obj) {
					// 	for (var i = 0; i < columns.length; i++)
					// 		if (obj[columns[i].id].toString().toLowerCase().indexOf(text) !== -1) return true;
					// 	return false;
					// })
				}
			}
		}]
	};
}

export function dashboard_details_main() {
	return {
		view: "list",
		scroll: false,
		select:  true,
		template: "<div class='filter_main_over' title='#title#'>#title# <span><i class='material-icons filter-arrow'>navigate_next</i></span></div>",
		data: [
			{ id:1, title: "Role"},
			{ id:2, title: "Status"},
			{ id:3, title: "Action"},
		],
		on: {
			onItemClick: function (id, ev) {
				if (id == '1') {
					document.getElementById('level1').classList.remove('hide');
					document.getElementById('level2').classList.add('hide');
					document.getElementById('level3').classList.add('hide');
				}
				else if (id == '2') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.remove('hide');
					document.getElementById('level3').classList.add('hide');
				}
				else if (id == '3') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.add('hide');
					document.getElementById('level3').classList.remove('hide');
				}

			}
		}

	}
}
export function dashboard_details_main2() {
	return {
		view: "list",
		scroll: false,
		select:  true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id:1, title: "Author"},
			{ id:2, title: "Publisher"},
			{ id:3, title: "Reviewer"},
			{ id: 4, title: "Production Editor"},
			{ id: 5, title: "Integra Production"}
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.publisher_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.role.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level1').classList.add('hide');	
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}
	}
}
export function dashboard_details_main3() {
	return {
		view: "list",
		scroll: false,
		select:  true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "In Progress" },
			{ id: 2, title: "Reviewer not assigned" },
			{ id: 3, title: "Awaiting response from reviewers" },
			{ id: 4, title: "No response - Invite more reviewers" },
			{ id: 5, title: "On time" },
			{ id: 6, title: "Overdue reviewer reports" },
			{ id: 7, title: "Overdue decision deadline" },
			{ id: 8, title: "Overdue revision deadline" },
			{ id: 9, title: "Overdue pre-publication checks" },
			{ id: 10, title: "Invitation" },
			{ id: 11, title: "In revision" },
			{ id: 12, title: "Completed" }
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.publisher_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.status.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level2').classList.add('hide');	
				document.getElementById('level0').classList.add('hide');
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}

	}
}
export function dashboard_details_main4() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id:1, title: "Submit"},
			{ id:2, title: "Invite reviewer"},
			{ id:3, title: "Wait"},
			{ id:4, title: "Invite more reviewers"},
			{ id:5, title: "Send reminder OR Invite more reviewers"},
			{ id:6, title: "Urgent! Make decision"},
			{ id:7, title: "Flag as urgent"},
			{ id:8, title: "Send reminder"},
			{ id:9, title: "Send to reviewer"},
			{ id:10, title: "Create final files"},
			{ id:11, title: "Accept or Decline"},
			{ id:12, title: "Provide your recommendation"},
			{ id:13, title: "Submit your Manuscript in iAuthor"},
			{ id:14, title: "Submit your revised manuscript"},
			{ id:15, title: "Wait for 7 days"},
			{ id:16, title: "Urgent"}
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.publisher_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					// for (let key in article) {
						// let value = article[key];
						let value = article.action.toLowerCase();
						// if (value) {
							if (value && typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									// break;
								}
							} 
							// else {
							// 	if (value.toString().indexOf(searchKeyword) != -1) {
							// 		isTextPresent = true;
							// 		break;
							// 	}
							// }
						// }
					// }
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level3').classList.add('hide');
				document.getElementById('level0').classList.add('hide');	
				document.getElementById('clear_filter_button').classList.remove('hide');
			}
		}

	}
}
/*25-12-2018*/