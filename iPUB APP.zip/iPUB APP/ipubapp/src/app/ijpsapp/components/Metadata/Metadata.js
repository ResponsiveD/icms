import React from 'react';
import Webix from '../../../../Webix';
import * as Data from './Metadata-data';

import { MetadataService } from '../../services';
import { Loader } from '../../../../components/Core/iCore';
import Alert from '../Alert/Alert';

export default class Metadata extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedJournal: { ...this.props.selectedJournal },
      metadata: {},
      articleKeyWords: [],
      articleKeywordGroups: [],
      isAlertShow: false,
      alertType: null,
      alertMessage: {
        header: "",
        content: ""
      },
    };
    this.load_metadata = this.load_metadata.bind(this);
    this.onMetadataStepSave = this.onMetadataStepSave.bind(this);
    this.onKeyWordAdd = this.onKeyWordAdd.bind(this);
    this.onKeyWordEdit = this.onKeyWordEdit.bind(this);
    this.onKeyWordDelete = this.onKeyWordDelete.bind(this);
    this.getMetadataFormValues = this.getMetadataFormValues.bind(this);
  };

  componentDidMount() {

    let { articleDetails } = this.props;
    if (articleDetails.article_id != 0) {
      this.getInitialData(articleDetails);
    }

    document.querySelector('.keywords_input').addEventListener("click", function (e) {
      document.querySelector('.keywords_input input').focus();
    });
    document.getElementById('key-popup').classList.add('hide');
  };

  componentWillReceiveProps(nextProps) {
    if (nextProps.articleDetails.article_id != this.props.articleDetails.article_id) {
      this.getInitialData(nextProps.articleDetails);
    }
  };

  getInitialData = (articleDetails) => {
    let base = this;
    // Loader.showLoader();
    this.setState({ isAlertShow: true, alertType: "success", alertMessage: { header: "Loading Metadata", content: "Please wait..." } });
    let getMetadataRes = MetadataService.getMetadataDetails(articleDetails.article_id);
    let getArticleKeywordsRes = MetadataService.getArticleKeywords(articleDetails.article_id);
    Promise.all([getMetadataRes, getArticleKeywordsRes]).then(function (allRes) {
      //Validating input for empty values
      let tagReplacedMetadata = allRes[0][0];
      tagReplacedMetadata.article_title = tagReplacedMetadata.article_title.replace("<article-title>", "").replace("</article-title>", "").replace("<br>", "");
      tagReplacedMetadata.abstract = tagReplacedMetadata.abstract.replace("<para>", "").replace("</para>", "").replace("<br>", "");

      base.setState({
        metadata: tagReplacedMetadata,
        articleKeywordGroups: allRes[1].key_word_groups,
        articleKeyWords: allRes[1].key_word_groups ? allRes[1].key_word_groups[0].key_words : []
      });
      //Loader.hideLoader();
      base.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
    }).catch(function (error) {
      window.webix.message({ text: error, type: "error" });
      //Loader.hideLoader();
      base.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
    });
  };

  onKeyWordAdd(key_word) {
    let { articleKeyWords, metadata } = this.state;
    metadata = this.getMetadataFormValues()
    articleKeyWords.push({ id: articleKeyWords.length + 1, key_word_id: 0, key_word, is_active: 1 });
    this.setState({ articleKeyWords, metadata });
    setTimeout(function () { window.$$("keyword_add_form_id").setValue(""); }, 100);
  };

  onKeyWordEdit(key_word_Obj) {
    let { articleKeyWords, metadata } = this.state;
    for (let keyWords of articleKeyWords) {
      if (key_word_Obj.id == keyWords.id) {
        keyWords.key_word = key_word_Obj.key_word.trim();
      }
    }

    metadata = this.getMetadataFormValues();
    this.setState({ articleKeyWords, metadata });

    document.getElementById('key-popup').classList.add('hide');
    window.webix.$$("Metadata_Keyword_edit_id").clear();
  };

  onKeyWordDelete(key_word_Obj) {
    let { articleKeyWords, metadata } = this.state;
    for (let keyWords of articleKeyWords) {
      if (key_word_Obj.id == keyWords.id) {
        keyWords.is_active = 0;
      }
    }

    metadata = this.getMetadataFormValues()
    this.setState({ articleKeyWords, metadata });
  };

  getMetadataFormValues() {
    let { metadata } = this.state;
    let webixMetadata = window.$$("metadataFormId").getValues();
    let title = webixMetadata.article_title.replace("<article-title>", "").replace("</article-title>", "");
    let abstract = webixMetadata.abstract.replace("<para>", "").replace("</para>", "");
    title = title ? "<article-title>" + title + "</article-title>" : "";
    abstract = abstract ? "<para>" + abstract + "</para>" : "";

    metadata.journal_id = webixMetadata.journal_id;
    metadata.article_title = title;
    metadata.abstract = abstract;
    return metadata;
  }

  load_metadata() {
    let { metadata } = this.state;
    return metadata
  }

  onMetadataStepSave(metadata) {
    //return new Promise((resolve, reject) => {
    let { articleDetails } = this.props;
    let { articleKeyWords, articleKeywordGroups } = this.state;
    for (let keyword of articleKeyWords) {
      keyword.key_word = `<kwd>${keyword.key_word}</kwd>`
    }
    let keyWord = {
      key_word_groups: [
        {
          key_word_group_id: articleKeywordGroups ? articleKeywordGroups[0].key_word_group_id : 0,
          key_word_group_name: articleKeywordGroups ? articleKeywordGroups[0].key_word_group_name : "key_word",
          is_active: 1,
          key_words: articleKeyWords
        }
      ],
      article_guid: articleDetails.article_guid,
      org_id: 2
    }

    this.setState({ isAlertShow: true, alertType: "success", alertMessage: { header: "Saving Metadata", content: "Please wait..." } });
    MetadataService.addEditArticleKeyword(keyWord).then(articleKeyWords => {
      this.props.onMetadataStepSave(metadata);
      //this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
    }).catch(error => {
      this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
      window.webix.message({ text: error, type: "error" });
    });
    //});
  };

  hideForm(_this, formID) {
    document.getElementById(_this).classList.add('hide');
  };

  componentWillUpdate() {
    window.webix.$$("Metadata_Keyword_list_id").clearAll();
  };

  render() {
    let { metadata, isAlertShow, alertType, alertMessage } = this.state;
    let { articleKeyWords } = this.state;
    return (
      <div className="Right-Panel Metadata">

        {/* header */}
        <div className="secondary-header">
          <div className="head-left">
            <span className="se-panel-title">Metadata</span>
            <div className="btn_fun">
              <div id="service_btn" className="common_btn icon_buttons">
                <Webix ui={Data.save_button(this.onMetadataStepSave, this.load_metadata)} ></Webix>
              </div>
            </div>
            {/* <Webix ui={Data.save_button(props.onMetadataStepSave)} ></Webix> */}
            <i title="Close" className="material-icons close-btn-top">close</i>
          </div>
        </div>

        <div className="data-scroll file-upload-progress">
          {
            isAlertShow ? <Alert alertType={alertType} header={alertMessage.header} content={alertMessage.content} navigateToSteps={this.props.navigateToSteps} /> : null
          }

          {/* body */}
          <div className="widget">
            <div className="widget_header metadata-tag">
              Meta Info.
             </div>
            <div className="widget_body">
              <Webix ui={Data.Metadata(this.props.journals)} data={metadata}></Webix>
            </div>
            <div className="widget_body keywords">
              <div className="keywords_lable metakey">
                Keywords
                </div>
              <div className="keywords_input">
                <Webix ui={Data.Metadata_Keyword_list(this.onKeyWordDelete)} data={articleKeyWords}></Webix>
                <Webix ui={Data.Metadata_Keyword(this.onKeyWordAdd)}></Webix>
              </div>
            </div>
          </div>

          {/* <div className="widget display-fun">
            <div className="widget_header metadata-tag">
               Funding Info.
             </div>
             <div className="widget_body">
                <Webix ui={Data.Metadata_datatable()}></Webix>
                <Webix ui={Data.Metadata_datatable_button()}></Webix>
              </div>
         </div> */}

          <div className='alt_show_from overlay' id="key-popup">
            <div className="iR-dialog dashbord-key-popup">
              <div className="expand iopp-popup-header iR-window-header txt-transform">
                <h2>Keywords</h2>
                <i className="material-icons view_cls iopp-cls" title="Close" onClick={this.hideForm.bind(this, "key-popup")}>clear</i>
              </div>
              <div className="widget">
                <div className="widget_body">
                  <Webix ui={Data.Metadata_Keyword_edit()}  ></Webix>
                </div>
                <div className="btn_fun">
                  <div id="service_btn" className="common_btn change_btn key-btn">
                    <Webix ui={Data.job_info_IOPP(this.onKeyWordEdit)} ></Webix>
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div>
      </div>
    )
  }
};
