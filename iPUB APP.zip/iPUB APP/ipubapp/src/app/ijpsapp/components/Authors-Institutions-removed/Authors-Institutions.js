import React, { Component } from 'react';
import Webix from '../../../../Webix';
import * as Data from './Authors-Institutions-Data';
import './author.css';
import addmaterila from '../../../../assets/images/icons/add-material.png';

import { AuthorService } from '../../services';
import { Loader } from '../../../../components/Core/iCore';
import Alert from '../Alert/Alert';

function hideForm() {
  document.getElementById('iopp_alt_sh').classList.add('hide');
  window.$$("generalInfoFormId").clear();
  window.$$("generalInfoFormId").clearValidation();
  window.$$("institutuionInfoFormId").clear();
  window.$$("institutuionInfoFormId").clearValidation();
};

function showForm(e) {
  document.getElementById('iopp_alt_sh').classList.remove('hide');
  // var currentElement = document.getElementById("iopp_alt_sh")
  // var Point = e.target.getBoundingClientRect();
  // var PointY, PointX;
  // if (window.innerHeight > Point.top + 500) {
  //   PointY = Point.top - 80;
  //   PointX = Point.left - 550;
  // } else {
  //   PointY = Point.top - 500;
  //   PointX = Point.left - 512;
  // }

  // currentElement.style.left = PointX + 'px';
  // currentElement.style.top = PointY + 'px';
  // currentElement.style.position = 'fixed';
  window.$$("Save").define("label", "Add");
  window.$$("Save").refresh();
};

export default class AuthorsInstitutions extends Component {
  constructor(props) {
    super(props);
    this.state = {
      salutations: [],
      noCoAuthors: false,
      coAuthors: [],
      isAlertShow: false,
      alertType: null,
      alertMessage: {
        header: "",
        content: ""
      },
    };
    this.onCoAuthorCheckBoxChange = this.onCoAuthorCheckBoxChange.bind(this);
    this.onAddEditCoAuthor = this.onAddEditCoAuthor.bind(this);
    this.onAuthorsInstitutionsStepSave = this.onAuthorsInstitutionsStepSave.bind(this);
    this.onAuthorsInstitutionsDelete = this.onAuthorsInstitutionsDelete.bind(this);
  };

  componentDidMount() {
    document.getElementById('iopp_alt_sh').classList.add('hide');
    let { articleDetails } = this.props;
    //Loader.showLoader();
    this.setState({ isAlertShow: true, alertType: "success", alertMessage: { header: "Loading Author & Institution", content: "Please wait..." } });
    AuthorService.getArticleCoauthorDetail(articleDetails.article_id).then(response => {
      this.setState({ coAuthors: response, noCoAuthors: response.length > 0 ? response[0].no_co_author : false });
      //Loader.hideLoader();
      this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
    }).catch(error => {
      // Loader.hideLoader();
      this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
      window.webix.message({ text: error, type: "error" });
    });
  };

  componentWillUpdate() {
    window.webix.$$("authorList") ? window.webix.$$("authorList").clearAll() : '';
  };

  componentDidUpdate(prevProps, prevState) {
    document.getElementById('iopp_alt_sh').classList.add('hide');
  };

  onCoAuthorCheckBoxChange(noCoAuthors) {
    this.setState({ noCoAuthors: !noCoAuthors });
  }

  onAddEditCoAuthor(coAuthorDetails) {
    let { coAuthors } = this.state;
    let { articleDetails } = this.props;
    coAuthorDetails.user_id = articleDetails.user_id;
    coAuthorDetails.org_id = articleDetails.org_id;
    coAuthorDetails.author_id = coAuthorDetails.author_id == "" ? 0 : coAuthorDetails.author_id;
    coAuthorDetails.article_author_id = coAuthorDetails.article_author_id == "" ? 0 : coAuthorDetails.article_author_id;
    // coAuthorDetails.author_id = articleDetails.author_id;
    Loader.showLoader();
    return new Promise((resolve, reject) => {
      AuthorService.addEditCoauthor(coAuthorDetails).then(response => {
        let isCoAUthorExist = false;
        for (let author of coAuthors) {
          if (coAuthorDetails.author_id == author.author_id) {
            author.orc_id = response.orc_id,
              author.sal_id = response.sal_id,
              author.first_name = response.first_name,
              author.middle_name = response.middle_name,
              author.last_name = response.last_name,
              author.email = response.email,
              author.institution_name = response.institution_name,
              author.department = response.department,
              author.role = response.role,
              author.address_1 = response.address_1,
              author.address_2 = response.address_2,
              author.city = response.city,
              author.state = response.state,
              author.country = response.country,
              author.contact_no = response.contact_no,
              author.name = author.first_name + ' ' + author.middle_name + ' ' + author.last_name + ' ' + '<p>((ORCID : ' + author.orc_id + ')</p>'
              author.dept_Inst_name = author.institution_name + ', ' + author.department;
              isCoAUthorExist = true;
            break;
          }
        }
        if (!isCoAUthorExist) {
          coAuthors.push(response);
        }
        this.setState({ coAuthors });
        Loader.hideLoader();
        resolve(response);
      }).catch(error => {
        Loader.hideLoader();
        reject(error);
      });
    });
  };


  onAuthorsInstitutionsStepSave() {
    let { coAuthors, noCoAuthors } = this.state;
    let { articleDetails } = this.props;

    let authors = [];
    for (const author of coAuthors) {
      authors.push({
        "article_author_id": author.article_author_id ? author.article_author_id : 0,
        "co_author_id": author.author_id,
        "is_active": author.is_active == true ? 1 : 0
      });
    }
    if (!noCoAuthors && authors.length === 0) {
      window.webix.message({ text: "Please add Co-author details or enable No Co-author and Save to proceed.", type: "error" });
      return false;
    }
    let articleAuthorInstituton = {
      "no_co_author": noCoAuthors,
      "article_id": articleDetails.article_id,
      "authors": authors
    }
    this.setState({ isAlertShow: true, alertType: "success", alertMessage: { header: "Saving Author & Institution", content: "Please wait..." } });
    //return new Promise((resolve, reject) => {
    this.props.onAuthorsInstitutionsStepSave(articleAuthorInstituton).then(response => {
      //this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
      // resolve(response);
    }).catch(error => {
      this.setState({ isAlertShow: false, alertType: null, alertMessage: { header: "", content: "" } });
      window.webix.message({ text: error, type: "error" });
      //reject(error);
    });
    //});

  };

  onAuthorsInstitutionsDelete(selectedCoAuthor) {
    let { coAuthors, noCoAuthors } = this.state;
    return new Promise((resolve, reject) => {
      for (let author of coAuthors) {
        if (author.author_id === selectedCoAuthor.author_id) {
          author.is_active = false;
        }
      }
      this.setState({ coAuthors });
    });
  };


  render() {

    let { noCoAuthors, coAuthors, isAlertShow, alertType, alertMessage } = this.state;
    return (
      <div className="Right-Panel Metadata">

        {/* header */}
        <div className="secondary-header">
          <div className="head-left">
            <span className="se-panel-title">Authors & Institutions</span>
            <div className="btn_fun">
              <div id="service_btn" className="common_btn icon_buttons">
                <Webix ui={Data.save_button(this.onAuthorsInstitutionsStepSave)} ></Webix>
              </div>
            </div>
            {/* <Webix ui={Data.save_button(props.onAuthorsInstitutionsStepSave)} ></Webix> */}
            <i title="Close" className="material-icons close-btn-top">close</i>
          </div>
        </div>

        <div className="data-scroll file-upload-progress">
          {
            isAlertShow ? <Alert alertType={alertType} header={alertMessage.header} content={alertMessage.content} navigateToSteps={this.props.navigateToSteps} /> : null
          }

          <div className="widget">

            <div className="widget_header metadata-tag2 author-table">
              My Co-Authors  <span className="switch-btn"><Webix ui={Data.CoAuthorCheckBox(this.onCoAuthorCheckBoxChange)} data={{ "noCoAuthors": noCoAuthors }}></Webix></span>
            </div>

            {/* co-author list */}
            {
              !noCoAuthors ?
                <div className="widget_body author-table-details" id="author-table-details">
                  <Webix ui={Data.Author_Table(this.onAuthorsInstitutionsDelete)} data={coAuthors} ></Webix>
                </div>
                : ''
            }

            {/* co-author add/edit form */}
            <div className="al-btn" id="author-add-btn">
              {
                !noCoAuthors ?
                  <button type="button" id="add_sel_approv" onClick={(e) => showForm(e)} className="alt-btn app_btn" title="Add Co-Author"><img src={addmaterila} alt="add to" /></button>
                  : ''
              }
              <div className='iR-col-6 alt-frm zoomIn animated alt_show_from iopp-popup author_popup' id="iopp_alt_sh">
                <div className="expand iopp-popup-header"> Add Co-Author <i title="Close" className="material-icons pop-up-close" onClick={() => hideForm()}>close</i></div>
                <div className="data-scroll">

                  {/* co-author general information */}
                  <div className="widget">
                    <div className="iopp widget_header profile-head" style={{ "marginTop": "0px" }}>
                      General info.
                        </div>
                    <div className="widget_body">
                      <Webix ui={Data.Genral_info(this.props.salutations)} ></Webix>
                    </div>
                  </div>
                  {/* co-author institutuion information */}
                  <div className="widget">
                    <div className="iopp widget_header profile-head">
                      Institution info.
                        </div>
                    <div className="widget_body">
                      <Webix ui={Data.institutuion_info(this.props.countries)} ></Webix>
                    </div>
                  </div>
                </div>

                {/* co-author cancel add button */}
                <div className="btn_fun">
                  <div id="service_btn" className="common_btn">
                    <Webix ui={Data.cancel_add_button(this.onAddEditCoAuthor)} ></Webix>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
};

