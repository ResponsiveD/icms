import 'webix/webix.js';
import 'webix/webix.css';

// journal search
export function journal_search() {
	return {
		view: "toolbar",
		id: "search_journal",
		cols: [
			{
				view: "search", align: "center", name: "search_journal_id", placeholder: "Search..", id: "search_journal_id", width: 300, height: 56,
				on: {
					onTimedKeyPress: function () {
						var value = this.getValue().toLowerCase();
						window.$$("journal-list").filter(function (obj) { //here it filters data!
							return obj.value.toLowerCase().indexOf(value) != -1;
						})
					}
				}
			}
		]
	}
};

// list of journal
export function journal_list(onJournalSelect) {
	return {
		view: "list",
		scroll: false,
		select: 1,
		id: "journal-list",
		css: "style-list iopp",
		template: function (obj, common, value, config, rowIndex) {
			return `<div class='iR-project-list-item'><div class='iR-litem-icon'></div><div class='iR-litem-detail'>
					<h1 class='iR-title' title='${obj.value}'>${obj.value}</h1>
					<span class="list-status">${obj.no_of_article} Manuscripts</span> <i class="material-icons add-iopp" title="Add">add</i>
					<i title="Show" class='material-icons iR-rt-arrow'>chevron_right</i> </div></div>`
		},
		onClick: {
			"add-iopp": function (ev, id) {
				onJournalSelect(window.webix.$$("journal-list").getItem(id), true);
				window.$$("journal-list").select(id);
				return false;
			},
			"iR-project-list-item": function (ev, id) {
				onJournalSelect(window.webix.$$("journal-list").getItem(id), false);
				window.$$("journal-list").select(id);
			},
		}
	};
};
