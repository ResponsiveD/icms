import React, { Component } from 'react';
import Webix from '../../../../Webix';
import * as Data from './Journal-Data';
import { connect } from 'react-redux';
import { submitManuscriptActions } from '../../../../redux/actions';
import JournalOptions from '../../components/Journal-Options/Journal-Options';
import './journal.css';
import { Loader } from '../../../../components/Core/iCore';
import { MetadataService, CommonService } from '../../services';
import { ProjectService } from '../../../irightsapp/services/project.sevices';

//scroll bar
import PerfectScrollbar from 'perfect-scrollbar';
import 'react-perfect-scrollbar/dist/css/styles.css';
import { func } from 'prop-types';

class Journal extends Component {
  constructor(props) {
    super(props);
    this.state = {
      selectedJournal: null,
      journals: [],
      salutations: [],
      countries: [],
      openAllPanelToSubmitManuscript: false,
      menuItem: {
        journal: true,
        options: true,
        manuscript: true,
        selectedManuscript: true,
        fileUpload: true,
        submitted : true,
        submittedOption : true
      }
    }
    this.onJournalSelect = this.onJournalSelect.bind(this);
    this.updateStateFromChild = this.updateStateFromChild.bind(this);
    this.updateMenuJournal = this.updateMenuJournal.bind(this);
  };

  //used to handel click event of journal list item click
  onJournalSelect(selectedJournal, openAllPanelToSubmitManuscript) {
    // let menuItem = {...this.state.menuItem};
    // menuItem.options = true;
    this.props.MenuShownAction({
      journal: true,
      options: true,
      manuscript: true,
      selectedManuscript: true,
      fileUpload: true,
      submitted : true,
      submittedOption : true
    });
    this.setState({ selectedJournal, openAllPanelToSubmitManuscript });

  };

  //update the journal component state by triggering this event from child component
  updateStateFromChild(props) {
    this.setState({ ...props });
  };

  componentDidMount() {
    //get journal types, salutations and countries. pass to child components to reuse
    Loader.showLoader();


    let getJournalsRes = MetadataService.getJournalType();
    let getSalutationsRes = CommonService.getSalutations();
    let getCountriesRes = ProjectService.getCustomerLocation();
    let base = this;
    Promise.all([getJournalsRes, getSalutationsRes, getCountriesRes]).then(function (allRes) {
      base.setState({
        journals: allRes[0],
        salutations: allRes[1],
        countries: allRes[2]
      });
      Loader.hideLoader();
    }).catch(function (error) {
      window.webix.message({ text: error, type: "error" });
      Loader.hideLoader();
    });

    var container = document.querySelector('.scroll_bar_hover');
    const ps = new PerfectScrollbar(container);
  };

  componentWillMount() {
    this.props.MenuShownAction(this.state.menuItem);
  }

  closeNextPanels = () => {
    this.setState({ selectedJournal: null });
    window.$$("journal-list").unselectAll();
  };

  updateMenuJournal = () => {
    let menuItem = {...this.state.menuItem};
    menuItem.options = false;
    menuItem.manuscript = false;
    menuItem.selectedManuscript = false;
    menuItem.fileUpload = false;
    this.setState({menuItem});
  }

  search_box_open = () => {
    document.getElementById('PL_spec_Header').classList.add('search-open');
    document.getElementById('iopp-top-icons').classList.add('hide');
    window.$$("search_journal").focus('search_journal_id');
  };

  search_box_close = () => {
    document.getElementById('PL_spec_Header').classList.remove('search-open');
    document.getElementById('iopp-top-icons').classList.remove('hide');
    //clear search
    window.$$("search_journal_id").setValue("");
    //set journal again
    window.$$("journal-list").filter(function (obj) {
      return obj.value.toLowerCase().indexOf("") != -1;
    })

    let { selectedJournal } = this.state;
    if (selectedJournal) {
      //select previously selected item
      window.$$("journal-list").select(selectedJournal.id);
    }

  };

  render() {

    let { journals, salutations, countries, selectedJournal, openAllPanelToSubmitManuscript } = this.state;
    return (
      <div className="IOPP scroll_bar_hover">

        {/* left pannel start*/}
        <div className="iopp seconday_sidebar single-border-RT">

          {/* search */}
          <div id="PL_spec_Header" className="secondary-header">
            <span className="se-panel-title">Journals</span>
            <div className="search-box search-open">
              <Webix ui={Data.journal_search()} ></Webix>
              <i title="Close" className="material-icons" onClick={() => this.search_box_close()}>close</i>
            </div>
            <span title="Search" className="se-panel-icon iopp-top-icons" id="iopp-top-icons">
              <i className="material-icons iR-book-search iopp-search" onClick={() => this.search_box_open()}>search</i>
              {/* {
                selectedJournal ? <i title="Close" className="material-icons close-btn-top iopp-editor-close iopp-top-icons-close" onClick={() => this.closeNextPanels()}>close</i> : null
              }  */}
            </span>
          </div>

          {/* submit manuscript steps */}
          <div className="secondary-body iopp-icon iR-listing-data window-scroll-div-list">
            <Webix ui={Data.journal_list(this.onJournalSelect)} data={journals}></Webix>
          </div>
        </div>
        {
          this.props.MenuShown.options ? selectedJournal ? <JournalOptions selectedJournal={selectedJournal} openAllPanelToSubmitManuscript={openAllPanelToSubmitManuscript} updateStateFromChild={this.updateStateFromChild} journals={journals} salutations={salutations} countries={countries} updateMenuJournal={this.updateMenuJournal} /> : null : null
        }
      </div>
    )
  }
};

const mapStateToProps = (state) => {
  const MenuShown = state.MenuShown
  return {
    MenuShown
  }
};



const mapDispatchToProps = (dispatch) => {
  return {
    MenuShownAction: (menuItem) => dispatch(submitManuscriptActions.MenuShownAction(menuItem))
  }
};

export default connect(mapStateToProps, mapDispatchToProps)(Journal);