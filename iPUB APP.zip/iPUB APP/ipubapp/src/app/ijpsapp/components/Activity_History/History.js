import React from 'react';
import Webix from '../../../../Webix';
import * as data from './History_Data';
import './history_style.css';
export default class ActivityStream extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
    };
  }

  componentDidMount() {

  }

  render() {
    return (
      <div className="activityhistory_page">
        <div className="activity_header">
          <h2>iPubSuite - File History</h2>
        </div>
        <div className="widget_filter ">
          <div className="filterOption_area">
            <div className="filterOption_area_option">
              <Webix ui={data.history_form()}></Webix>
            </div>
          </div>
        </div>
        <div className="dashboard-chart details-tables">
          <div className="iR-col-12 dashboard-chart-inner chart-height table_shrink">
            <div className="dashboard_deatils">
              <div className="table_filters">
                <div className="table_filters_inner">
                  <Webix ui={data.table_filter_top()}></Webix>
                  <div id="pagerB_here"></div>
                </div>
              </div>
              <div>
                <Webix ui={data.History_Table()}  ></Webix>
              </div>
              <div className="table_filters_bottom_outer">
                <div className="table_filters_bottom">
                  <Webix ui={data.table_filter_bottom()}></Webix>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    )
  }
}
