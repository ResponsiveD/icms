import "webix/webix.js";
import "webix/webix.css";

export function dashboard_details(download_option) {
	return {
		view: "datatable",
		rowHeight: 44,
		minHeight: 40,
		fixedRowHeight: false,
		id: "PaperQueueTable",
		css: "PaperQueueTable dashboard_height",
		tooltip: true,
		columns: [
			{ id: "iA_ArticleName", name: "iA_ArticleName", header: "Paper Name", minWidth: 180, sort: "string", fillspace: true, tooltip: false },
			{ id: "ArticleName", name: "ArticleName", header: "Paper Name", width: 240, sort: "string", hidden: true },
			{
				id: "JournalName", name: "JournalName", header: "Proceeding", width: 250, sort: "string", css: "auto_table",
            tooltip: "<div class='tooltip-style'>#JournalName#</div>",
			},
			{
				id: "IssueName", name: "IssueName", header: "Year", width: 100, sort: "string", css: "auto_table",
				tooltip: false,
			},
			{
				id: "stage", name: "stage", header: "Stage", width: 240, sort: "string", css: "auto_table",
				tooltip: false,
			},
			{ id: "CastOff", name: "CastOff", header: "Cast Off", width: 80, sort: "int", tooltip: false },
			{ id: "iCoreStatus", name: "iCoreStatus", header: "Status", width: 130, sort: "string", tooltip: false },
			{
				id: "iError", name: "iError", header: "Error", width: 170, sort: "string", css: "auto_table", hidden: true,
				tooltip: false,
			},
			{ id: "actions", name: "actions", css: "actions_row", header: "Download", width: 210, sort: "string", tooltip: false },
			{ id: "options", name: "options", header: "Options", width: 120, sort: "string", hidden: true, tooltip: false }

		],
		data: [],
		onClick: {
			// "upload": function (event, id, node) {
			// 	let item = window.$$('PaperQueueTable').getItem(id);
			// 	onUploadFileClick(item, true);
			// },
			"download_option": function (event, id, node) {
				let item = window.$$('PaperQueueTable').getItem(id)
				let clicked_item = event.srcElement.attributes.data.value;
				download_option(clicked_item, item);
			},

		},
		on: {
			onBeforeLoad: function () {
				this.showOverlay("Loading...");
			},
			onAfterLoad: function () {
				this.hideOverlay();
				if (!this.count()) {
					this.showOverlay("No Records Found");
				} else {
					this.hideOverlay();
				}
			}
		},
		ready: function () {
			if (!this.count()) {
				window.webix.extend(this, window.webix.OverlayBox);
				this.showOverlay("No Records Found");
			}
		},
		autoWidth: true,
		scroll: true,
		//minHeight: 500,
		autoHeight:true
	};
}
 
export function dashboard_details_search() {
	return {
		view: "form",
		id: "search_fun",
		elements: [{
			view: "search",
			align: "center",
			name: "search",
			placeholder: "Search..",
			id: "search",
			width: 300,
			height: 40,
			css: "search-dash-2",
			on: {
				onTimedKeyPress: function () {
					window.webix.$$("PaperQueueTable").clearAll();
					let searchKeyword = this.getValue().toLowerCase();
					let allArticles = window.publisher_dashboard_articles;
					let filteredArticles = []
					for (let article of allArticles) {
						let isTextPresent = false;
						for (let key in article) {
							let value = article[key];
							if (value) {
								if (typeof value == "string") {
									if (value.toLowerCase().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								} else {
									if (value.toString().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								}
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("PaperQueueTable").parse(filteredArticles);
					// var text = this.getValue().toLowerCase();
					// var table = window.$$("dashboard_details");
					// var columns = table.config.columns;
					// table.filter(function (obj) {
					// 	for (var i = 0; i < columns.length; i++)
					// 		if (obj[columns[i].id].toString().toLowerCase().indexOf(text) !== -1) return true;
					// 	return false;
					// })
				}
			}
		}]
	};
}

export function dashboard_details_main() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main_over' title='#title#'>#title# <span><i class='material-icons filter-arrow'>navigate_next</i></span></div>",
		data: [{
				id: 1,
				title: "Proceeding"
			},
			{
				id: 2,
				title: "Year"
			},
		],
		on: {
			onItemClick: function (id, ev) {
				if (id == '1') {
					document.getElementById('level1').classList.remove('hide');
					document.getElementById('level2').classList.add('hide');
				} else if (id == '2') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.remove('hide');
				}
			}
		}
	}
}
export function dashboard_details_main2() {
	return {
		view: "list",
		scroll: false,
		select:  true,
		id: "filter_proceeding",
		css:"list_height",
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			// { id:1, title: "Author"},
			// { id:2, title: "Publisher"},
			// { id:3, title: "Reviewer"},
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("PaperQueueTable").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.publisher_dashboard_articles;
				let filteredArticles = []
				if (searchKeyword == "all") {
					window.webix.$$("PaperQueueTable").parse(allArticles);
				} else {
					for (let article of allArticles) {
						let isTextPresent = false;
						let value = article.JournalName.toLowerCase();
						if (value && typeof value == "string") {
							if (value == searchKeyword) {
								isTextPresent = true;
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("PaperQueueTable").parse(filteredArticles);
				}
				// window.webix.$$("PaperQueueTable").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level1').classList.add('hide');	
				document.getElementById('level0').classList.add('hide');
			}
		}

	}
}
export function dashboard_details_main3() {
	return {
		view: "list",
		scroll: false,
		select:  true,
		id: "filter_issue",
		css:"list_height",
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			// { id:1, title: "In Progress"},
			// { id:2, title: "Reviewer not assigned"},
			// { id:3, title: "Awaiting response from reviewers"},
			// { id:4, title: "No response - Invite more reviewers"},
			// { id:5, title: "On time"},
			// { id:6, title: "Overdue reviewer reports"},
			// { id:7, title: "Overdue decision deadline"},
			// { id:8, title: "Overdue revision deadline"},
			// { id:9, title: "Overdue pre-publication checks"},
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("PaperQueueTable").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.publisher_dashboard_articles;
				let filteredArticles = []
				if (searchKeyword == "all") {
					window.webix.$$("PaperQueueTable").parse(allArticles);
				} else {
					for (let article of allArticles) {
						let isTextPresent = false;
						let value = article.IssueName.toLowerCase();
						if (value && typeof value == "string") {
							if (value == searchKeyword) {
								isTextPresent = true;
							}
						}
						if (isTextPresent) {
							filteredArticles.push(article);
						}
					}
					window.webix.$$("PaperQueueTable").parse(filteredArticles);
				}
				// window.webix.$$("PaperQueueTable").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level2').classList.add('hide');	
				document.getElementById('level0').classList.add('hide');
			}
		}

	}
}
export function dashboard_details_main4() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id:1, title: "Submission pending"},
			{ id:2, title: "Manuscript submitted"},
			{ id:3, title: "Out to reviewers"},
			{ id:4, title: "Awaiting reviewer report"},
			{ id:5, title: "Awaiting decision"},
			{ id:6, title: "In revision"},
			{ id:7, title: "Revision: manuscript submitted"},
			{ id:8, title: "Revision: Awaiting reviewer report"},
			{ id:9, title: "Revision: Awaiting decision"},
			//{ id:10, title: "Final checks"},
			{ id:11, title: "Send for publication"}
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.publisher_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					for (let key in article) {
						let value = article[key];
						if (value) {
							if (typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									break;
								}
							} else {
								if (value.toString().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									break;
								}
							}
						}
					}
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level3').classList.add('hide');
				document.getElementById('level0').classList.add('hide');	
			}
		}

	}
}
/*25-12-2018*/