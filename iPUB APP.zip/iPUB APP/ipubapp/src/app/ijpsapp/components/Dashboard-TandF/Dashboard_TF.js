import React from "react";
import Highcharts from "highcharts";
import Webix from "../../../../Webix";
import * as data from "./Dashboard_TF_data";
import { Loader } from "../../../../components/";
import { PaperService } from '../../services';
let publisher_dashboard_articles=[];

//scroll bar
import PerfectScrollbar from 'perfect-scrollbar';
import 'react-perfect-scrollbar/dist/css/styles.css';
export default class Dashboard extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      // journalLists: [],
      selected_status: null,
      dataLength: 0,
    };
    this.getPublisherDashboard = this.getPublisherDashboard.bind(this);
    // this.getJournalList = this.getJournalList.bind(this);
    this.download_option = this.download_option.bind(this);
  }

  download_option(clicked_item, selectedPaperQueue) {
    this.setState({ selectedPaperQueue });
    let canCheckAPI = false;
    if (clicked_item == "xml") {
        switch (selectedPaperQueue.XMLStatusID) {
            case 0:
                window.webix.message({ text: "XML not generated.", type: "error" });
                break;
            case 1:
                window.webix.message({ text: "XML in queue for generation.", type: "error" });
                break;
            case 2:
                window.webix.message({ text: "XML generation is inprogress.", type: "error" });
                break;
            case 4:
                canCheckAPI = true;
                break;
        }
    } else if (clicked_item == "pdf") {
        switch (selectedPaperQueue.PDFStatusID) {
            case 0:
                window.webix.message({ text: "PDF not generated.", type: "error" });
                break;
            case 1:
                window.webix.message({ text: "PDF in queue for generation.", type: "error" });
                break;
            case 2:
                window.webix.message({ text: "PDF generation is inprogress.", type: "error" });
                break;
            case 4:
                canCheckAPI = true;
                break;
        }
    }
    else {
        canCheckAPI = true;
    }

    if (canCheckAPI) {
        let result = {};
        result.doc_type = clicked_item;
        result.cust_id = 6;
        result.article_guid = selectedPaperQueue.ArticleGUID;
        result.aty_id = selectedPaperQueue.AtyID;
        Loader.showLoader();
        PaperService.downloadLink(result).then((response) => {
            Loader.hideLoader();
            window.location = response;
        }).catch(error => {
            Loader.hideLoader();
            window.webix.message({ text: error, type: "error" });
        });
    }
}

  search_box_open() {
    //document.getElementById('search_box').classList.add('search-open');
    document.getElementById('search_box').classList.add('active');
    document.getElementById('search_box_icon').classList.add('hide');
    window.$$("search_fun").focus('search');
  }

  search_box_close() {
    //document.getElementById('search_box').classList.remove('search-open');
    document.getElementById('search_box').classList.remove('active');
    document.getElementById('search_box_icon').classList.remove('hide');
  }

  filter_option() {
    document.getElementById('level0').classList.toggle('hide');
    document.getElementById('level1').classList.add('hide');
    document.getElementById('level2').classList.add('hide');
    // document.getElementById('level3').classList.add('hide');
  }

  // authorLink(selected_item) {
  //   let data = {};
  //   data.article_guid = selected_item.ArticleGUID;
  //   data.aty_id = selected_item.aty_id;
  //   data.user_name = LocalStorage.getLocOrSesData('username');
  //   data.email_id = LocalStorage.getLocOrSesData('emailid');
  //   Loader.hideLoader();
  //   PublisherDashboardService.getAuthorLink(data).then(response => {
  //     Loader.hideLoader();
  //     window.location = response;
  //   }).catch(error => {
  //     window.webix.message({
  //       text: error,
  //       type: "error"
  //     });
  //   });
  // }

  componentDidMount() {
    this.getPublisherDashboard();
    // this.getJournalList();

    document.getElementById('level0').classList.add('hide');
    document.getElementById('level1').classList.add('hide');
    document.getElementById('level2').classList.add('hide');
    document.addEventListener("click", function (e) {
      if (e.target.closest('#search_box')) {
      }
      else if (e.target.closest('#search_box_icon')) {

      }
      else {
        if(document.getElementById('search_box')!= null){
          document.getElementById('search_box').classList.remove('active');
          document.getElementById('search_box_icon').classList.remove('hide');
        }
      }
    });
    var container = document.querySelector('.scroll_bar_hover');
    const ps = new PerfectScrollbar(container);
  }

  // getJournalList() {
  //   Loader.showLoader();
  //   MetadataService.getJournalType()
  //     .then(result => {
  //       Loader.hideLoader();
  //       this.setState({ journalLists: result });
  //     })
  //     .catch(error => {
  //       console.log(error);
  //     });
  // }

  getPublisherDashboard() {
    Loader.showLoader();
    Highcharts.setOptions({
      colors: ["#F36B61", "#8BCB30"]
    });

    PaperService.getDashboardNL()
      .then(result => {
        Loader.hideLoader();
        let categoriesData = [],
          load_proceeding = [],
          load_issue = [],
          filter_proceeding = [],
          filter_issue = [],
          onTrackCount = [],
          delayCount = [],
          onLoadTrackCount = [];
        result.count.forEach(element => {
          categoriesData.push(element.AtyName);
          onTrackCount.push(element.Count);
          delayCount.push(0);
        });
        result.values.filter(value => {
          if(value.JournalName && value.IssueName){
            filter_proceeding.push(value.JournalName);
            filter_issue.push(value.IssueName);
          }
          
          if (value.AtyName == "Consistency Check Engine") {
            onLoadTrackCount.push(value);            
            this.setState({ selected_status: "Consistency Check Engine" });
            this.setState({ dataLength: onLoadTrackCount.length });
            window.publisher_dashboard_articles = onLoadTrackCount;
            window.$$("PaperQueueTable").parse(onLoadTrackCount);
          }
        });
        let temp_proceeding = [...new Set(filter_proceeding)];
        for (let i = 0; i < temp_proceeding.length; i++) {
          load_proceeding.push({
            id: i + 1,
            title: temp_proceeding[i]
          });
        }
        let temp_issue = [...new Set(filter_issue)];
        for (let i = 0; i < temp_issue.length; i++) {
          load_issue.push({
            id: i + 1,
            title: temp_issue[i]
          });
        }
        load_proceeding.unshift({
          id: 0,
          title: "All"
        });
        load_issue.unshift({
          id: 0,
          title: "All"
        });
        window.$$("filter_proceeding").clearAll();
        window.$$("filter_proceeding").parse(load_proceeding);
        window.$$("filter_issue").clearAll();
        window.$$("filter_issue").parse(load_issue);
        // Chart Start
        Highcharts.chart("ioppdashboard", {
          chart: {
            type: "bar",
            height: 300,
           // width: 1400
          },
          title: {
            text: "Queues data & actions",
            align: "left",
            fontSize: "14px",
            fontWeight: "bold",
            fontFamily: "Raleway"
          },
          xAxis: {
            categories: categoriesData,
            crosshair: true
          },
          tooltip:false,
          yAxis: {
            allowDecimals:false,
            gridLineDashStyle: "longdash",
            min: 0,
            title: {
              text: ""
            },
            stackLabels: {
              enabled: true,
              style: {
                fontWeight: 'bold',
                color: (Highcharts.theme && Highcharts.theme.textColor) || 'gray'
              }
            }
          },
          legend: {
            reversed: true,
            align: "right"
          },
          plotOptions: {
            series: {
              stacking: "normal",
              size: "24",
              cursor: "pointer"
            }
          },
          series: [
            {
              name: "Delay",
              pointWidth: 10,
              showInLegend: false,
              data: delayCount,
              cursor: "pointer",
              point: {
                events: {
                  click: (e) => {
                    let selected_status = e.point.category;
                    this.setState({ selected_status });
                    let showdata = result.values.filter(
                      obj => {
                        if (obj.track_status == "Delay") {
                          if (obj.activity == selected_status)
                            return true;
                        }
                      }
                    );
                    if (showdata.length != 0) {
                      this.setState({ dataLength: showdata.length });
                      window.$$("PaperQueueTable").clearAll();
                      window.publisher_dashboard_articles = showdata;
                      window.$$("PaperQueueTable").parse(showdata);
                    } else {
                      window.webix.message({
                        text: "No data is available to display.",
                        type: "error"
                      });
                    }
                  }
                }
              }
            },
            {
              name: "Count",
              pointWidth: 10,
              showInLegend: false,
              data: onTrackCount,
              cursor: "pointer",
              point: {
                events: {
                  click: (e) => {
                    let selected_status = e.point.category;
                    this.setState({ selected_status });
                    let showdata = result.values.filter(
                      obj => {
                        // if (obj.track_status == "OnTrack") {
                          if (obj.AtyName == selected_status)
                            return true;
                        // }
                      }
                    );
                    if (showdata.length != 0) {
                      this.setState({ dataLength: showdata.length });
                      window.$$("PaperQueueTable").clearAll();
                      window.publisher_dashboard_articles = showdata;
                      window.$$("PaperQueueTable").parse(showdata);
                    } else {
                      window.webix.message({
                        text: "No data is available to display.",
                        type: "error"
                      });
                    }
                  }
                }
              }
            }
          ]
        });
        // Chart End
      })
      .catch(err => {
        Loader.hideLoader();
        if (!err.message.includes("Highcharts error")) {
          window.webix.message({
            text: err,
            type: "error"
          });
        }
      });
    document.addEventListener("click", function (event) {
      if (event.target.closest('#filter_icon')) {
        document.getElementById('filter_overall').classList.remove('hide');
      }
      else if (!event.target.classList.contains('filter_main_over')) {
        if(document.getElementById('filter_overall')!= null){
          document.getElementById('filter_overall').classList.add('hide');
        }
      }
    });
  }

  render() {
    let { selected_status, dataLength } = this.state;
    return (
      <div className="iopp-dashbord-page scroll_bar_hover">
        <div className="dashboard-chart">
          <div className="iR-col-12 dashboard-chart-inner chart-area table_shrink">
            <div className="iopp chart_select">
              {/* <select>
                {journalLists.map(list => (
                  <option key={list.id} value={list.value}>
                    {list.value}
                  </option>
                ))}
              </select> */}
            </div>
            <div id="ioppdashboard" />
          </div>
        </div>

        <div className="dashboard-chart details-tables">
          <div className="iR-col-12 dashboard-chart-inner chart-height table_shrink">
            <div className="widget-dashboard">
              <div className="widget-dashboard-left">
                Queue - {selected_status} [{dataLength}]
              </div>
              <div className="widget-dashboard-right">
                <div className="filter_search">
                  {/* <div className="search-box2" id="search_box">
                    <Webix ui={data.dashboard_details_search()} />
                    <i title="Close" className="material-icons" onClick={this.search_box_close.bind()}> close</i>
                  </div>
                  <i className="material-icons" title="Search" id="search_box_icon" onClick={this.search_box_open.bind()}>search </i> */}
                  <i className="material-icons" title="filter" id="filter_icon" onClick={this.filter_option.bind()}>filter_list</i>
                </div>
                <div id="filter_overall">
                  <div className="filter_option" id="level0"><Webix ui={data.dashboard_details_main()} ></Webix></div>
                  <div className="filter_option level1" id="level1"><Webix ui={data.dashboard_details_main2()} ></Webix></div>
                  <div className="filter_option level2" id="level2"><Webix ui={data.dashboard_details_main3()} ></Webix></div>
                </div>
              </div>
            </div>
            <div className="iopp dashboard_deatils">
              <Webix ui={data.dashboard_details(this.download_option)} />
            </div>
          </div>
        </div>
      </div>
    );
  }
}
