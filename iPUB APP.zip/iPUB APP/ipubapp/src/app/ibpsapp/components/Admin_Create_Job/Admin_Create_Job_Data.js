
import { BookService } from '../../services/book.service';
import { Loader } from '../../../../components/Core/iCore';

export function create_job_form(setbookid, setWf) {
	return {
		view: "form", id: "_CreateJob",
		elements: [
			// { view: "text", label: "User Name", labelWidth: 200, name: "user_name", validateEvent: "blur", attributes: { maxlength: 150 }, validate: window.webix.rules.isNotEmpty, onblur: "this.value=removeSpaces(this.value);", },
			// { view: "text", label: "Email", labelWidth: 200, name: "user_email", validateEvent: "blur", attributes: { maxlength: 150 }, validate: window.webix.rules.isNotEmpty,validate: window.webix.rules.isEmail, onblur: "this.value=removeSpaces(this.value);", },
			{
				view: "combo", id: "customerList"
				, label: "Customer"
				, labelWidth: 200
				, validateEvent: "blur", validate: window.webix.rules.isNotEmpty
				, options: []
				, value: 0
				, on: {
					onChange: function (newv, oldv) {
						//set customer code
						if (newv) {
							Loader.showLoader();
							BookService.get_book(newv).then(res => {
								let customerList = window.$$("book_name").getPopup().getList();
								let OptionList = [];
								if (res.length > 0) {
									res.forEach(element => {
										OptionList.push({
											id: element.book_id,
											value: element.book_name
										});
									});
								}
								customerList.clearAll();
								customerList.parse(OptionList);
								Loader.hideLoader();
							});

							Loader.showLoader();
							BookService.getWorkFlow(newv).then(res => {
								let customerList = window.$$("workflow").getPopup().getList();
								let OptionList = [];
								if (res.length > 0) {
									res.forEach(element => {
										OptionList.push({
											id: element.wfd_id,
											value: element.wfd_name,
											serId: element.ser_id
										});
									});
								}
								customerList.clearAll();
								customerList.parse(OptionList);
								Loader.hideLoader();
							});
						}
					}
				}
			},
			{
				view: "combo", label: "Type", labelWidth: 200
				, options: [
					{ id: 1, value: "Book" },
					{ id: 2, value: "Journal" },
				]
				, id: 'article_type'
				, validateEvent: "blur", required: true, validate: window.webix.rules.isNotEmpty
				, value: "1",
				on: {
					onChange: function (newV, oldV) {
						if (newV == '1') {
							document.querySelector('[view_id="book_name"]').style.display = "block";
							document.querySelector('[view_id="journal_name"]').style.display = "none";
						} else {
							document.querySelector('[view_id="book_name"]').style.display = "none";
							document.querySelector('[view_id="journal_name"]').style.display = "block";
						}
					}
				}
			},
			{
				view: "combo", label: "Book Name <span class='add_book' title='Add Book Name'><i class='material-icons'>add</i>Add</span>", id: "book_name", labelWidth: 200, editable: true
				, options: []
				, value: 0
				, validateEvent: "blur", validate: window.webix.rules.isNotEmpty
				, on: {
					onChange: function (newv, oldv) {
						if (newv) {
							setbookid(newv);
						}
					}
				},
				click: function (event, node) {
					if (node.target.className == 'add_book') {
						document.querySelector('[view_id="add_book_name"]').classList.remove('hide')
					}
				}
			},
			{ view: "text", label: "Add Book Name", id: "add_book_name", labelWidth: 200, name: "user_name", },
			{
				view: "combo", label: "Journal Type", id: "journal_name", labelWidth: 200,
				options: [
					{ id: 1, value: "XML" },
					{ id: 2, value: "Word" },
					{ id: 3, value: "JATS XML" },
					{ id: 4, value: "BITS XML" },
				]
				, validateEvent: "blur", validate: window.webix.rules.isNotEmpty
			},
			{
				view: "combo", id: "file_type", label: "File Type", labelWidth: 200
				, options: []
				, value: 0
				, validateEvent: "blur", validate: window.webix.rules.isNotEmpty
			},
			{
				view: "combo", id: "workflow", label: "Work Flow", labelWidth: 200, options: []
				, validateEvent: "blur", validate: window.webix.rules.isNotEmpty
				, value: 0
				, on: {
					onChange: function (newv, oldv) {
						//set customer code
						if (newv) {
							Loader.showLoader();
							BookService.getWorkFlowAty({ "wfd_id": newv }).then(res => {
								if (res.length > 0) {
									let OptionList = [];

									res.forEach(element => {
										OptionList.push({
											id: element.aty_id,
											twfd_id:element.twfd_id,
											title: element.aty_name,
											title_two: ''
										});
									});

									window.$$("activity_list").clearAll();
									window.$$('activity_list').parse(OptionList);
									let fuleObject = window.$$("workflow").getList().serialize();
									let serId = fuleObject.find(x => x.id == newv).serId;
									setWf(newv, serId);
								}
								Loader.hideLoader();
							});
						}
					}
				}
			}
		],
		// rules: {
		// 	"user_name": removeSpaces,
		// 	"user_email": removeSpaces
		// },
		elementsConfig: {
			on: {
				onBlur() { this.validate() }
			}
		}
	}
}

function removeSpaces(string) {
	return (string.toString().trim());
}

export function create_job_table() {
	return {
		responsive: "true",
		view: "datatable",
		id: "job_table",
		rowHeight: 40,
		css: "admin_datatables",
		tooltip: true,
		scroll: true,
		columns: [
			{ id: "UserName", name: "User Name", minWidth: 200, fillspace: true, css: "auto_table", tooltip: "<div class='tooltip-style'>#UserName#</div>", header: ["User Name", { content: "textFilter" }] },
			{ id: "Email", name: "", width: 250, css: "auto_table", tooltip: "<div class='tooltip-style'>#UserName#</div>", header: ["Email", { content: "textFilter" }] },
			{ id: "BookType", name: "", width: 200, tooltip: false, header: ["Book Type", { content: "selectFilter" }] },
			{ id: "Customer", name: "", width: 200, tooltip: false, header: ["Customer", { content: "selectFilter" }] },
			{ id: "Workflow", name: "", width: 200, tooltip: false, header: ["Work Flow", { content: "selectFilter" }] },
		],
		data: [
			{ UserName: "Test", Email: "test@gmail.com", BookType: "Book", Customer: "TandF", Workflow: "WF1" },
			{ UserName: "Test", Email: "test@gmail.com", BookType: "Journal", Customer: "IOPP", Workflow: "WF2" },
		],
		autoheight: true
	}
}

export function Create_job_Button(Create_job, clearcontrolls) {
	return {
		view: "toolbar",
		width: 420,
		elements: [
			{
				view: "button", label: "Cancel", id: "cancel", css: "alt-btn2", autowidth: true, click: function () {
					clearcontrolls();
					document.getElementById('create_job').classList.add('hide');
				}, tooltip: "Cancel"
			},
			{
				view: "button", label: "Submit", id: "save", css: "alt-btn2", type: "form", autowidth: true, click: function () {

					if (window.$$('customerList').getValue() == '') {
						window.webix.message({ text: 'Please select customer', type: "error" });
						return false
					}
					if (window.$$('article_type').getValue() == '') {
						window.webix.message({ text: 'Please select article type', type: "error" });
						return false
					}
					if (window.$$('file_type').getValue() == '') {
						window.webix.message({ text: 'Please select upload type', type: "error" });
						return false
					}
					if (window.$$('workflow').getValue() == '') {
						window.webix.message({ text: 'Please select workflow', type: "error" });
						return false
					}

					if (window.$$('Upload_form_list').count() <= 0) {
						window.webix.message({ text: 'Please upload chapter', type: "error" });
						return false
					}

					if (window.$$("_CreateJob").validate() || window.$$("activity_list").validate()) {
						Create_job().then(res => {
							clearcontrolls();
							document.getElementById('create_job').classList.add('hide');
						}).catch(error => {
							window.webix.message({ text: error, type: "error" });
						});

					} else {
						window.webix.message({ text: "Please validate form", type: "error" });
						return false;
					}
				}, tooltip: "Submit"
			},
		]
	}
}

export function Upload_form_queue_one(onUploadChapter, validateMainFile) {
	return {
		view: "form",
		type: "line",
		css: "create_job_upload",
		id: "Upload_form_queue_one_form",
		rows: [
			{
				view: "uploader", id: "Upload_form_queue", css: "iopp uploads", align: "center", type: "iconButton", label: "Drag & Drop or Click to Browse", autosend: false, accept: ".xml", multiple: true,
				on: {
					"onBeforeFileAdd": function (file) {

						let savedFiles = validateMainFile(file.name);
						if (savedFiles > 0) {
							window.webix.message({ text: "Duplicate file with name " + file.name, type: "error" })
							return false;
						}

						if (file.size && file.size > 52428800) {
							window.webix.message({ text: "Maximum upload file size is 50 MB, above 50 MB file is not acceptable.", type: "error" })
							return false;
						};

						if (file.size != undefined && file.size != null && file.size == 0) {
							window.webix.message({ text: "Empty file cannot be uploaded.", type: "error" })
							return false;
						};

						if (file.name && file.name.indexOf(' ') !== -1) {
							window.webix.message({ text: "File name with space cannot be uploaded.", type: "error" })
							return false;
						};

						let fileExtensions = file.name.slice((file.name.lastIndexOf(".") - 1 >>> 0) + 2).toLowerCase();
						let isValidFileExtension = false;
						if (fileExtensions === "xml") {
							isValidFileExtension = true;
						}

						if (!isValidFileExtension) {
							window.webix.message({ text: "Please upload only document file with the extension(.docx)", type: "error" });
							return false;
						}

						if (window.$$('customerList').getValue() == '') {
							window.webix.message({ text: "Please select customer", type: "error" });
							return false;
						}
					},
					"onAfterFileAdd": function (file) {

						onUploadChapter(file).then(uploadedFileileResponse => {

						}).catch(error => {
							window.webix.message({ text: error, type: "error" });
						});
					}
				}
			},
		]
	};
};

export function Upload_form_one_file_list(onChapterFileSelect, onChapterFileDelete) {
	return {
		view: "list",
		autoheight: true,
		select: true,
		css: "download-list tandf createjob_list",
		id: "Upload_form_list",
		template: `<div class='iopp2 iR-project-list-item'> 
		<span class="drag" title="Drag & Drop"><i class="material-icons drag-inner">more_vert</i> 
		<i class="material-icons drag-inner">more_vert</i></span>
		#imgsrc#
		<div class='iopp-title iR-litem-detail'>
		<h1 class='iR-title overflow_text' title=#title#>#title#</h1>
		<span>#size#, #docdate#</span>
		<i class='material-icons list-delete iopp' title='delete'>delete_outline</i></div></div>`,
		drag: true,
		data: [],
		scroll: true,
		on: {
			onBeforeDrag: function (data, e) {
				return (e.target || e.srcElement).className == "material-icons drag-inner";
			},
			onSelectChange: function () {
				onChapterFileSelect(window.$$("Upload_form_list").getSelectedItem()).then(() => { })
					.catch(error => {
						window.webix.message({ text: error, type: "error" });
					});
			},
		},
		onClick: {
			"list-delete": function (event, id, node) {
				var list_down = this;
				window.webix.confirm("Are you sure, to delete this?", function (action) {
					if (action === true) {
						onChapterFileDelete(window.$$("Upload_form_list").getItem(id)).then(res => {
							res ? list_down.remove(id) : null;
						})

					}
				});
				return true;
			}
		}
	}
};

export function Upload_form_queue_two(onSupplementryFileUpload) {
	return {
		view: "form",
		type: "line",
		css: "create_job_upload",
		id: "Upload_form_queue_two",
		rows: [
			{
				view: "uploader", id: "Upload_form_queue_two", css: "iopp supplementry", align: "center", type: "iconButton", label: "Drag & Drop or Click to Browse", autosend: false,  accept: "image/png, image/jpg, image/jpeg,.pdf,.doc,.docx,.xlsx,.xls,.xlsb,.ppt,.pptx,.msg, .xml", multiple: true,

				on: {
					"onBeforeFileAdd": function (file) {
					},
					"onAfterRender": function (file) {

						let element = document.querySelector('.supplementry');

						element.addEventListener("dragover", function (event) {
							console.log(1);
							document.getElementById('sup_upload_list').classList.add('active');
							event.preventDefault();
						}, false);

						element.addEventListener("dragleave", function (event) {
							document.getElementById('sup_upload_list').classList.remove('active')
						}, false);
						element.addEventListener("drop", function (event) {
							document.getElementById('sup_upload_list').classList.remove('active');
						}, false);


					},
					"onAfterFileAdd": function (file) {
						onSupplementryFileUpload(file).then(uploadedFileileResponse => {

						}).catch(error => {
							window.webix.message({ text: error, type: "error" });
						});
					}
				}
			},
		]
	};
};

export function Upload_form_two_file_list(onSupplementryFileDelete) {
	return {
		view: "list",
		autoheight: true,
		css: "download-list tandf createjob_list",
		id: "Upload_suple_form_list",
		template: `<div class='iopp2 iR-project-list-item'>#imgsrc#
					<div class='iopp-title iR-litem-detail'>
					<h1 class='iR-title overflow_text' title=#title#>#title#</h1>
					<span>#size#, #docdate#</span>
					<i class='material-icons list-delete iopp' title='delete'>delete_outline</i></div></div>`,
		data: [],
		scroll: true,
		on: {
			onBeforeDrag: function (data, e) {
				return (e.target || e.srcElement).className == "material-icons drag-inner";
			}
		},
		onClick: {
			"list-delete": function (event, id, node) {
				var list_down = this;
				window.webix.confirm("Are you sure, to delete this?", function (action) {
					if (action === true) {
						onSupplementryFileDelete(window.$$("Upload_suple_form_list").getItem(id)).then(res => {
							res ? list_down.remove(id) : null;
						});
					}
				});
				return true;
			}
		}
	}
};

export function Activity_list() {
	return {
		view: "editlist",
		autoheight: true,
		css: "download-list tandf createjob_list activity_list",
		id: "activity_list",
		editable: true,
		editor: "text",
		editValue: "title_two",
		template: "<div class='filter_main filter_row' #title='#title'><div class='filter_label'>#title#</div><div class='filter_value'>#title_two#</div></div>",
		data: [],
		scroll: true,
		rules: {
			title_two: function (obj) {
				return (obj == "" ? true : (obj != "" && window.webix.rules.isEmail(obj)))
				//return obj>0;
			}
			//title_two: window.webix.rules.isEmail
		}
	}
};