import 'webix/webix.js';
import 'webix/webix.css';

export function dashboard_details(onOpenEmialPopup, openInfoPopup, onSendToSubmit) {
	return {
		responsive: "true",
		view: "datatable",
		id: "dashboard_details_sw",
		css: "admin_datatables sw_dashboard",
		rowHeight: 40,
		tooltip: true,
		columns: [
			{
				id: "action",
				name: "action",
				header: "Action",
				//header: ["Action", { content: "textFilter" }],
				minWidth: 400,
				tooltip: false,
				//sort: "string",
				fillspace: true,
				css: "action_button_table"
			},
			{
				id: "JobGUID",
				name: "JobGUID",
				header: ["Submission Id", { content: "textFilter" }],
				width: 225,
				sort: "int",
				tooltip: false
			},
			{
				id: "BookName",
				name: "BookName",
				header: ["Book", { content: "selectFilter" }],
				width: 250,
				sort: "string",
				tooltip: false,
			},
			{
				id: "AtyName",
				name: "AtyName",
				header: ["Stage", { content: "selectFilter" }],
				minWidth: 200,
				sort: "string",
				tooltip: false,
				fillspace: true,
			},
			{
				id: "Status",
				name: "Status",
				header: ["Status", { content: "selectFilter" }],
				width: 200,
				sort: "string",
				tooltip: false,
				hidden: true
			},
			{
				id: "Role",
				name: "Role",
				header: ["Currently with", { content: "selectFilter" }],
				width: 200,
				sort: "string",
				tooltip: false,
			},

		],

		data: [],

		scheme: {
			$init: function (obj) {
				obj.index = this.count();
			}
		},
		on: {
			onAfterLoad: function () {
				if (this.count() == 0) {
					this.showOverlay("No Records Found");
				} else {
					this.hideOverlay();
				}
			}
		},
		onClick: {
			"author": function (e, node) {
				onOpenEmialPopup("Author", window.$$('dashboard_details_sw').getItem(node));
			},
			"editor": function (e, node) {
				onOpenEmialPopup("Copyeditor", window.$$('dashboard_details_sw').getItem(node));
			},
			"integra": function (e, node) {
				//onOpenEmialPopup("Integra", window.$$('dashboard_details_sw').getItem(node));
				onSendToSubmit('', window.$$('dashboard_details_sw').getItem(node)).then(() => {

				});
			},
			"error-area": function (e, node) {
				openInfoPopup(window.$$('dashboard_details_sw').getItem(node));
			}
		},
		autoWidth: true,
		scroll: true,
		minHeight: 500,
	}
}

export function dashboard_details_search() {
	return {
		view: "form",
		id: "dashboard_details_search",
		elements: [{
			view: "search",
			align: "center",
			name: "search",
			placeholder: "Search..",
			id: "search",
			width: 300,
			height: 40,
			css: "search-dash-2",
			on: {
				onTimedKeyPress: function () {
					window.webix.$$("dashboard_details_sw").clearAll();
					let searchKeyword = this.getValue().toLowerCase();
					let allArticles = window.author_dashboard_articles;
					let filteredArticles = []
					for (let article of allArticles) {
						let isTextPresent = false;
						for (let key in article) {
							let value = article[key];
							if (value) {
								if (typeof value == "string") {
									if (value.toLowerCase().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								} else {
									if (value.toString().indexOf(searchKeyword) != -1) {
										isTextPresent = true;
										break;
									}
								}
							}
						}

					}
					window.webix.$$("dashboard_details_sw").parse(filteredArticles);
				}
			}
		}]
	}
}

export function dashboard_details_main() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main_over' title='#title#'>#title# <span><i class='material-icons filter-arrow'>navigate_next</i></span></div>",
		data: [
			{ id: 1, title: "Book" },
			{ id: 2, title: "Stage" },
			{ id: 3, title: "Status" },
		],
		on: {
			onItemClick: function (id, ev) {
				if (id == '1') {
					document.getElementById('level1').classList.remove('hide');
					document.getElementById('level2').classList.add('hide');
					document.getElementById('level3').classList.add('hide');
				}
				else if (id == '2') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.remove('hide');
					document.getElementById('level3').classList.add('hide');
				}
				else if (id == '3') {
					document.getElementById('level1').classList.add('hide');
					document.getElementById('level2').classList.add('hide');
					document.getElementById('level3').classList.remove('hide');
				}

			}
		}
	}
}
export function dashboard_details_main2() {
	return {
		view: "list",
		id: "dashboard_details_main2",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "S & W" },
			{ id: 2, title: "S & W" },
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details_sw").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.author_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					for (let key in article) {
						let value = article[key];
						if (value) {

							if (typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									break;
								}
							} else {
								if (value.toString().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									break;
								}
							}
						}
					}
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details_sw").parse(filteredArticles);
				document.getElementById('level1').classList.add('hide');
				document.getElementById('level0').classList.add('hide');
			}
		}

	}
}
export function dashboard_details_main3() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "Send to Copyeditor" },
			{ id: 2, title: "Copyediting" },
			{ id: 3, title: "Send to Author" },
			{ id: 4, title: "Author review" },
			{ id: 5, title: "Awaiting decision" },

		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details_sw").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.author_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					for (let key in article) {
						let value = article[key];
						if (value) {

							if (typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									break;
								}
							} else {
								if (value.toString().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									break;
								}
							}
						}
					}

				}
				window.webix.$$("dashboard_details_sw").parse(filteredArticles);
				document.getElementById('level2').classList.add('hide');
				document.getElementById('level0').classList.add('hide');
			}
		}

	}
}
export function dashboard_details_main4() {
	return {
		view: "list",
		scroll: false,
		select: true,
		template: "<div class='filter_main' title='#title#'>#title#</div>",
		data: [
			{ id: 1, title: "Overdue" },
			{ id: 2, title: "On time" },
		],
		on: {
			onItemClick: function (id, ev, node) {
				window.webix.$$("dashboard_details_sw").clearAll();
				let searchKeyword = node.textContent.toLowerCase();
				let allArticles = window.author_dashboard_articles;
				let filteredArticles = []
				for (let article of allArticles) {
					let isTextPresent = false;
					for (let key in article) {
						let value = article[key];
						if (value) {

							if (typeof value == "string") {
								if (value.toLowerCase().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									break;
								}
							} else {
								if (value.toString().indexOf(searchKeyword) != -1) {
									isTextPresent = true;
									break;
								}
							}
						}
					}
					if (isTextPresent) {
						filteredArticles.push(article);
					}
				}
				window.webix.$$("dashboard_details_sw").parse(filteredArticles);
				// let filterText = node.textContent.toLowerCase();
				// let filterTable = window.$$("dashboard_details_sw");
				// let filterColumns = filterTable.config.columns;
				// filterTable.filter(function (obj) {
				// 	for (let i = 0; i < filterColumns.length; i++)
				// 		if (
				// 			obj[filterColumns[i].id]
				// 				.toString()
				// 				.toLowerCase()
				// 				.indexOf(filterText) !== -1
				// 		)
				// 			return true;
				// 	return false;
				// });
				document.getElementById('level3').classList.add('hide');
				document.getElementById('level0').classList.add('hide');
			}
		}

	}
}

export function Mail_input_form() {
	return {
		view: "form",
		css: "mail_input_area",
		elements: [
			{ view: "text", label: "<i class='material-icons mail_input_area_icon'>email</i>", labelWidth: 50, placeholder: "Enter id", id: "email_id", name: "email_id", attributes: { maxlength: 150 } },
			// { view: "text", id: "send_email", label: "<i class='material-icons mail_input_area_icon'>email</i>", labelWidth: 50, placeholder: "Enter id" }
		]
	}
}

export function Mail_send_Button(onSendToSubmit) {
	return {
		view: "toolbar",
		width: 420,
		elements: [
			{
				view: "button", label: "Submit", id: "save", css: "alt-btn2", type: "form", autowidth: true,
				click: function () {
					let emailValue = window.$$("email_id").getValue();
					var emailvalidate = validateEmail(emailValue);
					if (window.$$("email_id").getValue() == "") {
						window.webix.message({ text: "Please enter the email id", type: "error" });
						return false;
					}
					if (emailvalidate == false) {
						window.webix.message({ text: "Invalid email id.", type: "error" });
						return false;
					}
					onSendToSubmit(emailValue).then(res => {

					});
				}, tooltip: "Submit"
			},
		]
	}
}

export function input_form_copy() {
	return {
		view: "form",
		css: "mail_input_area_copy",
		id: 'info_form',
		elements: [
			{
				view: "text", id: "UserEmailID", name: "UserEmailID", css: "email_text", label: "<i class='fa fa-clone copy_paste' title='Copy'></i> <i class='material-icons copy_check' title='copied'>check</i> Link", labelWidth: 100, readonly: true, click: function (event, node) {
					if (node.target.className == 'fa fa-clone copy_paste') {
						navigator.clipboard.writeText(window.$$("UserEmailID").getValue());
						//or, with visual mark
						window.$$("UserEmailID").getInputNode().select();
						document.execCommand("copy");
						//window.webix.message({ type: "success", text: "Copied." });
						var TEST = document.querySelectorAll('.mail_input_area_copy .copy_paste');
						TEST[0].classList.remove('copytext');
						TEST[1].classList.remove('copytext');
						node.target.classList.add('copytext');
					}
				}
			},
			{
				view: "text", id: "iALink", name: "iALink", css: "link_text", label: "<i class='fa fa-clone copy_paste' title='Copy'></i> <i class='material-icons copy_check' title='copied'>check</i> Email", labelWidth: 100, readonly: true, click: function (event, node) {
					if (node.target.className == 'fa fa-clone copy_paste') {
						navigator.clipboard.writeText(window.$$("iALink").getValue());
						//or, with visual mark
						window.$$("iALink").getInputNode().select();
						document.execCommand("copy");
						//window.webix.message({ type: "success", text: "Copied." });
						var TEST = document.querySelectorAll('.mail_input_area_copy .copy_paste');
						TEST[0].classList.remove('copytext');
						TEST[1].classList.remove('copytext');

						node.target.classList.add('copytext');
						//	document.querySelector('.email_text .copy_paste');
					}
				}
			}
		]
	}
}

function validateEmail(emailField) {
	var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

	if (reg.test(emailField) == false) {
		return false;
	}
	return true;
}