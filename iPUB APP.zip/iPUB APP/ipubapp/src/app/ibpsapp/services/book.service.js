import { API } from '../../../helpers';
import { Urls } from '../helpers/url.helper';
import { CommonHelper } from '../../ijpsapp/helpers/common.helper';

export const BookService = {
    getWorkFlow,
    getfileType,
    getWorkFlowAty,
    get_book,
    create_book,
    getCustomer,
    add_chapter,
    chapter_upload,
    supplementary_upload,
    getDashboardBook,
    sendToSubmit,
    iAuthorUserUpdate,
    get_user_aty,
    submit_activity,
    post_user_aty,
    add_file_attachments,
    getJobDetails
};

//
function getCustomer() {
    return new Promise(function (resolve, reject) {
        API.getTokenAPI(Urls.get_customer)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function getfileType() {
    return new Promise(function (resolve, reject) {
        API.getTokenAPI(Urls.get_file_type)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function getWorkFlow(custId) {
    return new Promise(function (resolve, reject) {
        API.getTokenAPI(Urls.get_workflow_detail, { cust_id: custId })
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function getWorkFlowAty(params) {
    return new Promise(function (resolve, reject) {
        API.getTokenAPI(Urls.get_workflow_atys, params)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function get_book(custId) {
    return new Promise(function (resolve, reject) {
        API.getTokenAPI(Urls.get_book, { cust_id: custId })
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function create_book(bookdetails) {
    return new Promise(function (resolve, reject) {
        API.postTokenAPI(Urls.get_create_book, bookdetails)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function add_chapter(chapter) {
    return new Promise(function (resolve, reject) {
        API.postTokenAPI(Urls.get_chapter_details, chapter)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function chapter_upload(chapter) {
    return new Promise(function (resolve, reject) {
        API.uploadFileAPI(Urls.get_chapter_upload_files, chapter)
            .then(response => {
                let responseData = JSON.parse(response);

                if (responseData.is_success) {
                    let fileDetails = { path: responseData.data.path, title: chapter.file.name, size: CommonHelper.formatBytes(chapter.file.size, 1), doc_added: "Just now added", src: CommonHelper.getFileIcon(chapter.file.name), is_active: 1 };
                    resolve(fileDetails);
                }
                else {
                    reject(response);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function supplementary_upload(file) {
    return new Promise(function (resolve, reject) {
        API.uploadFileAPI(Urls.get_supplementary_upload_files, file)
            .then(response => {
                let responseData = JSON.parse(response);
                if (responseData.is_success) {
                    let fileDetails = { path: responseData.data.path, title: file.file.name, size: CommonHelper.formatBytes(file.file.size, 1), doc_added: "Just now added", src: CommonHelper.getFileIcon(file.file.name), is_active: 1 };
                    resolve(fileDetails);
                } else {
                    reject(responseData);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function get_user_aty(params) {
    return new Promise(function (resolve, reject) {
        API.getTokenAPI(Urls.get_user_aty, params)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                } else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
}

//
function post_user_aty(param) {
    return new Promise(function (resolve, reject) {
        API.postTokenAPI(Urls.post_user_aty, param)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });

}

//
function add_file_attachments(file) {
    return new Promise(function (resolve, reject) {
        API.postTokenAPI(Urls.get_add_file_attachments, file)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

function getDashboardBook() {
    return new Promise(function (resolve, reject) {
        API.getTokenAPI(Urls.GET_Dashboard_Book)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    res.data.forEach(element => {
                        let ilink = element.iAuthorDisplay ? '' : ' hide';
                        let Int_btn = element.Int_btn ? "<span class='author_action integra'>Send to Integra</span>" : '';
                        let CE_btn = element.CE_btn ? "<span class='author_action editor'>Send to Copyeditor</span>" : '';
                        let Auth_btn = element.Auth_btn ? "<span class='author_action author'>Send to Author</span>" : '';
                        let infoLink = element.infoDisplay ? "<ul class='action-list-table'><li class='error-area'><i class='material-icons' title='Info'>error_outline</i>Click here for more info</li></ul>" : '';
                        // let Int_btn = true ? "<span class='author_action integra'>Send to Integra</span>" : '';
                        // let CE_btn = true ? "<span class='author_action editor'>Send to Copyeditor</span>" : '';
                        // let Auth_btn = true ? "<span class='author_action author'>Send to Author</span>" : '';
                        // let infoLink = !element.infoDisplay ? "<ul class='action-list-table'><li class='error-area'><i class='material-icons' title='Error'>error_outline</i></li></ul>" : '';

                        element.action = "<a target='_blank' href='" + element.iALink + "' title='Open in iAuthor' class='bg-color " + ilink + "'>iA</a>" + infoLink + Int_btn + CE_btn + Auth_btn;

                    });
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function sendToSubmit(bookdetails) {
    return new Promise(function (resolve, reject) {
        API.postTokenAPI(Urls.SubmitActivity, bookdetails)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
}
function submit_activity(params) {
    return new Promise(function (resolve, reject) {
        API.postTokenAPI(Urls.SubmitActivity, params)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                } else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};

//
function iAuthorUserUpdate(userdata) {
    return new Promise(function (resolve, reject) {
        API.postTokenAPI(Urls.iAuthor_User_Update, userdata)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
}

//
function getJobDetails() {
    return new Promise(function (resolve, reject) {
        API.getTokenAPI(Urls.Get_Jobs)
            .then(response => {
                let res = JSON.parse(response);
                if (res.is_success) {
                    resolve(res.data);
                }
                else {
                    reject(res);
                }
            }).catch(error => {
                reject(error);
            });
    });
};