export const Urls = {
    //Get
    get_customer: "/ibps/get-customers",
    get_file_type: "/ibps/get-file-type",
    get_workflow_detail: "/ibps/get-workflow",
    get_book: "/ibps/get-books",
    get_workflow_atys: "/ibps/get-workflow-atys",
    get_create_book: "/ibps/create-book",
    get_chapter_details: "/ibps/add-chapter-details",
    get_chapter_upload_files: "/ibps/chapter-upload-files",
    get_supplementary_upload_files: "/ibps/supplementary-upload-files",
    get_add_file_attachments: "/ibps/add-file-attachments",
    GET_Dashboard_Book: "/ibps/dashboard-book",
    SubmitActivity: "/ibps/submit-activity",
    iAuthor_User_Update: "/ibps/iauthor-user-update",
    get_user_aty: "/ibps/get-user-for-aty",
    post_user_aty: "/ibps/addedit-user-for-aty",
    submite_aty: "/ibps/submit-activity",
    Get_Jobs: "/ibps/get-jobs"
};
