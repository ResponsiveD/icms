//Components
import Dashboad_IOPP from '../components/Dashboard_SW/Dashboard_SW';

export const iBP_COMPONENTS = [  
  {
    "name": "Dashboard_SW",
    "value": Dashboard_SW,
    "icon": "dashboard"
  }
];
