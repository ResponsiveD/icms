//React
import React, { Component } from 'react';
import { HashRouter as Router, Route, NavLink } from 'react-router-dom';
import * as data from './AppData';
import Webix from './Webix';
import { connect } from 'react-redux';
import { Loader } from './components/Core/iCore';
import { iP_COMPONENTS, iP_PROJECTS } from './helpers';

//iopp
import IOPP_Profile from './app/ijpsapp/components/IOPP-profile/profile-iopp';
import Review from './components/Review/Review';

import About from './components/About-us/about'
import UpdateProjectPage from './app/irightsapp/containers/Project/Update-Project-Page';
import Gantt from './app/irightsapp/components/Gantt/taskalocationLoader';
import Under_Work from './app/irightsapp/components/Under_work/Under';
import Help from './app/irightsapp/components/Under_user/Under';
// helpers
import { LocalStorage, history } from './helpers';
import { ROLES } from './app/irightsapp/helpers';
import { authenticationService } from './services';
const package_json = require('../package.json');

//Styles
import './App.css';

//scroll bar
import 'react-perfect-scrollbar/dist/css/styles.css';

//Images
import IoppLogo from './assets/images/IOPP-iPubSuite.png';

// helpers
function placeholder_loader() {
  var myVar = setTimeout(stage1, 1000);
}

/* Set the width of the side navigation to 0 */
function closeNav() {
  document.getElementById("mySidenav").classList.toggle("nav_sty");
  if (document.querySelector(".ver_name") !== null) {
    document.querySelector(".ver_name").classList.toggle("hide");
  }
  if (window.$$('dashboard_details')) {
    window.$$('dashboard_details').adjust();
  }
}

function stage1() {
  document.querySelector('.sidebar-placeholder').style.display = "none";
  document.querySelector('.iR-LT-sidebar').style.display = "block";
  document.querySelector('.header-placeholder').style.display = "none";
  document.querySelector('.iR-header-content').style.display = "block";
  setTimeout(stage2, 1000);
}
function stage2() {
  document.querySelector('.main-placeholder').style.display = "none";
  document.querySelector('.iR-body-content').style.display = "block";
}


function myFunction() {
  var w = window.innerWidth;
  if (w < 1200) {
    if (document.getElementById("mySidenav") != null) {
      document.getElementById("mySidenav").classList.add("nav_sty");
    }
  }
  else {
    if (document.getElementById("mySidenav") != null) {
      document.getElementById("mySidenav").classList.remove("nav_sty");
    }
  }
}

function myFunction2() {
  var w = window.innerWidth;

  if (w < 1200) {
    if (document.getElementById("mySidenav") != null) {
      document.getElementById("mySidenav").classList.add("nav_sty");
    }
  }
  else {
    if (!document.getElementsByClassName("nav_sty")) {
      if (document.getElementById("mySidenav") != null) {
        document.getElementById("mySidenav").classList.remove("nav_sty");
      }
    }
  }
}

class App extends Component {

  constructor(props) {
    super(props);
    this.state = {};
    this.state = { role: 0, isMenuActive: false, pageTitle: "", menuList: [], "ROLES": ROLES };
    this.isNavigate = this.isNavigate.bind(this);
    this.isLogout = this.isLogout.bind(this);
    this.updatePendingTasks = this.updatePendingTasks.bind(this);
    //this.getIsActive = this.getIsActive.bind(this);
    this.indexBasedOnRole = this.indexBasedOnRole.bind(this);
    //this.onSearch = this.onSearch.bind(this);    
  }

  LogoutToggle() {
    document.querySelector('.dropdown-menu').classList.toggle('active');
  }

  showForm(_this, formID) {
    document.getElementById(_this).style.display = 'block';
    document.getElementById('change_password').classList.remove('hide');
    window.$$('_Login').clearValidation();
    window.$$('_Login').clear();
  }
  showForm2(_this, formID) {
    document.getElementById('iopp_change_password').classList.remove('hide');
  }

  hideForm(_this, formID) {
    document.getElementById('change_password').classList.add('hide');
    document.getElementById('iopp_change_password').classList.add('hide');
  }


  componentWillReceiveProps(nextProps, prevProps) {
    this.setState({ pageTitle: nextProps.location.hash.replace("#/", "") });
  }

  componentDidMount() {
    document.getElementById('change_password').classList.add('hide');
    //document.getElementById('iopp_change_password').classList.add('hide');
    this.setState({ pageTitle: this.props.location.hash.replace("#/", "") });
    myFunction();
    myFunction2();
    placeholder_loader();
    document.addEventListener('click', function (e) {
      if (document.getElementById('outside-box').contains(e.target)) {
        // Clicked in box
      }
      else {
        document.querySelector('.Search_suggestion').style.display = 'none';
      }
      if (document.getElementById('logout_window').contains(e.target)) {

      }
      else {
        // Clicked outside the box
        document.querySelector('.dropdown-menu').classList.remove('active');
      }
    });

    window.addEventListener('beforeunload', this.updatePendingTasks);

    let user_id = LocalStorage.getLocOrSesData("uid");
    authenticationService.getUserMenu(user_id).then(result => {
      this.setState({ menuList: result });
    });

    for (let index = 0; index < this.state.ROLES.length; index++) {
      if (LocalStorage.getLocOrSesData("ud").toLowerCase() == this.state.ROLES[index].user.toLowerCase()) {
        this.setState(s => ({ role: s.ROLES[index].role }));
        break;
      }
    }
    window.onkeydown = function (event) {
      if (event.keyCode == 27) {
        document.querySelector('.dropdown-menu').classList.remove('active');
        document.querySelector('.overlay').classList.add('hide');
        // document.querySelector('.view_log').classList.add('hide');
        if (document.getElementById('QA_Reject_form')) {
          document.getElementById('QA_Reject_form').classList.add('hide');
        }
        // if (document.querySelector('.view_log')) {
        //   document.querySelector('.view_log').classList.add('hide');
        // }
        if (document.querySelector('#view_log')) {
          document.querySelector('#view_log').classList.add('hide');
        }
        if (document.getElementById('appr_alt_sh')) {
          document.getElementById('appr_alt_sh').style.display = "none";
        }
        if (document.getElementById('service_alt_sh')) {
          document.getElementById('service_alt_sh').classList.add('hide');
        }
        if (document.getElementById('task_project_popup')) {
          document.getElementById('task_project_popup').style.display = 'none';
        }
        if (document.getElementById('gantt_sh')) {
          document.getElementById('gantt_sh').style.display = 'none';
        }
        if (document.getElementById('gantt_sh2')) {
          document.getElementById('gantt_sh2').style.display = 'none';
        }
        if (document.getElementById('file_upload')) {
          document.getElementById('file_upload').classList.add('hide');
        }
        if (document.getElementById('create_job')) {
          document.getElementById('create_job').classList.add('hide');
        }
        if (document.getElementById('assest-image-popup')) {
          document.getElementById('assest-image-popup').classList.add('hide');
        }
        if (document.querySelector('.secondary-header')) {
          document.querySelector('.secondary-header').classList.remove('search-open');
        }
        if (document.querySelector('.image_overlay')) {
          document.querySelector('body').classList.remove('image_overlay');
        }
      }
    };
    let role = LocalStorage.getLocOrSesData("role");
    if (role == "Publisher" || role == "Author" || role == "Reviewer" || role == "Customer" || (typeof (role) == "object" && role.filter(item => item == 'Author').length > 0)) {
      document.getElementById('change_password_item').style.display = 'block';
    }
    else {
      document.getElementById('change_password_item').classList.add('hide');
    }

    if (role == "Author" || (typeof (role) == "object" && role.filter(item => item == 'Author').length > 0)) {
      document.getElementById('iopp-profile').style.display = 'block';
    }
    else {
      document.getElementById('iopp-profile').classList.add('hide');
    }

    if (!this.props.location.hash) {
      let info = {
        RoleName: LocalStorage.getLocOrSesData("role"),
        Type: undefined
      }
      this.indexBasedOnRole(info);
    }
    // var container = document.querySelector('.scroll_bar_hover');
    // const ps = new PerfectScrollbar(container);

  }

  indexBasedOnRole(res) {
    let roleName = (res.RoleName && (typeof (res.RoleName) == "object")) ? res.RoleName.join() : res.RoleName;
    let custId = LocalStorage.getLocOrSesData('custid');
    switch (roleName) {
      case 'DU Head':
        this.props.history.push({ pathname: '/home/#/Dashboard_PL', state: 'Dashboard_PL' });
        break;
      case 'Project Lead':
        this.props.history.push({ pathname: '/home/#/Dashboard_PL', state: 'Dashboard_PL' });
        break;
      case 'TandF Production':
        this.props.history.push({ pathname: '/home/#/Dashboard-TandF', state: 'Dashboard-TandF' });
        break;
      case 'Integra Production ':
        this.props.history.push({ pathname: '/home/#/Dashboard-TandF', state: 'Dashboard-TandF' });
        break;
      case 'Customer':
        this.props.history.push({ pathname: '/home/#/Dashboard_Customer', state: 'Dashboard_Customer' });
        break;
      case 'Publisher':
        this.props.history.push({ pathname: '/home/#/Dashboard-IOPP', state: 'Dashboard-IOPP' });
        break;
      case "Author":
        if (custId == 10) {
          this.props.history.push({ pathname: '/home/#/Dashboard-SW', state: 'Dashboard-SW' });
        } else {
          this.props.history.push({ pathname: '/home/#/Dashboard-Author', state: 'Dashboard-Author' });
        }
        break;
      case "Reviewer":
        this.props.history.push({ pathname: '/home/#/Dashboard-Reviewer', state: 'Dashboard-Reviewer' });
        break;
      case "Author,Reviewer":
        this.props.history.push({ pathname: '/home/#/Dashboard-Reviewer', state: 'Dashboard-Reviewer' });
        break;
      case "Integra Production":
        this.props.history.push({ pathname: '/home/#/Dashboard_Integra', state: 'Dashboard_Integra' });
        break;
      case "Production Editor":
        if (custId == 10) {
          this.props.history.push({ pathname: '/home/#/Dashboard-SW', state: 'Dashboard-SW' });
        } else {
          this.props.history.push({ pathname: '/home/#/Dashboard-IOPP', state: 'Dashboard-IOPP' });
        }
        break;
      case "Copy Editor":
        if (custId == 10) {
          this.props.history.push({ pathname: '/home/#/Dashboard-SW', state: 'Dashboard-SW' });
        }
        break;
      case "Admin":
        if (custId == 10 || custId == 13) {
          this.props.history.push({ pathname: '/home/#/Dashboard-SW', state: 'Dashboard-SW' });
        }
        else if (custId == 1 || custId == 2 || custId == 3 || custId == 8 || custId == 14) {
          this.props.history.push({ pathname: '/home/#/Dashboard_PL', state: 'Dashboard_PL' });
        }
        break;
      case 'Researcher':
        if (res.Type !== undefined) {
          if (res.Type.filter(function (e) { return e.SubRole === 'Photo Researcher'; }).length > 0) {
            this.props.history.push({ pathname: '/home/#/Dashboard_PR', state: 'Dashboard_PR' });
          } else if (res.Type.filter(function (e) { return e.SubRole === 'Text Researcher'; }).length > 0) {
            this.props.history.push({ pathname: '/home/#/Dashboard_TR', state: 'Dashboard_TR' });
          } else if (res.Type.filter(function (e) { return e.SubRole === 'Media Researcher'; }).length > 0) {
            this.props.history.push({ pathname: '/home/#/', state: '' });
          } else {
            this.props.history.push({ pathname: '/home/#/Dashboard_PR', state: 'Dashboard_PR' });
          }
        } else {
          this.props.history.push({ pathname: '/home/#/Dashboard_PR', state: 'Dashboard_PR' });
        }
        break;
      case 'Team Lead':
        if (res.Type !== undefined) {
          if (res.Type.filter(function (e) { return e.SubRole === 'Photo Researcher'; }).length > 0) {
            this.props.history.push({ pathname: '/home/#/Dashboard_PR_TL', state: 'Dashboard_PR_TL' });
          } else if (res.Type.filter(function (e) { return e.SubRole === 'Text Researcher'; }).length > 0) {
            this.props.history.push({ pathname: '/home/#/Dashboard_TR_TL', state: 'Dashboard_TR_TL' });
          } else if (res.Type.filter(function (e) { return e.SubRole === 'Media Researcher'; }).length > 0) {
            this.props.history.push({ pathname: '/home/#/', state: '' });
          } else {
            this.props.history.push({ pathname: '/home/#/Dashboard_PR_TL', state: 'Dashboard_PR_TL' });
          }
        } else {
          this.props.history.push({ pathname: '/home/#/Dashboard_PR_TL', state: 'Dashboard_PR_TL' });
        }
        break;
      default:
        this.props.history.push({ pathname: '/home/#/', state: '' });
    }
  }

  updatePendingTasks() {
    let user_id = LocalStorage.getLocOrSesData("uid");
    // localStorage.clear();
    // sessionStorage.clear();
    LocalStorage.clearLocOrSesData("is_started");
    LocalStorage.clearLocOrSesData("iopp_isSaveNext");
    LocalStorage.clearLocOrSesData("iopp_isuploading");
    LocalStorage.clearLocOrSesData("iopp_isModifiedData");
    LocalStorage.clearLocOrSesData("ExportImages");
    authenticationService.updatependingtasks(user_id);
    // let b = authenticationService.logout();
    //  e.returnValue='';
    //  return e;
  }

  isLogout() {
    if (LocalStorage.getData("is_started")) {
      window.webix.message({ text: "Currently you started the Task it is in progress, Please Pause or Submit to proceed", type: "debug" });
      //event.preventDefault();
      return false;
    }
    else if (LocalStorage.getData("is_task_started")) {
      window.webix.message({ text: "Currently you made some changes in the task creation, Please Submit or Cancel to proceed", type: "error" });
      return false;
    }
    else if (LocalStorage.getData("gantt_started")) {
      window.webix.message({ text: "Currently you made some changes in the task allocation, Please Submit or Cancel to proceed", type: "error" });
      return false;
    }
    else {
      Loader.showLoader();
      authenticationService.logout().then(() => {
        Loader.hideLoader();
        this.setState({ isMenuActive: true });
        history.push('/');
      }).catch(err => {
        Loader.hideLoader();
        //window.webix.message({ text: err, type: "error" })
      });

    }
  }

  SearchOpen() {
    document.querySelector('.filter_search_form').classList.add('search-open');
    //this.props.history.push({ pathname: '/home/#/Search', state: 'Search' });
    //history.push({ pathname: '/home/#/Search', state: 'Search' });
  }
  SearchClose() {
    document.querySelector('.filter_search_form').classList.remove('search-open');
  }


  isNavigate(event) {
    if (LocalStorage.getData("is_started")) {
      window.webix.message({ text: "Currently you started the Task it is in progress, Please Pause or Submit to proceed", type: "debug" })
      this.setState({ isMenuActive: false });
      event.preventDefault();
    }
    else if (LocalStorage.getData("is_task_started")) {
      window.webix.message({ text: "Currently you made some changes in the task creation, Please Submit or Cancel to proceed", type: "error" })
      this.setState({ isMenuActive: false });
      event.preventDefault();
    }
    else if (LocalStorage.getData("gantt_started")) {
      window.webix.message({ text: "Currently you made some changes in the task allocation, Please Submit or Cancel to proceed", type: "error" })
      this.setState({ isMenuActive: false });
      event.preventDefault();
    }
    else if (localStorage.getItem('iopp_isSaveNext') === "true") {
      window.webix.message({ text: "Please wait until the previous manuscript move to engine process Queue.", type: "error" });
      this.setState({ isMenuActive: false });
      event.preventDefault();
      return false;
    }
    else if (localStorage.getItem('iopp_isuploading') === "true") {
      window.webix.message({ text: "Please wait until upload to be completed", type: "error" });
      this.setState({ isMenuActive: false });
      event.preventDefault();
      return false;
    }
    else if (localStorage.getItem('iopp_isModifiedData') === "true") {
      window.webix.message({ text: "Please save current selected article.", type: "error" });
      this.setState({ isMenuActive: false });
      event.preventDefault();
      return false;
    }
    else {
      this.setState({ isMenuActive: true });
    }
  }

  // submenu 
  isSubMenu(e) {
    if (e.currentTarget.closest('li').classList.contains('menu_active')) {
      e.currentTarget.closest('li').classList.remove('menu_active')
    } else {

      var ToggleElement = document.querySelectorAll(".sub_menu");
      if (ToggleElement !== null) {
        for (var i = 0; i < ToggleElement.length; i++) {
          ToggleElement[i].classList.remove('menu_active');
        }
        e.currentTarget.closest('li').classList.add('menu_active');

      }

    }
  }

  render() {

    let ipMenuItems = this.state.menuList.length > 0 ? this.state.menuList.filter(m => m.comp_id == iP_PROJECTS.iPUBS) : null;
    let irMenuItems = this.state.menuList.length > 0 ? this.state.menuList.filter(m => m.comp_id == iP_PROJECTS.iRights) : null;
    let ijMenuItems = this.state.menuList.length > 0 ? this.state.menuList.filter(m => m.comp_id == iP_PROJECTS.iJPS) : null;
    let ibMenuItems = this.state.menuList.length > 0 ? this.state.menuList.filter(m => m.comp_id == iP_PROJECTS.iBPS) : null;
    let parentipMenuItems = null;
    if (ipMenuItems) {
      ipMenuItems = ipMenuItems.sort((a, b) => a.menuorder - b.menuorder);
      parentipMenuItems = ipMenuItems.filter(item => item.parent_id == 0);
      parentipMenuItems = parentipMenuItems.sort((a, b) => a.menuorder - b.menuorder);
    }

    let parentirMenuItems = null;
    if (irMenuItems) {
      irMenuItems = irMenuItems.sort((a, b) => a.menuorder - b.menuorder);
      parentirMenuItems = irMenuItems.filter(item => item.parent_id == 0);
      parentirMenuItems = parentirMenuItems.sort((a, b) => a.menuorder - b.menuorder);
    }

    let isIJPS = (ijMenuItems && ijMenuItems.length > 0);
    let iopp = LocalStorage.getLocOrSesData("custid") == 5 ? "iopp" : "";
    let roleDisplay = '';
    let role = LocalStorage.getLocOrSesData("role");
    if (role && typeof (role) == "object") {
      role.forEach(element => {
        if (roleDisplay == undefined || roleDisplay == "")
          roleDisplay = element;
        else
          roleDisplay = roleDisplay + ', ' + element;
      })
    } else {
      roleDisplay = role;
    }
    return (
      // <BrowserRouter>
      <Router>
        <div id="mySidenav" >
          <div className="app">
            {/* Loader Start  */}
            <div className="root_loader">

              <div className="header-placeholder">
                <div className="placeholder place-icon"></div>
                <div className="placeholder place-logo"></div>
                <div className="placeholder place-sub-level"></div>
                <div className="placeholder place-profile one"></div>
                <div className="placeholder place-profile two"></div>
                <div className="placeholder place-profile three"></div>
              </div>
              <div className="sidebar-placeholder">
                <div className="placeholder place-title-logo"></div>
                <div className="placeholder place-title-bar"></div>
                <div className="placeholder"></div>
                <div className="placeholder"></div>
                <div className="placeholder"></div> <br></br>
                <div className="placeholder place-title-bar"></div>
                <div className="placeholder"></div>
                <div className="placeholder"></div>
                <div className="placeholder"></div><br></br>
              </div>

              <div className="main-placeholder">
                <div className="placeholder"></div>
                {/* <!-- Cols 1 Start --> */}
                <div className="place-col-6">
                  <div className="place-group-card">
                    <div className="placeholder pl-title"></div>
                    <div className="placeholder pl-body pl-card-1"></div>
                  </div>
                  <div className="place-group-card">
                    <div className="placeholder pl-title"></div>
                    <div className="placeholder pl-body pl-card-2"></div>
                  </div>
                  <div className="clearfix"></div>
                </div>
                {/* <!-- Cols 1 End --> */}
                {/* <!-- Cols 2 Start --> */}
                <div className="place-col-6">
                  <div className="place-group-card">
                    <div className="placeholder pl-title"></div>
                    <div className="placeholder pl-body pl-card-3"></div>
                  </div>
                  <div className="place-group-card">
                    <div className="placeholder pl-title"></div>
                    <div className="placeholder pl-body pl-card-4"></div>
                  </div>
                  <div className="place-group-card">
                    <div className="placeholder pl-title"></div>
                    <div className="placeholder pl-body pl-card-5"></div>
                  </div>
                  <div className="clearfix"></div>
                </div>
                {/* <!-- Cols 2 End --> */}
                <div className="clearfix"></div>
                {/* row 1 start  */}
                <div className="place-col-12">
                  <div className="place-group-card">
                    <div className="placeholder pl-title"></div>
                    <div className="placeholder pl-body"></div>
                  </div>
                </div>
                {/* row 1 end  */}
              </div>

            </div>
            {/* Loader End  */}

            <div className="root-content">

              {/* Header Section Start */}
              <div className="iR-header-content">
                <div className="iR-row">
                  <div className="iR-menu-toggle"><span className="closebtn" title="Menu Open" onClick={closeNav}><i className="material-icons">menu</i></span></div>
                  <div className="iR-col-4">
                    <ul className="iR-breadcum">
                      <li>{
                        this.state.menuList.length > 0 ? this.state.menuList.map((menu, i) => {
                          let title = "/" + this.state.pageTitle
                          if (title == menu.path)
                            return menu.displayname
                        }) : ""
                      }</li>
                    </ul>
                  </div>

                  <div className="iR-col-8">
                    <div className="iR-RT-header">
                      {/* <div className="filter_search_form">
                        <input id="search" type="text" placeholder="Search..." className="filter_input_box" onKeyUp={(event) => this.onSearchChange(event)} autoFocus />
                        <button className="srch-btn " onClick={(event) => { this.SearchOpen() }}><i className="material-icons filter_search_btn">search</i></button>
                        <button className="clear-btn" onClick={(event) => { this.SearchClose() }}><i className="material-icons filter_close_btn">close</i></button>
                      </div> */}
                      <ul className="rt-header-top">
                        <li id="outside-box">
                          <div className="g_search_area hide">
                            <Webix ui={data.Global_Search()} ></Webix>
                            <i className="material-icons g-srch-icon" onClick={this.showForm.bind(this, "Search_suggestion")}>search</i>
                            <div className="Search_suggestion" id="Search_suggestion">
                              <Webix ui={data.Global_Search_List()} ></Webix>
                            </div>
                            <div className="clearfix"></div>
                          </div>
                        </li>
                        <li id="logout_window" onClick={this.LogoutToggle.bind()}>
                          {/* <img title="User Profile" src={avator} className="iR-image-circle img-shadow" /> */}
                          <div className="iR-image-circle img-shadow sprite-images" title="User Profile"></div>
                          <div className="profile_name_area">
                            <div className="user_title" title={LocalStorage.getLocOrSesData("username")} >{LocalStorage.getLocOrSesData("username")}</div>
                            <span className="sub_profile" title={roleDisplay}>{roleDisplay}</span><i className="material-icons md-20 i-arrow-down" id="log_tog" title="Logout option">keyboard_arrow_down</i> </div>

                          <div className="dropdown-menu">

                            {/* iopp author my-profile*/}
                            <a href="#/IOPP-Profile"><div id="iopp-profile" className="profile_btn"><i className="material-icons">mood</i> My Profile</div></a>

                            {/* iopp change password */}
                            <div id="change_password_item" className="change_button" onClick={this.showForm.bind(this, "change_password")}> <i className="material-icons key-icon">vpn_key</i> Change Password</div>

                            <div className="logout_button" onClick={this.isLogout}> <i className="fa fa-sign-out" aria-hidden="true"></i> Logout</div>
                          </div>
                        </li>
                      </ul>

                    </div>
                  </div>

                </div>
              </div>
              {/* Header Section End */}
              {/* commom loader start */}
              <div id="loader" className="loading" tabIndex='-1'>
                <div className="loader">
                  <div className="bubble-loader">
                    <span className="bubble bubble-one"></span>
                    <span className="bubble bubble-two"></span>
                    <span className="bubble bubble-three"></span>
                  </div>
                </div>
              </div>
              {/* commom loader end*/}

              {/* change password form  start */}
              <div id="change_password" className="overlay">
                <div className="iR-dialog">
                  <div className="expand iopp-popup-header iR-window-header">
                    <h2>Change password </h2>
                    <i className="material-icons view_cls" onClick={this.hideForm.bind(this, "change_password")} title="Close">clear</i>
                  </div>
                  <div className="widget">
                    <div className="iR-window-body">
                      <Webix ui={data._change_password()}  ></Webix>
                    </div>
                    <div className="iR-window-footer change_btn common_btn" >
                      <Webix ui={data._change_btn()}  ></Webix>
                    </div>
                    <div className="clearfix"></div>
                  </div>
                </div>
              </div>

              {/* iopp change password form  End */}
              <div className="iR-main-content">

                {/* Main Content Start */}
                <div className="iR-body-content">
                {
                    ipMenuItems ? ipMenuItems.map((menu, i) => {
                      let compo = iP_COMPONENTS.find(c => c.name == menu.component);
                      compo = compo ? compo.value : "";
                      if (compo)
                        return <Route key={menu.menu_id} path={menu.path} component={compo} />
                    }) : ""
                  }
                  {
                    irMenuItems ? irMenuItems.map((menu, i) => {
                      let compo = iP_COMPONENTS.find(c => c.name == menu.component);
                      compo = compo ? compo.value : "";
                      if (compo)
                        return <Route key={menu.menu_id} path={menu.path} component={compo} />
                    }) : ""
                  }
                  {
                    irMenuItems ? irMenuItems.map((menu, i) => {
                      let compo = iP_COMPONENTS.find(c => c.name == menu.component && menu.component == "CreateProjectPage");
                      compo = compo ? compo.value : "";
                      if (compo)
                        return <Route key="100" path="/UpdateProject" component={UpdateProjectPage} />
                    }) : ""
                  }
                  {
                    irMenuItems ? irMenuItems.map((menu, i) => {
                      let compo = iP_COMPONENTS.find(c => c.name == menu.component && menu.component == "ProjectList");
                      compo = compo ? compo.value : "";
                      if (compo)
                        return <Route key="101" path="/Gantt" component={Gantt} />
                    }) : ""
                  }

                  {
                    ijMenuItems ? ijMenuItems.map((menu, i) => {
                      let compo = iP_COMPONENTS.find(c => c.name == menu.component);

                      compo = compo ? compo.value : "";
                      if (compo)
                        return <Route key={menu.menu_id} path={menu.path} component={compo} />
                    }) : ""
                  }
                  {
                    ijMenuItems ? ijMenuItems.map((menu, i) => {
                      let compo = iP_COMPONENTS.find(c => c.name == menu.component && menu.component == "SubmitManuscript");
                      compo = compo ? compo.value : "";
                      if (compo)
                        return <span>
                          <Route key="104" path="/IOPP-Profile" component={IOPP_Profile} />
                        </span>
                    }) : ""
                  }
                  {
                    ibMenuItems ? ibMenuItems.map((menu, i) => {
                      let compo = iP_COMPONENTS.find(c => c.name == menu.component);

                      compo = compo ? compo.value : "";
                      if (compo)
                        return <Route key={menu.menu_id} path={menu.path} component={compo} />
                    }) : ""
                  }
                  {/* <Route key="107" path="/Proceeding-List" component={Proceeding_List} /> */}
                  <Route key="105" path="/Review" component={Review} />
                  <Route key="106" path="/About" component={About} />
                  <Route key="122" path="/Under_work" component={Under_Work} />
                  <Route key="123" path="/Help" component={Help} />
                </div>
                {/* Main Content End  */}
              </div>
              <div className="mob_overlay" id="mobile" onClick={closeNav}></div>
              {/* Left Sidebar Start  */}
              <div className="iR-LT-sidebar">

                <div className={"iR-sidebar-header " + iopp}>
                  <div className="logo">

                    {
                      // (ijMenuItems && ijMenuItems.length > 0) ?
                      (LocalStorage.getLocOrSesData("custname") == "IOPP") ?
                        // <a href="#/">  <img src={IoppLogo} className="logo-iopp" alt="Logo" title="Logo" /> </a> : <a href="#/"> iPubSuite  </a>
                        <img src={IoppLogo} className="logo-iopp" alt="Logo" title="Logo" /> : <span>iPubSuite</span>
                    }


                    {/* <div className="logo_text"> iPubSuite <span className="ver_name" >V1.0</span></div> */}
                    <div className="iR-menu-toggle">{/*<i className="material-icons">menu</i>*/}   <span className="closebtn" title="Menu Close" onClick={closeNav}><i className="material-icons">menu</i></span>
                    </div>
                  </div>
                  <div className="logo_hidden">
                    <a href="#"> iP </a>
                    {/* <a href="#"> iR </a> */}
                    <div className="iR-menu-toggle">{/*<i className="material-icons">menu</i>*/}   <span className="closebtn" title="Menu Open" onClick={closeNav}><i className="material-icons">menu</i></span>
                    </div>
                  </div>
                  <div className="iR-Profile-Header">

                    <h3 title={LocalStorage.getLocOrSesData("username")}>{LocalStorage.getLocOrSesData("username")}</h3>

                    {
                      // (ijMenuItems && ijMenuItems.length > 0) ?
                      (LocalStorage.getLocOrSesData("custname") == "IOPP") ?
                        <p><a href="#">{roleDisplay}</a></p> :
                        <p><a href={LocalStorage.getLocOrSesData("emailid")}>{LocalStorage.getLocOrSesData("emailid")}</a></p>
                    }


                  </div>
                  <div className="iR-Profile-Image">
                    <div className="sprite-images user-pro"></div>
                    {/* <img src={avator} alt="User Photo" /> */}
                  </div>
                </div>

                <div className="iR-sidebar-body" id="container">
                  <div className="iR-sidebar-body-inner">
                    <div className="iR-sidebar-body-inner-sec">
                    {
                        (ipMenuItems && ipMenuItems.length > 0) ?
                          <div className="iR-Cat-Menu-1 Menu">
                            <h1 className="iR-menu-title">iPUBS</h1>

                            <ul>
                              {
                                parentipMenuItems.map((menu, i) => {
                                  if (menu.grouptext == '') {
                                    let icon = iP_COMPONENTS.find(c => menu.comp_id == iP_PROJECTS.iPUBS && c.name == menu.component);
                                    icon = icon ? icon.icon : "";
                                    if (icon != "") {
                                      return (<li key={menu.menu_id} className="tooltip"><NavLink to={menu.path} onClick={this.isNavigate.bind(this)}><span className="menu_icon"><i className="material-icons" aria-hidden="true">{icon}</i></span><div className="menu_item_list">{menu.menu_name}</div></NavLink> <div className="tooltiptext-outer"><span className="tooltiptext">{menu.menu_name}</span></div></li>)
                                    }
                                  }
                                  else {
                                    let icon = iP_COMPONENTS.find(c => menu.comp_id == iP_PROJECTS.iPUBS && c.group == menu.grouptext);
                                    icon = icon ? icon.icon : "";
                                    return (<li className="tooltip sub_menu"><div className="sub_menu_main" onClick={this.isSubMenu.bind(this)}><span className="menu_icon"><i className="material-icons" aria-hidden="true">{icon}</i></span><div className="menu_item_list">{menu.grouptext}</div><i className="material-icons expand_ic">expand_more</i> <i className="material-icons expand_ics">expand_less</i></div>
                                      <ul className="sub_menu_area">
                                        {
                                          ipMenuItems.map((smenu, i) => {
                                            if (menu.menu_id == smenu.parent_id)
                                              return (<li key={smenu.menu_id} className="tooltip sub_menu_area_inner"><NavLink to={smenu.path} onClick={this.isNavigate.bind(this)}><span className="menu_icon sub_menu_icon"><i className="material-icons" aria-hidden="true">{icon}</i></span><div className="menu_item_list">{smenu.menu_name}</div></NavLink> <div className="tooltiptext-outer"><span className="tooltiptext">{smenu.menu_name}</span></div></li>)
                                          })
                                        }
                                      </ul>
                                    </li>)
                                  }
                                })
                              }
                            </ul>
                          </div> : null
                      }
                      {
                        (irMenuItems && irMenuItems.length > 0) ?
                          <div className="iR-Cat-Menu-1 Menu">
                            <h1 className="iR-menu-title">iRIGHTS</h1>

                            <ul>
                              {
                                parentirMenuItems.map((menu, i) => {
                                  if (menu.grouptext == '') {
                                    let icon = iP_COMPONENTS.find(c => menu.comp_id == 1 && c.name == menu.component);
                                    icon = icon ? icon.icon : "";
                                    if (icon != "") {
                                      return (<li key={menu.menu_id} className="tooltip"><NavLink to={menu.path} onClick={this.isNavigate.bind(this)}><span className="menu_icon"><i className="material-icons" aria-hidden="true">{icon}</i></span><div className="menu_item_list">{menu.menu_name}</div></NavLink> <div className="tooltiptext-outer"><span className="tooltiptext">{menu.menu_name}</span></div></li>)
                                    }
                                  }
                                  else {
                                    let icon = iP_COMPONENTS.find(c => menu.comp_id == 1 && c.group == menu.grouptext);
                                    icon = icon ? icon.icon : "";
                                    return (<li key={menu.menu_id} className="tooltip sub_menu"><div className="sub_menu_main" onClick={this.isSubMenu.bind(this)}><span className="menu_icon"><i className="material-icons" aria-hidden="true">{icon}</i></span><div className="menu_item_list">{menu.grouptext}</div><i className="material-icons expand_ic">expand_more</i> <i className="material-icons expand_ics">expand_less</i></div>
                                      <ul className="sub_menu_area">
                                        {
                                          irMenuItems.map((smenu, i) => {
                                            if (menu.menu_id == smenu.parent_id)
                                              return (<li key={smenu.menu_id} className="tooltip sub_menu_area_inner"><NavLink to={smenu.path} onClick={this.isNavigate.bind(this)}><span className="menu_icon sub_menu_icon"><i className="material-icons" aria-hidden="true">{icon}</i></span><div className="menu_item_list">{smenu.menu_name}</div></NavLink> <div className="tooltiptext-outer"><span className="tooltiptext">{smenu.menu_name}</span></div></li>)
                                          })
                                        }
                                      </ul>
                                    </li>)
                                  }
                                })
                              }
                            </ul>
                          </div> : null
                      }
                      {
                        (ijMenuItems && ijMenuItems.length > 0) ?
                          <div className="iR-Cat-Menu-1 Menu">
                            <h1 className="iR-menu-title">iJPS</h1>
                            <ul>
                              {
                                ijMenuItems.map((menu, i) => {
                                  let icon = iP_COMPONENTS.find(c => menu.comp_id == 2 && c.name == menu.component);
                                  icon = icon ? icon.icon : "";
                                  if (icon != "")
                                    return (<li key={menu.menu_id} className="tooltip"><NavLink to={menu.path} onClick={this.isNavigate.bind(this)}><span className="menu_icon"><i className="material-icons" aria-hidden="true">{icon}</i></span><div className="menu_item_list">{menu.menu_name}</div></NavLink> <div className="tooltiptext-outer"><span className="tooltiptext">{menu.menu_name}</span></div></li>)
                                })
                              }
                            </ul>
                          </div> : null
                      }
                    </div>
                  </div>
                  {
                    (ibMenuItems && ibMenuItems.length > 0) ?
                      <div className="iR-Cat-Menu-1 Menu">
                        <h1 className="iR-menu-title">iBPS</h1>
                        <ul>
                          {
                            ibMenuItems.map((menu, i) => {
                              let icon = iP_COMPONENTS.find(c => menu.comp_id == 3 && c.name == menu.component);
                              icon = icon ? icon.icon : "";
                              if (icon != "")
                                return (<li key={menu.menu_id} className="tooltip"><NavLink to={menu.path} onClick={this.isNavigate.bind(this)}><span className="menu_icon"><i className="material-icons" aria-hidden="true">{icon}</i></span><div className="menu_item_list">{menu.menu_name}</div></NavLink> <div className="tooltiptext-outer"><span className="tooltiptext">{menu.menu_name}</span></div></li>)
                            })
                          }
                        </ul>
                      </div> : null
                  }
                  {
                    (irMenuItems && irMenuItems.length > 0) || (ipMenuItems && ipMenuItems.length > 0)  ?
                      <div className="iR-Cat-Menu-2 Menu">
                        <h1 className="iR-menu-title">OTHERS</h1>
                        <ul>
                          <li className="tooltip">
                            <a href="#/About"><span className="menu_icon"><i className="material-icons">error_outline</i></span><div className="menu_item_list">About</div></a>
                            <div className="tooltiptext-outer"><span className="tooltiptext">About</span></div>
                          </li>
                          <li className="tooltip">
                            <a href="#/Help"><span className="menu_icon"><i className="material-icons">help</i></span><div className="menu_item_list">Help</div></a>
                            <div className="tooltiptext-outer"><span className="tooltiptext">Help</span></div>
                          </li>
                        </ul>
                      </div> : null
                  }
                </div>
                {/* Left Sidebar End  */}

                {
                  (irMenuItems && irMenuItems.length > 0) ?
                    <div className="sidebar_footer">
                      <div className="ver_name">{package_json.version}</div>
                      <div className="ver_name">Copyright © Integra Software Services Pvt. Ltd.</div>
                    </div> : null
                }
              </div>
            </div>
          </div>
        </div>
      </Router>
      // </BrowserRouter>
    )
  }
}

function mapStateToProps(state) {
  const { loggingIn, user } = state.authentication;
  return {
    loggingIn, user
  };
}

// function mapDispatchToProps(dispatch) {
//   return {
//     logout: () => dispatch(authenticationActions.logout())
//   };
// }


const connectedApp = connect(mapStateToProps)(App);
export default connectedApp;
//08