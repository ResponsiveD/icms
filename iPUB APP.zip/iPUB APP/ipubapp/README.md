# iPubapp
iPubsuite application created

Webix and dhtmlx Licensed version node modules should be updated with UI Team.
Check api configuration in Config.JS file.

